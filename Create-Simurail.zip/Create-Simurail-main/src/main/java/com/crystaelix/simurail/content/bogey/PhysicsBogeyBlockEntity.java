package com.crystaelix.simurail.content.bogey;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

import org.joml.Quaterniond;
import org.joml.Quaterniondc;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;

import com.crystaelix.simurail.api.bogey.BogeyLinkable;
import com.crystaelix.simurail.api.math.Basis3d;
import com.crystaelix.simurail.api.math.Basis3dc;
import com.crystaelix.simurail.api.math.MovingQuaternionfLerp;
import com.crystaelix.simurail.api.math.MovingVector3fLerp;
import com.crystaelix.simurail.api.math.SimurailMath;
import com.crystaelix.simurail.api.physics.AuxiliaryPhysicsBody;
import com.crystaelix.simurail.api.physics.BoxAuxiliaryPhysicsBody;
import com.crystaelix.simurail.api.physics.SimurailJoints;
import com.crystaelix.simurail.api.physics.SubLevelAuxiliaryPhysicsBody;
import com.crystaelix.simurail.api.util.PhysicsStaffUtil;
import com.crystaelix.simurail.api.util.SchematicContextUtil;
import com.crystaelix.simurail.compat.SimurailCompat;
import com.crystaelix.simurail.compat.computercraft.SimurailComputerCraftProxy;
import com.crystaelix.simurail.config.SimurailConfig;
import com.crystaelix.simurail.config.SimurailPhysicsConfig;
import com.crystaelix.simurail.content.SimurailBlockEntities;
import com.crystaelix.simurail.content.SimurailBlocks;
import com.crystaelix.simurail.content.automatic_coupler.AutomaticCouplerBlockEntity;
import com.crystaelix.simurail.content.connector.ConnectorConnectable;
import com.google.common.collect.ImmutableList;
import com.google.common.primitives.Floats;
import com.simibubi.create.compat.computercraft.AbstractComputerBehaviour;
import com.simibubi.create.content.equipment.clipboard.ClipboardCloneable;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import dan200.computercraft.api.peripheral.PeripheralCapability;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.block.BlockEntitySubLevelActor;
import dev.ryanhcode.sable.api.physics.constraint.ConstraintJointAxis;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintConfiguration;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintHandle;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.api.physics.mass.MassData;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.companion.math.JOMLConversion;
import dev.ryanhcode.sable.companion.math.Pose3d;
import dev.ryanhcode.sable.companion.math.Pose3dc;
import dev.ryanhcode.sable.sublevel.ClientSubLevel;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import dev.ryanhcode.sable.util.SableNBTUtils;
import foundry.veil.api.network.VeilPacketManager;
import it.unimi.dsi.fastutil.longs.LongIntPair;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.createmod.catnip.data.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.Nameable;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

public class PhysicsBogeyBlockEntity extends KineticBlockEntity implements Nameable, MenuProvider, BlockEntitySubLevelActor, ConnectorConnectable, ClipboardCloneable {

	public static final double LINEAR_Y_LIMIT = 0.5;
	public static final double LINEAR_Z_LIMIT = 1;
	public static final double ANGULAR_X_LIMIT = Math.PI / 12;
	public static final double ANGULAR_Y_LIMIT = Math.PI / 4;
	public static final double ANGULAR_Z_LIMIT = Math.PI / 4;
	public static final double TILT_LIMIT = Math.PI / 18;

	public static final Component NAME = Component.translatable("block.simurail.physics_bogey");
	public static final Component INVERTED_NAME = Component.translatable("item.simurail.inverted_physics_bogey");
	public static final Component UNPOWERED_NAME = Component.translatable("block.simurail.unpowered_physics_bogey");
	public static final Component INVERTED_UNPOWERED_NAME = Component.translatable("item.simurail.unpowered_inverted_physics_bogey");

	protected boolean initialized = false;

	protected Component customName = null;

	// Bogey type components
	protected final PhysicsBogeyOptions options;
	protected CompoundTag bogeyData;
	protected AbstractComputerBehaviour computerBehaviour;
	protected final PhysicsBogeyControlOverrides computerOverrides = new PhysicsBogeyControlOverrides();

	// Connection components
	protected BlockPos connectionFront;
	protected UUID connectionFrontSubLevelID;
	protected boolean connectionFrontToFront;
	protected BlockPos connectionBack;
	protected UUID connectionBackSubLevelID;
	protected boolean connectionBackToFront;
	protected PhysicsBogeyGroup group;

	// Physics components
	protected final Vector3dc localCenter;
	protected AuxiliaryPhysicsBody pivot;
	protected CompoundTag pivotTag;
	protected final Pose3d pivotPose = new Pose3d();
	protected Vector3d localPivotOffset;
	protected final Vector3d lastLocalPivotOffset = new Vector3d();
	protected Quaterniond localPivotRot;
	protected final Quaterniond lastLocalPivotRot = new Quaterniond();
	protected GenericConstraintHandle pivotJoint;
	protected GenericConstraintHandle motorJoint;
	protected final PhysicsBogeyAxle axleFront;
	protected final PhysicsBogeyAxle axleBack;
	public double visualSpeed = 0;
	protected double lastVisualSpeed = 0;
	public double slipSpeed = 0;
	protected double lastSlipSpeed = 0;
	protected boolean staffRestrained = false;
	protected final LerpedFloat lerpedCurvature = LerpedFloat.linear();
	protected final Vector3d lastScale = new Vector3d(1);

	// Navigator components
	protected float navigatorBrakeOverride = 0;

	// Link cache
	protected Set<BlockPos> links = new HashSet<>();

	// Controller cache
	protected Map<BlockPos, LongIntPair> remoteBrakeOverrides = new HashMap<>();
	protected Map<BlockPos, LongIntPair> remoteLeftSteerOverrides = new HashMap<>();
	protected Map<BlockPos, LongIntPair> remoteRightSteerOverrides = new HashMap<>();
	protected Map<BlockPos, LongIntPair> remoteStrengthOverrides = new HashMap<>();

	// Client rendering components
	protected final MovingQuaternionfLerp renderPivotRot = MovingQuaternionfLerp.of(2);
	protected final MovingVector3fLerp renderPivotOffset = MovingVector3fLerp.of(2);
	public float renderAxleOffset;
	protected double distanceMoved;
	protected float movementSpeed;
	protected float lastMovementSpeed;
	protected PhysicsBogeySounds sounds;
	protected PhysicsBogeyEffects effects;

	public static final Set<PhysicsBogeyBlockEntity> LOADED_BOGEYS = Collections.newSetFromMap(new WeakHashMap<>());

	public PhysicsBogeyBlockEntity(BlockEntityType<?> typeIn, BlockPos pos, BlockState state) {
		super(typeIn, pos, state);
		options = new PhysicsBogeyOptions(isUnpowered(), isInverted());
		localCenter = JOMLConversion.atCenterOf(pos);
		axleFront = new PhysicsBogeyAxle(this, true);
		axleBack = new PhysicsBogeyAxle(this, false);
	}

	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		SimurailCompat.COMPUTERCRAFT.ifLoaded(() -> () -> {
			event.registerBlockEntity(
					PeripheralCapability.get(),
					SimurailBlockEntities.PHYSICS_BOGEY.get(),
					(be, context) -> be.computerBehaviour.getPeripheralCapability());
		});
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(computerBehaviour = SimurailComputerCraftProxy.behaviour(this));
	}

	@Override
	public Component getName() {
		return customName != null ? customName : isUnpowered() ?
				isInverted() ? INVERTED_UNPOWERED_NAME : UNPOWERED_NAME :
					isInverted() ? INVERTED_NAME : NAME;
	}

	@Override
	public Component getDisplayName() {
		return getName();
	}

	@Override
	public Component getCustomName() {
		return customName;
	}

	public void setCustomName(Component customName) {
		this.customName = customName;
	}

	public PhysicsBogeyOptions getOptions() {
		return options;
	}

	public void setOptions(PhysicsBogeyOptions options) {
		if(computerBehaviour.hasAttachedComputer()) {
			this.options.setNonComputer(options);
		}
		else {
			this.options.set(options);
		}
		axleFront.resetOffset();
		axleBack.resetOffset();
		bogeyData = null;
		if(!level.isClientSide()) {
			setChanged();
			sendData();
		}
	}

	public PhysicsBogeyControlOverrides getComputerOverrides() {
		return computerOverrides;
	}

	@Override
	public Direction getFacing() {
		return getBlockState().getValue(BlockStateProperties.HORIZONTAL_FACING);
	}

	@Override
	public AABB getOutline(Direction direction) {
		return AABB.ofSize(
				getBlockPos().getCenter().add(direction.getStepX() * 0.28125, 0, direction.getStepZ() * 0.28125),
				direction.getStepX() == 0 ? 1 : 0.4375, 1, direction.getStepZ() == 0 ? 1 : 0.4375);
	}

	@Override
	public boolean canConnectTo(Direction selfDir, ConnectorConnectable other, Direction otherDir) {
		if(other instanceof PhysicsBogeyBlockEntity) {
			SubLevel selfSubLevel = Sable.HELPER.getContaining(this);
			SubLevel otherSubLevel = Sable.HELPER.getContaining(level, other.getBlockPos());
			Pose3dc selfPose = selfSubLevel == null ? SimurailMath.POSE_I : selfSubLevel.logicalPose();
			Pose3dc otherPose = otherSubLevel == null ? SimurailMath.POSE_I : otherSubLevel.logicalPose();
			Vector3d selfNormal = selfPose.transformNormal(new Vector3d(selfDir.step()));
			Vector3d otherNormal = otherPose.transformNormal(new Vector3d(otherDir.step()));
			Vector3d selfPos = selfPose.transformPosition(JOMLConversion.atCenterOf(getBlockPos()));
			Vector3d otherPos = otherPose.transformPosition(JOMLConversion.atCenterOf(other.getBlockPos()));
			double x = otherPos.x - selfPos.x;
			double y = otherPos.y - selfPos.y;
			double z = otherPos.z - selfPos.z;
			return selfNormal.dot(x, y, z) > 0 && otherNormal.dot(x, y, z) < 0;
		}
		if(other instanceof AutomaticCouplerBlockEntity) {
			return other.canConnectTo(otherDir, this, selfDir);
		}
		return false;
	}

	@Override
	public double connectionRange(ConnectorConnectable other) {
		if(other instanceof PhysicsBogeyBlockEntity otherBogey) {
			if(Sable.HELPER.getContaining(this) == Sable.HELPER.getContaining(otherBogey)) {
				return SimurailConfig.server().blocks.connectionBogeyRangeSame.get();
			}
			else {
				return SimurailConfig.server().blocks.connectionBogeyRangeDifferent.get();
			}
		}
		if(other instanceof AutomaticCouplerBlockEntity) {
			return other.connectionRange(this);
		}
		return 0;
	}

	@Override
	public void connect(boolean front, ConnectorConnectable other, boolean otherFront) {
		if(other instanceof PhysicsBogeyBlockEntity otherBogey) {
			SubLevel otherSubLevel = Sable.HELPER.getContaining(otherBogey);
			if(front) {
				if(connectionFront != null) {
					disconnect(true);
				}
				connectionFront = otherBogey.getBlockPos();
				connectionFrontSubLevelID = otherSubLevel == null ? null : otherSubLevel.getUniqueId();
				connectionFrontToFront = otherFront;
			}
			else {
				if(connectionBack != null) {
					disconnect(false);
				}
				connectionBack = otherBogey.getBlockPos();
				connectionBackSubLevelID = otherSubLevel == null ? null : otherSubLevel.getUniqueId();
				connectionBackToFront = otherFront;
			}
			if(group != null) {
				group.invalidate();
			}
			if(!level.isClientSide()) {
				setChanged();
				sendData();
			}
			otherBogey.propagateConnect(otherFront, this, front);
		}
		if(other instanceof AutomaticCouplerBlockEntity) {
			other.connect(otherFront, this, front);
		}
	}

	protected void propagateConnect(boolean front, PhysicsBogeyBlockEntity otherBogey, boolean otherFront) {
		SubLevel otherSubLevel = Sable.HELPER.getContaining(otherBogey);
		if(front) {
			connectionFront = otherBogey.getBlockPos();
			connectionFrontSubLevelID = otherSubLevel == null ? null : otherSubLevel.getUniqueId();
			connectionFrontToFront = otherFront;
		}
		else {
			connectionBack = otherBogey.getBlockPos();
			connectionBackSubLevelID = otherSubLevel == null ? null : otherSubLevel.getUniqueId();
			connectionBackToFront = otherFront;
		}
		if(group != null) {
			group.invalidate();
		}
		if(!level.isClientSide()) {
			setChanged();
			sendData();
		}
	}

	@Override
	public void disconnect(boolean front) {
		if(front) {
			if(connectionFront != null && level.getBlockEntity(connectionFront) instanceof PhysicsBogeyBlockEntity otherBogey) {
				otherBogey.propagateDisconnect(connectionFrontToFront);
			}
			connectionFront = null;
			connectionFrontSubLevelID = null;
		}
		else {
			if(connectionBack != null && level.getBlockEntity(connectionBack) instanceof PhysicsBogeyBlockEntity otherBogey) {
				otherBogey.propagateDisconnect(connectionBackToFront);
			}
			connectionBack = null;
			connectionBackSubLevelID = null;
		}
		if(group != null) {
			group.invalidate();
		}
		if(!level.isClientSide()) {
			setChanged();
			sendData();
		}
	}

	protected void propagateDisconnect(boolean front) {
		if(front) {
			connectionFront = null;
			connectionFrontSubLevelID = null;
		}
		else {
			connectionBack = null;
			connectionBackSubLevelID = null;
		}
		if(group != null) {
			group.invalidate();
		}
		if(!level.isClientSide()) {
			setChanged();
			sendData();
		}
	}

	public void beforeMove(BlockPos newPos) {
		for(BlockPos linkablePos : links) {
			if(level.getBlockEntity(linkablePos) instanceof BogeyLinkable linkable) {
				linkable.setTargetPos(newPos);
			}
		}
	}

	public void afterMove() {
		if(pivot != null) {
			pivot.afterParentMove();
		}
		if(connectionFront != null && level.getBlockEntity(connectionFront) instanceof PhysicsBogeyBlockEntity otherBogey) {
			connect(true, otherBogey, connectionFrontToFront);
		}
		if(connectionBack != null && level.getBlockEntity(connectionBack) instanceof PhysicsBogeyBlockEntity otherBogey) {
			connect(false, otherBogey, connectionBackToFront);
		}
	}

	public boolean isInverted() {
		return getBlockState().getValue(BlockStateProperties.INVERTED);
	}

	public Vector3dc getDirection() {
		return switch(getFacing()) {
		case EAST -> SimurailMath.DIR_XP; case WEST -> SimurailMath.DIR_XN;
		case SOUTH -> SimurailMath.DIR_ZP; case NORTH -> SimurailMath.DIR_ZN;
		case null, default -> throw new IllegalArgumentException("Unexpected value: " + getFacing());
		};
	}

	public Vector3dc getLateral() {
		return switch(getFacing()) {
		case EAST -> SimurailMath.DIR_ZP; case WEST -> SimurailMath.DIR_ZN;
		case SOUTH -> SimurailMath.DIR_XN; case NORTH -> SimurailMath.DIR_XP;
		case null, default -> throw new IllegalArgumentException("Unexpected value: " + getFacing());
		};
	}

	public Quaterniondc getJointOrientation() {
		return switch(getFacing()) {
		case EAST -> SimurailMath.ROT_XPYPZP; case WEST -> SimurailMath.ROT_XNYPZN;
		case SOUTH -> SimurailMath.ROT_ZPYPXN; case NORTH -> SimurailMath.ROT_ZNYPXP;
		case null, default -> throw new IllegalArgumentException("Unexpected value: " + getFacing());
		};
	}

	public PhysicsBogeyAxle getAxle(boolean front) {
		return front ? axleFront : axleBack;
	}

	public PhysicsBogeyBlockEntity getConnected(boolean front) {
		if(front) {
			if(connectionFront != null && level.getBlockEntity(connectionFront) instanceof PhysicsBogeyBlockEntity other) {
				return other;
			}
		}
		else {
			if(connectionBack != null && level.getBlockEntity(connectionBack) instanceof PhysicsBogeyBlockEntity other) {
				return other;
			}
		}
		return null;
	}

	public boolean getConnectedToFront(boolean front) {
		return front ? connectionFrontToFront : connectionBackToFront;
	}

	public void addLink(BlockPos linkPos) {
		links.add(linkPos);
	}

	public void removeLink(BlockPos linkPos) {
		links.remove(linkPos);
	}

	public void setRemoteBrakeOverride(BlockPos controllerPos, int value) {
		if(value > 0) {
			remoteBrakeOverrides.put(controllerPos, LongIntPair.of(level.getGameTime(), value));
		}
		else {
			remoteBrakeOverrides.remove(controllerPos);
		}
	}

	public void setRemoteStrengthOverride(BlockPos controllerPos, int value) {
		if(value >= 0) {
			remoteStrengthOverrides.put(controllerPos, LongIntPair.of(level.getGameTime(), value));
		}
		else {
			remoteStrengthOverrides.remove(controllerPos);
		}
	}

	public void setRemoteLeftSteerOverride(BlockPos controllerPos, int value) {
		if(value != 0) {
			remoteLeftSteerOverrides.put(controllerPos, LongIntPair.of(level.getGameTime(), value));
		}
		else {
			remoteLeftSteerOverrides.remove(controllerPos);
		}
	}

	public void setRemoteRightSteerOverride(BlockPos controllerPos, int value) {
		if(value != 0) {
			remoteRightSteerOverrides.put(controllerPos, LongIntPair.of(level.getGameTime(), value));
		}
		else {
			remoteRightSteerOverrides.remove(controllerPos);
		}
	}

	public void removeRemoteController(BlockPos controllerPos) {
		links.remove(controllerPos);
		remoteBrakeOverrides.remove(controllerPos);
		remoteStrengthOverrides.remove(controllerPos);
		remoteLeftSteerOverrides.remove(controllerPos);
		remoteRightSteerOverrides.remove(controllerPos);
	}

	public boolean hasNavigator() {
		return false;
	}

	@Override
	public void setLevel(Level level) {
		super.setLevel(level);
		if(level != null && !level.isClientSide()) {
			LOADED_BOGEYS.add(this);
		}
	}

	// Sometimes physicsTick happens before tick?
	public void init() {
		if(initialized) {
			return;
		}
		if(localPivotRot == null) {
			localPivotRot = new Quaterniond(getJointOrientation());
		}
		if(localPivotOffset == null) {
			localPivotOffset = new Vector3d();
		}
		lastLocalPivotRot.set(localPivotRot);
		lastLocalPivotOffset.set(localPivotOffset);
		renderPivotRot.initialize(localPivotRot);
		resetPivotPose();
		if(!level.isClientSide() && Sable.HELPER.getContaining(this) instanceof ServerSubLevel subLevel) {
			lastScale.set(subLevel.logicalPose().scale());
			createPivot(subLevel);
			axleFront.init(subLevel);
			axleBack.init(subLevel);
		}
		initialized = true;
	}

	protected void resetPivotPose() {
		pivotPose.position().set(localCenter).add(localPivotOffset);
		pivotPose.orientation().set(localPivotRot);
		SubLevel subLevel = Sable.HELPER.getContaining(this);
		if(subLevel != null) {
			Pose3d containingPose = subLevel.logicalPose();
			containingPose.transformPosition(pivotPose.position());
			pivotPose.orientation().premul(containingPose.orientation());
			Vector3d scale = containingPose.scale();
			if(getFacing().getAxis() != Direction.Axis.Z) {
				pivotPose.scale().set(scale);
			}
			else {
				pivotPose.scale().set(scale.z, scale.y, scale.x);
			}
		}
	}

	protected void createPivot(ServerSubLevel subLevel) {
		SimurailPhysicsConfig config = SimurailConfig.server().physics;
		if(pivot == null) {
			if(config.bogeyPivotBox.get()) {
				pivot = new BoxAuxiliaryPhysicsBody(subLevel.getLevel(), getBlockPos(), new Vector3d(0.5, 0.125, 0.125), config.bogeyPivotMass.get());
			}
			else {
				pivot = new SubLevelAuxiliaryPhysicsBody(subLevel.getLevel(), getBlockPos(), SimurailBlocks.PHYSICS_BOGEY_PIVOT.getDefaultState());
			}
			if(pivotTag != null) {
				pivot.read(pivotTag);
				pivotTag = null;
			}
		}
		if(pivot.isRemoved()) {
			pivot.create(pivotPose);
		}
		SubLevelPhysicsSystem physics = SubLevelPhysicsSystem.require(subLevel.getLevel());
		if(pivotJoint == null || !pivotJoint.isValid()) {
			GenericConstraintConfiguration jointConfig = SimurailJoints.pivotJoint(
					localCenter, pivot.position(SimurailMath.VEC_0),
					getJointOrientation(), SimurailMath.ROT_XPYPZP);
			pivotJoint = physics.getPipeline().addConstraint(subLevel, pivot.physicsBody(), jointConfig);
			pivotJoint.setContactsEnabled(false);
		}
		if(motorJoint == null || !motorJoint.isValid()) {
			GenericConstraintConfiguration jointConfig = SimurailJoints.freeJoint(
					localCenter, pivotPose.position(),
					getJointOrientation(), pivotPose.orientation());
			motorJoint = physics.getPipeline().addConstraint(subLevel, null, jointConfig);
		}
	}

	protected void removePivot(ServerSubLevel subLevel) {
		axleFront.invalidate(subLevel);
		axleBack.invalidate(subLevel);
		if(pivotJoint != null) {
			pivotJoint.remove();
			pivotJoint = null;
		}
		if(motorJoint != null) {
			motorJoint.remove();
			motorJoint = null;
		}
		if(pivot != null) {
			pivot.remove();
		}
	}

	@Override
	public void tick() {
		init();
		super.tick();
		if(!level.isClientSide()) {
			if(!computerBehaviour.hasAttachedComputer() && computerOverrides.hasOverrides()) {
				computerOverrides.reset();
			}
			if(Sable.HELPER.getContaining(this) instanceof ServerSubLevel subLevel) {
				Vector3d currentScale = subLevel.logicalPose().scale();
				if(!lastScale.equals(currentScale, SimurailMath.EPSILON)) {
					lastScale.set(currentScale);
					if(getFacing().getAxis() != Direction.Axis.Z) {
						pivotPose.scale().set(currentScale);
					}
					else {
						pivotPose.scale().set(currentScale.z, currentScale.y, currentScale.x);
					}
					if(!pivot.scaleEquals(pivotPose.scale())) {
						removePivot(subLevel);
						createPivot(subLevel);
					}
				}

				staffRestrained = PhysicsStaffUtil.isRestrained(subLevel);

				axleFront.updateVisualSpeed();
				axleBack.updateVisualSpeed();

				axleFront.updateSignalGroup();
				axleBack.updateSignalGroup();

				axleFront.updateInnerProbe();
				axleBack.updateInnerProbe();

				if((level.getGameTime() + getBlockPos().asLong()) %
						SimurailConfig.server().blocks.bogeyProbeInterval.get() == 0) {
					axleFront.updateOuterProbe();
					axleBack.updateOuterProbe();
				}

				axleFront.updateOffsetChange();
				axleBack.updateOffsetChange();
			}
			else {
				localPivotOffset.zero();
				localPivotRot.set(getJointOrientation());
				resetPivotPose();
				staffRestrained = false;
				axleFront.resetSlip();
				axleBack.resetSlip();
			}
			visualSpeed = Math.abs(axleFront.visualSpeed) > Math.abs(axleBack.visualSpeed) ? axleFront.visualSpeed : axleBack.visualSpeed;
			slipSpeed = Math.abs(axleFront.slipSpeed) > Math.abs(axleBack.slipSpeed) ? axleFront.slipSpeed : axleBack.slipSpeed;
			movementSpeed = (float)getMovementSpeed();
			if(!lastLocalPivotOffset.equals(localPivotOffset, 1E-4) ||
					!lastLocalPivotRot.equals(localPivotRot, 1E-4) ||
					lastVisualSpeed != visualSpeed ||
					lastSlipSpeed != slipSpeed ||
					!Mth.equal(lastMovementSpeed, movementSpeed)) {
				VeilPacketManager.tracking(this).sendPacket(new PhysicsBogeyRenderDataPacket(this));
			}
			lastLocalPivotOffset.set(localPivotOffset);
			lastLocalPivotRot.set(localPivotRot);
			lastVisualSpeed = visualSpeed;
			lastSlipSpeed = slipSpeed;
			lastMovementSpeed = movementSpeed;
		}
		else {
			renderPivotOffset.step(localPivotOffset);
			renderPivotRot.step(localPivotRot);
			distanceMoved = Math.fma(visualSpeed, 0.05, distanceMoved);
			if(Sable.HELPER.getContaining(this) instanceof ClientSubLevel) {
				if(sounds == null) {
					sounds = new PhysicsBogeySounds(this);
				}
				sounds.tick();
				if(effects == null) {
					effects = new PhysicsBogeyEffects(this);
				}
				effects.tick();
			}
		}
	}

	@Override
	public void lazyTick() {
		super.lazyTick();
		if(!level.isClientSide()) {
			if(Sable.HELPER.getContaining(this) instanceof ServerSubLevel) {
			}

			double maxDist = SimurailConfig.server().blocks.connectionBogeyRangeDifferent.get();
			if(connectionFront != null) {
				if(level.getBlockEntity(connectionFront) instanceof PhysicsBogeyBlockEntity other) {
					SubLevel selfSubLevel = Sable.HELPER.getContaining(this);
					SubLevel otherSubLevel = Sable.HELPER.getContaining(other);
					if(selfSubLevel != otherSubLevel && Sable.HELPER.distanceSquaredWithSubLevels(level, getBlockPos().getCenter(), connectionFront.getCenter()) > Mth.square(maxDist)) {
						disconnect(true);
					}
					else if(other.getConnected(connectionFrontToFront) != this) {
						disconnect(true);
					}
				}
				else {
					disconnect(true);
				}
			}
			if(connectionBack != null) {
				if(level.getBlockEntity(connectionBack) instanceof PhysicsBogeyBlockEntity other) {
					SubLevel selfSubLevel = Sable.HELPER.getContaining(this);
					SubLevel otherSubLevel = Sable.HELPER.getContaining(other);
					if(selfSubLevel != otherSubLevel && Sable.HELPER.distanceSquaredWithSubLevels(level, getBlockPos().getCenter(), connectionBack.getCenter()) > Mth.square(maxDist)) {
						disconnect(false);
					}
					else if(other.getConnected(connectionBackToFront) != this) {
						disconnect(true);
					}
				}
				else {
					disconnect(false);
				}
			}
		}
	}

	@Override
	public void sable$physicsTick(ServerSubLevel subLevel, RigidBodyHandle handle, double timeStep) {
		init();
		if(pivot.isRemoved()) {
			createPivot(subLevel);
		}
		pivotPose.set(pivot.pose());
		subLevel.logicalPose().transformPositionInverse(pivotPose.position(), localPivotOffset).sub(localCenter);
		subLevel.logicalPose().orientation().conjugate(localPivotRot).mul(pivotPose.orientation());

		motorJoint.setFrame2(pivotPose.position(), pivotPose.orientation());

		updateAxles(subLevel, handle, timeStep);
		updatePivotLimits(subLevel, timeStep);
		updateForces(subLevel, handle, timeStep);
	}

	protected void updateAxles(ServerSubLevel subLevel, RigidBodyHandle handle, double timeStep) {
		axleFront.updateOffset(subLevel, timeStep);
		axleBack.updateOffset(subLevel, timeStep);

		axleFront.updateTrack(subLevel, timeStep);
		axleBack.updateTrack(subLevel, timeStep);

		axleFront.updateJoint(subLevel);
		axleBack.updateJoint(subLevel);

		axleFront.updateLimits(subLevel, timeStep);
		axleBack.updateLimits(subLevel, timeStep);

		axleFront.updateForces(subLevel, timeStep);
		axleBack.updateForces(subLevel, timeStep);
	}

	protected void updatePivotLimits(ServerSubLevel subLevel, double timeStep) {
		boolean hasTrack = hasTrack();
		boolean bothTrack = !isDerailed();

		double linYLimit = options.enabled && options.allowVerticalOffset && hasTrack ? LINEAR_Y_LIMIT : 0;
		double linZLimit = options.enabled && options.allowLateralOffset && hasTrack ? LINEAR_Z_LIMIT : 0;
		double angXLimit = options.enabled && hasTrack ? ANGULAR_X_LIMIT : 0;
		double angYLimit = options.enabled && options.allowYawOffset && hasTrack ? ANGULAR_Y_LIMIT : 0;
		double angZLimit = options.enabled && options.allowPitchOffset && bothTrack ? ANGULAR_Z_LIMIT : 0;

		pivotJoint.setLimit(ConstraintJointAxis.LINEAR_Y, -linYLimit, linYLimit);
		pivotJoint.setLimit(ConstraintJointAxis.LINEAR_Z, -linZLimit, linZLimit);
		pivotJoint.setLimit(ConstraintJointAxis.ANGULAR_X, -angXLimit, angXLimit);
		pivotJoint.setLimit(ConstraintJointAxis.ANGULAR_Y, -angYLimit, angYLimit);
		pivotJoint.setLimit(ConstraintJointAxis.ANGULAR_Z, -angZLimit, angZLimit);
		pivotJoint.setContactsEnabled(false);
	}

	protected void updateForces(ServerSubLevel subLevel, RigidBodyHandle handle, double timeStep) {
		if(!options.enabled || !isActive()) {
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Y, 0, 0, SimurailMath.EPSILON, false, 0);
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Z, 0, 0, SimurailMath.EPSILON, false, 0);
			motorJoint.setMotor(ConstraintJointAxis.ANGULAR_X, 0, 0, SimurailMath.EPSILON, false, 0);
			motorJoint.setMotor(ConstraintJointAxis.ANGULAR_Y, 0, 0, SimurailMath.EPSILON, false, 0);
			motorJoint.setMotor(ConstraintJointAxis.ANGULAR_Z, 0, 0, SimurailMath.EPSILON, false, 0);
			return;
		}

		RigidBodyHandle pivotHandle = RigidBodyHandle.of(subLevel.getLevel(), pivot.physicsBody());
		Vector3dc localDir = getDirection();
		Quaterniond rot = subLevel.logicalPose().orientation();
		globalBasis.orthogonalized(localDir, SimurailMath.DIR_YP).transform(rot);
		Basis3dc.I.transform(pivotPose, globalPivotBasis);
		handle.getAngularVelocity(globalAngVel);
		pivotHandle.getAngularVelocity(globalPivotAngVel);
		globalAngVel.sub(globalPivotAngVel, globalRelAngVel);
		MassData massData = subLevel.getMassTracker();

		queuedTorque.zero();

		SimurailPhysicsConfig config = SimurailConfig.server().physics;

		// Linear Y
		if(options.allowVerticalOffset) {
			double frequency = config.bogeyVerticalSpringFrequency.get();
			double dampingRate = config.bogeyVerticalSpringDampingRate.get();
			double stiffness = frequency * frequency;
			double damping = frequency * dampingRate * 2;
			double maxForce = config.bogeyVerticalSpringMaxForce.get();
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Y, 0, stiffness, damping, true, maxForce);
		}
		else {
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Y, 0, 0, SimurailMath.EPSILON, false, 0);
		}

		// Linear Z
		if(options.allowLateralOffset) {
			double frequency = config.bogeyLateralSpringFrequency.get();
			double dampingRate = config.bogeyLateralSpringDampingRate.get();
			double stiffness = frequency * frequency;
			double damping = frequency * dampingRate * 2;
			double maxForce = config.bogeyLateralSpringMaxForce.get();
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Z, 0, stiffness, damping, true, maxForce);
		}
		else {
			motorJoint.setMotor(ConstraintJointAxis.LINEAR_Z, 0, 0, SimurailMath.EPSILON, false, 0);
		}

		// Angular X
		{
			lerpedCurvature.chase(getSignedLateralCurvature(), timeStep * 10, Chaser.EXP);
			lerpedCurvature.tickChaser();
			double kLateral = lerpedCurvature.getValue();
			double speed = getMovementSpeed();
			double centAcc = speed * speed * kLateral;
			double tiltStrength = options.getTiltStrength() * 0.1;
			double tilt = Math.clamp(Math.atan(centAcc * tiltStrength), -TILT_LIMIT, TILT_LIMIT);

			double multiplier = config.bogeyRollSpringMomentMultiplier.get();
			double frequency = config.bogeyRollSpringFrequency.get();
			double dampingRate = config.bogeyRollSpringDampingRate.get();
			double stiffness = multiplier * frequency * frequency;
			double damping = multiplier * frequency * dampingRate * 2;
			double maxTorque = config.bogeyRollSpringMaxTorque.get();
			motorJoint.setMotor(ConstraintJointAxis.ANGULAR_X, -tilt, stiffness, damping, true, maxTorque);

			double torqueOffset = massData.getCenterOfMass().y() - localCenter.y();
			double mass = massData.getMass();
			double centTorque = mass * centAcc * torqueOffset / getActiveBogeyCount(subLevel);
			queuedTorque.fma(Math.clamp(centTorque, -maxTorque, maxTorque) * timeStep, globalBasis.direction);
		}

		rot.transformInverse(queuedTorque);
		handle.applyTorqueImpulse(queuedTorque);
	}

	protected boolean isActive() {
		return options.enabled && axleFront.hasTrack() && axleBack.hasTrack();
	}

	protected int getActiveBogeyCount(ServerSubLevel subLevel) {
		int count = 0;
		for(BlockEntitySubLevelActor actor : subLevel.getPlot().getBlockEntityActors()) {
			if(actor instanceof PhysicsBogeyBlockEntity bogey && bogey.isActive()) {
				++count;
			}
		}
		return count;
	}

	public PhysicsBogeyGroup getGroup() {
		if(group == null) {
			PhysicsBogeyGroup.createAndAssign(this);
		}
		return group;
	}

	public float getControlStrength() {
		return Math.clamp((isInverted() ? level.getSignal(getBlockPos().below(), Direction.DOWN) : level.getSignal(getBlockPos().above(), Direction.UP)) / 15F, 0, 1);
	}

	public float getBrakeStrength() {
		float[] brakeStrengths = new float[4];
		brakeStrengths[0] = Mth.square(switch(options.controlMode) {
		case BRAKING -> getControlStrength();
		case BRAKING_INVERTED -> 1 - getControlStrength();
		case null, default -> 0;
		});
		brakeStrengths[1] = getRemoteBrakeStrength();
		if(computerBehaviour.hasAttachedComputer() && computerOverrides.overrideBrakeStrength) {
			brakeStrengths[2] = computerOverrides.getBrakeStrength();
		}
		if(hasNavigator()) {
			brakeStrengths[3] = navigatorBrakeOverride;
		}
		return Floats.max(brakeStrengths);
	}

	public float getRemoteBrakeStrength() {
		int value = 0;
		long currentTime = level.getGameTime();
		Iterator<Map.Entry<BlockPos, LongIntPair>> i = remoteBrakeOverrides.entrySet().iterator();
		while(i.hasNext()) {
			Map.Entry<BlockPos, LongIntPair> entry = i.next();
			LongIntPair pair = entry.getValue();
			if(currentTime - pair.leftLong() > 2) {
				i.remove();
			}
			else if(pair.rightInt() > value) {
				value = pair.rightInt();
			}
		}
		return Mth.square(Math.clamp(value / 15F, 0, 1));
	}

	public float getGroupBrakeStrength() {
		return getGroup().getBrakeStrength(this);
	}

	public float getSteerValue() {
		if(computerBehaviour.hasAttachedComputer() && computerOverrides.overrideSteerValue) {
			return computerOverrides.getSteerValue();
		}
		int value = switch(getFacing()) {
		case EAST -> level.getSignal(getBlockPos().south(), Direction.SOUTH) - level.getSignal(getBlockPos().north(), Direction.NORTH);
		case WEST -> level.getSignal(getBlockPos().north(), Direction.NORTH) - level.getSignal(getBlockPos().south(), Direction.SOUTH);
		case SOUTH -> level.getSignal(getBlockPos().west(), Direction.WEST) - level.getSignal(getBlockPos().east(), Direction.EAST);
		case NORTH -> level.getSignal(getBlockPos().east(), Direction.EAST) - level.getSignal(getBlockPos().west(), Direction.WEST);
		case null, default -> throw new IllegalArgumentException("Unexpected value: " + getFacing());
		};
		if(value == 0) {
			return getRemoteSteerValue();
		}
		return Math.clamp(value / 15F, -1, 1);
	}

	public float getRemoteSteerValue() {
		int left = 0, right = 0;
		long currentTime = level.getGameTime();
		Iterator<Map.Entry<BlockPos, LongIntPair>> i;
		i = remoteLeftSteerOverrides.entrySet().iterator();
		while(i.hasNext()) {
			LongIntPair pair = i.next().getValue();
			if(currentTime - pair.leftLong() > 2) {
				i.remove();
			}
			else if(pair.rightInt() > left) {
				left = pair.rightInt();
			}
		}
		i = remoteRightSteerOverrides.entrySet().iterator();
		while(i.hasNext()) {
			LongIntPair pair = i.next().getValue();
			if(currentTime - pair.leftLong() > 2) {
				i.remove();
			}
			else if(pair.rightInt() > right) {
				right = pair.rightInt();
			}
		}
		return Math.clamp((right - left) / 15F, -1, 1);
	}

	public float getGroupSteerValue() {
		return getGroup().getSteerValue(this);
	}

	@Override
	public Iterable<SubLevel> sable$getConnectionDependencies() {
		ImmutableList.Builder<SubLevel> builder = ImmutableList.builderWithExpectedSize(2);
		SubLevelContainer container = SubLevelContainer.getContainer(level);
		if(pivot != null && pivot.physicsBody() instanceof SubLevel subLevel) {
			builder.add(subLevel);
		}
		if(connectionFront != null && connectionFrontSubLevelID != null) {
			SubLevel subLevel = container.getSubLevel(connectionFrontSubLevelID);
			if(subLevel != null) {
				builder.add(subLevel);
			}
		}
		if(connectionBack != null && connectionBackSubLevelID != null) {
			SubLevel subLevel = container.getSubLevel(connectionBackSubLevelID);
			if(subLevel != null) {
				builder.add(subLevel);
			}
		}
		return builder.build();
	}

	public float getStressMultiplier() {
		if(computerBehaviour.hasAttachedComputer() && computerOverrides.overrideStressMultiplier) {
			return computerOverrides.getStressMultiplier();
		}
		float remoteStrength = getRemoteStrengthMultiplier();
		if(remoteStrength >= 0) {
			return remoteStrength;
		}
		return switch(options.controlMode) {
		case STRENGTH -> getControlStrength();
		case STRENGTH_INVERTED -> 1 - getControlStrength();
		case null, default -> 1;
		};
	}

	public float getRemoteStrengthMultiplier() {
		int value = -1;
		long currentTime = level.getGameTime();
		Iterator<Map.Entry<BlockPos, LongIntPair>> i = remoteStrengthOverrides.entrySet().iterator();
		while(i.hasNext()) {
			Map.Entry<BlockPos, LongIntPair> entry = i.next();
			LongIntPair pair = entry.getValue();
			if(currentTime - pair.leftLong() > 2) {
				i.remove();
			}
			else if(pair.rightInt() > value) {
				value = pair.rightInt();
			}
		}
		return Math.min(value / 15F, 1);
	}

	@Override
	public float calculateStressApplied() {
		if(!options.enabled || isUnpowered()) {
			return 0;
		}
		return Math.abs(options.getStress()) * Math.abs(getStressMultiplier());
	}

	public boolean isUnpowered() {
		return getBlockState().getBlock() instanceof UnpoweredPhysicsBogeyBlock;
	}

	public float getStressSign() {
		return Math.signum(options.getStress()) * Math.signum(getStressMultiplier());
	}

	@Override
	protected AABB createRenderBoundingBox() {
		return super.createRenderBoundingBox().inflate(16);
	}

	protected void updateRenderData(Vector3dc pivotOffset, Quaterniondc pivotRot, float visualSpeed, float slipSpeed, float movementSpeed) {
		this.localPivotOffset.set(pivotOffset);
		this.localPivotRot.set(pivotRot);
		this.visualSpeed = visualSpeed;
		this.slipSpeed = slipSpeed;
		this.movementSpeed = movementSpeed;
	}

	public CompoundTag getBogeyData() {
		if(bogeyData == null) {
			bogeyData = options.type.data(isInverted());
		}
		return bogeyData;
	}

	public Vector3f getRenderPivotOffset(float partialTick, Vector3f dest) {
		return renderPivotOffset.lerp(partialTick, dest);
	}

	public Quaternionf getRenderPivotRot(float partialTick, Quaternionf dest) {
		return renderPivotRot.nlerp(partialTick, dest);
	}

	public Vector3f getConnectorAnchorOffset(float partialTick, boolean front, Vector3f dest) {
		options.type.connectorAnchorOffset(isInverted(), dest);
		if(!front) {
			dest.x = -dest.x;
		}
		return dest;
	}

	public float getWheelAngle(float partialTick) {
		double distance = Math.fma(visualSpeed * 0.05, partialTick, distanceMoved);
		double angle = distance / options.type.wheelRadius();
		return (float)Math.toDegrees(angle) % 360;
	}

	public boolean hasTrack() {
		return axleFront.hasTrack() || axleBack.hasTrack();
	}

	public boolean isDerailed() {
		return !axleFront.hasTrack() || !axleBack.hasTrack();
	}

	public double getMovementSpeed() {
		return (axleFront.speed + axleBack.speed) * 0.5;
	}

	public double getLateralCurvature() {
		return Math.max(axleFront.kLateral, axleBack.kLateral);
	}

	public double getSignedLateralCurvature() {
		return (axleFront.kLateralSigned + axleBack.kLateralSigned) * 0.5;
	}

	public double getVerticalCurvature() {
		return (axleFront.kVertical + axleBack.kVertical) * 0.5;
	}

	@Override
	public PhysicsBogeyMenu createMenu(int windowId, Inventory inv, Player player) {
		return new PhysicsBogeyMenu(windowId, this);
	}

	@Override
	public void setBlockState(BlockState blockState) {
		super.setBlockState(blockState);
		if(!initialized) {
			return;
		}
		if(!level.isClientSide()) {
			if(pivot != null && Sable.HELPER.getContaining(this) instanceof ServerSubLevel subLevel) {
				if(pivotJoint != null) {
					pivotJoint.remove();
					pivotJoint = null;
				}
				if(motorJoint != null) {
					motorJoint.remove();
					motorJoint = null;
				}
				createPivot(subLevel);
				axleFront.resetOffset();
				axleBack.resetOffset();
			}
		}
	}

	@Override
	protected void applyImplicitComponents(DataComponentInput componentInput) {
		customName = componentInput.get(DataComponents.CUSTOM_NAME);
	}

	@Override
	public void invalidate() {
		super.invalidate();
		if(!level.isClientSide()) {
			if(Sable.HELPER.getContaining(this) instanceof ServerSubLevel subLevel) {
				removePivot(subLevel);
			}
		}
		else {
			if(sounds != null) {
				sounds.stop();
			}
		}
		computerBehaviour.removePeripheral();
	}

	@Override
	public String getClipboardKey() {
		return isInverted() ? "inverted_physics_bogey" : "physics_bogey";
	}

	@Override
	public boolean writeToClipboard(HolderLookup.Provider registries, CompoundTag tag, Direction side) {
		tag.put("options", options.write());
		return true;
	}

	@Override
	public boolean readFromClipboard(HolderLookup.Provider registries, CompoundTag tag, Player player, Direction side, boolean simulate) {
		if(simulate) {
			return true;
		}
		if(tag.contains("options")) {
			options.read(tag.getCompound("options"));
			bogeyData = null;
		}
		if(!level.isClientSide()) {
			setChanged();
			sendData();
		}
		return true;
	}

	@Override
	protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);

		tag.put("options", options.write());
		if(customName != null) {
			tag.putString("custom_name", Component.Serializer.toJson(customName, registries));
		}

		if(pivot != null) {
			tag.put("pivot", pivot.write());
		}

		if(!clientPacket) {
			tag.put("axle_front", axleFront.write());
			tag.put("axle_back", axleBack.write());
			tag.put("computer_overrides", computerOverrides.write());
		}

		if(localPivotOffset != null) {
			tag.put("pivot_offset", SableNBTUtils.writeVector3d(localPivotOffset));
		}
		if(localPivotRot != null) {
			tag.put("pivot_rot", SableNBTUtils.writeQuaternion(localPivotRot));
		}
		tag.putDouble("visual_speed", visualSpeed);

		Pair<BlockPos, UUID> front = SchematicContextUtil.writeTransform(connectionFront, connectionFrontSubLevelID);
		Pair<BlockPos, UUID> back = SchematicContextUtil.writeTransform(connectionBack, connectionBackSubLevelID);

		if(front.getFirst() != null) {
			tag.put("connection_front", NbtUtils.writeBlockPos(front.getFirst()));
			if(front.getSecond() != null) {
				tag.putUUID("connection_front_id", front.getSecond());
			}
			tag.putBoolean("connection_front_front", connectionFrontToFront);
		}
		if(back.getFirst() != null) {
			tag.put("connection_back", NbtUtils.writeBlockPos(back.getFirst()));
			if(back.getSecond() != null) {
				tag.putUUID("connection_back_id", back.getSecond());
			}
			tag.putBoolean("connection_back_front", connectionBackToFront);
		}
	}

	@Override
	public void writeSafe(CompoundTag tag, HolderLookup.Provider registries) {
		super.writeSafe(tag, registries);
		tag.put("options", options.write());
		if(customName != null) {
			tag.putString("custom_name", Component.Serializer.toJson(customName, registries));
		}
	}

	@Override
	protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);

		if(tag.contains("options")) {
			options.read(tag.getCompound("options"));
			bogeyData = null;
		}
		if(tag.contains("custom_name")) {
			customName = Component.Serializer.fromJson(tag.getString("custom_name"), registries);
		}

		if(tag.contains("pivot")) {
			pivotTag = tag.getCompound("pivot");
		}

		if(!clientPacket) {
			axleFront.read(tag.getCompound("axle_front"));
			axleBack.read(tag.getCompound("axle_back"));
			computerOverrides.read(tag.getCompound("computer_overrides"));
		}

		if(tag.contains("pivot_offset")) {
			if(localPivotOffset == null) {
				localPivotOffset = new Vector3d();
			}
			localPivotOffset.set(SableNBTUtils.readVector3d(tag.getCompound("pivot_offset")));
		}
		if(tag.contains("pivot_rot")) {
			if(localPivotRot == null) {
				localPivotRot = new Quaterniond(getJointOrientation());
			}
			localPivotRot.set(SableNBTUtils.readQuaternion(tag.getCompound("pivot_rot")));
		}

		visualSpeed = tag.getDouble("visual_speed");

		Pair<BlockPos, UUID> front = SchematicContextUtil.readTransform(
				NbtUtils.readBlockPos(tag, "connection_front").orElse(null),
				tag.hasUUID("connection_front_id") ? tag.getUUID("connection_front_id") : null);
		Pair<BlockPos, UUID> back = SchematicContextUtil.readTransform(
				NbtUtils.readBlockPos(tag, "connection_back").orElse(null),
				tag.hasUUID("connection_back_id") ? tag.getUUID("connection_back_id") : null);

		connectionFront = front.getFirst();
		connectionFrontSubLevelID = front.getSecond();
		connectionFrontToFront = tag.getBoolean("connection_front_front");
		connectionBack = back.getFirst();
		connectionBackSubLevelID = back.getSecond();
		connectionBackToFront = tag.getBoolean("connection_back_front");

		if(group != null) {
			group.invalidate();
		}
	}

	@Override
	public void removeComponentsFromTag(CompoundTag tag) {
		tag.remove("custom_name");
		tag.remove("axle_front");
		tag.remove("axle_back");
		tag.remove("pivot_offset");
		tag.remove("pivot_rot");
	}

	// Mutable physics fields
	protected Basis3d globalBasis = new Basis3d();
	protected Basis3d globalPivotBasis = new Basis3d();
	protected Vector3d globalAngVel = new Vector3d();
	protected Vector3d globalPivotAngVel = new Vector3d();
	protected Vector3d globalRelAngVel = new Vector3d();
	protected Vector3d queuedTorque = new Vector3d();
}
