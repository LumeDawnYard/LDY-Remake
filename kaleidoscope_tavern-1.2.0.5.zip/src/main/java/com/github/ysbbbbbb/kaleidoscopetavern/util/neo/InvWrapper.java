package com.github.ysbbbbbb.kaleidoscopetavern.util.neo;

import net.minecraft.class_1263;
import net.minecraft.class_1799;

public record InvWrapper(class_1263 inv) implements IItemHandler {
   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         InvWrapper that = (InvWrapper)o;
         return this.inv().equals(that.inv());
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return this.inv().hashCode();
   }

   @Override
   public int getSlots() {
      return this.inv().method_5439();
   }

   @Override
   public class_1799 getStackInSlot(int slot) {
      return this.inv().method_5438(slot);
   }

   @Override
   public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
      if (stack.method_7960()) {
         return class_1799.field_8037;
      }

      class_1799 stackInSlot = this.inv().method_5438(slot);
      if (!stackInSlot.method_7960()) {
         if (stackInSlot.method_7947() >= Math.min(stackInSlot.method_7914(), this.getSlotLimit(slot))) {
            return stack;
         }

         if (!class_1799.method_31577(stack, stackInSlot)) {
            return stack;
         }

         if (!this.inv().method_5437(slot, stack)) {
            return stack;
         }

         int m = Math.min(stack.method_7914(), this.getSlotLimit(slot)) - stackInSlot.method_7947();
         if (stack.method_7947() <= m) {
            if (!simulate) {
               class_1799 copy = stack.method_7972();
               copy.method_7933(stackInSlot.method_7947());
               this.inv().method_5447(slot, copy);
               this.inv().method_5431();
            }

            return class_1799.field_8037;
         } else {
            stack = stack.method_7972();
            if (!simulate) {
               class_1799 copy = stack.method_7971(m);
               copy.method_7933(stackInSlot.method_7947());
               this.inv().method_5447(slot, copy);
               this.inv().method_5431();
               return stack;
            } else {
               stack.method_7934(m);
               return stack;
            }
         }
      } else {
         if (!this.inv().method_5437(slot, stack)) {
            return stack;
         }

         int m = Math.min(stack.method_7914(), this.getSlotLimit(slot));
         if (m < stack.method_7947()) {
            stack = stack.method_7972();
            if (!simulate) {
               this.inv().method_5447(slot, stack.method_7971(m));
               this.inv().method_5431();
               return stack;
            } else {
               stack.method_7934(m);
               return stack;
            }
         } else {
            if (!simulate) {
               this.inv().method_5447(slot, stack);
               this.inv().method_5431();
            }

            return class_1799.field_8037;
         }
      }
   }

   @Override
   public class_1799 extractItem(int slot, int amount, boolean simulate) {
      if (amount == 0) {
         return class_1799.field_8037;
      }

      class_1799 stackInSlot = this.inv().method_5438(slot);
      if (stackInSlot.method_7960()) {
         return class_1799.field_8037;
      }

      if (simulate) {
         if (stackInSlot.method_7947() < amount) {
            return stackInSlot.method_7972();
         }

         class_1799 copy = stackInSlot.method_7972();
         copy.method_7939(amount);
         return copy;
      } else {
         int m = Math.min(stackInSlot.method_7947(), amount);
         class_1799 decrStackSize = this.inv().method_5434(slot, m);
         this.inv().method_5431();
         return decrStackSize;
      }
   }

   @Override
   public void setStackInSlot(int slot, class_1799 stack) {
      this.inv().method_5447(slot, stack);
   }

   @Override
   public int getSlotLimit(int slot) {
      return this.inv().method_5444();
   }

   @Override
   public boolean isItemValid(int slot, class_1799 stack) {
      return this.inv().method_5437(slot, stack);
   }
}
