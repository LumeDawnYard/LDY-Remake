package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public class GlasswareHolderBlockEntity extends BaseBlockEntity {
   private static final String ITEMS = "items";
   private final ItemStackHandler items = new ItemStackHandler(4) {
      @Override
      public int getSlotLimit(int slot) {
         return 1;
      }
   };

   public GlasswareHolderBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.GLASSWARE_HOLDER_BE, pos, state);
   }

   public void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.items.deserializeNBT(valueInput, "items", "items_size");
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      this.items.serialize(valueOutput, "items", "items_size");
   }

   public ItemStackHandler getItems() {
      return this.items;
   }

   public class_238 getRenderBoundingBox() {
      class_2338 pos = this.method_11016();
      return new class_238(pos);
   }
}
