package com.github.ysbbbbbb.kaleidoscopetavern.util;

import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class PortHelper {
   public static class_5321<class_2248> createBlockId(String name) {
      return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("kaleidoscope_tavern", name));
   }

   public static class_1304 getSlotForHand(class_1268 interactionHand) {
      return interactionHand == class_1268.field_5808 ? class_1304.field_6173 : class_1304.field_6171;
   }

   public static class_5321<class_1792> createItemId(String name) {
      return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655("kaleidoscope_tavern", name));
   }
}
