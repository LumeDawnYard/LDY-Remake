package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.BarStoolBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.SitUtil;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BarStoolBlockEntity extends BaseBlockEntity {
   private static final String CACHE_ROT_KEY = "CacheRot";
   private static final float ROTATE_SYNC_THRESHOLD = 0.35F;
   private final class_1767 color;
   private float cachedRot;

   public BarStoolBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.BAR_STOOL_BE, pos, state);
      this.color = class_1767.field_7952;
      this.cachedRot = getInitialRot(state);
   }

   public BarStoolBlockEntity(class_2338 pos, class_2680 state, class_1767 color) {
      super(ModBlocks.BAR_STOOL_BE, pos, state);
      this.color = color;
      this.cachedRot = getInitialRot(state);
   }

   public boolean isIntactAngle(float tolerance) {
      float remainder = Math.abs(this.getCachedRot() % 90.0F);
      return remainder < tolerance || remainder > 90.0F - tolerance;
   }

   @Nullable
   public class_2350 currentFacing(float tolerance, class_2680 state) {
      if (this.isIntactAngle(tolerance) && state.method_28498(BarStoolBlock.FACING)) {
         if (class_3532.method_15379(this.getCachedRot() + 180.0F) <= tolerance || class_3532.method_15379(this.getCachedRot() - 180.0F) <= tolerance) {
            return class_2350.field_11043;
         }

         if (class_3532.method_15379(this.getCachedRot()) <= tolerance) {
            return class_2350.field_11035;
         }

         if (class_3532.method_15379(this.getCachedRot() - 90.0F) <= tolerance) {
            return class_2350.field_11039;
         }

         if (class_3532.method_15379(this.getCachedRot() + 90.0F) <= tolerance) {
            return class_2350.field_11034;
         }
      }

      return null;
   }

   public float getCachedRot() {
      return this.cachedRot;
   }

   public class_1767 getColor() {
      return this.color;
   }

   public static void tick(class_1937 level, class_2338 pos, class_2680 state, BarStoolBlockEntity blockEntity) {
      blockEntity.serverTick(level, pos);
   }

   private void serverTick(class_1937 level, class_2338 pos) {
      if (!level.method_8608()) {
         SitEntity sitEntity = SitUtil.getSitEntity(level, pos);
         if (sitEntity != null && sitEntity.method_5805() && !sitEntity.method_5685().isEmpty()) {
            class_1297 passenger = sitEntity.method_31483();
            float targetRot = class_3532.method_15393(getBodyRot(passenger));
            float diff = class_3532.method_15356(this.cachedRot, targetRot);
            if (!(diff < 0.35F)) {
               this.cachedRot = targetRot;
               this.refresh();
            }
         }
      }
   }

   protected void method_11014(@NotNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.cachedRot = class_3532.method_15392(valueInput.method_71424("CacheRot", Math.round(this.cachedRot)));
   }

   protected void method_11007(@NotNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      valueOutput.method_71465("CacheRot", Math.round(this.cachedRot));
   }

   private static float getInitialRot(class_2680 state) {
      return !state.method_28498(BarStoolBlock.FACING) ? 0.0F : ((class_2350)state.method_11654(BarStoolBlock.FACING)).method_10144();
   }

   private static float getBodyRot(class_1297 passenger) {
      return passenger instanceof class_1309 livingEntity ? livingEntity.field_6283 : passenger.method_36454();
   }
}
