package com.github.ysbbbbbb.kaleidoscopetavern.block.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.SignatureCocktailBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.item.SignatureCocktailBlockItem;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SignatureCocktailBlock extends CocktailBlock implements class_2343 {
   public SignatureCocktailBlock(class_2251 properties) {
      super(properties);
   }

   @Nullable
   public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
      return new SignatureCocktailBlockEntity(pPos, pState);
   }

   public void method_9567(class_1937 pLevel, class_2338 pPos, class_2680 pState, @Nullable class_1309 pPlacer, class_1799 pStack) {
      if (SignatureCocktailBlockItem.hasEffects(pStack) && pLevel.method_8321(pPos) instanceof SignatureCocktailBlockEntity ordinary) {
         List<DrinkEffectData.Entry> effects = SignatureCocktailBlockItem.getEffects(pStack);
         int color = SignatureCocktailBlockItem.getColor(pStack);
         ordinary.setEffects(effects);
         ordinary.setColor(color);
         ordinary.refresh();
      }
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, class_8568 params) {
      List<class_1799> stacks = Lists.newArrayList(super.method_9560(state, params));
      class_2586 blockEntity = (class_2586)params.method_51876(class_181.field_1228);
      if (blockEntity instanceof SignatureCocktailBlockEntity be) {
         class_1799 instance = ModItems.SIGNATURE_COCKTAIL.method_7854();
         SignatureCocktailBlockItem.setEffects(instance, be.getEffects());
         SignatureCocktailBlockItem.setColor(instance, be.getColor());
         stacks.add(instance);
      }

      return stacks;
   }
}
