package com.github.ysbbbbbb.kaleidoscopetavern.network.message;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.util.TextAlignment;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.Context;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.class_8710.class_9154;
import org.jetbrains.annotations.NotNull;

public record TextUpdateC2SMessage(class_2338 pos, String text, TextAlignment textAlignment) implements class_8710 {
   public static final class_9154<TextUpdateC2SMessage> TYPE = new class_9154(class_2960.method_60655("kaleidoscope_tavern", "text_update"));
   public static final class_9139<class_2540, TextUpdateC2SMessage> STREAM_CODEC = new class_9139<class_2540, TextUpdateC2SMessage>() {
      @NotNull
      public TextUpdateC2SMessage decode(class_2540 buf) {
         return new TextUpdateC2SMessage(buf.method_10811(), buf.method_10800(2048), (TextAlignment)buf.method_10818(TextAlignment.class));
      }

      public void encode(class_2540 buf, TextUpdateC2SMessage msg) {
         buf.method_10807(msg.pos());
         buf.method_10788(msg.text(), 2048);
         buf.method_10817(msg.textAlignment());
      }
   };

   @NotNull
   public class_9154<? extends class_8710> method_56479() {
      return TYPE;
   }

   public static void receive(TextUpdateC2SMessage message, Context context) {
      if (context.player() instanceof class_3222 sender) {
         class_1937 level = sender.method_51469();
         class_2338 pos = message.pos();
         if (!level.method_8477(pos)) {
            return;
         }

         if (level.method_8321(pos) instanceof TextBlockEntity textBlock) {
            if (textBlock.isWaxed()) {
               return;
            }

            if (textBlock.playerIsTooFarAwayToEdit(sender.method_5667())) {
               return;
            }

            textBlock.setText(message.text());
            textBlock.setTextAlignment(message.textAlignment());
            textBlock.refresh();
         }
      }
   }
}
