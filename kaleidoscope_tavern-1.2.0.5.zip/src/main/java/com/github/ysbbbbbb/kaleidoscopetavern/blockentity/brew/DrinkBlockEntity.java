package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public class DrinkBlockEntity extends BaseBlockEntity {
   private final class_2371<class_1799> items = class_2371.method_10213(4, class_1799.field_8037);

   public DrinkBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.DRINK_BE, pos, state);
   }

   public boolean addItem(class_1799 stack) {
      for (int i = 0; i < this.items.size(); i++) {
         if (((class_1799)this.items.get(i)).method_7960()) {
            this.items.set(i, stack.method_46651(1));
            return true;
         }
      }

      return false;
   }

   public class_1799 removeItem() {
      for (int i = this.items.size() - 1; i >= 0; i--) {
         if (!((class_1799)this.items.get(i)).method_7960()) {
            class_1799 stack = (class_1799)this.items.get(i);
            this.items.set(i, class_1799.field_8037);
            return stack.method_46651(1);
         }
      }

      return class_1799.field_8037;
   }

   protected void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      class_1262.method_5429(valueInput, this.items);
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      class_1262.method_5426(valueOutput, this.items);
   }

   public class_2371<class_1799> getItems() {
      return this.items;
   }
}
