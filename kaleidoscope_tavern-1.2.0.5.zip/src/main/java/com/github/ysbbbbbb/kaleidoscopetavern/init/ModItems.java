package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.item.BarStoolBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.CocktailBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.DrinkBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.GlasswareBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.GrapevineItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.JuiceBucketItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.MolotovBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.PaintingBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.SandwichBoardBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.ShakerItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.SignatureCocktailBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.SofaBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.StringLightsBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.TooltipBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.TooltipItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_1792.class_1793;

public final class ModItems {
   public static final class_1792 GRAPE = registerItem("grape", p -> new TooltipItem(p.method_19265(ModFoods.GRAPE), "tooltip.kaleidoscope_tavern.grape"));
   public static final class_1792 ICE_GRAPE = registerItem(
      "ice_grape", p -> new TooltipItem(p.method_19265(ModFoods.GRAPE), "tooltip.kaleidoscope_tavern.ice_grape")
   );
   public static final class_1792 GOLD_GRAPE = registerItem(
      "gold_grape", p -> new TooltipItem(p.method_19265(ModFoods.GRAPE), "tooltip.kaleidoscope_tavern.gold_grape")
   );
   public static final class_1792 GREEN_GRAPE = registerItem(
      "green_grape", p -> new TooltipItem(p.method_19265(ModFoods.GRAPE), "tooltip.kaleidoscope_tavern.green_grape")
   );
   public static final class_1792 GRAPEVINE = registerItem("grapevine", GrapevineItem::new);
   public static final class_1792 GRAPE_BUCKET = registerItem("grape_bucket", p -> new JuiceBucketItem(ModFluids.GRAPE_JUICE, p));
   public static final class_1792 SWEET_BERRIES_BUCKET = registerItem("sweet_berries_bucket", p -> new JuiceBucketItem(ModFluids.SWEET_BERRIES_JUICE, p));
   public static final class_1792 GLOW_BERRIES_BUCKET = registerItem("glow_berries_bucket", p -> new JuiceBucketItem(ModFluids.GLOW_BERRIES_JUICE, p));
   public static final class_1792 ICE_GRAPE_BUCKET = registerItem("ice_grape_bucket", p -> new JuiceBucketItem(ModFluids.ICE_GRAPE_JUICE, p));
   public static final class_1792 GOLD_GRAPE_BUCKET = registerItem("gold_grape_bucket", p -> new JuiceBucketItem(ModFluids.GOLD_GRAPE_JUICE, p));
   public static final class_1792 GREEN_GRAPE_BUCKET = registerItem("green_grape_bucket", p -> new JuiceBucketItem(ModFluids.GREEN_GRAPE_JUICE, p));
   public static final class_1792 EMPTY_BOTTLE = registerBlockItem("empty_bottle", p -> new BottleBlockItem(ModBlocks.EMPTY_BOTTLE, p));
   public static final class_1792 EMPTY_GLASSWARE = registerBlockItem("empty_glassware", p -> new GlasswareBlockItem(ModBlocks.EMPTY_GLASSWARE, p));
   public static final class_1792 SIGNATURE_COCKTAIL = registerBlockItem(
      "signature_cocktail", p -> new SignatureCocktailBlockItem(ModBlocks.SIGNATURE_COCKTAIL, p)
   );
   public static final class_1792 MYSTERY_COCKTAIL = registerBlockItem("mystery_cocktail", p -> new CocktailBlockItem(ModBlocks.MYSTERY_COCKTAIL, p));
   public static final class_1792 WHITE_LADY = registerBlockItem("white_lady", p -> new CocktailBlockItem(ModBlocks.WHITE_LADY, p));
   public static final class_1792 EMERALD = registerBlockItem("emerald", p -> new CocktailBlockItem(ModBlocks.EMERALD, p));
   public static final class_1792 BRASS_HEART = registerBlockItem("brass_heart", p -> new CocktailBlockItem(ModBlocks.BRASS_HEART, p));
   public static final class_1792 GODFATHER = registerBlockItem("godfather", p -> new CocktailBlockItem(ModBlocks.GODFATHER, p));
   public static final class_1792 GRASSHOPPER = registerBlockItem("grasshopper", p -> new CocktailBlockItem(ModBlocks.GRASSHOPPER, p));
   public static final class_1792 SCREWDRIVER = registerBlockItem("screwdriver", p -> new CocktailBlockItem(ModBlocks.SCREWDRIVER, p));
   public static final class_1792 MOJITO = registerBlockItem("mojito", p -> new CocktailBlockItem(ModBlocks.MOJITO, p));
   public static final class_1792 ALLIUM_GARDEN = registerBlockItem("allium_garden", p -> new CocktailBlockItem(ModBlocks.ALLIUM_GARDEN, p));
   public static final class_1792 DEPTH_CHARGE = registerBlockItem("depth_charge", p -> new CocktailBlockItem(ModBlocks.DEPTH_CHARGE, p));
   public static final class_1792 NETHER_SPECIAL = registerBlockItem("nether_special", p -> new CocktailBlockItem(ModBlocks.NETHER_SPECIAL, p));
   public static final class_1792 BLOODY_MARY = registerBlockItem("bloody_mary", p -> new CocktailBlockItem(ModBlocks.BLOODY_MARY, p));
   public static final class_1792 SCULK_SPECIAL = registerBlockItem("sculk_special", p -> new CocktailBlockItem(ModBlocks.SCULK_SPECIAL, p));
   public static final class_1792 WHITE_SOFA = registerBlockItem("white_sofa", p -> new SofaBlockItem(ModBlocks.WHITE_SOFA, p));
   public static final class_1792 LIGHT_GRAY_SOFA = registerBlockItem("light_gray_sofa", p -> new SofaBlockItem(ModBlocks.LIGHT_GRAY_SOFA, p));
   public static final class_1792 GRAY_SOFA = registerBlockItem("gray_sofa", p -> new SofaBlockItem(ModBlocks.GRAY_SOFA, p));
   public static final class_1792 BLACK_SOFA = registerBlockItem("black_sofa", p -> new SofaBlockItem(ModBlocks.BLACK_SOFA, p));
   public static final class_1792 BROWN_SOFA = registerBlockItem("brown_sofa", p -> new SofaBlockItem(ModBlocks.BROWN_SOFA, p));
   public static final class_1792 RED_SOFA = registerBlockItem("red_sofa", p -> new SofaBlockItem(ModBlocks.RED_SOFA, p));
   public static final class_1792 ORANGE_SOFA = registerBlockItem("orange_sofa", p -> new SofaBlockItem(ModBlocks.ORANGE_SOFA, p));
   public static final class_1792 YELLOW_SOFA = registerBlockItem("yellow_sofa", p -> new SofaBlockItem(ModBlocks.YELLOW_SOFA, p));
   public static final class_1792 LIME_SOFA = registerBlockItem("lime_sofa", p -> new SofaBlockItem(ModBlocks.LIME_SOFA, p));
   public static final class_1792 GREEN_SOFA = registerBlockItem("green_sofa", p -> new SofaBlockItem(ModBlocks.GREEN_SOFA, p));
   public static final class_1792 CYAN_SOFA = registerBlockItem("cyan_sofa", p -> new SofaBlockItem(ModBlocks.CYAN_SOFA, p));
   public static final class_1792 LIGHT_BLUE_SOFA = registerBlockItem("light_blue_sofa", p -> new SofaBlockItem(ModBlocks.LIGHT_BLUE_SOFA, p));
   public static final class_1792 BLUE_SOFA = registerBlockItem("blue_sofa", p -> new SofaBlockItem(ModBlocks.BLUE_SOFA, p));
   public static final class_1792 PURPLE_SOFA = registerBlockItem("purple_sofa", p -> new SofaBlockItem(ModBlocks.PURPLE_SOFA, p));
   public static final class_1792 MAGENTA_SOFA = registerBlockItem("magenta_sofa", p -> new SofaBlockItem(ModBlocks.MAGENTA_SOFA, p));
   public static final class_1792 PINK_SOFA = registerBlockItem("pink_sofa", p -> new SofaBlockItem(ModBlocks.PINK_SOFA, p));
   public static final class_1792 WHITE_BAR_STOOL = registerBlockItem("white_bar_stool", p -> new BarStoolBlockItem(ModBlocks.WHITE_BAR_STOOL, p));
   public static final class_1792 LIGHT_GRAY_BAR_STOOL = registerBlockItem(
      "light_gray_bar_stool", p -> new BarStoolBlockItem(ModBlocks.LIGHT_GRAY_BAR_STOOL, p)
   );
   public static final class_1792 GRAY_BAR_STOOL = registerBlockItem("gray_bar_stool", p -> new BarStoolBlockItem(ModBlocks.GRAY_BAR_STOOL, p));
   public static final class_1792 BLACK_BAR_STOOL = registerBlockItem("black_bar_stool", p -> new BarStoolBlockItem(ModBlocks.BLACK_BAR_STOOL, p));
   public static final class_1792 BROWN_BAR_STOOL = registerBlockItem("brown_bar_stool", p -> new BarStoolBlockItem(ModBlocks.BROWN_BAR_STOOL, p));
   public static final class_1792 RED_BAR_STOOL = registerBlockItem("red_bar_stool", p -> new BarStoolBlockItem(ModBlocks.RED_BAR_STOOL, p));
   public static final class_1792 ORANGE_BAR_STOOL = registerBlockItem("orange_bar_stool", p -> new BarStoolBlockItem(ModBlocks.ORANGE_BAR_STOOL, p));
   public static final class_1792 YELLOW_BAR_STOOL = registerBlockItem("yellow_bar_stool", p -> new BarStoolBlockItem(ModBlocks.YELLOW_BAR_STOOL, p));
   public static final class_1792 LIME_BAR_STOOL = registerBlockItem("lime_bar_stool", p -> new BarStoolBlockItem(ModBlocks.LIME_BAR_STOOL, p));
   public static final class_1792 GREEN_BAR_STOOL = registerBlockItem("green_bar_stool", p -> new BarStoolBlockItem(ModBlocks.GREEN_BAR_STOOL, p));
   public static final class_1792 CYAN_BAR_STOOL = registerBlockItem("cyan_bar_stool", p -> new BarStoolBlockItem(ModBlocks.CYAN_BAR_STOOL, p));
   public static final class_1792 LIGHT_BLUE_BAR_STOOL = registerBlockItem(
      "light_blue_bar_stool", p -> new BarStoolBlockItem(ModBlocks.LIGHT_BLUE_BAR_STOOL, p)
   );
   public static final class_1792 BLUE_BAR_STOOL = registerBlockItem("blue_bar_stool", p -> new BarStoolBlockItem(ModBlocks.BLUE_BAR_STOOL, p));
   public static final class_1792 PURPLE_BAR_STOOL = registerBlockItem("purple_bar_stool", p -> new BarStoolBlockItem(ModBlocks.PURPLE_BAR_STOOL, p));
   public static final class_1792 MAGENTA_BAR_STOOL = registerBlockItem("magenta_bar_stool", p -> new BarStoolBlockItem(ModBlocks.MAGENTA_BAR_STOOL, p));
   public static final class_1792 PINK_BAR_STOOL = registerBlockItem("pink_bar_stool", p -> new BarStoolBlockItem(ModBlocks.PINK_BAR_STOOL, p));
   public static final class_1792 BELL_PENDANT_LAMP = registerBlockItem("bell_pendant_lamp", p -> new class_1747(ModBlocks.BELL_PENDANT_LAMP, p));
   public static final class_1792 YELLOW_PENDANT_LAMP = registerBlockItem("yellow_pendant_lamp", p -> new class_1747(ModBlocks.YELLOW_PENDANT_LAMP, p));
   public static final class_1792 BLUE_PENDANT_LAMP = registerBlockItem("blue_pendant_lamp", p -> new class_1747(ModBlocks.BLUE_PENDANT_LAMP, p));
   public static final class_1792 CHALKBOARD = registerBlockItem("chalkboard", p -> new class_1747(ModBlocks.CHALKBOARD, p));
   public static final class_1792 SAKURA_INCENSE = registerBlockItem("sakura_incense", p -> new class_1747(ModBlocks.SAKURA_INCENSE, p));
   public static final class_1792 PINE_INCENSE = registerBlockItem("pine_incense", p -> new class_1747(ModBlocks.PINE_INCENSE, p));
   public static final class_1792 GINKGO_INCENSE = registerBlockItem("ginkgo_incense", p -> new class_1747(ModBlocks.GINKGO_INCENSE, p));
   public static final class_1792 SPORE_INCENSE = registerBlockItem("spore_incense", p -> new class_1747(ModBlocks.SPORE_INCENSE, p));
   public static final class_1792 CATNIP_INCENSE = registerBlockItem("catnip_incense", p -> new class_1747(ModBlocks.CATNIP_INCENSE, p));
   public static final class_1792 SNOW_INCENSE = registerBlockItem("snow_incense", p -> new class_1747(ModBlocks.SNOW_INCENSE, p));
   public static final class_1792 BUTTERFLY_INCENSE = registerBlockItem("butterfly_incense", p -> new class_1747(ModBlocks.BUTTERFLY_INCENSE, p));
   public static final class_1792 FIREFLY_INCENSE = registerBlockItem("firefly_incense", p -> new class_1747(ModBlocks.FIREFLY_INCENSE, p));
   public static final class_1792 TABLE = registerBlockItem("table", p -> new class_1747(ModBlocks.TABLE, p));
   public static final class_1792 BASE_SANDWICH_BOARD = registerBlockItem(
      "base_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.BASE_SANDWICH_BOARD, p)
   );
   public static final class_1792 GRASS_SANDWICH_BOARD = registerBlockItem(
      "grass_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.GRASS_SANDWICH_BOARD, p)
   );
   public static final class_1792 ALLIUM_SANDWICH_BOARD = registerBlockItem(
      "allium_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.ALLIUM_SANDWICH_BOARD, p)
   );
   public static final class_1792 AZURE_BLUET_SANDWICH_BOARD = registerBlockItem(
      "azure_bluet_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.AZURE_BLUET_SANDWICH_BOARD, p)
   );
   public static final class_1792 CORNFLOWER_SANDWICH_BOARD = registerBlockItem(
      "cornflower_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.CORNFLOWER_SANDWICH_BOARD, p)
   );
   public static final class_1792 ORCHID_SANDWICH_BOARD = registerBlockItem(
      "orchid_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.ORCHID_SANDWICH_BOARD, p)
   );
   public static final class_1792 PEONY_SANDWICH_BOARD = registerBlockItem(
      "peony_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.PEONY_SANDWICH_BOARD, p)
   );
   public static final class_1792 PINK_PETALS_SANDWICH_BOARD = registerBlockItem(
      "pink_petals_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.PINK_PETALS_SANDWICH_BOARD, p)
   );
   public static final class_1792 PITCHER_PLANT_SANDWICH_BOARD = registerBlockItem(
      "pitcher_plant_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.PITCHER_PLANT_SANDWICH_BOARD, p)
   );
   public static final class_1792 POPPY_SANDWICH_BOARD = registerBlockItem(
      "poppy_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.POPPY_SANDWICH_BOARD, p)
   );
   public static final class_1792 SUNFLOWER_SANDWICH_BOARD = registerBlockItem(
      "sunflower_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.SUNFLOWER_SANDWICH_BOARD, p)
   );
   public static final class_1792 TORCHFLOWER_SANDWICH_BOARD = registerBlockItem(
      "torchflower_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.TORCHFLOWER_SANDWICH_BOARD, p)
   );
   public static final class_1792 TULIP_SANDWICH_BOARD = registerBlockItem(
      "tulip_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.TULIP_SANDWICH_BOARD, p)
   );
   public static final class_1792 WITHER_ROSE_SANDWICH_BOARD = registerBlockItem(
      "wither_rose_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.WITHER_ROSE_SANDWICH_BOARD, p)
   );
   public static final class_1792 EYEBLOSSOM_SANDWICH_BOARD = registerBlockItem(
      "eyeblossom_sandwich_board", p -> new SandwichBoardBlockItem(ModBlocks.EYEBLOSSOM_SANDWICH_BOARD, p)
   );
   public static final class_1792 STRING_LIGHTS_COLORLESS = registerBlockItem(
      "string_lights_colorless", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_COLORLESS, p)
   );
   public static final class_1792 STRING_LIGHTS_WHITE = registerBlockItem(
      "string_lights_white", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_WHITE, p)
   );
   public static final class_1792 STRING_LIGHTS_LIGHT_GRAY = registerBlockItem(
      "string_lights_light_gray", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_LIGHT_GRAY, p)
   );
   public static final class_1792 STRING_LIGHTS_GRAY = registerBlockItem("string_lights_gray", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_GRAY, p));
   public static final class_1792 STRING_LIGHTS_BLACK = registerBlockItem(
      "string_lights_black", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_BLACK, p)
   );
   public static final class_1792 STRING_LIGHTS_BROWN = registerBlockItem(
      "string_lights_brown", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_BROWN, p)
   );
   public static final class_1792 STRING_LIGHTS_RED = registerBlockItem("string_lights_red", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_RED, p));
   public static final class_1792 STRING_LIGHTS_ORANGE = registerBlockItem(
      "string_lights_orange", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_ORANGE, p)
   );
   public static final class_1792 STRING_LIGHTS_YELLOW = registerBlockItem(
      "string_lights_yellow", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_YELLOW, p)
   );
   public static final class_1792 STRING_LIGHTS_LIME = registerBlockItem("string_lights_lime", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_LIME, p));
   public static final class_1792 STRING_LIGHTS_GREEN = registerBlockItem(
      "string_lights_green", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_GREEN, p)
   );
   public static final class_1792 STRING_LIGHTS_CYAN = registerBlockItem("string_lights_cyan", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_CYAN, p));
   public static final class_1792 STRING_LIGHTS_LIGHT_BLUE = registerBlockItem(
      "string_lights_light_blue", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_LIGHT_BLUE, p)
   );
   public static final class_1792 STRING_LIGHTS_BLUE = registerBlockItem("string_lights_blue", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_BLUE, p));
   public static final class_1792 STRING_LIGHTS_PURPLE = registerBlockItem(
      "string_lights_purple", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_PURPLE, p)
   );
   public static final class_1792 STRING_LIGHTS_MAGENTA = registerBlockItem(
      "string_lights_magenta", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_MAGENTA, p)
   );
   public static final class_1792 STRING_LIGHTS_PINK = registerBlockItem("string_lights_pink", p -> new StringLightsBlockItem(ModBlocks.STRING_LIGHTS_PINK, p));
   public static final class_1792 YSBB_PAINTING = registerBlockItem("ysbb_painting", p -> new PaintingBlockItem(ModBlocks.YSBB_PAINTING, p));
   public static final class_1792 TARTARIC_ACID_PAINTING = registerBlockItem(
      "tartaric_acid_painting", p -> new PaintingBlockItem(ModBlocks.TARTARIC_ACID_PAINTING, p)
   );
   public static final class_1792 CR019_PAINTING = registerBlockItem("cr019_painting", p -> new PaintingBlockItem(ModBlocks.CR019_PAINTING, p));
   public static final class_1792 UNKNOWN_PAINTING = registerBlockItem("unknown_painting", p -> new PaintingBlockItem(ModBlocks.UNKNOWN_PAINTING, p));
   public static final class_1792 MASTER_MARISA_PAINTING = registerBlockItem(
      "master_marisa_painting", p -> new PaintingBlockItem(ModBlocks.MASTER_MARISA_PAINTING, p)
   );
   public static final class_1792 SON_OF_MAN_PAINTING = registerBlockItem("son_of_man_painting", p -> new PaintingBlockItem(ModBlocks.SON_OF_MAN_PAINTING, p));
   public static final class_1792 DAVID_PAINTING = registerBlockItem("david_painting", p -> new PaintingBlockItem(ModBlocks.DAVID_PAINTING, p));
   public static final class_1792 GIRL_WITH_PEARL_EARRING_PAINTING = registerBlockItem(
      "girl_with_pearl_earring_painting", p -> new PaintingBlockItem(ModBlocks.GIRL_WITH_PEARL_EARRING_PAINTING, p)
   );
   public static final class_1792 STARRY_NIGHT_PAINTING = registerBlockItem(
      "starry_night_painting", p -> new PaintingBlockItem(ModBlocks.STARRY_NIGHT_PAINTING, p)
   );
   public static final class_1792 VAN_GOGH_SELF_PORTRAIT_PAINTING = registerBlockItem(
      "van_gogh_self_portrait_painting", p -> new PaintingBlockItem(ModBlocks.VAN_GOGH_SELF_PORTRAIT_PAINTING, p)
   );
   public static final class_1792 FATHER_PAINTING = registerBlockItem("father_painting", p -> new PaintingBlockItem(ModBlocks.FATHER_PAINTING, p));
   public static final class_1792 GREAT_WAVE_PAINTING = registerBlockItem("great_wave_painting", p -> new PaintingBlockItem(ModBlocks.GREAT_WAVE_PAINTING, p));
   public static final class_1792 MONA_LISA_PAINTING = registerBlockItem("mona_lisa_painting", p -> new PaintingBlockItem(ModBlocks.MONA_LISA_PAINTING, p));
   public static final class_1792 MONDRIAN_PAINTING = registerBlockItem("mondrian_painting", p -> new PaintingBlockItem(ModBlocks.MONDRIAN_PAINTING, p));
   public static final class_1792 NIGHT_EPIPHANY_PAINTING = registerBlockItem(
      "night_epiphany_painting", p -> new PaintingBlockItem(ModBlocks.NIGHT_EPIPHANY_PAINTING, p)
   );
   public static final class_1792 BAR_COUNTER = registerBlockItem("bar_counter", p -> new class_1747(ModBlocks.BAR_COUNTER, p));
   public static final class_1792 STEPLADDER = registerBlockItem("stepladder", p -> new class_1747(ModBlocks.STEPLADDER, p));
   public static final class_1792 TRELLIS = registerBlockItem(
      "trellis", p -> new TooltipBlockItem(ModBlocks.TRELLIS, p, "tooltip.kaleidoscope_tavern.trellis.1", "tooltip.kaleidoscope_tavern.trellis.2")
   );
   public static final class_1792 PRESSING_TUB = registerBlockItem("pressing_tub", p -> new class_1747(ModBlocks.PRESSING_TUB, p));
   public static final class_1792 TAP = registerBlockItem("tap", p -> new class_1747(ModBlocks.TAP, p));
   public static final class_1792 BARREL = registerBlockItem("barrel", p -> new class_1747(ModBlocks.BARREL, p));
   public static final class_1792 MOLOTOV = registerBlockItem("molotov", p -> new MolotovBlockItem(ModBlocks.MOLOTOV, p));
   public static final class_1792 BAR_CABINET = registerBlockItem("bar_cabinet", p -> new class_1747(ModBlocks.BAR_CABINET, p));
   public static final class_1792 GLASS_BAR_CABINET = registerBlockItem("glass_bar_cabinet", p -> new class_1747(ModBlocks.GLASS_BAR_CABINET, p));
   public static final class_1792 CELLAR_CABINET = registerBlockItem("cellar_cabinet", p -> new class_1747(ModBlocks.CELLAR_CABINET, p));
   public static final class_1792 TILTED_RACK = registerBlockItem("tilted_rack", p -> new class_1747(ModBlocks.TILTED_RACK, p));
   public static final class_1792 CIRCULAR_RACK = registerBlockItem("circular_rack", p -> new class_1747(ModBlocks.CIRCULAR_RACK, p));
   public static final class_1792 HOLDER = registerBlockItem("holder", p -> new class_1747(ModBlocks.HOLDER, p));
   public static final class_1792 SHAKER = registerBlockItem("shaker", ShakerItem::new);
   public static final class_1792 GLASSWARE_HOLDER = registerBlockItem("glassware_holder", p -> new class_1747(ModBlocks.GLASSWARE_HOLDER, p));
   public static final class_1792 WINE = registerBlockItem("wine", p -> new DrinkBlockItem(ModBlocks.WINE, p));
   public static final class_1792 CHAMPAGNE = registerBlockItem("champagne", p -> new DrinkBlockItem(ModBlocks.CHAMPAGNE, p));
   public static final class_1792 VODKA = registerBlockItem("vodka", p -> new DrinkBlockItem(ModBlocks.VODKA, p));
   public static final class_1792 BRANDY = registerBlockItem("brandy", p -> new DrinkBlockItem(ModBlocks.BRANDY, p));
   public static final class_1792 CARIGNAN = registerBlockItem("carignan", p -> new DrinkBlockItem(ModBlocks.CARIGNAN, p));
   public static final class_1792 SAKURA_WINE = registerBlockItem("sakura_wine", p -> new DrinkBlockItem(ModBlocks.SAKURA_WINE, p));
   public static final class_1792 PLUM_WINE = registerBlockItem("plum_wine", p -> new DrinkBlockItem(ModBlocks.PLUM_WINE, p));
   public static final class_1792 WHISKEY = registerBlockItem("whiskey", p -> new DrinkBlockItem(ModBlocks.WHISKEY, p));
   public static final class_1792 ICE_WINE = registerBlockItem("ice_wine", p -> new DrinkBlockItem(ModBlocks.ICE_WINE, p));
   public static final class_1792 VINEGAR = registerBlockItem("vinegar", p -> new DrinkBlockItem(ModBlocks.VINEGAR, p));
   public static final class_1792 POLARIS_SWEET_WHITE = registerBlockItem("polaris_sweet_white", p -> new DrinkBlockItem(ModBlocks.POLARIS_SWEET_WHITE, p));
   public static final class_1792 MOTHER_SNOW = registerBlockItem("mother_snow", p -> new DrinkBlockItem(ModBlocks.MOTHER_SNOW, p));
   public static final class_1792 SHERRY = registerBlockItem("sherry", p -> new DrinkBlockItem(ModBlocks.SHERRY, p));
   public static final class_1792 SWEET_BERRY_WINE = registerBlockItem("sweet_berry_wine", p -> new DrinkBlockItem(ModBlocks.SWEET_BERRY_WINE, p));
   public static final class_1792 RED_QUEEN = registerBlockItem("red_queen", p -> new DrinkBlockItem(ModBlocks.RED_QUEEN, p));
   public static final class_1792 RUM = registerBlockItem("rum", p -> new DrinkBlockItem(ModBlocks.RUM, p));
   public static final class_1792 MINERS_STAR = registerBlockItem("miners_star", p -> new DrinkBlockItem(ModBlocks.MINERS_STAR, p));
   public static final class_1792 HONEY_WINE = registerBlockItem("honey_wine", p -> new DrinkBlockItem(ModBlocks.HONEY_WINE, p));
   public static final class_1792 MADAME_SHEXIANG = registerBlockItem("madame_shexiang", p -> new DrinkBlockItem(ModBlocks.MADAME_SHEXIANG, p));
   public static final class_1792 SUNSET_GLOW = registerBlockItem("sunset_glow", p -> new DrinkBlockItem(ModBlocks.SUNSET_GLOW, p));
   public static final class_1792 SAUVIGNON_BLANC_DRY_WHITE = registerBlockItem(
      "sauvignon_blanc_dry_white", p -> new DrinkBlockItem(ModBlocks.SAUVIGNON_BLANC_DRY_WHITE, p)
   );
   public static final class_1792 RIESLING_DRY_WHITE = registerBlockItem("riesling_dry_white", p -> new DrinkBlockItem(ModBlocks.RIESLING_DRY_WHITE, p));
   public static final class_1792 LUMINOUS_BRIDE = registerBlockItem("luminous_bride", p -> new DrinkBlockItem(ModBlocks.LUMINOUS_BRIDE, p));
   public static final class_1792 GLOWFLOWER_BREW = registerBlockItem("glowflower_brew", p -> new DrinkBlockItem(ModBlocks.GLOWFLOWER_BREW, p));
   public static final class_1792 WATERMELON_JUICE = registerBlockItem("watermelon_juice", p -> new DrinkBlockItem(ModBlocks.WATERMELON_JUICE, p));

   private static class_1792 registerItem(String id, Function<class_1793, class_1792> factory) {
      return registerItem(id, factory, new class_1793());
   }

   private static class_1792 registerItem(String id, Function<class_1793, class_1792> factory, class_1793 properties) {
      class_5321<class_1792> key = PortHelper.createItemId(id);
      class_1792 item = factory.apply(properties.method_63686(key));
      if (item instanceof class_1747 blockItem) {
         blockItem.method_7713(class_1792.field_8003, item);
      }

      return (class_1792)class_2378.method_39197(class_7923.field_41178, key, item);
   }

   private static class_1792 registerBlockItem(String id, Function<class_1793, class_1792> factory) {
      return registerItem(id, factory, new class_1793().method_63685());
   }

   public static void registerItems() {
   }
}
