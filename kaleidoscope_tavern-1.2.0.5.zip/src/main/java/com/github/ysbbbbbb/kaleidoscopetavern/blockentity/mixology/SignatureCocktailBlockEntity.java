package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public class SignatureCocktailBlockEntity extends BaseBlockEntity {
   private static final Codec<List<DrinkEffectData.Entry>> EFFECTS_CODEC = Codec.list(DrinkEffectData.Entry.ENTRY_CODEC);
   private List<DrinkEffectData.Entry> effects = Lists.newArrayList();
   private int color = 5592575;

   public SignatureCocktailBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.SIGNATURE_COCKTAIL_BE, pos, state);
   }

   public void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      valueInput.method_71426("effects", EFFECTS_CODEC).ifPresent(r -> this.effects = (List<DrinkEffectData.Entry>)r);
      this.color = valueInput.method_71424("color", 5592575);
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      valueOutput.method_71468("effects", EFFECTS_CODEC, this.effects);
      valueOutput.method_71465("color", this.color);
   }

   public List<DrinkEffectData.Entry> getEffects() {
      return this.effects;
   }

   public void setEffects(List<DrinkEffectData.Entry> effects) {
      this.effects = effects;
   }

   public int getColor() {
      return this.color;
   }

   public void setColor(int color) {
      this.color = color;
   }
}
