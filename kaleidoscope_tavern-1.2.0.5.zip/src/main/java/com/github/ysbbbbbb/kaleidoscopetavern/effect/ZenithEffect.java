package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_2902.class_2903;
import org.jetbrains.annotations.Nullable;

public class ZenithEffect extends BaseEffect {
   public ZenithEffect(int color) {
      super(color);
   }

   public boolean method_5561() {
      return true;
   }

   @Override
   public void method_5564(
      class_3218 serverLevel, @Nullable class_1297 source, @Nullable class_1297 indirectSource, class_1309 livingEntity, int amplifier, double health
   ) {
      this.performEffect(livingEntity);
   }

   @Override
   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      this.performEffect(livingEntity);
      return true;
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return duration == 1;
   }

   private void performEffect(class_1309 user) {
      class_1937 level = user.method_73183();
      if (!level.method_8608()) {
         class_2338 pos = user.method_24515();
         int surfaceY = level.method_8624(class_2903.field_13197, pos.method_10263(), pos.method_10260());
         if (pos.method_10264() < surfaceY) {
            double targetX = pos.method_10263() + 0.5;
            double targetZ = pos.method_10260() + 0.5;
            level.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14890, class_3419.field_15248, 1.0F, 1.0F);
            user.method_5859(targetX, surfaceY, targetZ);
            user.field_6017 = 0.0;
            level.method_43128(null, targetX, surfaceY, targetZ, class_3417.field_14890, class_3419.field_15248, 1.0F, 1.0F);
            user.method_6092(new class_1293(class_1294.field_5903, 600, 0));
         }
      }
   }
}
