package com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.google.common.collect.Lists;
import java.util.List;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeHolderType;
import mezz.jei.api.recipe.types.IRecipeType;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_638;
import net.minecraft.class_8786;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarrelRecipeCategory implements IRecipeCategory<class_8786<BarrelRecipe>> {
   public static final IRecipeHolderType<BarrelRecipe> TYPE = IRecipeType.create(ModRecipes.BARREL_RECIPE);
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/barrel.png");
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.barrel");
   public static final int WIDTH = 180;
   public static final int HEIGHT = 150;
   private final IDrawable bgDraw;
   private final IDrawable iconDraw;

   public BarrelRecipeCategory(IGuiHelper guiHelper) {
      this.bgDraw = guiHelper.createDrawable(BG, 0, 0, 180, 150);
      this.iconDraw = guiHelper.createDrawableItemLike(ModItems.BARREL);
   }

   public static List<class_8786<BarrelRecipe>> getRecipes() {
      class_638 level = class_310.method_1551().field_1687;
      if (level == null) {
         return List.of();
      }

      List<class_8786<BarrelRecipe>> recipes = Lists.newArrayList();
      recipes.addAll(level.method_8433().getSynchronizedRecipes().getAllOfType(ModRecipes.BARREL_RECIPE));
      return recipes;
   }

   public void draw(class_8786<BarrelRecipe> holder, @NonNull IRecipeSlotsView recipeSlotsView, @NonNull class_332 guiGraphics, double mouseX, double mouseY) {
      this.bgDraw.draw(guiGraphics);
   }

   public void setRecipe(@NonNull IRecipeLayoutBuilder builder, class_8786<BarrelRecipe> holder, @NonNull IFocusGroup focuses) {
      BarrelRecipe recipe = (BarrelRecipe)holder.comp_1933();
      int offsetX = 0;

      for (class_1856 input : recipe.requiredIngredients()) {
         List<class_1799> list = input.method_8105().map(s -> ((class_1792)s.comp_349()).method_7854().method_46651(16)).toList();
         builder.addSlot(RecipeIngredientRole.INPUT, 30 + offsetX, 9).addIngredients(VanillaTypes.ITEM_STACK, list);
         offsetX += 18;
      }

      class_1799 fluidStack = new class_1799(recipe.fluid().method_15774(), 4);
      builder.addSlot(RecipeIngredientRole.INPUT, 10, 9).add(fluidStack);
      builder.addSlot(RecipeIngredientRole.INPUT, 84, 117).add(recipe.carrier());
      class_1799 outputStack = recipe.result().method_46651(16);
      builder.addSlot(RecipeIngredientRole.OUTPUT, 152, 86).add(outputStack);
   }

   public @NonNull IRecipeType<class_8786<BarrelRecipe>> getRecipeType() {
      return TYPE;
   }

   @NotNull
   public class_2561 getTitle() {
      return TITLE;
   }

   public int getWidth() {
      return 180;
   }

   public int getHeight() {
      return 150;
   }

   @Nullable
   public IDrawable getIcon() {
      return this.iconDraw;
   }
}
