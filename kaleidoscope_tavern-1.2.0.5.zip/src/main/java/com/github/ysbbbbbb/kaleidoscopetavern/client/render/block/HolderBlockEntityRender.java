package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.HolderBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.HolderBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class HolderBlockEntityRender extends StorageBlockEntityRender<HolderBlockEntity, StorageBlockEntityRenderState> {
   public HolderBlockEntityRender(class_5615 context) {
      super(context);
   }

   public void extractRenderState(
      @NonNull HolderBlockEntity blockEntity,
      @NonNull StorageBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.extractRenderState(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(HolderBlock.field_11177);
   }

   public @NonNull StorageBlockEntityRenderState createRenderState() {
      return new StorageBlockEntityRenderState();
   }

   @Override
   public void submit(
      StorageBlockEntityRenderState state, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      if (!state.items.isEmpty()) {
         class_1799 stack = state.items.get(0);
         if (!stack.method_7960()) {
            poseStack.method_22903();
            this.applyFacingRotation(state.facing, poseStack);
            this.renderStack(stack, poseStack, submitNodeCollector, state.field_62676, 0.5, 0.125, 0.75, 0.95F, 0.0, -45.0);
            poseStack.method_22909();
         }
      }
   }
}
