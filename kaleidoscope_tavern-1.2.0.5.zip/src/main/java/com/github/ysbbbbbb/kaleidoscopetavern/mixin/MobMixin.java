package com.github.ysbbbbbb.kaleidoscopetavern.mixin;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.LivingChangeTargetEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.EventHooks;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1308.class)
public abstract class MobMixin extends class_1309 {
   protected MobMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
      super(entityType, level);
   }

   @Inject(method = "method_5980", at = @At("HEAD"), cancellable = true)
   public void setTarget(class_1309 livingEntity, CallbackInfo ci) {
      LivingChangeTargetEvent livingChangeTargetEvent = EventHooks.onLivingChangeTarget(this, livingEntity, LivingChangeTargetEvent.LivingTargetType.MOB_TARGET);
      if (livingChangeTargetEvent.isCanceled()) {
         ci.cancel();
      }
   }
}
