package com.github.ysbbbbbb.kaleidoscopetavern.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_707;
import net.minecraft.class_3940.class_11941;
import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public class FireflyIncenseLargeParticle extends class_3940 {
   private final float baseAlpha;
   private final float flickerSpeed;

   protected FireflyIncenseLargeParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites) {
      super(level, x, y, z, sprites.method_18139(level.field_9229));
      this.field_3852 = xSpeed;
      this.field_3869 = ySpeed;
      this.field_3850 = zSpeed;
      this.field_3847 = 60 + level.field_9229.method_43048(40);
      this.field_3844 = -0.001F;
      this.field_17867 = 0.08F + level.field_9229.method_43057() * 0.04F;
      this.baseAlpha = 0.9F;
      this.field_62636 = this.baseAlpha;
      this.flickerSpeed = 0.3F + level.field_9229.method_43057() * 0.4F;
      this.field_3862 = false;
   }

   @NotNull
   public class_11941 method_74255() {
      return class_11941.field_62641;
   }

   public void method_3070() {
      this.field_3858 = this.field_3874;
      this.field_3838 = this.field_3854;
      this.field_3856 = this.field_3871;
      if (this.field_3866++ >= this.field_3847) {
         this.method_3085();
      } else {
         this.field_3852 = this.field_3852 + (this.field_3840.method_43058() - 0.5) * 0.002;
         this.field_3850 = this.field_3850 + (this.field_3840.method_43058() - 0.5) * 0.002;
         this.field_3869 = this.field_3869 + (this.field_3840.method_43058() - 0.5) * 5.0E-4;
         float flicker = (float)(Math.sin(this.field_3866 * this.flickerSpeed) * 0.4 + 0.6);
         float progress = (float)this.field_3866 / this.field_3847;
         float fadeAlpha = progress > 0.8F ? this.baseAlpha * (1.0F - (progress - 0.8F) * 5.0F) : this.baseAlpha;
         this.field_62636 = fadeAlpha * flicker;
         this.method_3069(this.field_3852, this.field_3869, this.field_3850);
         this.field_3852 *= 0.96;
         this.field_3850 *= 0.96;
      }
   }

   public int method_3068(float partialTick) {
      return 15728880;
   }

   public static class Provider implements class_707<class_2400> {
      private final class_4002 sprites;

      public Provider(class_4002 sprites) {
         this.sprites = sprites;
      }

      public class_3940 createParticle(
         @NotNull class_2400 type, @NotNull class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_5819 randomSource
      ) {
         return new FireflyIncenseLargeParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
      }
   }
}
