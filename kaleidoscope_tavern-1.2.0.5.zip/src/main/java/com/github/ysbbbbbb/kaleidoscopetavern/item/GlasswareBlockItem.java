package com.github.ysbbbbbb.kaleidoscopetavern.item;

import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_1792.class_1793;

public class GlasswareBlockItem extends class_1747 {
   public GlasswareBlockItem(class_2248 block) {
      this(block, new class_1793().method_7889(16));
   }

   public GlasswareBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties);
   }
}
