package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_1322.class_1323;

public class HighHeelsEffect extends BaseEffect {
   public HighHeelsEffect(int color) {
      super(color);
      this.method_5566(class_5134.field_47761, class_2960.method_60655("kaleidoscope_tavern", "high_heels_step_height"), 0.5, class_1323.field_6328);
   }
}
