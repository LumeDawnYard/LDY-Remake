package com.github.ysbbbbbb.kaleidoscopetavern.client.model.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.client.animation.ShakerAnimation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11509;
import net.minecraft.class_12249;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.class_7094;

@Environment(EnvType.CLIENT)
public class ShakerModel extends class_3879<ShakerModel.State> {
   public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655("kaleidoscope_tavern", "shaker"), "main");
   private final class_630 root;
   private final class_11509 putAnimation;

   public ShakerModel(class_630 modelPart) {
      super(modelPart, class_12249::method_75994);
      this.root = modelPart.method_32086("root");
      this.putAnimation = ShakerAnimation.PUT.method_71979(this.root);
   }

   public static class_5607 createBodyLayer() {
      class_5609 meshdefinition = new class_5609();
      class_5610 partdefinition = meshdefinition.method_32111();
      class_5610 root = partdefinition.method_32117(
         "root",
         class_5606.method_32108()
            .method_32101(23, 28)
            .method_32098(-3.0F, 0.75F, -3.0F, 6.0F, 4.0F, 6.0F, new class_5605(0.0F))
            .method_32101(2, 2)
            .method_32098(-3.5F, -6.25F, -3.5F, 7.0F, 7.0F, 7.0F, new class_5605(0.0F)),
         class_5603.method_32090(0.0F, 19.25F, 0.0F)
      );
      class_5610 bone2 = root.method_32117(
         "bone2",
         class_5606.method_32108()
            .method_32101(3, 36)
            .method_32098(-1.5F, -3.8333F, -1.5F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F))
            .method_32101(2, 2)
            .method_32098(-3.5F, 0.1667F, -3.5F, 7.0F, 1.0F, 7.0F, new class_5605(0.0F))
            .method_32101(0, 46)
            .method_32098(-3.0F, -1.8333F, -3.0F, 6.0F, 2.0F, 6.0F, new class_5605(0.0F)),
         class_5603.method_32090(0.0F, -7.4167F, 0.0F)
      );
      return class_5607.method_32110(meshdefinition, 64, 64);
   }

   public void setupAnim(ShakerModel.State state) {
      this.root.method_32088().forEach(part -> part.method_41923());
      if (state.lastPutTick > 0) {
         float elapsed = state.ageInTicks - state.lastPutTick;
         if (elapsed >= 0.0F && elapsed < 10.0F) {
            class_7094 putState = new class_7094();
            putState.method_41322(state.lastPutTick);
            this.putAnimation.method_71986(putState, state.ageInTicks, 1.0F);
         }
      }
   }

   @Environment(EnvType.CLIENT)
   public record State(float ageInTicks, int lastPutTick) {
      public State() {
         this(0.0F, 0);
      }
   }
}
