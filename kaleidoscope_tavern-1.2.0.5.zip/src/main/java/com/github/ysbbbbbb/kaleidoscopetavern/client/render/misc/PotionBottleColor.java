package com.github.ysbbbbbb.kaleidoscopetavern.client.render.misc;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PotionBottleBlockEntity;
import net.minecraft.class_1844;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class PotionBottleColor implements class_322 {
   public int getColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int tintIndex) {
      if (tintIndex == 0 && level != null && pos != null) {
         if (level.method_8321(pos) instanceof PotionBottleBlockEntity be && !be.getPotionStack().method_7960()) {
            class_1844 contents = (class_1844)be.getPotionStack().method_58694(class_9334.field_49651);
            if (contents != null) {
               return contents.method_8064();
            }
         }

         return 16777215;
      } else {
         return 16777215;
      }
   }
}
