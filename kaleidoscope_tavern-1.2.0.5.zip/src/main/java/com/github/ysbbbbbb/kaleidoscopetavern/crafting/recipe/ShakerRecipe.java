package com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.container.SimpleInput;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ColorUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.RecipeMatcher;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.class_10355;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_9887;
import net.minecraft.class_7225.class_7874;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class ShakerRecipe implements class_1860<SimpleInput> {
   private final class_2371<class_1856> ingredients;
   private final class_1799 result;
   private Int2ObjectMap<class_124> ingredientColors;

   public ShakerRecipe(class_2371<class_1856> ingredients, class_1799 result, Int2ObjectMap<class_124> ingredientColors) {
      this.ingredients = ingredients;
      this.result = result;
      this.ingredientColors = ingredientColors;
   }

   public boolean matches(SimpleInput input, class_1937 level) {
      List<class_1799> nonEmptyInputs = input.inputs().stream().filter(stack -> !stack.method_7960()).toList();
      List<class_1856> nonEmptyIngredients = this.ingredients.stream().filter(ing -> !ing.method_65799()).toList();
      return nonEmptyInputs.size() != nonEmptyIngredients.size() ? false : RecipeMatcher.findMatches(nonEmptyInputs, nonEmptyIngredients) != null;
   }

   @NotNull
   public class_1799 assemble(SimpleInput input, class_7874 registries) {
      return this.result.method_7972();
   }

   @NotNull
   public class_2371<class_1856> getIngredients() {
      return this.ingredients;
   }

   @NotNull
   public class_1799 getResultItem(class_7874 registries) {
      return this.result;
   }

   @NotNull
   public class_1865<? extends class_1860<SimpleInput>> method_8119() {
      return ModRecipes.SHAKER_SERIALIZER;
   }

   public boolean method_8118() {
      return true;
   }

   @NotNull
   public class_3956<? extends class_1860<SimpleInput>> method_17716() {
      return ModRecipes.SHAKER_RECIPE;
   }

   @NotNull
   public class_9887 method_61671() {
      return class_9887.field_52597;
   }

   @NotNull
   public class_10355 method_64668() {
      return new class_10355();
   }

   public class_2371<class_1856> ingredients() {
      return this.ingredients;
   }

   public class_1799 result() {
      return this.result;
   }

   public Int2ObjectMap<class_124> ingredientColors() {
      if (this.ingredientColors.equals(Int2ObjectMaps.emptyMap())) {
         this.ingredientColors = getIngredientColors(this.ingredients);
      }

      return this.ingredientColors;
   }

   private static Int2ObjectMap<class_124> getIngredientColors(class_2371<class_1856> ingredients) {
      Int2ObjectMap<class_124> ingredientColors = new Int2ObjectOpenHashMap();

      for (int i = 0; i < ingredients.size(); i++) {
         class_124 formatting = getColor((class_1856)ingredients.get(i));
         if (formatting != null) {
            ingredientColors.put(i, formatting);
         }
      }

      return ingredientColors;
   }

   @Nullable
   private static class_124 getColor(class_1856 ingredient) {
      for (class_6880<class_1792> holder : ingredient.method_8105().toList()) {
         for (Entry<class_6862<class_1792>, class_124> entry : ColorUtils.COCKTAIL_INGREDIENT_COLORS.entrySet()) {
            if (((class_1792)holder.comp_349()).equals(entry.getKey())) {
               return entry.getValue();
            }
         }
      }

      return null;
   }
}
