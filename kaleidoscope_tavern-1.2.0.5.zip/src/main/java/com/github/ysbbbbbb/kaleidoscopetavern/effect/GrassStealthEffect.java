package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jspecify.annotations.NonNull;

public class GrassStealthEffect extends BaseEffect {
   public GrassStealthEffect(int color) {
      super(color);
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return duration % 10 == 0;
   }

   @Override
   public boolean method_5572(@NonNull class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      if (!livingEntity.method_5715()) {
         return true;
      }

      class_1937 level = livingEntity.method_73183();
      class_2338 pos = livingEntity.method_24515();
      class_2338 abovePos = pos.method_10084();
      if (notInGrassStealthPlant(level, pos) && notInGrassStealthPlant(level, abovePos)) {
         return true;
      }

      if (livingEntity instanceof class_1657 player) {
         player.method_7322(0.1F);
      }

      level.method_18467(class_1308.class, new class_238(pos).method_1014(32.0)).forEach(e -> {
         if (e.method_5968() == livingEntity) {
            e.method_5980(null);
         }
      });
      return true;
   }

   public static boolean notInGrassStealthPlant(class_1937 level, class_2338 pos) {
      class_2680 blockState = level.method_8320(pos);
      return blockState.method_26204() instanceof class_2302 cropBlock
         ? !cropBlock.method_9825(blockState)
         : !blockState.method_26164(TagMod.GRASS_STEALTH_PLANTS);
   }
}
