package com.github.ysbbbbbb.kaleidoscopetavern.client.init.registry;

import com.github.ysbbbbbb.kaleidoscopetavern.client.animation.ShakerAnimation;
import com.github.ysbbbbbb.kaleidoscopetavern.client.gui.overlay.ShakerOverlay;
import com.github.ysbbbbbb.kaleidoscopetavern.client.init.ClientSetupEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.client.init.CommonModelLoading;
import com.github.ysbbbbbb.kaleidoscopetavern.client.init.ModEntitiesRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.init.ModParticleFactoryRegistry;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.init.PonderCompat;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModFluids;
import com.github.ysbbbbbb.kaleidoscopetavern.network.NetworkHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_2248;

@Environment(EnvType.CLIENT)
public final class ClientRegistry {
   public static void init() {
      NetworkHandler.Clientside.init();
      CommonModelLoading.init();
      renderType();
      ClientSetupEvent.init();
      ModEntitiesRender.init();
      ModFluids.registerFluidRenderers();
      ModParticleFactoryRegistry.init();
      ShakerAnimation.trigger();
      ShakerOverlay.register();
      modCompatClient();
   }

   public static void renderType() {
      BlockRenderLayerMap.putBlocks(
         class_11515.field_60926,
         new class_2248[]{
            ModBlocks.SIGNATURE_COCKTAIL,
            ModBlocks.MYSTERY_COCKTAIL,
            ModBlocks.WHITE_LADY,
            ModBlocks.EMERALD,
            ModBlocks.BRASS_HEART,
            ModBlocks.GODFATHER,
            ModBlocks.GRASSHOPPER,
            ModBlocks.SCREWDRIVER,
            ModBlocks.MOJITO,
            ModBlocks.ALLIUM_GARDEN,
            ModBlocks.DEPTH_CHARGE,
            ModBlocks.NETHER_SPECIAL,
            ModBlocks.BLOODY_MARY,
            ModBlocks.SCULK_SPECIAL,
            ModBlocks.BELL_PENDANT_LAMP,
            ModBlocks.YELLOW_PENDANT_LAMP,
            ModBlocks.BLUE_PENDANT_LAMP,
            ModBlocks.POTION_BOTTLE,
            ModBlocks.XP_BOTTLE
         }
      );
      BlockRenderLayerMap.putBlocks(
         class_11515.field_60925,
         new class_2248[]{
            ModBlocks.TILTED_RACK,
            ModBlocks.HOLDER,
            ModBlocks.PRESSING_TUB,
            ModBlocks.BARREL,
            ModBlocks.CHALKBOARD,
            ModBlocks.BASE_SANDWICH_BOARD,
            ModBlocks.GRASS_SANDWICH_BOARD,
            ModBlocks.ALLIUM_SANDWICH_BOARD,
            ModBlocks.AZURE_BLUET_SANDWICH_BOARD,
            ModBlocks.CORNFLOWER_SANDWICH_BOARD,
            ModBlocks.ORCHID_SANDWICH_BOARD,
            ModBlocks.PEONY_SANDWICH_BOARD,
            ModBlocks.PINK_PETALS_SANDWICH_BOARD,
            ModBlocks.PITCHER_PLANT_SANDWICH_BOARD,
            ModBlocks.POPPY_SANDWICH_BOARD,
            ModBlocks.SUNFLOWER_SANDWICH_BOARD,
            ModBlocks.TORCHFLOWER_SANDWICH_BOARD,
            ModBlocks.TULIP_SANDWICH_BOARD,
            ModBlocks.WITHER_ROSE_SANDWICH_BOARD,
            ModBlocks.EYEBLOSSOM_SANDWICH_BOARD,
            ModBlocks.STRING_LIGHTS_COLORLESS,
            ModBlocks.STRING_LIGHTS_WHITE,
            ModBlocks.STRING_LIGHTS_LIGHT_BLUE,
            ModBlocks.STRING_LIGHTS_GRAY,
            ModBlocks.STRING_LIGHTS_BLACK,
            ModBlocks.STRING_LIGHTS_BROWN,
            ModBlocks.STRING_LIGHTS_RED,
            ModBlocks.STRING_LIGHTS_ORANGE,
            ModBlocks.STRING_LIGHTS_YELLOW,
            ModBlocks.STRING_LIGHTS_LIME,
            ModBlocks.STRING_LIGHTS_GREEN,
            ModBlocks.STRING_LIGHTS_CYAN,
            ModBlocks.STRING_LIGHTS_LIGHT_GRAY,
            ModBlocks.STRING_LIGHTS_BLUE,
            ModBlocks.STRING_LIGHTS_PURPLE,
            ModBlocks.STRING_LIGHTS_MAGENTA,
            ModBlocks.STRING_LIGHTS_PINK,
            ModBlocks.EMPTY_BOTTLE,
            ModBlocks.MOLOTOV,
            ModBlocks.VODKA,
            ModBlocks.GRAPE_CROP,
            ModBlocks.GRAPEVINE_TRELLIS,
            ModBlocks.ICE_GRAPE_CROP,
            ModBlocks.ICE_GRAPEVINE_TRELLIS,
            ModBlocks.GOLD_GRAPE_CROP,
            ModBlocks.GOLD_GRAPEVINE_TRELLIS,
            ModBlocks.WILD_GRAPEVINE,
            ModBlocks.WILD_GRAPEVINE_PLANT,
            ModBlocks.BAR_CABINET,
            ModBlocks.GLASS_BAR_CABINET,
            ModBlocks.RED_BAR_STOOL,
            ModBlocks.GREEN_BAR_STOOL,
            ModBlocks.BLUE_BAR_STOOL,
            ModBlocks.YELLOW_BAR_STOOL,
            ModBlocks.ORANGE_BAR_STOOL,
            ModBlocks.PINK_BAR_STOOL,
            ModBlocks.PURPLE_BAR_STOOL,
            ModBlocks.WHITE_BAR_STOOL,
            ModBlocks.BLACK_BAR_STOOL,
            ModBlocks.LIGHT_BLUE_BAR_STOOL,
            ModBlocks.LIME_BAR_STOOL,
            ModBlocks.BROWN_BAR_STOOL,
            ModBlocks.CYAN_BAR_STOOL,
            ModBlocks.MAGENTA_BAR_STOOL,
            ModBlocks.GRAY_BAR_STOOL,
            ModBlocks.LIGHT_GRAY_BAR_STOOL,
            ModBlocks.SAKURA_INCENSE,
            ModBlocks.PINE_INCENSE,
            ModBlocks.GINKGO_INCENSE,
            ModBlocks.SPORE_INCENSE,
            ModBlocks.CATNIP_INCENSE,
            ModBlocks.SNOW_INCENSE,
            ModBlocks.BUTTERFLY_INCENSE,
            ModBlocks.FIREFLY_INCENSE
         }
      );
   }

   private static void modCompatClient() {
      PonderCompat.init();
   }
}
