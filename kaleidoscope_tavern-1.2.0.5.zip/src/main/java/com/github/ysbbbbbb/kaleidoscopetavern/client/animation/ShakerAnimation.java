package com.github.ysbbbbbb.kaleidoscopetavern.client.animation;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_7179.class_7181;
import net.minecraft.class_7179.class_7183;
import net.minecraft.class_7184.class_7185;

@Environment(EnvType.CLIENT)
public class ShakerAnimation {
   public static final class_7184 PUT = class_7185.method_41818(0.375F)
      .method_41820(
         "root",
         new class_7179(
            class_7183.field_37887,
            new class_7186[]{
               new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.0833F, class_7187.method_41829(0.0F, -4.5F, 0.0F), class_7181.field_37885),
               new class_7186(0.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7181.field_37885)
            }
         )
      )
      .method_41820(
         "bone2",
         new class_7179(
            class_7183.field_37887,
            new class_7186[]{
               new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.0833F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.2083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.2917F, class_7187.method_41829(-7.5F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7181.field_37885)
            }
         )
      )
      .method_41820(
         "bone2",
         new class_7179(
            class_7183.field_37886,
            new class_7186[]{
               new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.0833F, class_7187.method_41823(0.0F, 2.0F, 0.0F), class_7181.field_37885),
               new class_7186(0.2083F, class_7187.method_41823(0.0F, 1.5F, 0.0F), class_7181.field_37885),
               new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7181.field_37885),
               new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7181.field_37885)
            }
         )
      )
      .method_41821();

   public static boolean applyHandTransform(class_4587 poseStack, class_746 player, class_1306 arm, float partialTick, class_1799 stack) {
      if (player != null && stack.method_31574(ModItems.SHAKER)) {
         int remainingTicks = player.method_6014();
         if (remainingTicks == 0) {
            return false;
         }

         float totalTicks = player.field_6012 + partialTick;
         double xOffset = arm == class_1306.field_6183 ? 0.56 : -0.56;
         double offset = (float)Math.sin(totalTicks * 1.5) * 0.25;
         poseStack.method_22904(xOffset, -0.52 - offset * 0.6, -0.72);
         poseStack.method_22907(class_7833.field_40713.rotationDegrees(-15.0F));
         return true;
      } else {
         return false;
      }
   }

   public static void trigger() {
   }
}
