package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11954;
import net.minecraft.class_1799;
import net.minecraft.class_2350;

@Environment(EnvType.CLIENT)
public class StorageBlockEntityRenderState extends class_11954 {
   public class_2350 facing = class_2350.field_11043;
   public List<class_1799> items = new ArrayList<>();
}
