package com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.ReiUtil;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;

public class ReiShakerRecipeCategory implements DisplayCategory<ReiShakerRecipeCategory.ShakerRecipeDisplay> {
   public static final CategoryIdentifier<ReiShakerRecipeCategory.ShakerRecipeDisplay> ID = CategoryIdentifier.of("kaleidoscope_tavern", "plugin/shaker");
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.shaker");
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/shaker.png");
   public static final int WIDTH = 150;
   public static final int HEIGHT = 80;

   public CategoryIdentifier<? extends ReiShakerRecipeCategory.ShakerRecipeDisplay> getCategoryIdentifier() {
      return ID;
   }

   public List<Widget> setupDisplay(ReiShakerRecipeCategory.ShakerRecipeDisplay display, Rectangle bounds) {
      List<Widget> widgets = new ArrayList<>();
      int startX = bounds.x;
      int startY = bounds.y;
      widgets.add(Widgets.createRecipeBase(bounds));
      widgets.add(Widgets.createTexturedWidget(BG, startX, startY, 0.0F, 0.0F, 150, 80));
      List<EntryIngredient> inputs = display.getInputEntries();
      int offsetY = 0;

      for (EntryIngredient input : inputs) {
         widgets.add(Widgets.createSlot(new Point(startX + 52, startY + 14 + offsetY)).entries(input).markInput());
         offsetY += 18;
      }

      widgets.add(
         Widgets.createSlot(new Point(startX + 112, startY + 36))
            .entries((Collection)display.getOutputEntries().getFirst())
            .backgroundEnabled(false)
            .markOutput()
      );
      if (display.recipe != null) {
         ((ShakerRecipe)display.recipe.comp_1933()).ingredientColors().forEach((index, color) -> {
            int x = startX + 69;
            int y = startY + 14 + 18 * index;
            int rgba = 0xFF000000 | color.method_532();
            widgets.add(Widgets.createDrawableWidget((guiGraphics, mouseX, mouseY, v) -> guiGraphics.method_25294(x, y, x + 5, y + 16, rgba)));
         });
      }

      return widgets;
   }

   public int getDisplayWidth(ReiShakerRecipeCategory.ShakerRecipeDisplay display) {
      return 150;
   }

   public int getDisplayHeight() {
      return 80;
   }

   public class_2561 getTitle() {
      return TITLE;
   }

   public Renderer getIcon() {
      return EntryStacks.of(ModItems.SHAKER);
   }

   public static void registerCategories(CategoryRegistry registry) {
      registry.add(new ReiShakerRecipeCategory());
      registry.addWorkstations(ID, new EntryIngredient[]{ReiUtil.ofItem(ModItems.SHAKER)});
   }

   public static class ShakerRecipeDisplay extends BasicDisplay {
      public final class_8786<ShakerRecipe> recipe;
      public static final DisplaySerializer<ReiShakerRecipeCategory.ShakerRecipeDisplay> SERIALIZER = DisplaySerializer.of(
         RecordCodecBuilder.mapCodec(
            inst -> inst.group(
                  class_2960.field_25139.fieldOf("location").forGetter(r -> r.getDisplayLocation().orElse(class_2960.method_60656("air"))),
                  EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(BasicDisplay::getInputEntries),
                  EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(BasicDisplay::getOutputEntries)
               )
               .apply(inst, (location, inputs, outputs) -> new ReiShakerRecipeCategory.ShakerRecipeDisplay(null, inputs, outputs, Optional.of(location)))
         ),
         class_9139.method_56436(
            class_2960.field_48267,
            r -> r.getDisplayLocation().orElse(class_2960.method_60656("air")),
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getInputEntries,
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getOutputEntries,
            (location, inputs, outputs) -> new ReiShakerRecipeCategory.ShakerRecipeDisplay(null, inputs, outputs, Optional.of(location))
         )
      );

      public ShakerRecipeDisplay(@Nullable class_8786<ShakerRecipe> holder) {
         this(
            holder,
            holder != null
               ? ((ShakerRecipe)holder.comp_1933()).getIngredients().stream().filter(i -> !i.method_65799()).map(ReiUtil::ofIngredient).toList()
               : List.of(),
            holder != null ? List.of(ReiUtil.ofItemStack(((ShakerRecipe)holder.comp_1933()).result())) : List.of(),
            holder != null ? Optional.of(holder.comp_1932().method_29177()) : Optional.empty()
         );
      }

      public ShakerRecipeDisplay(
         @Nullable class_8786<ShakerRecipe> holder, List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location
      ) {
         super(inputs, outputs, location);
         this.recipe = holder;
      }

      public CategoryIdentifier<?> getCategoryIdentifier() {
         return ReiShakerRecipeCategory.ID;
      }

      @Nullable
      public DisplaySerializer<? extends Display> getSerializer() {
         return SERIALIZER;
      }
   }
}
