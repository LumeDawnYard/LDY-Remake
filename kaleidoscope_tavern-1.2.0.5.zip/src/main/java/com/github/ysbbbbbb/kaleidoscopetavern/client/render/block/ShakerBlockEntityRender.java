package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.ShakerBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.mixology.ShakerModel;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.ShakerBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class ShakerBlockEntityRender implements class_827<ShakerBlockEntity, ShakerBlockEntityRenderState> {
   private static final class_2960 TEXTURE = class_2960.method_60655("kaleidoscope_tavern", "textures/block/mixology/shaker.png");
   private final ShakerModel model;

   public ShakerBlockEntityRender(class_5615 context) {
      this.model = new ShakerModel(context.method_32140(ShakerModel.LAYER_LOCATION));
   }

   public void extractRenderState(
      @NonNull ShakerBlockEntity blockEntity,
      @NonNull ShakerBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      if (blockEntity.method_10997() != null) {
         blockEntityRenderState.time = (float)blockEntity.method_10997().method_75260() + f;
      }

      blockEntityRenderState.lastPutTick = blockEntity.lastPutTick;
   }

   public @NonNull ShakerBlockEntityRenderState createRenderState() {
      return new ShakerBlockEntityRenderState();
   }

   public void submit(
      @NonNull ShakerBlockEntityRenderState shaker,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      poseStack.method_22903();
      poseStack.method_22904(0.5, 1.5, 0.5);
      poseStack.method_22907(class_7833.field_40717.rotationDegrees(180.0F));
      poseStack.method_22907(class_7833.field_40715.rotationDegrees(180.0F));
      submitNodeCollector.method_73489(
         this.model,
         new ShakerModel.State(shaker.time, shaker.lastPutTick),
         poseStack,
         class_12249.method_75994(TEXTURE),
         shaker.field_62676,
         class_4608.field_21444,
         0,
         null
      );
      poseStack.method_22909();
   }
}
