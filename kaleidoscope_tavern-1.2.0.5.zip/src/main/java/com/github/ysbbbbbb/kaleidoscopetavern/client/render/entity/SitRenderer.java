package com.github.ysbbbbbb.kaleidoscopetavern.client.render.entity;

import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_897;
import net.minecraft.class_5617.class_5618;

@Deprecated
@Environment(EnvType.CLIENT)
public class SitRenderer extends class_897<SitEntity, class_10017> {
   public SitRenderer(class_5618 context) {
      super(context);
   }

   public class_10017 method_55269() {
      return new class_10017();
   }
}
