package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11954;

@Environment(EnvType.CLIENT)
public class ShakerBlockEntityRenderState extends class_11954 {
   public float time;
   public int lastPutTick;
}
