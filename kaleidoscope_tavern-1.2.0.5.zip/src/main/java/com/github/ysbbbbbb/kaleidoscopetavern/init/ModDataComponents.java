package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.item.ShakerItem;
import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

public final class ModDataComponents {
   public static final class_9331<Integer> BREW_LEVEL = class_9331.method_57873().method_57881(Codec.INT).method_57882(class_9135.field_48550).method_57880();
   public static final class_9331<ShakerItem.Result> SHAKER_RESULT = class_9331.method_57873()
      .method_57881(ShakerItem.Result.CODEC)
      .method_57882(ShakerItem.Result.STREAM_CODEC)
      .method_57880();
   public static final class_9331<List<class_1799>> SHAKER_STORAGE = class_9331.method_57873()
      .method_57881(class_1799.field_49266.listOf())
      .method_57882(class_1799.field_49269)
      .method_57880();
   public static final class_9331<List<DrinkEffectData.Entry>> SIGNATURE_COCKTAIL_EFFECTS = class_9331.method_57873()
      .method_57881(Codec.list(DrinkEffectData.Entry.ENTRY_CODEC))
      .method_57882(DrinkEffectData.Entry.STREAM_CODEC.method_56433(class_9135.method_56363()))
      .method_57880();
   public static final class_9331<Integer> SIGNATURE_COCKTAIL_COLOR = class_9331.method_57873()
      .method_57881(Codec.INT)
      .method_57882(class_9135.field_48550)
      .method_57880();

   public static void register() {
      class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("kaleidoscope_tavern", "brew_level"), BREW_LEVEL);
      class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("kaleidoscope_tavern", "shaker_result"), SHAKER_RESULT);
      class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("kaleidoscope_tavern", "shaker_storage"), SHAKER_STORAGE);
      class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("kaleidoscope_tavern", "signature_cocktail_effects"), SIGNATURE_COCKTAIL_EFFECTS);
      class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("kaleidoscope_tavern", "signature_cocktail_color"), SIGNATURE_COCKTAIL_COLOR);
   }
}
