package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.effect.ArdentHeatEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.BaseEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.GrassStealthEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.HighHeelsEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.LongReachEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.ShriekAttackEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.TombRaiderEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.UpsideDownEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.VisionEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.XpDrainEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.ZenithEffect;
import java.util.function.Supplier;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class ModEffects {
   public static class_6880<class_1291> SLIGHTLY_TIPSY = register("slightly_tipsy", () -> new BaseEffect(class_4081.field_18273, 16767306));
   public static class_6880<class_1291> HIGH_HEELS = register("high_heels", () -> new HighHeelsEffect(15227818));
   public static class_6880<class_1291> GRASS_STEALTH = register("grass_stealth", () -> new GrassStealthEffect(7454183));
   public static class_6880<class_1291> VISION = register("vision", () -> new VisionEffect(4229527));
   public static class_6880<class_1291> BLOODY_MARY = register("bloody_mary", () -> new BaseEffect(16202294));
   public static class_6880<class_1291> ARDENT_HEAT = register("ardent_heat", () -> new ArdentHeatEffect(16739125));
   public static class_6880<class_1291> LONG_REACH = register("long_reach", () -> new LongReachEffect(9136404));
   public static class_6880<class_1291> TOMB_RAIDER = register("tomb_raider", () -> new TombRaiderEffect(14329120));
   public static class_6880<class_1291> XP_DRAIN = register("xp_drain", () -> new XpDrainEffect(8190976));
   public static class_6880<class_1291> UPSIDE_DOWN = register("upside_down", () -> new UpsideDownEffect(10181046));
   public static class_6880<class_1291> ZENITH = register("zenith", () -> new ZenithEffect(8900331));
   public static class_6880<class_1291> SHRIEK_ATTACK = register("shriek_attack", () -> new ShriekAttackEffect(871498));

   private static class_6880<class_1291> register(String s, Supplier<class_1291> effectSupplier) {
      return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("kaleidoscope_tavern", s), effectSupplier.get());
   }

   public static void registerEffects() {
   }
}
