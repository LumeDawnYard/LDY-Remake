package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.TiltedRackBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TiltedRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_7833;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class TiltedRackBlockEntityRender extends StorageBlockEntityRender<TiltedRackBlockEntity, StorageBlockEntityRenderState> {
   public TiltedRackBlockEntityRender(class_5615 context) {
      super(context);
   }

   public void extractRenderState(
      @NonNull TiltedRackBlockEntity blockEntity,
      @NonNull StorageBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.extractRenderState(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(TiltedRackBlock.field_11177);
   }

   public @NonNull StorageBlockEntityRenderState createRenderState() {
      return new StorageBlockEntityRenderState();
   }

   @Override
   public void submit(
      StorageBlockEntityRenderState state, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      float scale = 0.9F;
      float angle = 180.0F - state.facing.method_10161() * 90.0F;
      poseStack.method_22903();
      poseStack.method_22904(0.5, 0.0, 0.5);
      poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
      poseStack.method_22904(-0.5, 0.0, -0.5);

      for (int i = 0; i < state.items.size(); i++) {
         class_1799 stack = state.items.get(i);
         if (!stack.method_7960() && stack.method_7909() instanceof class_1747 blockItem) {
            poseStack.method_22903();
            class_2680 state2 = blockItem.method_7711().method_9564();
            poseStack.method_22905(scale, scale, scale);
            poseStack.method_22904(0.425 - 0.375 * i, 0.3125, 0.02 + (i - 1) * 0.005);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(22.5F));
            class_1087 blockStateModel = this.blockRender.method_3349(state2);
            submitNodeCollector.method_73484(
               poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, state.field_62676, class_4608.field_21444, 0
            );
            poseStack.method_22909();
         }
      }

      poseStack.method_22909();
   }
}
