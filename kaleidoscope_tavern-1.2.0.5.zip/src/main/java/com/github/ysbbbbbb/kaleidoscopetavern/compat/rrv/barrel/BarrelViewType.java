package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.barrel;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu.SlotDefinition;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jspecify.annotations.Nullable;

public class BarrelViewType implements ReliableClientRecipeType {
   public static final BarrelViewType INSTANCE = new BarrelViewType();

   private BarrelViewType() {
   }

   public class_2561 getDisplayName() {
      return class_2561.method_43471("emi.category.kaleidoscope_tavern.barrel");
   }

   public int getDisplayWidth() {
      return 170;
   }

   public int getDisplayHeight() {
      return 138;
   }

   public @Nullable class_2960 getGuiTexture() {
      return class_2960.method_60655("kaleidoscope_tavern", "textures/gui/eiv/barrel.png");
   }

   public int getSlotCount() {
      return 7;
   }

   public void placeSlots(SlotDefinition slotDefinition) {
      slotDefinition.addItemSlot(0, 10, 2);

      for (int i = 0; i < 4; i++) {
         slotDefinition.addItemSlot(i + 1, 30 + 18 * i, 2);
      }

      slotDefinition.addItemSlot(5, 84, 110);
      slotDefinition.addItemSlot(6, 147, 79);
   }

   public class_2960 getId() {
      return class_2960.method_60656("kaleidoscope_barrel");
   }

   public class_1799 getIcon() {
      return ModItems.BARREL.method_7854();
   }
}
