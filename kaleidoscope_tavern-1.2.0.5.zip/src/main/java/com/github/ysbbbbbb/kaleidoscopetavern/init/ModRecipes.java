package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer.BarrelRecipeSerializer;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer.PressingTubRecipeSerializer;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer.ShakerRecipeSerializer;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public final class ModRecipes {
   public static final class_1865<PressingTubRecipe> PRESSING_TUB_SERIALIZER = new PressingTubRecipeSerializer();
   public static final class_1865<BarrelRecipe> BARREL_SERIALIZER = new BarrelRecipeSerializer();
   public static final class_1865<ShakerRecipe> SHAKER_SERIALIZER = new ShakerRecipeSerializer();
   public static final class_3956<PressingTubRecipe> PRESSING_TUB_RECIPE = simple(class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"));
   public static final class_3956<BarrelRecipe> BARREL_RECIPE = simple(class_2960.method_60655("kaleidoscope_tavern", "barrel"));
   public static final class_3956<ShakerRecipe> SHAKER_RECIPE = simple(class_2960.method_60655("kaleidoscope_tavern", "shaker"));

   public static void registerRecipes() {
      class_2378.method_10230(class_7923.field_41189, class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"), PRESSING_TUB_SERIALIZER);
      class_2378.method_10230(class_7923.field_41188, class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"), PRESSING_TUB_RECIPE);
      class_2378.method_10230(class_7923.field_41189, class_2960.method_60655("kaleidoscope_tavern", "barrel"), BARREL_SERIALIZER);
      class_2378.method_10230(class_7923.field_41188, class_2960.method_60655("kaleidoscope_tavern", "barrel"), BARREL_RECIPE);
      class_2378.method_10230(class_7923.field_41189, class_2960.method_60655("kaleidoscope_tavern", "shaker"), SHAKER_SERIALIZER);
      class_2378.method_10230(class_7923.field_41188, class_2960.method_60655("kaleidoscope_tavern", "shaker"), SHAKER_RECIPE);
   }

   private static <T extends class_1860<?>> class_3956<T> simple(class_2960 id) {
      return new class_3956<T>() {
         @Override
         public String toString() {
            return id.toString();
         }
      };
   }
}
