package com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.ModJadePlugin;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import org.jspecify.annotations.NonNull;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.JadeUI;

public class PressingTubComponentProvider implements IBlockComponentProvider {
   public static final PressingTubComponentProvider INSTANCE = new PressingTubComponentProvider();
   private static final String KEY_FLUID = "kt_fluid";
   private static final String KEY_AMOUNT = "kt_amount";
   private static final String KEY_CAPACITY = "kt_capacity";
   private static final class_2960 PROGRESS_BASE = class_2960.method_60655("jade", "navbar_background");
   private static final class_2960 PROGRESS_FILL = class_2960.method_60655("jade", "progressbar");

   public void appendTooltip(@NonNull ITooltip iTooltip, BlockAccessor blockAccessor, @NonNull IPluginConfig iPluginConfig) {
      class_2487 data = blockAccessor.getServerData();
      int capacity = data.method_10550("kt_capacity").orElse(0);
      if (capacity <= 0) {
         capacity = 1000;
      }

      String fluidId = data.method_10558("kt_fluid").orElse("");
      int amount = Math.max(0, data.method_10550("kt_amount").orElse(0));
      float ratio = capacity > 0 ? Math.min(1.0F, (float)amount / capacity) : 0.0F;
      if (!fluidId.isEmpty() && amount != 0) {
         class_2960 fluidRegistryId = class_2960.method_60654(fluidId);
         class_3611 fluid = (class_3611)class_7923.field_41173.method_63535(fluidRegistryId);
         FluidVariant variant = FluidVariant.of(fluid);
         if (!variant.isBlank()) {
            class_2561 name = FluidVariantAttributes.getName(variant);
            iTooltip.add(
               JadeUI.progress(
                  ratio,
                  PROGRESS_BASE,
                  PROGRESS_FILL,
                  185,
                  15,
                  class_2561.method_43470("Liquid: ").method_10852(name).method_10852(class_2561.method_43470(" " + amount + "/" + capacity + " mB")),
                  JadeUI.progressStyle()
               )
            );
         } else {
            iTooltip.add(
               JadeUI.progress(
                  ratio,
                  PROGRESS_BASE,
                  PROGRESS_FILL,
                  185,
                  15,
                  class_2561.method_43470("Liquid: Empty " + amount + "/" + capacity + " mB").method_27692(class_124.field_1068),
                  JadeUI.progressStyle()
               )
            );
         }
      } else {
         iTooltip.add(
            JadeUI.progress(
               ratio,
               PROGRESS_BASE,
               PROGRESS_FILL,
               185,
               15,
               class_2561.method_43470("Liquid: Empty " + amount + "/" + capacity + " mB").method_27692(class_124.field_1068),
               JadeUI.progressStyle()
            )
         );
      }
   }

   public @NonNull class_2960 getUid() {
      return ModJadePlugin.PRESSING_TUB;
   }
}
