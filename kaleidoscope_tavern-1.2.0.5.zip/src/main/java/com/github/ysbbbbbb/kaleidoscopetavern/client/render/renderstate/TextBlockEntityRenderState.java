package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import com.github.ysbbbbbb.kaleidoscopetavern.util.TextAlignment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11954;
import net.minecraft.class_1767;
import net.minecraft.class_2350;

@Environment(EnvType.CLIENT)
public class TextBlockEntityRenderState extends class_11954 {
   public class_2350 facing = class_2350.field_11043;
   public int rotation = -1;
   public String text = "";
   public class_1767 color = class_1767.field_7952;
   public boolean glowing = false;
   public TextAlignment textAlignment;
}
