package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import com.github.ysbbbbbb.kaleidoscopetavern.util.event.CancellableEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.IEvent;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public abstract class CropStateChangeEvent extends CancellableEvent {
   private final class_1936 level;
   private final class_2338 pos;
   private final class_2680 state;

   protected CropStateChangeEvent(class_1936 level, class_2338 pos, class_2680 state) {
      this.level = level;
      this.pos = pos;
      this.state = state;
   }

   public class_2680 getState() {
      return this.state;
   }

   public class_2338 getPos() {
      return this.pos;
   }

   public class_1936 getLevel() {
      return this.level;
   }

   @Override
   public void post() {
      ((IEvent.Callback)CALLBACK.invoker()).post(this);
   }

   public static class Post extends CropStateChangeEvent {
      private final class_2680 originalState;

      public Post(class_1937 level, class_2338 pos, class_2680 original, class_2680 state) {
         super(level, pos, state);
         this.originalState = original;
      }

      public class_2680 getOriginalState() {
         return this.originalState;
      }
   }

   public static class Pre extends CropStateChangeEvent {
      public Pre(class_1936 level, class_2338 pos, class_2680 state) {
         super(level, pos, state);
      }
   }
}
