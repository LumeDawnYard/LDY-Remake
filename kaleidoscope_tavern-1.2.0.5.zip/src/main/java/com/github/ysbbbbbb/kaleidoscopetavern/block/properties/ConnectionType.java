package com.github.ysbbbbbb.kaleidoscopetavern.block.properties;

import java.util.Locale;
import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum ConnectionType implements class_3542 {
   SINGLE,
   LEFT,
   RIGHT,
   MIDDLE,
   LEFT_CORNER,
   RIGHT_CORNER;

   @NotNull
   public String method_15434() {
      return this.name().toLowerCase(Locale.ENGLISH);
   }

   @Override
   public String toString() {
      return this.method_15434();
   }
}
