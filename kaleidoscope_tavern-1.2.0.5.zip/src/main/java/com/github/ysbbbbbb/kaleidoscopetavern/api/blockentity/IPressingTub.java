package com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity;

import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface IPressingTub {
   int MAX_FLUID_AMOUNT = 1000;
   long MAX_FLUID_AMOUNT_TRANSFER = 81000L;
   float MIN_FALL_DISTANCE = 0.5F;

   ItemStackHandler getItems();

   CustomFluidTank getFluid();

   int getFluidAmount();

   boolean addIngredient(class_1799 var1);

   boolean removeIngredient(class_1309 var1, int var2);

   boolean press(class_1309 var1, float var2);

   boolean getResult(class_1309 var1, class_1799 var2);
}
