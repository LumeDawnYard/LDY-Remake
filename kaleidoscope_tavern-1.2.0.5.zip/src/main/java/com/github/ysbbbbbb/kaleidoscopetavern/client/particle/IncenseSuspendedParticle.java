package com.github.ysbbbbbb.kaleidoscopetavern.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3532;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_3940.class_11941;
import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public class IncenseSuspendedParticle extends class_3940 {
   protected IncenseSuspendedParticle(class_638 level, class_4002 sprites, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
      super(level, x, y - 0.125, z, xSpeed, ySpeed, zSpeed, sprites.method_18139(level.field_9229));
      this.method_3080(0.01F, 0.01F);
      this.field_17867 = this.field_17867 * (this.field_3840.method_43057() * 0.6F + 0.6F);
      this.field_3847 = class_3532.method_32751(level.field_9229, 500, 1000);
      this.field_3862 = false;
      this.field_28786 = 1.0F;
      this.field_3844 = 0.01F;
   }

   @NotNull
   public class_11941 method_74255() {
      return class_11941.field_62640;
   }

   public static class Provider implements class_707<class_2400> {
      private final class_4002 sprites;

      public Provider(class_4002 sprites) {
         this.sprites = sprites;
      }

      public class_703 createParticle(
         @NotNull class_2400 type,
         @NotNull class_638 level,
         double x,
         double y,
         double z,
         double xSpeed,
         double ySpeed,
         double zSpeed,
         @NotNull class_5819 randomSource
      ) {
         return new IncenseSuspendedParticle(level, this.sprites, x, y, z, 0.0, -0.8, 0.0);
      }
   }
}
