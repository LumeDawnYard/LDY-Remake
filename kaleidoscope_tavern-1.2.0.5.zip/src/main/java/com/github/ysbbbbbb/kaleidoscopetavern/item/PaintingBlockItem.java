package com.github.ysbbbbbb.kaleidoscopetavern.item;

import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jspecify.annotations.NonNull;

public class PaintingBlockItem extends class_1747 {
   public PaintingBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties.method_63684("block.kaleidoscope_tavern.painting"));
   }

   public void method_67187(
      @NonNull class_1799 itemStack,
      @NonNull class_9635 tooltipContext,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 tooltipFlag
   ) {
      String desc = class_156.method_646("tooltip", class_7923.field_41178.method_10221(this));
      consumer.accept(class_2561.method_43471(desc).method_27692(class_124.field_1080));
   }
}
