package com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.DrinkBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class WatermelonTapBehavior implements ITapBehavior {
   @Override
   public boolean isMatch(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      return destinationState.method_27852(ModBlocks.EMPTY_BOTTLE);
   }

   @Nullable
   @Override
   public class_2394 onStartExtract(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      return ModParticles.WATER_TAP_DRIP;
   }

   @Override
   public void onEndExtract(class_1937 level, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState) {
      if (destinationState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
         level.method_8501(tapPos.method_10074(), ModBlocks.WATERMELON_JUICE.method_9564());
         if (level.method_8321(tapPos.method_10074()) instanceof DrinkBlockEntity drink) {
            drink.addItem(ModItems.WATERMELON_JUICE.method_7854());
            drink.refresh();
         }

         level.method_8396(null, tapPos.method_10074(), class_3417.field_14978, class_3419.field_15245, 1.0F, 1.0F);
         ITapBehavior.sendParticles(level, tapPos);
      }
   }
}
