package com.github.ysbbbbbb.kaleidoscopetavern.effect;

public class TombRaiderEffect extends BaseEffect {
   public TombRaiderEffect(int color) {
      super(color);
   }
}
