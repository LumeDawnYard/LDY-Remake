package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.mixin.ZombieVillagerAccessor;
import net.minecraft.class_1309;
import net.minecraft.class_1641;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3483;

public class IncenseBlockEntity extends BaseBlockEntity {
   public IncenseBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.INCENSE_BE, pos, state);
   }

   public static void serverTick(class_1937 level, class_2338 pos, class_2680 state, IncenseBlockEntity incense) {
      if (level.method_75260() % 120L == 0L) {
         class_238 area = new class_238(pos).method_1014(32.0);

         for (class_1309 entity : level.method_8390(class_1309.class, area, e -> e.method_5864().method_20210(class_3483.field_46232) && e.method_5805())) {
            if (entity instanceof class_1641 zombieVillager) {
               if (zombieVillager.method_7198()) {
                  continue;
               }

               if (zombieVillager.method_6032() <= 1.0F) {
                  ((ZombieVillagerAccessor)zombieVillager).invokeStartConverting(null, 60);
                  continue;
               }
            }

            entity.method_64419(level.method_48963().method_48831(), 1.0F);
         }
      }
   }
}
