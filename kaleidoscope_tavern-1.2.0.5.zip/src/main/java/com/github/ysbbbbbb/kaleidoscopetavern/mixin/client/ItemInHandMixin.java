package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.client.animation.ShakerAnimation;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_759.class)
public abstract class ItemInHandMixin {
   @Shadow
   @Final
   private class_310 field_4050;

   @Shadow
   public abstract void method_3233(class_1309 var1, class_1799 var2, class_811 var3, class_4587 var4, class_11659 var5, int var6);

   @Inject(
      method = "method_3228",
      at = @At(value = "FIELD", target = "Lnet/minecraft/class_1306;field_6183:Lnet/minecraft/class_1306;", ordinal = 1, shift = Shift.AFTER, opcode = 178),
      cancellable = true
   )
   public void renderArmWithItem(
      class_742 abstractClientPlayer,
      float f,
      float g,
      class_1268 interactionHand,
      float h,
      class_1799 itemStack,
      float i,
      class_4587 poseStack,
      class_11659 multiBufferSource,
      int j,
      CallbackInfo ci,
      @Local class_1306 arm
   ) {
      if (ShakerAnimation.applyHandTransform(poseStack, this.field_4050.field_1724, arm, f, itemStack)) {
         boolean bool = arm == class_1306.field_6183;
         this.method_3233(abstractClientPlayer, itemStack, bool ? class_811.field_4320 : class_811.field_4323, poseStack, multiBufferSource, j);
         poseStack.method_22909();
         ci.cancel();
      }
   }
}
