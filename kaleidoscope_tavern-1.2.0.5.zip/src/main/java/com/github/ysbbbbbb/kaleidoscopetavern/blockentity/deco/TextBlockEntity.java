package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.network.message.TextOpenS2CMessage;
import com.github.ysbbbbbb.kaleidoscopetavern.util.TextAlignment;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5953;
import net.minecraft.class_8232;
import net.minecraft.class_8233;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public abstract class TextBlockEntity extends BaseBlockEntity {
   @Nullable
   protected UUID playerWhoMayEdit = null;
   protected String text = "";
   protected class_1767 color = class_1767.field_7952;
   protected TextAlignment textAlignment = TextAlignment.CENTER;
   protected boolean isWaxed = false;
   protected boolean isGlowing = false;

   public TextBlockEntity(class_2591<?> entityType, class_2338 pos, class_2680 state) {
      super(entityType, pos, state);
   }

   public static void tick(class_1937 level, class_2338 pos, class_2680 state, TextBlockEntity be) {
      UUID uuid = be.getPlayerWhoMayEdit();
      if (uuid != null && be.playerIsTooFarAwayToEdit(uuid)) {
         be.setPlayerWhoMayEdit(null);
      }
   }

   public static class_1269 onItemUse(class_1937 level, TextBlockEntity textBlock, class_1657 player, class_1268 hand) {
      class_2338 pos = textBlock.method_11016();
      if (textBlock.playerIsTooFarAwayToEdit(player.method_5667())) {
         return class_1269.field_5811;
      }

      if (textBlock.isWaxed()) {
         level.method_45447(null, pos, class_3417.field_43167, class_3419.field_15245);
         return class_1269.field_5811;
      }

      class_1799 itemInHand = player.method_5998(hand);
      if (itemInHand.method_7909() instanceof class_1769 dyeItem) {
         class_1767 newColor = dyeItem.method_7802();
         if (newColor != textBlock.getColor()) {
            textBlock.setColor(newColor);
            textBlock.refresh();
            level.method_45447(null, pos, class_3417.field_28391, class_3419.field_15245);
            if (!player.method_68878()) {
               itemInHand.method_7934(1);
            }

            return class_1269.field_5812;
         }
      }

      if (itemInHand.method_7909() instanceof class_8232 && !textBlock.isGlowing()) {
         textBlock.setGlowing(true);
         textBlock.refresh();
         level.method_45447(null, pos, class_3417.field_28392, class_3419.field_15245);
         if (!player.method_68878()) {
            itemInHand.method_7934(1);
         }

         return class_1269.field_5812;
      } else if (itemInHand.method_7909() instanceof class_8233 && textBlock.isGlowing()) {
         textBlock.setGlowing(false);
         textBlock.refresh();
         level.method_45447(null, pos, class_3417.field_28397, class_3419.field_15245);
         if (!player.method_68878()) {
            itemInHand.method_7934(1);
         }

         return class_1269.field_5812;
      } else if (itemInHand.method_7909() instanceof class_5953) {
         textBlock.setWaxed(true);
         textBlock.refresh();
         if (level instanceof class_3218 serverLevel) {
            serverLevel.method_65096(
               class_2398.field_29642, pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5, 10, 0.5, 0.2, 0.5, 0.1
            );
            serverLevel.method_8396(null, pos, class_3417.field_29543, class_3419.field_15245, 1.0F, 1.0F);
         }

         if (!player.method_68878()) {
            itemInHand.method_7934(1);
         }

         return class_1269.field_5812;
      } else {
         if (player instanceof class_3222 serverPlayer) {
            ServerPlayNetworking.send(serverPlayer, new TextOpenS2CMessage(pos));
         }

         return class_1269.field_5812;
      }
   }

   public abstract int getMaxTextLength();

   public void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.text = valueInput.method_71428("text", "");
      this.color = class_1767.method_7791(valueInput.method_71424("color", class_1767.field_7952.method_7789()));
      this.textAlignment = TextAlignment.byId(valueInput.method_71424("text_alignment", TextAlignment.CENTER.getId()));
      this.isWaxed = valueInput.method_71433("is_waxed", false);
      this.isGlowing = valueInput.method_71433("is_glowing", false);
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      valueOutput.method_71469("text", this.text);
      valueOutput.method_71465("color", this.color.method_7789());
      valueOutput.method_71465("text_alignment", this.textAlignment.getId());
      valueOutput.method_71472("is_waxed", this.isWaxed);
      valueOutput.method_71472("is_glowing", this.isGlowing);
   }

   public boolean playerIsTooFarAwayToEdit(UUID id) {
      if (this.field_11863 == null) {
         return true;
      }

      class_1657 player = this.field_11863.method_18470(id);
      if (player == null) {
         return true;
      }

      class_2338 pos = this.method_11016();
      return player.method_5649(pos.method_10263(), pos.method_10264(), pos.method_10260()) > 64.0;
   }

   @Nullable
   public UUID getPlayerWhoMayEdit() {
      return this.playerWhoMayEdit;
   }

   public void setPlayerWhoMayEdit(@Nullable UUID playerWhoMayEdit) {
      this.playerWhoMayEdit = playerWhoMayEdit;
   }

   public String getText() {
      return this.text;
   }

   public void setText(String text) {
      this.text = text;
   }

   public class_1767 getColor() {
      return this.color;
   }

   public void setColor(class_1767 color) {
      this.color = color;
   }

   public TextAlignment getTextAlignment() {
      return this.textAlignment;
   }

   public void setTextAlignment(TextAlignment textAlignment) {
      this.textAlignment = textAlignment;
   }

   public boolean isWaxed() {
      return this.isWaxed;
   }

   public void setWaxed(boolean waxed) {
      this.isWaxed = waxed;
   }

   public boolean isGlowing() {
      return this.isGlowing;
   }

   public void setGlowing(boolean glowing) {
      this.isGlowing = glowing;
   }
}
