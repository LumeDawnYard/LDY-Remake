package com.github.ysbbbbbb.kaleidoscopetavern.api.client;

import net.minecraft.class_2769;

public interface IModelModifyRotationAfterBake<T extends class_2769<Integer>> {
   T getRotationProperty();
}
