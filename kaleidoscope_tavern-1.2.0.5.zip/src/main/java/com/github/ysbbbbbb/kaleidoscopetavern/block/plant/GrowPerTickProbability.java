package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

@FunctionalInterface
public interface GrowPerTickProbability {
   float getProbability(class_2680 var1, class_3218 var2, class_2338 var3, class_5819 var4);
}
