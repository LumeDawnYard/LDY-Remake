package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import org.apache.commons.lang3.tuple.Pair;

public class SitUtil {
   private static final Map<class_2960, Map<class_2338, Pair<SitEntity, class_243>>> OCCUPIED = new HashMap<>();

   private SitUtil() {
   }

   public static boolean addSitEntity(class_1937 level, class_2338 blockPos, SitEntity entity, class_243 playerPos) {
      if (!level.method_8608()) {
         class_2960 id = getDimensionTypeId(level);
         OCCUPIED.computeIfAbsent(id, unused -> new HashMap<>());
         OCCUPIED.get(id).put(blockPos, Pair.of(entity, playerPos));
         return true;
      } else {
         return false;
      }
   }

   public static void removeSitEntity(class_1937 level, class_2338 pos) {
      if (!level.method_8608()) {
         class_2960 id = getDimensionTypeId(level);
         if (OCCUPIED.containsKey(id)) {
            OCCUPIED.get(id).remove(pos);
         }
      }
   }

   public static SitEntity getSitEntity(class_1937 level, class_2338 pos) {
      if (!level.method_8608()) {
         class_2960 id = getDimensionTypeId(level);
         if (OCCUPIED.containsKey(id) && OCCUPIED.get(id).containsKey(pos)) {
            return (SitEntity)OCCUPIED.get(id).get(pos).getLeft();
         }
      }

      return null;
   }

   public static class_243 getPreviousPlayerPosition(class_1657 player, SitEntity sitEntity) {
      if (!player.method_73183().method_8608()) {
         class_2960 id = getDimensionTypeId(player.method_73183());
         if (OCCUPIED.containsKey(id)) {
            for (Pair<SitEntity, class_243> pair : OCCUPIED.get(id).values()) {
               if (pair.getLeft() == sitEntity) {
                  return (class_243)pair.getRight();
               }
            }
         }
      }

      return null;
   }

   public static boolean isOccupied(class_1937 level, class_2338 pos) {
      class_2960 id = getDimensionTypeId(level);
      return OCCUPIED.containsKey(id) && OCCUPIED.get(id).containsKey(pos);
   }

   public static boolean isPlayerSitting(class_1657 player) {
      for (Entry<class_2960, Map<class_2338, Pair<SitEntity, class_243>>> entry : OCCUPIED.entrySet()) {
         for (Pair<SitEntity, class_243> pair : entry.getValue().values()) {
            if (((SitEntity)pair.getLeft()).method_5626(player)) {
               return true;
            }
         }
      }

      return false;
   }

   private static class_2960 getDimensionTypeId(class_1937 level) {
      return level.method_27983().method_29177();
   }
}
