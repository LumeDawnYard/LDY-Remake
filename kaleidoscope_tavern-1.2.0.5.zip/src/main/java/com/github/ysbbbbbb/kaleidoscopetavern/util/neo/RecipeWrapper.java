package com.github.ysbbbbbb.kaleidoscopetavern.util.neo;

import net.minecraft.class_1799;
import net.minecraft.class_9695;
import org.jetbrains.annotations.NotNull;

public class RecipeWrapper implements class_9695 {
   protected final IItemHandler inv;

   public RecipeWrapper(IItemHandler inv) {
      this.inv = inv;
   }

   public int method_59983() {
      return this.inv.getSlots();
   }

   @NotNull
   public class_1799 method_59984(int slot) {
      return this.inv.getStackInSlot(slot);
   }
}
