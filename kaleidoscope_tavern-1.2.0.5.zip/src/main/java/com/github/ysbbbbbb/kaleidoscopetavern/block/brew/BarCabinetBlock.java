package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.PositionType;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarCabinetBlock extends class_2237 {
   public static final MapCodec<BarCabinetBlock> CODEC = method_54094(BarCabinetBlock::new);
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2754<PositionType> POSITION = class_2754.method_11850("position", PositionType.class);

   public BarCabinetBlock(class_2251 properties) {
      super(properties.method_31710(class_3620.field_15996).method_9632(2.5F).method_9626(class_2498.field_11547).method_22488().method_50013());
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043))
            .method_11657(POSITION, PositionType.SINGLE)
      );
   }

   public @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (!level.method_8608() && hand == class_1268.field_5808) {
         class_2350 direction = (class_2350)state.method_11654(FACING);

         boolean isLeftSide = switch (direction) {
            case field_11043 -> hitResult.method_17784().field_1352 - pos.method_10263() > 0.5;
            case field_11035 -> hitResult.method_17784().field_1352 - pos.method_10263() < 0.5;
            case field_11034 -> hitResult.method_17784().field_1350 - pos.method_10260() < 0.5;
            case field_11039 -> hitResult.method_17784().field_1350 - pos.method_10260() > 0.5;
            default -> false;
         };
         if (level.method_8321(pos) instanceof BarCabinetBlockEntity barCabinet && this.onClick(barCabinet, player, stack, isLeftSide)) {
            float pitch = stack.method_7960() ? level.field_9229.method_43057() * 0.2F + 0.8F : level.field_9229.method_43057() * 0.2F + 0.2F;
            level.method_8396(null, pos, class_3417.field_14843, class_3419.field_15245, level.field_9229.method_43057() * 0.2F + 0.8F, pitch);
            return class_1269.field_5812;
         } else {
            return super.method_55765(stack, state, level, pos, player, hand, hitResult);
         }
      } else {
         return class_1269.field_5811;
      }
   }

   private boolean onClick(BarCabinetBlockEntity barCabinet, class_1657 player, class_1799 stack, boolean isLeftSide) {
      boolean irregular = false;
      boolean single = barCabinet.isSingle();
      BottleBlock bottleBlock = this.getBottleBlock(stack);
      class_1799 leftItem = barCabinet.getLeftItem();
      class_1799 rightItem = barCabinet.getRightItem();
      if (bottleBlock != null) {
         if (single) {
            return false;
         }

         if (stack.method_31573(TagMod.BAR_CABINET_IRREGULAR)) {
            if (!leftItem.method_7960() || !rightItem.method_7960()) {
               return false;
            }

            isLeftSide = true;
            irregular = true;
         } else if (!leftItem.method_7960() && rightItem.method_7960() && isLeftSide) {
            isLeftSide = false;
         } else if (leftItem.method_7960() && !rightItem.method_7960() && !isLeftSide) {
            isLeftSide = true;
         }
      }

      if (stack.method_7960()) {
         if (single) {
            isLeftSide = true;
            irregular = true;
         } else if (leftItem.method_7960() && !rightItem.method_7960() && isLeftSide) {
            isLeftSide = false;
         } else if (!leftItem.method_7960() && rightItem.method_7960() && !isLeftSide) {
            isLeftSide = true;
         }
      }

      if (isLeftSide) {
         if (stack.method_7960()) {
            if (!leftItem.method_7960()) {
               player.method_6122(class_1268.field_5808, leftItem.method_7972());
               barCabinet.setLeftItem(class_1799.field_8037);
               barCabinet.setSingle(false);
               barCabinet.refresh();
               return true;
            }

            return false;
         }

         if (bottleBlock != null && leftItem.method_7960()) {
            class_1799 split = stack.method_7971(1);
            barCabinet.setLeftItem(split);
            barCabinet.setSingle(irregular);
            barCabinet.refresh();
            return true;
         }
      } else {
         if (stack.method_7960()) {
            if (!rightItem.method_7960()) {
               player.method_6122(class_1268.field_5808, rightItem.method_7972());
               barCabinet.setRightItem(class_1799.field_8037);
               barCabinet.setSingle(false);
               barCabinet.refresh();
               return true;
            }

            return false;
         }

         if (bottleBlock != null && rightItem.method_7960()) {
            class_1799 split = stack.method_7971(1);
            barCabinet.setRightItem(split);
            barCabinet.refresh();
            barCabinet.setSingle(irregular);
            return true;
         }
      }

      return false;
   }

   @Nullable
   private BottleBlock getBottleBlock(class_1799 stack) {
      return stack.method_7909() instanceof BottleBlockItem item && item.method_7711() instanceof BottleBlock bottleBlock ? bottleBlock : null;
   }

   protected @NonNull class_2680 method_9559(
      class_2680 state,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      class_2350 self = (class_2350)state.method_11654(FACING);
      class_2350 left = self.method_10170();
      class_2350 right = self.method_10160();
      if (direction == left) {
         boolean leftIsCabinet = blockState2.method_27852(this) && blockState2.method_11654(FACING) == self;
         PositionType position = (PositionType)state.method_11654(POSITION);
         if (leftIsCabinet) {
            if (position == PositionType.SINGLE) {
               return (class_2680)state.method_11657(POSITION, PositionType.RIGHT);
            }

            if (position == PositionType.LEFT) {
               return (class_2680)state.method_11657(POSITION, PositionType.MIDDLE);
            }
         } else {
            if (position == PositionType.RIGHT) {
               return (class_2680)state.method_11657(POSITION, PositionType.SINGLE);
            }

            if (position == PositionType.MIDDLE) {
               return (class_2680)state.method_11657(POSITION, PositionType.LEFT);
            }
         }
      } else if (direction == right) {
         boolean rightIsCabinet = blockState2.method_27852(this) && blockState2.method_11654(FACING) == self;
         PositionType position = (PositionType)state.method_11654(POSITION);
         if (rightIsCabinet) {
            if (position == PositionType.SINGLE) {
               return (class_2680)state.method_11657(POSITION, PositionType.LEFT);
            }

            if (position == PositionType.RIGHT) {
               return (class_2680)state.method_11657(POSITION, PositionType.MIDDLE);
            }
         } else {
            if (position == PositionType.LEFT) {
               return (class_2680)state.method_11657(POSITION, PositionType.SINGLE);
            }

            if (position == PositionType.MIDDLE) {
               return (class_2680)state.method_11657(POSITION, PositionType.RIGHT);
            }
         }
      }

      return super.method_9559(state, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 pos = context.method_8037();
      class_2350 opposite = context.method_8042().method_10153();
      class_2680 left = level.method_8320(pos.method_10093(opposite.method_10170()));
      class_2680 right = level.method_8320(pos.method_10093(opposite.method_10160()));
      PositionType position = PositionType.SINGLE;
      boolean leftIsCabinet = left.method_27852(this) && left.method_11654(FACING) == opposite;
      boolean rightIsCabinet = right.method_27852(this) && right.method_11654(FACING) == opposite;
      if (leftIsCabinet && rightIsCabinet) {
         position = PositionType.MIDDLE;
      } else if (leftIsCabinet) {
         position = PositionType.RIGHT;
      } else if (rightIsCabinet) {
         position = PositionType.LEFT;
      }

      return (class_2680)((class_2680)this.method_9564().method_11657(FACING, opposite)).method_11657(POSITION, position);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, POSITION});
   }

   @NotNull
   public List<class_1799> method_9560(@NonNull class_2680 state, @NonNull class_8568 builder) {
      List<class_1799> stacks = super.method_9560(state, builder);
      class_2586 blockEntity = (class_2586)builder.method_51876(class_181.field_1228);
      if (blockEntity instanceof BarCabinetBlockEntity barCabinet) {
         class_1799 leftItem = barCabinet.getLeftItem();
         if (!leftItem.method_7960()) {
            stacks.add(leftItem.method_7972());
         }

         class_1799 rightItem = barCabinet.getRightItem();
         if (!rightItem.method_7960()) {
            stacks.add(rightItem.method_7972());
         }
      }

      return stacks;
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, @NonNull class_2680 state) {
      return new BarCabinetBlockEntity(pos, state);
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }

   @NotNull
   public class_2464 method_9604(@NonNull class_2680 state) {
      return class_2464.field_11458;
   }

   @NotNull
   public class_2680 method_9598(class_2680 state, class_2470 rot) {
      return (class_2680)state.method_11657(FACING, rot.method_10503((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   public class_2680 method_9569(class_2680 state, class_2415 mirror) {
      return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
   }
}
