package com.github.ysbbbbbb.kaleidoscopetavern.client.model.baked;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_10889;
import net.minecraft.class_2350;
import net.minecraft.class_777;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public final class RotatedBlockModelPart implements class_10889 {
   private static final double SEGMENT_RADIANS = Math.PI / 8;
   private final class_10889 delegate;
   private final float sin;
   private final float cos;

   public RotatedBlockModelPart(class_10889 delegate, int rotation) {
      this.delegate = delegate;
      double radians = rotation * (Math.PI / 8);
      this.sin = (float)Math.sin(radians);
      this.cos = (float)Math.cos(radians);
   }

   public @NonNull List<class_777> method_68509(class_2350 direction) {
      List<class_777> original = this.delegate.method_68509(direction);
      if (original.isEmpty()) {
         return original;
      }

      List<class_777> rotated = new ArrayList<>(original.size());

      for (class_777 quad : original) {
         rotated.add(this.rotateQuad(quad));
      }

      return Collections.unmodifiableList(rotated);
   }

   public boolean comp_3751() {
      return this.delegate.comp_3751();
   }

   public @NonNull class_1058 comp_3752() {
      return this.delegate.comp_3752();
   }

   private @NonNull class_777 rotateQuad(class_777 quad) {
      Vector3f p0 = this.rotateAroundY(quad.comp_5238());
      Vector3f p1 = this.rotateAroundY(quad.comp_5239());
      Vector3f p2 = this.rotateAroundY(quad.comp_5240());
      Vector3f p3 = this.rotateAroundY(quad.comp_5241());
      class_2350 rotatedDir = calculateDirection(p0, p1, p2, p3);
      return new class_777(
         p0,
         p1,
         p2,
         p3,
         quad.comp_5242(),
         quad.comp_5243(),
         quad.comp_5244(),
         quad.comp_5245(),
         quad.comp_3722(),
         rotatedDir,
         quad.comp_3724(),
         quad.comp_3725(),
         quad.comp_3726()
      );
   }

   private @NonNull Vector3f rotateAroundY(Vector3fc pos) {
      float centeredX = pos.x() - 0.5F;
      float centeredZ = pos.z() - 0.5F;
      float newX = centeredX * this.cos - centeredZ * this.sin + 0.5F;
      float newZ = centeredX * this.sin + centeredZ * this.cos + 0.5F;
      return new Vector3f(newX, pos.y(), newZ);
   }

   private static class_2350 calculateDirection(Vector3fc p0, Vector3fc p1, Vector3fc p2, Vector3fc p3) {
      Vector3f v1 = new Vector3f(p1).sub(p0);
      Vector3f v2 = new Vector3f(p2).sub(p0);
      Vector3f normal = v1.cross(v2);
      return class_2350.method_10147(normal.x(), normal.y(), normal.z());
   }
}
