package com.github.ysbbbbbb.kaleidoscopetavern.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BottleBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.StorageBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.ThrownMolotovEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModSounds;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.DrinkBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.MolotovBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_5894;
import net.minecraft.class_9904;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractStorageBlock extends class_2383 implements class_2343 {
   public static final class_2746 POWERED = class_2741.field_12484;

   public AbstractStorageBlock(class_2251 properties) {
      super(properties.method_31710(class_3620.field_15996).method_9632(2.5F).method_9626(class_2498.field_11547).method_22488().method_50013());
   }

   public AbstractStorageBlock() {
      super(class_2251.method_9637().method_31710(class_3620.field_15996).method_9632(2.5F).method_9626(class_2498.field_11547).method_22488().method_50013());
   }

   protected abstract int getClickedSlot(class_2350 var1, class_2338 var2, class_3965 var3);

   protected abstract class_243 getShootPos(class_2350 var1, class_2338 var2, int var3);

   protected abstract class_243 getMovement(class_2350 var1, class_2338 var2, int var3);

   protected abstract boolean blockListCheck(class_1799 var1);

   protected double getLocalX(class_2350 direction, class_2338 pos, class_3965 hitResult) {
      double relativeX = hitResult.method_17784().field_1352 - pos.method_10263();
      double relativeZ = hitResult.method_17784().field_1350 - pos.method_10260();

      return switch (direction) {
         case field_11043 -> 1.0 - relativeX;
         case field_11035 -> relativeX;
         case field_11034 -> 1.0 - relativeZ;
         case field_11039 -> relativeZ;
         default -> 0.5;
      };
   }

   protected double getLocalZ(class_2350 direction, class_2338 pos, class_3965 hitResult) {
      double relativeX = hitResult.method_17784().field_1352 - pos.method_10263();
      double relativeZ = hitResult.method_17784().field_1350 - pos.method_10260();

      return switch (direction) {
         case field_11043 -> relativeZ;
         case field_11035 -> 1.0 - relativeZ;
         case field_11034 -> 1.0 - relativeX;
         case field_11039 -> relativeX;
         default -> 0.5;
      };
   }

   protected class_1269 handleUse(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
      if (hand != class_1268.field_5808) {
         return class_1269.field_5811;
      }

      if (level.method_8321(pos) instanceof StorageBlockEntity storage) {
         class_1799 handItem = player.method_5998(hand);
         int clickedSlot = this.getClickedSlot((class_2350)state.method_11654(field_11177), pos, hitResult);
         if (clickedSlot == -1) {
            return class_1269.field_5811;
         } else {
            return handItem.method_7960() ? takeOut(level, pos, player, hand, storage, clickedSlot) : this.putOn(level, pos, player, storage, clickedSlot);
         }
      } else {
         return class_1269.field_5811;
      }
   }

   protected class_1269 putOn(class_1937 level, class_2338 pos, class_1657 player, StorageBlockEntity storage, int clickedSlot) {
      ItemStackHandler items = storage.getItems();
      class_1799 handItem = player.method_6047();
      BottleBlock bottleBlock = this.getBottleBlock(handItem);
      if (bottleBlock == null) {
         this.sendMessage(player, class_2561.method_43471("message.kaleidoscope_tavern.rack.not_drink"));
         return class_1269.field_5814;
      } else if (this.blockListCheck(handItem)) {
         this.sendMessage(player, class_2561.method_43471("message.kaleidoscope_tavern.rack.irregular"));
         return class_1269.field_5814;
      } else if (items.getStackInSlot(clickedSlot).method_7960()) {
         items.setStackInSlot(clickedSlot, handItem.method_7971(1));
         storage.refresh();
         level.method_45447(null, pos, class_3417.field_14574, class_3419.field_15245);
         return class_1269.field_5812;
      } else {
         return class_1269.field_5811;
      }
   }

   protected static class_1269 takeOut(class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, StorageBlockEntity storage, int clickedSlot) {
      ItemStackHandler items = storage.getItems();
      class_1799 stack = items.getStackInSlot(clickedSlot);
      if (!stack.method_7960()) {
         player.method_6122(hand, stack.method_7972());
         items.setStackInSlot(clickedSlot, class_1799.field_8037);
         storage.refresh();
         level.method_45447(null, pos, class_3417.field_14770, class_3419.field_15245);
         return class_1269.field_5812;
      } else {
         return class_1269.field_5811;
      }
   }

   @Nullable
   protected BottleBlock getBottleBlock(class_1799 stack) {
      return stack.method_7909() instanceof BottleBlockItem item && item.method_7711() instanceof BottleBlock bottleBlock ? bottleBlock : null;
   }

   protected void sendMessage(class_1657 player, class_2561 message) {
      if (player instanceof class_3222 serverPlayer) {
         serverPlayer.field_13987.method_14364(new class_5894(message));
      }
   }

   public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_9904 orientation, boolean isMoving) {
      boolean powered = level.method_49803(pos);
      boolean wasPowered = (Boolean)state.method_11654(POWERED);
      if (powered && !wasPowered) {
         this.popBottle(level, pos, state);
      }

      if (powered != wasPowered) {
         level.method_8652(pos, (class_2680)state.method_11657(POWERED, powered), 2);
      }
   }

   protected void popBottle(class_1937 level, class_2338 pos, class_2680 state) {
      if (!level.method_8608() && level.method_8321(pos) instanceof StorageBlockEntity storage) {
         ItemStackHandler var15 = storage.getItems();
         IntArrayList slots = new IntArrayList();

         for (int randomIndex = 0; randomIndex < var15.getSlots(); randomIndex++) {
            if (var15.getStackInSlot(randomIndex).method_7909() instanceof BottleBlockItem) {
               slots.add(randomIndex);
            }
         }

         if (!slots.isEmpty()) {
            int randomIndex = level.field_9229.method_43048(slots.size());
            int slot = slots.getInt(randomIndex);
            class_1799 stack = var15.getStackInSlot(slot);
            if (stack.method_7909() instanceof DrinkBlockItem drink) {
               var15.setStackInSlot(slot, class_1799.field_8037);
               storage.refresh();
               class_2350 direction = (class_2350)state.method_11654(field_11177);
               int brewLevel = BottleBlockItem.getBrewLevel(stack);
               class_243 shootPos = this.getShootPos(direction, pos, slot);
               class_243 movement = this.getMovement(direction, pos, slot);
               drink.makeThrownPotion(level, shootPos.method_10216(), shootPos.method_10214(), shootPos.method_10215(), brewLevel, null, movement);
               level.method_8396(null, pos, ModSounds.HOLDER_POP, class_3419.field_15245, 0.9F, 1.0F);
            } else {
               if (stack.method_7909() instanceof MolotovBlockItem) {
                  var15.setStackInSlot(slot, class_1799.field_8037);
                  storage.refresh();
                  class_2350 direction = (class_2350)state.method_11654(field_11177);
                  class_243 shootPos = this.getShootPos(direction, pos, slot);
                  class_243 movement = this.getMovement(direction, pos, slot);
                  ThrownMolotovEntity molotov = new ThrownMolotovEntity(level, shootPos.method_10216(), shootPos.method_10214(), shootPos.method_10215());
                  molotov.method_18799(movement);
                  level.method_8649(molotov);
               }
            }
         }
      }
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, POWERED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2350 opposite = context.method_8042().method_10153();
      boolean signal = context.method_8045().method_49803(context.method_8037());
      return (class_2680)((class_2680)this.method_9564().method_11657(field_11177, opposite)).method_11657(POWERED, signal);
   }

   public float method_9575(class_2680 state, class_1922 level, class_2338 pos) {
      return 1.0F;
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, class_8568 builder) {
      List<class_1799> stacks = super.method_9560(state, builder);
      class_2586 blockEntity = (class_2586)builder.method_51876(class_181.field_1228);
      if (blockEntity instanceof StorageBlockEntity storage) {
         ItemStackHandler items = storage.getItems();

         for (int i = 0; i < items.getSlots(); i++) {
            class_1799 stack = items.getStackInSlot(i);
            if (!stack.method_7960()) {
               stacks.add(stack);
            }
         }
      }

      return stacks;
   }
}
