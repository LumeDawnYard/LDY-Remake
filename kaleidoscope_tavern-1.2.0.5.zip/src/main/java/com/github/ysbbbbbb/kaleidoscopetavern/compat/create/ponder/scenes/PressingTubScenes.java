package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.PressingTubBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.utils.PonderBlockWrapper;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.zurrtum.create.catnip.math.Pointing;
import com.zurrtum.create.client.ponder.api.ParticleEmitter;
import com.zurrtum.create.client.ponder.api.element.ElementLink;
import com.zurrtum.create.client.ponder.api.element.EntityElement;
import com.zurrtum.create.client.ponder.api.scene.SceneBuilder;
import com.zurrtum.create.client.ponder.api.scene.SceneBuildingUtil;
import com.zurrtum.create.client.ponder.api.scene.Selection;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1452;
import net.minecraft.class_1621;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class PressingTubScenes {
   public static void introduction(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         scene.title("pressing_tub_introduction", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         Selection decoSel = util.select().fromTo(2, 1, 3, 4, 4, 4);
         PonderBlockWrapper tub = new PonderBlockWrapper(2, 1, 2, scene, util);
         class_1799 grape = new class_1799(ModItems.GRAPE);
         new class_1799(class_1802.field_8477);
         scene.world().showSection(decoSel, class_2350.field_11036);
         scene.idle(20);
         tub.showSection(class_2350.field_11035);
         scene.idle(25);
         scene.overlay().showText(40).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick().withItem(grape.method_7972());
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.addIngredient(grape.method_46651(16)));
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).rightClick();
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> {
            be.getItems().extractItem(0, 1, false);
            be.refresh();
         });
         scene.idle(25);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).withItem(grape.method_7972());
         scene.idle(45);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).rightClick().whileSneaking();
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> {
            be.getItems().extractItem(0, 64, false);
            be.refresh();
         });
         scene.idle(25);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).withItem(grape.method_7972());
         scene.idle(50);
      }
   }

   public static void pressing(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         class_1452 pig = new class_1452(class_1299.field_6093, level);
         scene.title("pressing_tub_pressing", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         Selection decoSel = util.select().fromTo(2, 1, 3, 4, 4, 4);
         PonderBlockWrapper tub = new PonderBlockWrapper(2, 1, 2, scene, util);
         class_1799 grape = new class_1799(ModItems.GRAPE);
         class_1799 diamond = new class_1799(class_1802.field_8477);
         scene.world().showSection(decoSel, class_2350.field_11036);
         scene.idle(20);
         tub.showSection(class_2350.field_11035);
         scene.idle(30);
         scene.overlay().showText(35).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick().withItem(grape.method_7972());
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.addIngredient(grape.method_46651(8)));
         scene.idle(45);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(90).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         ElementLink<EntityElement> slime = initSlime(scene, util, 1.5);

         for (int i = 0; i < 8; i++) {
            int j = i;
            scene.world().modifyEntity(slime, e -> {
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), 0.0);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
            scene.idle(1);
         }

         scene.idle(1);
         AtomicReference<Double> speed = new AtomicReference<>();
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, -speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), -speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.press(pig, 2.0F));
         emitParticles(tub.pos.method_46558(), grape.method_7972(), scene, 10, 0.05, level.method_8409());

         for (int x = 0; x < 7; x++) {
            scene.idle(1);

            for (int i = 0; i < 6; i++) {
               int j = i;
               scene.idle(1);
               scene.world().modifyEntity(slime, e -> {
                  e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, 0.0);
                  e.method_5784(class_1313.field_6308, e.method_18798());
                  e.method_5636(180.0F);
                  e.method_5847(180.0F);
               });
            }

            scene.idle(1);

            for (int i = 0; i < 6; i++) {
               int j = i;
               scene.idle(1);
               scene.world().modifyEntity(slime, e -> {
                  e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), 0.0);
                  e.method_5784(class_1313.field_6308, e.method_18798());
                  e.method_5636(180.0F);
                  e.method_5847(180.0F);
               });
            }

            tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.press(pig, 1.0F));
            emitParticles(tub.pos.method_46558(), grape.method_7972(), scene, 10, 0.05, level.method_8409());
            scene.world().modifyEntity(slime, e -> {
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(0.0F, 6);
         });
         scene.idle(6);
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(180.0F, 6);
         });
         scene.idle(6);
         scene.idle(20);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).rightClick().withItem(new class_1799(class_1802.field_8550));
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> {
            be.getFluid().drain(1000, CustomFluidTank.FluidAction.EXECUTE);
            be.refresh();
         });
         scene.idle(25);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).withItem(new class_1799(ModItems.GRAPE_BUCKET));
         scene.idle(40);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick().withItem(diamond.method_7972());
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.addIngredient(diamond.method_46651(12)));
         scene.idle(40);
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, -speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), -speed.get() * 0.8);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         tub.modifyBlockEntity(PressingTubBlockEntity.class, PressingTubBlockEntity::dropContents);
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(0.1F, 0.0, 0.14F), diamond.method_7972());
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(-0.1F, 0.0, 0.1F), diamond.method_7972());
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(0.0, 0.0, -0.14F), diamond.method_7972());
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(0.12, 0.0, 0.0), diamond.method_7972());
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(-0.14, 0.0, 0.03), diamond.method_7972());
         scene.world().createItemEntity(tub.blockSurface(class_2350.field_11036), new class_243(0.2, 0.0, -0.06F), diamond.method_7972());
         scene.idle(10);
         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(150.0F, 6);
         });
         scene.idle(25);
      }
   }

   public static void variant(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         scene.title("pressing_tub_variant", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         Selection decoSel = util.select().fromTo(4, 1, 4, 4, 4, 4);
         Selection decoSel1 = util.select().fromTo(2, 4, 3, 4, 4, 4);
         Selection mainSel = util.select().fromTo(2, 1, 2, 2, 1, 3);
         PonderBlockWrapper tub = new PonderBlockWrapper(2, 1, 2, scene, util);
         class_1799 grape = new class_1799(ModItems.GRAPE);
         class_1799 diamond = new class_1799(class_1802.field_8477);
         tub.modifyBlock(s -> (class_2680)s.method_11657(PressingTubBlock.TILT, true), false);
         scene.world().setBlock(tub.pos.method_10093(class_2350.field_11035), class_2246.field_10359.method_9564(), false);
         scene.world().showSection(decoSel, class_2350.field_11036);
         scene.world().showSection(decoSel1, class_2350.field_11036);
         scene.idle(20);
         scene.world().showSection(mainSel, class_2350.field_11035);
         scene.idle(30);
         scene.overlay().showText(40).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick().withItem(grape.method_7972());
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> be.addIngredient(grape.method_46651(8)));
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         ElementLink<EntityElement> slime = initSlime(scene, util, 1.5);
         scene.world().modifyEntity(slime, e -> {
            e.method_5814(e.method_23317(), e.method_23318(), e.method_23321() - 2.0);
            e.method_36456(0.0F);
            e.method_5636(0.0F);
            e.method_5847(0.0F);
         });

         for (int i = 0; i < 8; i++) {
            int j = i;
            scene.world().modifyEntity(slime, e -> {
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), 0.0);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
            scene.idle(1);
         }

         scene.idle(1);
         AtomicReference<Double> speed = new AtomicReference<>();
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         scene.idle(1);
         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(180.0F, 6);
         });
         scene.idle(6);
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, -speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         for (int i = 0; i < 9; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), -speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         scene.idle(1);
         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(0.0F, 6);
         });
         scene.idle(6);
         scene.idle(20);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(90).text("").pointAt(tub.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).rightClick();
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> {
            be.getItems().extractItem(0, 64, false);
            be.refresh();
         });
         scene.idle(25);
         scene.overlay().showControls(tub.blockSurface(class_2350.field_11036), Pointing.DOWN, 20).rightClick().withItem(diamond.method_7972());
         scene.idle(5);
         tub.modifyBlockEntity(PressingTubBlockEntity.class, be -> {
            be.addIngredient(diamond.method_46651(12));
            be.refresh();
         });
         scene.idle(40);
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(0.0F);
               e.method_5847(0.0F);
            });
         }

         scene.idle(1);
         scene.world().modifyEntity(slime, e -> {
            e.method_5750(new class_243(e.method_23317(), e.method_23318(), e.method_23321()));
            e.method_5683(180.0F, 6);
         });
         scene.idle(6);
         speed.set(0.0);

         for (int i = 0; i < 6; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(accelerate(speed.get(), 0.6));
               e.method_18800(0.0, jumpSpeed(j + 1) * 0.75, -speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         for (int i = 0; i < 9; i++) {
            int j = i;
            scene.idle(1);
            scene.world().modifyEntity(slime, e -> {
               speed.set(decelerate(speed.get(), 0.6));
               e.method_18800(0.0, fallingSpeed(j, 0.08, 0.98), -speed.get() * 0.7);
               e.method_5784(class_1313.field_6308, e.method_18798());
               e.method_5636(180.0F);
               e.method_5847(180.0F);
            });
         }

         scene.idle(20);
      }
   }

   private static ElementLink<EntityElement> initSlime(SceneBuilder scene, SceneBuildingUtil util, double y) {
      return scene.world().createEntity(l -> {
         class_1621 e = new class_1621(class_1299.field_6069, l);
         e.method_36456(180.0F);
         e.method_5636(180.0F);
         e.method_5847(180.0F);
         class_243 vec3 = util.grid().at(2, 1, 3).method_46558();
         e.method_5814(vec3.field_1352, vec3.field_1351 + y, vec3.field_1350);
         return e;
      });
   }

   private static double fallingSpeed(int tick, double gravity, double drag) {
      return (Math.pow(drag, tick) - 1.0) * (gravity / (1.0 - drag));
   }

   private static double jumpSpeed(int tick) {
      double speed = 0.42 * Math.pow(0.98, tick - 1) + 4.0 * Math.pow(0.98, tick) - 3.92;
      return speed <= 0.003 ? 0.0 : speed;
   }

   private static double accelerate(double pre, double drag) {
      double speed = pre * drag * 0.91 + 0.1 * Math.pow(0.6 / drag, 3.0);
      return speed <= 0.003 ? 0.0 : speed;
   }

   private static double decelerate(double pre, double drag) {
      double speed = pre * drag * 0.91;
      return speed <= 0.003 ? 0.0 : speed;
   }

   private static void emitParticles(class_243 pos, class_1799 itemStack, SceneBuilder scene, int amount, double speed, class_5819 random) {
      double angle = Math.toRadians(random.method_43048(360));
      double sin = Math.sin(angle);
      double cos = Math.cos(angle);
      class_243 motion = new class_243(speed * cos, speed, speed * sin);
      ParticleEmitter emitter = scene.effects().simpleParticleEmitter(new class_2392(class_2398.field_11218, itemStack), motion);
      scene.effects().emitParticles(pos, emitter, amount, 1);
   }
}
