package com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public interface ITapBehavior {
   static void sendParticles(class_1937 level, class_2338 tapPos) {
      if (level instanceof class_3218 serverLevel) {
         serverLevel.method_65096(
            class_2398.field_29643, tapPos.method_10263() + 0.5, tapPos.method_10264() - 0.5, tapPos.method_10260() + 0.5, 10, 0.25, 0.25, 0.25, 0.1
         );
      }
   }

   boolean isMatch(class_1937 var1, @Nullable class_1657 var2, class_2338 var3, class_2680 var4, class_2680 var5, class_2680 var6);

   @Nullable
   class_2394 onStartExtract(class_1937 var1, @Nullable class_1657 var2, class_2338 var3, class_2680 var4, class_2680 var5, class_2680 var6);

   void onEndExtract(class_1937 var1, class_2338 var2, class_2680 var3, class_2680 var4, class_2680 var5);
}
