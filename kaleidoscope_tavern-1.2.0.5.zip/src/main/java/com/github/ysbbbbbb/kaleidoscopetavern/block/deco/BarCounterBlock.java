package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.ConnectionType;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3620;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarCounterBlock extends class_2383 implements IConnectionBlock {
   public static final MapCodec<BarCounterBlock> CODEC = method_54094(BarCounterBlock::new);

   public BarCounterBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_16009)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
            .method_11657(CONNECTION, ConnectionType.SINGLE)
      );
   }

   @Override
   public boolean sameType(class_2680 state) {
      return state.method_26204() instanceof BarCounterBlock;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      blockState = this.updateShape(levelReader, blockPos, blockState, direction);
      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, CONNECTION});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2350 direction = context.method_8042().method_10153();
      ConnectionType connectionType = this.getConnectionForPlacement(context);
      return (class_2680)((class_2680)this.method_9564().method_11657(field_11177, direction)).method_11657(CONNECTION, connectionType);
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
