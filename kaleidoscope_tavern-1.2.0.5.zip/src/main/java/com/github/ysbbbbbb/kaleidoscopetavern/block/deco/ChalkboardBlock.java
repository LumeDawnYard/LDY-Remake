package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.PositionType;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.ChalkboardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2760;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class ChalkboardBlock extends class_2237 implements class_3737 {
   public static final MapCodec<ChalkboardBlock> CODEC = method_54094(ChalkboardBlock::new);
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2754<class_2760> HALF = class_2741.field_12518;
   public static final class_2754<PositionType> POSITION = class_2754.method_11850("position", PositionType.class);
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 UP_SOUTH_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 14.0, 1.0);
   public static final class_265 DOWN_SOUTH_SHAPE = class_2248.method_9541(0.0, 2.0, 0.0, 16.0, 16.0, 1.0);
   private static final class_265 UP_NORTH_SHAPE = class_2248.method_9541(0.0, 0.0, 15.0, 16.0, 14.0, 16.0);
   private static final class_265 DOWN_NORTH_SHAPE = class_2248.method_9541(0.0, 2.0, 15.0, 16.0, 16.0, 16.0);
   private static final class_265 UP_EAST_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 1.0, 14.0, 16.0);
   private static final class_265 DOWN_EAST_SHAPE = class_2248.method_9541(0.0, 2.0, 0.0, 1.0, 16.0, 16.0);
   private static final class_265 UP_WEST_SHAPE = class_2248.method_9541(15.0, 0.0, 0.0, 16.0, 14.0, 16.0);
   private static final class_265 DOWN_WEST_SHAPE = class_2248.method_9541(15.0, 2.0, 0.0, 16.0, 16.0, 16.0);

   public ChalkboardBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043))
                  .method_11657(HALF, class_2760.field_12617))
               .method_11657(POSITION, PositionType.SINGLE))
            .method_11657(WATERLOGGED, false)
      );
   }

   public @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      class_2760 half = (class_2760)state.method_11654(HALF);
      PositionType position = (PositionType)state.method_11654(POSITION);
      class_2350 facing = (class_2350)state.method_11654(FACING);
      class_2338 clickedPos;
      if (position == PositionType.SINGLE) {
         clickedPos = half == class_2760.field_12619 ? pos.method_10074() : pos;
      } else if (position == PositionType.MIDDLE) {
         clickedPos = half == class_2760.field_12619 ? pos.method_10074() : pos;
      } else if (position == PositionType.LEFT) {
         class_2338 rightPos = pos.method_10093(facing.method_10160());
         clickedPos = half == class_2760.field_12619 ? rightPos.method_10074() : rightPos;
      } else {
         class_2338 leftPos = pos.method_10093(facing.method_10170());
         clickedPos = half == class_2760.field_12619 ? leftPos.method_10074() : leftPos;
      }

      return level.method_8321(clickedPos) instanceof ChalkboardBlockEntity chalkboard
         ? TextBlockEntity.onItemUse(level, chalkboard, player, hand)
         : super.method_55765(stack, state, level, pos, player, hand, hitResult);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_1937 level = context.method_8045();
      class_3610 fluidState = context.method_8045().method_8316(pos);
      if (pos.method_10264() < level.method_31600() - 1 && level.method_8320(pos.method_10084()).method_26166(context)) {
         class_2350 clickedFace = context.method_8038();
         if (clickedFace.method_10166().method_10178()) {
            clickedFace = context.method_8042().method_10153();
         }

         return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(FACING, clickedFace)).method_11657(HALF, class_2760.field_12617))
            .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
      } else {
         return null;
      }
   }

   @NotNull
   public class_2680 method_9576(@NonNull class_1937 level, @NonNull class_2338 pos, @NonNull class_2680 state, @NonNull class_1657 player) {
      handleRemove(level, pos, state, player);
      return super.method_9576(level, pos, state, player);
   }

   public void method_9586(@NonNull class_3218 serverLevel, @NonNull class_2338 blockPos, @NonNull class_1927 explosion) {
      handleRemove(serverLevel, blockPos, serverLevel.method_8320(blockPos), null);
      super.method_9586(serverLevel, blockPos, explosion);
   }

   private static void handleRemove(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1657 player) {
      if (!world.method_8608()) {
         PositionType position = (PositionType)state.method_11654(POSITION);
         class_2350 facing = (class_2350)state.method_11654(FACING);
         class_2760 half = (class_2760)state.method_11654(HALF);
         boolean drop = player == null || !player.method_68878();
         if (position == PositionType.SINGLE) {
            class_2338 originPos = half == class_2760.field_12619 ? pos.method_10074() : pos;
            world.method_22352(originPos, drop);
            world.method_22352(originPos.method_10084(), false);
         } else {
            class_2338 originPos;
            if (position == PositionType.MIDDLE) {
               originPos = half == class_2760.field_12619 ? pos.method_10074() : pos;
            } else if (position == PositionType.LEFT) {
               class_2350 counterClockWise = facing.method_10160();
               originPos = half == class_2760.field_12619 ? pos.method_10074().method_10093(counterClockWise) : pos.method_10093(counterClockWise);
            } else {
               class_2350 clockWise = facing.method_10170();
               originPos = half == class_2760.field_12619 ? pos.method_10074().method_10093(clockWise) : pos.method_10093(clockWise);
            }

            if (facing.method_10166() == class_2351.field_11051) {
               for (int x = -1; x < 2; x++) {
                  for (int y = 0; y < 2; y++) {
                     class_2338 targetPos = originPos.method_10069(x, y, 0);
                     world.method_22352(targetPos, y != 1 && drop);
                  }
               }
            } else {
               for (int z = -1; z < 2; z++) {
                  for (int y = 0; y < 2; y++) {
                     class_2338 targetPos = originPos.method_10069(0, y, z);
                     world.method_22352(targetPos, y != 1 && drop);
                  }
               }
            }
         }
      }
   }

   public void method_9567(@NonNull class_1937 level, @NonNull class_2338 pos, class_2680 state, @Nullable class_1309 entity, @NonNull class_1799 stack) {
      class_2350 direction = (class_2350)state.method_11654(FACING);
      if (entity == null || !entity.method_5715()) {
         class_2338 left1 = pos.method_10093(direction.method_10170());
         class_2338 left2 = left1.method_10093(direction.method_10170());
         class_2680 left1State = level.method_8320(left1);
         class_2680 left2State = level.method_8320(left2);
         if (this.isMatchedChalkboard(level, left1, left1State, direction) && this.isMatchedChalkboard(level, left2, left2State, direction)) {
            this.setChalkboard(level, pos, state, PositionType.RIGHT);
            this.setChalkboard(level, left1, left1State, PositionType.MIDDLE);
            this.setChalkboard(level, left2, left2State, PositionType.LEFT);
            level.method_8544(pos);
            level.method_8544(left2);
            class_2586 be = this.method_10123(left1, level.method_8320(left1));
            if (be != null) {
               level.method_8438(be);
            }

            return;
         }

         class_2338 right1 = pos.method_10093(direction.method_10160());
         class_2680 right1State = level.method_8320(right1);
         if (this.isMatchedChalkboard(level, left1, left1State, direction) && this.isMatchedChalkboard(level, right1, right1State, direction)) {
            this.setChalkboard(level, pos, state, PositionType.MIDDLE);
            this.setChalkboard(level, left1, left1State, PositionType.LEFT);
            this.setChalkboard(level, right1, right1State, PositionType.RIGHT);
            level.method_8544(left1);
            level.method_8544(right1);
            class_2586 be = this.method_10123(pos, level.method_8320(pos));
            if (be != null) {
               level.method_8438(be);
            }

            return;
         }

         class_2338 right2 = right1.method_10093(direction.method_10160());
         class_2680 right2State = level.method_8320(right2);
         if (this.isMatchedChalkboard(level, right1, right1State, direction) && this.isMatchedChalkboard(level, right2, right2State, direction)) {
            this.setChalkboard(level, pos, state, PositionType.LEFT);
            this.setChalkboard(level, right1, right1State, PositionType.MIDDLE);
            this.setChalkboard(level, right2, right2State, PositionType.RIGHT);
            level.method_8544(pos);
            level.method_8544(right2);
            class_2586 be = this.method_10123(right1, level.method_8320(right1));
            if (be != null) {
               level.method_8438(be);
            }

            return;
         }
      }

      class_2680 blockState = (class_2680)((class_2680)state.method_11657(class_2741.field_12508, level.method_22351(pos)))
         .method_11657(HALF, class_2760.field_12619);
      level.method_8501(pos.method_10084(), blockState);
   }

   private boolean isMatchedChalkboard(class_1937 level, class_2338 pos, class_2680 state, class_2350 direction) {
      boolean stateMatch = state.method_27852(this)
         && state.method_11654(HALF) == class_2760.field_12617
         && state.method_11654(POSITION) == PositionType.SINGLE
         && state.method_11654(FACING) == direction;
      return stateMatch && level.method_8321(pos) instanceof ChalkboardBlockEntity chalkboard ? StringUtils.isBlank(chalkboard.getText()) : stateMatch;
   }

   private void setChalkboard(class_1937 level, class_2338 pos, class_2680 state, PositionType position) {
      boolean waterAt = level.method_22351(pos);
      class_2680 blockState = (class_2680)((class_2680)state.method_11657(class_2741.field_12508, waterAt)).method_11657(POSITION, position);
      level.method_8501(pos, (class_2680)blockState.method_11657(HALF, class_2760.field_12617));
      level.method_8501(pos.method_10084(), (class_2680)blockState.method_11657(HALF, class_2760.field_12619));
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, class_2680 state) {
      class_2760 half = (class_2760)state.method_11654(HALF);
      PositionType position = (PositionType)state.method_11654(POSITION);
      if (half == class_2760.field_12617 && position == PositionType.SINGLE) {
         return ChalkboardBlockEntity.small(pos, state);
      } else {
         return half == class_2760.field_12617 && position == PositionType.MIDDLE ? ChalkboardBlockEntity.large(pos, state) : null;
      }
   }

   @Nullable
   public <T extends class_2586> class_5558<T> method_31645(@NonNull class_1937 level, @NonNull class_2680 state, @NonNull class_2591<T> type) {
      return method_31618(type, ModBlocks.CHALKBOARD_BE, TextBlockEntity::tick);
   }

   @NotNull
   public class_2464 method_9604(class_2680 state) {
      class_2760 half = (class_2760)state.method_11654(HALF);
      PositionType position = (PositionType)state.method_11654(POSITION);
      if (half == class_2760.field_12617 && position == PositionType.SINGLE) {
         return class_2464.field_11458;
      } else {
         return half == class_2760.field_12617 && position == PositionType.MIDDLE ? class_2464.field_11458 : class_2464.field_11455;
      }
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      class_2350 facing = (class_2350)state.method_11654(FACING);
      class_2760 half = (class_2760)state.method_11654(HALF);
      if (facing == class_2350.field_11043) {
         return half == class_2760.field_12617 ? DOWN_NORTH_SHAPE : UP_NORTH_SHAPE;
      } else if (facing == class_2350.field_11035) {
         return half == class_2760.field_12617 ? DOWN_SOUTH_SHAPE : UP_SOUTH_SHAPE;
      } else if (facing == class_2350.field_11039) {
         return half == class_2760.field_12617 ? DOWN_WEST_SHAPE : UP_WEST_SHAPE;
      } else {
         return half == class_2760.field_12617 ? DOWN_EAST_SHAPE : UP_EAST_SHAPE;
      }
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, @NonNull class_8568 lootParamsBuilder) {
      return state.method_11654(HALF) == class_2760.field_12617 ? super.method_9560(state, lootParamsBuilder) : Collections.emptyList();
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, HALF, POSITION, WATERLOGGED});
   }

   @NotNull
   public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
      return (class_2680)pState.method_11657(FACING, pRot.method_10503((class_2350)pState.method_11654(FACING)));
   }

   @NotNull
   public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
      return pState.method_26186(pMirror.method_10345((class_2350)pState.method_11654(FACING)));
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }
}
