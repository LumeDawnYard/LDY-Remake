package com.github.ysbbbbbb.kaleidoscopetavern.item;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jspecify.annotations.NonNull;

public class SandwichBoardBlockItem extends class_1747 {
   private final List<class_1792> transformItems;

   public SandwichBoardBlockItem(class_2248 block, class_1793 properties, class_1792... transformItems) {
      super(block, properties.method_63684("block.kaleidoscope_tavern.sandwich_board"));
      this.transformItems = List.of(transformItems);
   }

   public void method_67187(
      @NonNull class_1799 itemStack,
      @NonNull class_9635 tooltipContext,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 tooltipFlag
   ) {
      if (!this.transformItems.isEmpty()) {
         consumer.accept(this.transformItems.getFirst().method_7854().method_63015().method_27661().method_27692(class_124.field_1080));
      }
   }
}
