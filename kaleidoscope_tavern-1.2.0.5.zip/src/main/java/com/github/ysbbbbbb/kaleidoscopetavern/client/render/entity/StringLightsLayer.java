package com.github.ysbbbbbb.kaleidoscopetavern.client.render.entity;

import com.github.ysbbbbbb.kaleidoscopetavern.item.StringLightsBlockItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public class StringLightsLayer<S extends class_10034, M extends class_572<? super S>> extends class_3887<S, M> {
   private final class_10442 itemModelResolver = class_310.method_1551().method_65386();

   public StringLightsLayer(class_3883<S, M> renderLayerParent) {
      super(renderLayerParent);
   }

   public void submit(@NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, int i, S entityRenderState, float f, float g) {
      class_1799 stack = entityRenderState.field_53418;
      class_10444 itemStackRenderState = new class_10444();
      if (stack.method_7909() instanceof StringLightsBlockItem && this.method_17165() instanceof class_572<?> humanoidModel) {
         poseStack.method_22903();
         humanoidModel.field_3391.method_22703(poseStack);
         poseStack.method_46416(0.0F, -0.1875F, -0.4375F);
         poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
         poseStack.method_22905(-0.625F, -0.625F, 0.625F);
         this.itemModelResolver.method_65598(itemStackRenderState, stack, class_811.field_4316, null, null, 0);
         itemStackRenderState.method_65604(poseStack, submitNodeCollector, i, class_4608.field_21444, 0);
         poseStack.method_22909();
      }
   }
}
