package com.github.ysbbbbbb.kaleidoscopetavern.network.message;

import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.Context;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_8710.class_9154;
import org.jetbrains.annotations.NotNull;

public record DrinkEffectSyncS2CMessage(List<DrinkEffectData> entries) implements class_8710 {
   public static final class_9154<DrinkEffectSyncS2CMessage> TYPE = new class_9154(class_2960.method_60655("kaleidoscope_tavern", "drink_effect_sync"));
   public static final class_9139<class_9129, DrinkEffectSyncS2CMessage> STREAM_CODEC = DrinkEffectData.STREAM_CODEC
      .method_56433(class_9135.method_56363())
      .method_56432(DrinkEffectSyncS2CMessage::new, DrinkEffectSyncS2CMessage::entries);

   public static DrinkEffectSyncS2CMessage fromServer() {
      List<DrinkEffectData> copyData = List.copyOf(DrinkEffectDataReloadListener.INSTANCE.values());
      return new DrinkEffectSyncS2CMessage(copyData);
   }

   @NotNull
   public class_9154<? extends class_8710> method_56479() {
      return TYPE;
   }

   @Environment(EnvType.CLIENT)
   public static void onHandle(DrinkEffectSyncS2CMessage message, Context context) {
      DrinkEffectDataReloadListener.INSTANCE.clear();

      for (DrinkEffectData data : message.entries()) {
         DrinkEffectDataReloadListener.INSTANCE.put(data.item(), data);
      }
   }
}
