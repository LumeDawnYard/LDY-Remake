package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.entity.ThrownMolotovEntity;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import net.minecraft.class_4970.class_2251;
import org.jspecify.annotations.NonNull;

public class MolotovBlock extends BottleBlock {
   public MolotovBlock(class_2251 properties) {
      super(properties.method_22488().method_9618().method_9631(s -> 14).method_50012(class_3619.field_15971).method_9626(class_2498.field_11537), false);
   }

   @Override
   public void method_19286(class_1937 level, @NonNull class_2680 state, @NonNull class_3965 hit, @NonNull class_1676 projectile) {
      if (!level.method_8608()) {
         class_2338 pos = hit.method_17777();
         ThrownMolotovEntity molotov = new ThrownMolotovEntity(level, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
         level.method_8649(molotov);
      }

      super.method_19286(level, state, hit, projectile);
   }
}
