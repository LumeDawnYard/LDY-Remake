package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_1322.class_1323;

public class LongReachEffect extends BaseEffect {
   public LongReachEffect(int color) {
      super(color);
      this.method_5566(class_5134.field_47758, class_2960.method_60655("kaleidoscope_tavern", "long_reach_block"), 3.0, class_1323.field_6328);
      this.method_5566(class_5134.field_47759, class_2960.method_60655("kaleidoscope_tavern", "long_reach_entity"), 3.0, class_1323.field_6328);
   }
}
