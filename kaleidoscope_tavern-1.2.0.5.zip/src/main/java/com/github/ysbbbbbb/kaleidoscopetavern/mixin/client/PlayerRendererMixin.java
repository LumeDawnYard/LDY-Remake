package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.client.event.PlayerRenderEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_11901;
import net.minecraft.class_591;
import net.minecraft.class_922;
import net.minecraft.class_5617.class_5618;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_1007.class)
public abstract class PlayerRendererMixin<AvatarEntity extends class_11890 & class_11901> extends class_922<AvatarEntity, class_10055, class_591> {
   public PlayerRendererMixin(class_5618 context, class_591 entityModel, float f) {
      super(context, entityModel, f);
   }

   @Inject(method = "method_62604", at = @At("TAIL"))
   private void extractRenderState(AvatarEntity avatar, class_10055 avatarRenderState, float f, CallbackInfo ci) {
      if (avatar.method_6059(ModEffects.GRASS_STEALTH)) {
         avatar.method_5648(PlayerRenderEvent.shouldCancelRender(avatar));
      }
   }
}
