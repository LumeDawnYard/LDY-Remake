package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class CircularRackBlockEntity extends StorageBlockEntity {
   public CircularRackBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.CIRCULAR_RACK_BE, pos, state, 6);
   }
}
