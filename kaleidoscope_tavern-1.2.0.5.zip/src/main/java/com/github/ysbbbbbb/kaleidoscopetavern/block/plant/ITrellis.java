package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.TrellisType;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_4538;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;

public interface ITrellis {
   class_2754<TrellisType> TYPE = class_2754.method_11850("type", TrellisType.class);
   class_265 SINGLE_SHAPE = class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0);
   class_265 NORTH_SOUTH_SHAPE = class_2248.method_9541(6.0, 6.0, 0.0, 10.0, 10.0, 16.0);
   class_265 EAST_WEST_SHAPE = class_2248.method_9541(0.0, 6.0, 6.0, 16.0, 10.0, 10.0);
   class_265 CROSS_NORTH_SOUTH_SHAPE = class_259.method_1084(SINGLE_SHAPE, NORTH_SOUTH_SHAPE);
   class_265 CROSS_EAST_WEST_SHAPE = class_259.method_1084(SINGLE_SHAPE, EAST_WEST_SHAPE);
   class_265 CROSS_UP_DOWN_SHAPE = class_259.method_1084(NORTH_SOUTH_SHAPE, EAST_WEST_SHAPE);
   class_265 SIX_DIRECTION_SHAPE = class_259.method_17786(SINGLE_SHAPE, new class_265[]{NORTH_SOUTH_SHAPE, EAST_WEST_SHAPE});
   class_265 SINGLE_OUTLINE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);
   class_265 NORTH_SOUTH_OUTLINE = class_2248.method_9541(4.0, 4.0, 0.0, 12.0, 12.0, 16.0);
   class_265 EAST_WEST_OUTLINE = class_2248.method_9541(0.0, 4.0, 4.0, 16.0, 12.0, 12.0);
   class_265 CROSS_NORTH_SOUTH_OUTLINE = class_259.method_1084(SINGLE_OUTLINE, NORTH_SOUTH_OUTLINE);
   class_265 CROSS_EAST_WEST_OUTLINE = class_259.method_1084(SINGLE_OUTLINE, EAST_WEST_OUTLINE);
   class_265 CROSS_UP_DOWN_OUTLINE = class_259.method_1084(NORTH_SOUTH_OUTLINE, EAST_WEST_OUTLINE);
   class_265 SIX_DIRECTION_OUTLINE = class_259.method_17786(SINGLE_OUTLINE, new class_265[]{NORTH_SOUTH_OUTLINE, EAST_WEST_OUTLINE});

   static boolean axisHasTrellis(class_4538 level, class_2338 pos, class_2351 axis) {
      class_2350 positive = class_2350.method_10169(axis, class_2352.field_11056);
      class_2680 positiveState = level.method_8320(pos.method_10093(positive));
      if (positiveState.method_26204() instanceof ITrellis trellis) {
         return trellis.sameType(positiveState);
      } else {
         class_2350 negative = class_2350.method_10169(axis, class_2352.field_11060);
         class_2680 negativeState = level.method_8320(pos.method_10093(negative));
         return negativeState.method_26204() instanceof ITrellis trellis ? trellis.sameType(negativeState) : false;
      }
   }

   static TrellisType getTypeForPlacement(boolean xHas, boolean yHas, boolean zHas, class_2351 clickAxis) {
      if (xHas && yHas && zHas) {
         return TrellisType.SIX_DIRECTION;
      }

      if (xHas && yHas) {
         return TrellisType.CROSS_EAST_WEST;
      }

      if (yHas && zHas) {
         return TrellisType.CROSS_NORTH_SOUTH;
      }

      if (xHas && zHas) {
         return TrellisType.CROSS_UP_DOWN;
      }

      if (xHas) {
         return switch (clickAxis) {
            case field_11048 -> TrellisType.EAST_WEST;
            case field_11052 -> TrellisType.CROSS_EAST_WEST;
            case field_11051 -> TrellisType.CROSS_UP_DOWN;
            default -> throw new MatchException(null, null);
         };
      } else if (yHas) {
         return switch (clickAxis) {
            case field_11048 -> TrellisType.CROSS_EAST_WEST;
            case field_11052 -> TrellisType.SINGLE;
            case field_11051 -> TrellisType.CROSS_NORTH_SOUTH;
            default -> throw new MatchException(null, null);
         };
      } else if (zHas) {
         return switch (clickAxis) {
            case field_11048 -> TrellisType.CROSS_UP_DOWN;
            case field_11052 -> TrellisType.CROSS_NORTH_SOUTH;
            case field_11051 -> TrellisType.NORTH_SOUTH;
            default -> throw new MatchException(null, null);
         };
      } else {
         return switch (clickAxis) {
            case field_11048 -> TrellisType.EAST_WEST;
            case field_11052 -> TrellisType.SINGLE;
            case field_11051 -> TrellisType.NORTH_SOUTH;
            default -> throw new MatchException(null, null);
         };
      }
   }

   static TrellisType updateType(TrellisType current, boolean xHas, boolean yHas, boolean zHas) {
      return switch (current) {
         case SINGLE -> xHas && zHas
            ? TrellisType.SIX_DIRECTION
            : (xHas ? TrellisType.CROSS_EAST_WEST : (zHas ? TrellisType.CROSS_NORTH_SOUTH : TrellisType.SINGLE));
         case NORTH_SOUTH -> xHas && yHas
            ? TrellisType.SIX_DIRECTION
            : (xHas ? TrellisType.CROSS_UP_DOWN : (yHas ? TrellisType.CROSS_NORTH_SOUTH : TrellisType.NORTH_SOUTH));
         case EAST_WEST -> yHas && zHas
            ? TrellisType.SIX_DIRECTION
            : (yHas ? TrellisType.CROSS_EAST_WEST : (zHas ? TrellisType.CROSS_UP_DOWN : TrellisType.EAST_WEST));
         case CROSS_NORTH_SOUTH -> xHas
            ? TrellisType.SIX_DIRECTION
            : (zHas && yHas ? TrellisType.CROSS_NORTH_SOUTH : (zHas ? TrellisType.NORTH_SOUTH : TrellisType.SINGLE));
         case CROSS_EAST_WEST -> zHas
            ? TrellisType.SIX_DIRECTION
            : (xHas && yHas ? TrellisType.CROSS_EAST_WEST : (xHas ? TrellisType.EAST_WEST : TrellisType.SINGLE));
         case CROSS_UP_DOWN -> yHas
            ? TrellisType.SIX_DIRECTION
            : (xHas && zHas ? TrellisType.CROSS_UP_DOWN : (xHas ? TrellisType.EAST_WEST : TrellisType.NORTH_SOUTH));
         case SIX_DIRECTION -> xHas && yHas && zHas
            ? TrellisType.SIX_DIRECTION
            : (
               xHas && yHas
                  ? TrellisType.CROSS_EAST_WEST
                  : (
                     yHas && zHas
                        ? TrellisType.CROSS_NORTH_SOUTH
                        : (xHas && zHas ? TrellisType.CROSS_UP_DOWN : (xHas ? TrellisType.EAST_WEST : (zHas ? TrellisType.NORTH_SOUTH : TrellisType.SINGLE)))
                  )
            );
      };
   }

   boolean sameType(class_2680 var1);

   default class_265 collisionShape(TrellisType type) {
      return switch (type) {
         case SINGLE -> SINGLE_SHAPE;
         case NORTH_SOUTH -> NORTH_SOUTH_SHAPE;
         case EAST_WEST -> EAST_WEST_SHAPE;
         case CROSS_NORTH_SOUTH -> CROSS_NORTH_SOUTH_SHAPE;
         case CROSS_EAST_WEST -> CROSS_EAST_WEST_SHAPE;
         case CROSS_UP_DOWN -> CROSS_UP_DOWN_SHAPE;
         case SIX_DIRECTION -> SIX_DIRECTION_SHAPE;
      };
   }

   default class_265 selectShape(TrellisType type) {
      return switch (type) {
         case SINGLE -> SINGLE_OUTLINE;
         case NORTH_SOUTH -> NORTH_SOUTH_OUTLINE;
         case EAST_WEST -> EAST_WEST_OUTLINE;
         case CROSS_NORTH_SOUTH -> CROSS_NORTH_SOUTH_OUTLINE;
         case CROSS_EAST_WEST -> CROSS_EAST_WEST_OUTLINE;
         case CROSS_UP_DOWN -> CROSS_UP_DOWN_OUTLINE;
         case SIX_DIRECTION -> SIX_DIRECTION_OUTLINE;
      };
   }
}
