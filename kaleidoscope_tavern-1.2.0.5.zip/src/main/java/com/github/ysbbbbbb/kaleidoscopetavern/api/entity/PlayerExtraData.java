package com.github.ysbbbbbb.kaleidoscopetavern.api.entity;

import net.minecraft.class_2487;

public interface PlayerExtraData {
   default class_2487 kaleidoscope_tavern$getPersistentData() {
      throw new RuntimeException("This should be overridden via mixin...");
   }

   default void kaleidoscope_tavern$setPersistentData(class_2487 compoundTag) {
      throw new RuntimeException("This should be overridden via mixin...");
   }
}
