package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModCreativeTabs {
   private static final class_2960 MAIN_ICON_ID = class_2960.method_60655("kaleidoscope_tavern", "wine");
   private static final class_2960 DECO_ICON_ID = class_2960.method_60655("kaleidoscope_tavern", "stepladder");
   private static final class_5321<class_1761> TAVERN_MAIN_TAB = class_5321.method_29179(
      class_7924.field_44688, class_2960.method_60655("kaleidoscope_tavern", "tavern_main")
   );
   private static final class_5321<class_1761> TAVERN_DECO_TAB = class_5321.method_29179(
      class_7924.field_44688, class_2960.method_60655("kaleidoscope_tavern", "tavern_deco")
   );

   public static void registerTabs() {
      class_2378.method_39197(
         class_7923.field_44687,
         TAVERN_MAIN_TAB,
         FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("item_group.kaleidoscope_tavern.tavern_main.name"))
            .method_47320(() -> ((class_1792)class_7923.field_41178.method_63535(MAIN_ICON_ID)).method_7854())
            .method_47317((par, output) -> {
               output.method_45421(ModItems.GRAPEVINE);
               output.method_45421(ModItems.GRAPE);
               output.method_45421(ModItems.ICE_GRAPE);
               output.method_45421(ModItems.GOLD_GRAPE);
               output.method_45421(ModItems.GREEN_GRAPE);
               output.method_45421(ModItems.TRELLIS);
               output.method_45421(ModItems.PRESSING_TUB);
               output.method_45421(ModItems.BARREL);
               output.method_45421(ModItems.TAP);
               output.method_45421(ModItems.SHAKER);
               output.method_45421(ModItems.GRAPE_BUCKET);
               output.method_45421(ModItems.ICE_GRAPE_BUCKET);
               output.method_45421(ModItems.GOLD_GRAPE_BUCKET);
               output.method_45421(ModItems.GREEN_GRAPE_BUCKET);
               output.method_45421(ModItems.SWEET_BERRIES_BUCKET);
               output.method_45421(ModItems.GLOW_BERRIES_BUCKET);
               output.method_45421(ModItems.EMPTY_BOTTLE);
               output.method_45421(ModItems.EMPTY_GLASSWARE);
               output.method_45421(ModItems.MOLOTOV);
               output.method_45421(ModItems.WATERMELON_JUICE);
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.VINEGAR));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.SAKURA_WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.CHAMPAGNE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.BRANDY));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.CARIGNAN));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.ICE_WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.POLARIS_SWEET_WHITE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.SHERRY));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.MOTHER_SNOW));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.MINERS_STAR));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.HONEY_WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.MADAME_SHEXIANG));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.SUNSET_GLOW));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.SAUVIGNON_BLANC_DRY_WHITE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.RIESLING_DRY_WHITE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.LUMINOUS_BRIDE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.GLOWFLOWER_BREW));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.PLUM_WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.SWEET_BERRY_WINE));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.RED_QUEEN));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.VODKA));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.WHISKEY));
               output.method_45420(BottleBlockItem.getMaxLevelDrink(ModItems.RUM));
               output.method_45421(ModItems.SIGNATURE_COCKTAIL);
               output.method_45421(ModItems.MYSTERY_COCKTAIL);
               output.method_45421(ModItems.WHITE_LADY);
               output.method_45421(ModItems.EMERALD);
               output.method_45421(ModItems.BRASS_HEART);
               output.method_45421(ModItems.GODFATHER);
               output.method_45421(ModItems.GRASSHOPPER);
               output.method_45421(ModItems.SCREWDRIVER);
               output.method_45421(ModItems.MOJITO);
               output.method_45421(ModItems.ALLIUM_GARDEN);
               output.method_45421(ModItems.DEPTH_CHARGE);
               output.method_45421(ModItems.NETHER_SPECIAL);
               output.method_45421(ModItems.BLOODY_MARY);
               output.method_45421(ModItems.SCULK_SPECIAL);
            })
            .method_47324()
      );
      class_2378.method_39197(
         class_7923.field_44687,
         TAVERN_DECO_TAB,
         FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("item_group.kaleidoscope_tavern.tavern_deco.name"))
            .method_47320(() -> ((class_1792)class_7923.field_41178.method_63535(DECO_ICON_ID)).method_7854())
            .method_47317((par, output) -> {
               output.method_45421(ModItems.BAR_CABINET);
               output.method_45421(ModItems.GLASS_BAR_CABINET);
               output.method_45421(ModItems.CELLAR_CABINET);
               output.method_45421(ModItems.BAR_COUNTER);
               output.method_45421(ModItems.TABLE);
               output.method_45421(ModItems.TILTED_RACK);
               output.method_45421(ModItems.CIRCULAR_RACK);
               output.method_45421(ModItems.HOLDER);
               output.method_45421(ModItems.GLASSWARE_HOLDER);
               output.method_45421(ModItems.STEPLADDER);
               output.method_45421(ModItems.STRING_LIGHTS_COLORLESS);
               output.method_45421(ModItems.STRING_LIGHTS_WHITE);
               output.method_45421(ModItems.STRING_LIGHTS_LIGHT_GRAY);
               output.method_45421(ModItems.STRING_LIGHTS_GRAY);
               output.method_45421(ModItems.STRING_LIGHTS_BLACK);
               output.method_45421(ModItems.STRING_LIGHTS_BROWN);
               output.method_45421(ModItems.STRING_LIGHTS_RED);
               output.method_45421(ModItems.STRING_LIGHTS_ORANGE);
               output.method_45421(ModItems.STRING_LIGHTS_YELLOW);
               output.method_45421(ModItems.STRING_LIGHTS_LIME);
               output.method_45421(ModItems.STRING_LIGHTS_GREEN);
               output.method_45421(ModItems.STRING_LIGHTS_CYAN);
               output.method_45421(ModItems.STRING_LIGHTS_LIGHT_BLUE);
               output.method_45421(ModItems.STRING_LIGHTS_BLUE);
               output.method_45421(ModItems.STRING_LIGHTS_PURPLE);
               output.method_45421(ModItems.STRING_LIGHTS_MAGENTA);
               output.method_45421(ModItems.STRING_LIGHTS_PINK);
               output.method_45421(ModItems.BELL_PENDANT_LAMP);
               output.method_45421(ModItems.YELLOW_PENDANT_LAMP);
               output.method_45421(ModItems.BLUE_PENDANT_LAMP);
               output.method_45421(ModItems.WHITE_SOFA);
               output.method_45421(ModItems.LIGHT_GRAY_SOFA);
               output.method_45421(ModItems.GRAY_SOFA);
               output.method_45421(ModItems.BLACK_SOFA);
               output.method_45421(ModItems.BROWN_SOFA);
               output.method_45421(ModItems.RED_SOFA);
               output.method_45421(ModItems.ORANGE_SOFA);
               output.method_45421(ModItems.YELLOW_SOFA);
               output.method_45421(ModItems.LIME_SOFA);
               output.method_45421(ModItems.GREEN_SOFA);
               output.method_45421(ModItems.CYAN_SOFA);
               output.method_45421(ModItems.LIGHT_BLUE_SOFA);
               output.method_45421(ModItems.BLUE_SOFA);
               output.method_45421(ModItems.PURPLE_SOFA);
               output.method_45421(ModItems.MAGENTA_SOFA);
               output.method_45421(ModItems.PINK_SOFA);
               output.method_45421(ModItems.WHITE_BAR_STOOL);
               output.method_45421(ModItems.LIGHT_GRAY_BAR_STOOL);
               output.method_45421(ModItems.GRAY_BAR_STOOL);
               output.method_45421(ModItems.BLACK_BAR_STOOL);
               output.method_45421(ModItems.BROWN_BAR_STOOL);
               output.method_45421(ModItems.RED_BAR_STOOL);
               output.method_45421(ModItems.ORANGE_BAR_STOOL);
               output.method_45421(ModItems.YELLOW_BAR_STOOL);
               output.method_45421(ModItems.LIME_BAR_STOOL);
               output.method_45421(ModItems.GREEN_BAR_STOOL);
               output.method_45421(ModItems.CYAN_BAR_STOOL);
               output.method_45421(ModItems.LIGHT_BLUE_BAR_STOOL);
               output.method_45421(ModItems.BLUE_BAR_STOOL);
               output.method_45421(ModItems.PURPLE_BAR_STOOL);
               output.method_45421(ModItems.MAGENTA_BAR_STOOL);
               output.method_45421(ModItems.PINK_BAR_STOOL);
               output.method_45421(ModItems.BASE_SANDWICH_BOARD);
               output.method_45421(ModItems.GRASS_SANDWICH_BOARD);
               output.method_45421(ModItems.PINK_PETALS_SANDWICH_BOARD);
               output.method_45421(ModItems.SUNFLOWER_SANDWICH_BOARD);
               output.method_45421(ModItems.POPPY_SANDWICH_BOARD);
               output.method_45421(ModItems.CORNFLOWER_SANDWICH_BOARD);
               output.method_45421(ModItems.ORCHID_SANDWICH_BOARD);
               output.method_45421(ModItems.ALLIUM_SANDWICH_BOARD);
               output.method_45421(ModItems.AZURE_BLUET_SANDWICH_BOARD);
               output.method_45421(ModItems.TULIP_SANDWICH_BOARD);
               output.method_45421(ModItems.TORCHFLOWER_SANDWICH_BOARD);
               output.method_45421(ModItems.WITHER_ROSE_SANDWICH_BOARD);
               output.method_45421(ModItems.PEONY_SANDWICH_BOARD);
               output.method_45421(ModItems.PITCHER_PLANT_SANDWICH_BOARD);
               output.method_45421(ModItems.YSBB_PAINTING);
               output.method_45421(ModItems.TARTARIC_ACID_PAINTING);
               output.method_45421(ModItems.CR019_PAINTING);
               output.method_45421(ModItems.UNKNOWN_PAINTING);
               output.method_45421(ModItems.MASTER_MARISA_PAINTING);
               output.method_45421(ModItems.NIGHT_EPIPHANY_PAINTING);
               output.method_45421(ModItems.SON_OF_MAN_PAINTING);
               output.method_45421(ModItems.DAVID_PAINTING);
               output.method_45421(ModItems.GIRL_WITH_PEARL_EARRING_PAINTING);
               output.method_45421(ModItems.STARRY_NIGHT_PAINTING);
               output.method_45421(ModItems.VAN_GOGH_SELF_PORTRAIT_PAINTING);
               output.method_45421(ModItems.FATHER_PAINTING);
               output.method_45421(ModItems.GREAT_WAVE_PAINTING);
               output.method_45421(ModItems.MONA_LISA_PAINTING);
               output.method_45421(ModItems.MONDRIAN_PAINTING);
               output.method_45421(ModItems.CHALKBOARD);
               output.method_45421(ModItems.SAKURA_INCENSE);
               output.method_45421(ModItems.PINE_INCENSE);
               output.method_45421(ModItems.GINKGO_INCENSE);
               output.method_45421(ModItems.SPORE_INCENSE);
               output.method_45421(ModItems.CATNIP_INCENSE);
               output.method_45421(ModItems.SNOW_INCENSE);
               output.method_45421(ModItems.BUTTERFLY_INCENSE);
               output.method_45421(ModItems.FIREFLY_INCENSE);
            })
            .method_47324()
      );
   }
}
