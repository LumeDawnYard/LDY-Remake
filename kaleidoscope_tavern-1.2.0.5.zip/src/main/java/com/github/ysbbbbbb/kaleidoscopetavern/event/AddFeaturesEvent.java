package com.github.ysbbbbbb.kaleidoscopetavern.event;

import com.github.ysbbbbbb.kaleidoscopetavern.worldgen.WildGrapevineDecorator;
import com.google.common.collect.ImmutableList;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.EndDataPackReload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.ServerStarted;
import net.minecraft.class_2975;
import net.minecraft.class_4643;
import net.minecraft.class_5321;
import net.minecraft.class_6808;
import net.minecraft.class_7924;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7225.class_7226;

public class AddFeaturesEvent {
   public static void addFeatures() {
      ServerLifecycleEvents.SERVER_STARTED
         .register((ServerStarted)server -> applyWildGrapevineDecorators(server.method_30611().method_30530(class_7924.field_41239)));
      ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((EndDataPackReload)(server, manager, success) -> {
         if (success) {
            applyWildGrapevineDecorators(server.method_30611().method_30530(class_7924.field_41239));
         }
      });
   }

   private static void applyWildGrapevineDecorators(class_7226<class_2975<?, ?>> registryLookup) {
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35917, 0.002F, 3, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35918, 1.0F, 1, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35922, 0.002F, 3, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35923, 0.02F, 2, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35924, 0.05F, 1, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35888, 0.002F, 3, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35889, 0.02F, 2, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35890, 0.05F, 1, 3);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35891, 0.02F, 5, 7);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35892, 0.2F, 5, 7);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35893, 0.5F, 5, 7);
      addWildGrapevineTreeDeco(registryLookup, class_6808.field_35894, 1.0F, 5, 7);
   }

   private static void addWildGrapevineTreeDeco(
      class_7226<class_2975<?, ?>> registryLookup, class_5321<class_2975<?, ?>> id, float probability, int maxVineCount, int vineChainLength
   ) {
      class_6883<class_2975<?, ?>> holder = (class_6883<class_2975<?, ?>>)registryLookup.method_46746(id).orElse(null);
      if (holder != null) {
         class_2975<?, ?> configuredFeature = (class_2975<?, ?>)holder.comp_349();
         if (configuredFeature.comp_333() instanceof class_4643 treeConfiguration) {
            if (treeConfiguration.field_21290.stream().anyMatch(decorator -> decorator instanceof WildGrapevineDecorator)) {
               return;
            }

            treeConfiguration.field_21290 = ImmutableList.builder()
               .addAll(treeConfiguration.field_21290)
               .add(new WildGrapevineDecorator(probability, maxVineCount, vineChainLength))
               .build();
         }
      }
   }
}
