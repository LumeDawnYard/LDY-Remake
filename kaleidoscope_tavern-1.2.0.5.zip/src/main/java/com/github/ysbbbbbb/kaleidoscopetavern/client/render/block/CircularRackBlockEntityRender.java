package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.CircularRackBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.CircularRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class CircularRackBlockEntityRender extends StorageBlockEntityRender<CircularRackBlockEntity, StorageBlockEntityRenderState> {
   public CircularRackBlockEntityRender(class_5615 context) {
      super(context);
   }

   public void extractRenderState(
      @NonNull CircularRackBlockEntity blockEntity,
      @NonNull StorageBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.extractRenderState(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(CircularRackBlock.field_11177);
   }

   public @NonNull StorageBlockEntityRenderState createRenderState() {
      return new StorageBlockEntityRenderState();
   }

   @Override
   public void submit(
      StorageBlockEntityRenderState state, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      poseStack.method_22903();
      this.applyFacingRotation(state.facing, poseStack);

      for (int i = 0; i < state.items.size(); i++) {
         class_1799 stack = state.items.get(i);
         if (!stack.method_7960()) {
            double x = 0.0;
            double z = 0.0;
            double yRot = 0.0;
            switch (i) {
               case 0:
                  x = 0.5;
                  z = 0.125;
                  yRot = 0.0;
                  break;
               case 1:
                  x = 0.875;
                  z = 0.3125;
                  yRot = 22.5;
                  break;
               case 2:
                  x = 0.875;
                  z = 0.6875;
                  yRot = -22.5;
                  break;
               case 3:
                  x = 0.5;
                  z = 0.875;
                  yRot = 180.0;
                  break;
               case 4:
                  x = 0.125;
                  z = 0.6875;
                  yRot = 157.5;
                  break;
               case 5:
                  x = 0.125;
                  z = 0.3125;
                  yRot = -157.5;
            }

            this.renderStack(stack, poseStack, submitNodeCollector, state.field_62676, x, 0.125, z, 0.82F, yRot, 0.0);
         }
      }

      poseStack.method_22909();
   }
}
