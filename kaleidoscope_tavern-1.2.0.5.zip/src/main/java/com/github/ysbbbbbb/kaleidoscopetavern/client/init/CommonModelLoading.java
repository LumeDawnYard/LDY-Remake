package com.github.ysbbbbbb.kaleidoscopetavern.client.init;

import com.github.ysbbbbbb.kaleidoscopetavern.api.client.IModelModifyRotationAfterBake;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.baked.RotatedBlockModelPart;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier.AfterBakeBlock;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier.AfterBakeBlock.Context;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_5819;

@Environment(EnvType.CLIENT)
public final class CommonModelLoading {
   public static void init() {
      ModelLoadingPlugin.register(
         pluginContext -> pluginContext.modifyBlockModelAfterBake()
            .register(ModelModifier.WRAP_PHASE, (AfterBakeBlock)(model, context) -> wrapModel(model, context))
      );
   }

   private static class_1087 wrapModel(class_1087 model, Context context) {
      if (model != null && context != null && context.state() != null) {
         if (context.state().method_26204() instanceof IModelModifyRotationAfterBake<?> bake) {
            class_2769<Integer> rotationProperty = bake.getRotationProperty();
            if (rotationProperty != class_2741.field_12532) {
               return model;
            }

            Integer rotation = (Integer)context.state().method_11654(rotationProperty);
            return rotation != null && rotation > 0 ? new CommonModelLoading.RotatedBlockStateModel(model, rotation) : model;
         } else {
            return model;
         }
      } else {
         return model;
      }
   }

   private CommonModelLoading() {
   }

   private record RotatedBlockStateModel(class_1087 delegate, int rotation) implements class_1087 {
      public void method_68513(class_5819 randomSource, List<class_10889> list) {
         for (class_10889 part : this.delegate.method_68512(randomSource)) {
            list.add(new RotatedBlockModelPart(part, this.rotation));
         }
      }

      public class_1058 method_68511() {
         return this.delegate.method_68511();
      }
   }
}
