package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11954;
import net.minecraft.class_1799;
import net.minecraft.class_2350;

@Environment(EnvType.CLIENT)
public class BarCabinetBlockEntityRenderState extends class_11954 {
   public class_2350 facing;
   public class_1799 leftItem = class_1799.field_8037;
   public class_1799 rightItem = class_1799.field_8037;
   public boolean isSingle = true;
}
