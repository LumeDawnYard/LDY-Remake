package com.github.ysbbbbbb.kaleidoscopetavern.util.fluids;

import java.util.Optional;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_3611;
import net.minecraft.class_6903;
import net.minecraft.class_7225.class_7874;
import org.jetbrains.annotations.Nullable;

public class CustomFluidTank extends SingleVariantStorage<FluidVariant> {
   public static final int MB_PER_BUCKET = 1000;
   private static final String TAG_VARIANT = "variant";
   private static final String TAG_VARIANT_LEGACY = "fluidVariant";
   private static final String TAG_AMOUNT = "amount";
   private final long capacity;
   private final Runnable onContentsChanged;

   public CustomFluidTank(long capacity, Runnable onContentsChanged) {
      this.capacity = capacity;
      this.onContentsChanged = onContentsChanged;
      this.variant = FluidVariant.blank();
      this.amount = 0L;
   }

   protected FluidVariant getBlankVariant() {
      return FluidVariant.blank();
   }

   protected long getCapacity(FluidVariant variant) {
      return this.capacity;
   }

   protected void onFinalCommit() {
      if (this.onContentsChanged != null) {
         this.onContentsChanged.run();
      }
   }

   public FluidVariant getFluidVariant() {
      return (FluidVariant)this.variant;
   }

   public class_3611 getFluid() {
      return ((FluidVariant)this.variant).getFluid();
   }

   public int getFluidAmountMb() {
      if (this.amount <= 0L) {
         return 0;
      }

      long mb = this.amount * 1000L / 81000L;
      return mb <= 0L ? 0 : (int)Math.min(2147483647L, mb);
   }

   public long getFluidAmountTransfer() {
      return this.amount;
   }

   public long getCapacityTransfer() {
      return this.capacity;
   }

   @Deprecated
   public class_2487 serializeNBT(class_7874 registries) {
      class_2487 tag = new class_2487();
      return this.writeToNBT(registries, tag);
   }

   public void writeToNBT(class_11372 output) {
      FluidVariant variantToWrite = this.amount > 0L && !((FluidVariant)this.variant).isBlank() ? (FluidVariant)this.variant : FluidVariant.blank();
      output.method_71477("variant", FluidVariant.CODEC, variantToWrite);
      output.method_71477("fluidVariant", FluidVariant.CODEC, variantToWrite);
      output.method_71466("amount", Math.max(0L, this.amount));
   }

   @Deprecated
   public class_2487 writeToNBT(class_7874 registries, class_2487 tag) {
      FluidVariant variantToWrite = this.amount > 0L && !((FluidVariant)this.variant).isBlank() ? (FluidVariant)this.variant : FluidVariant.blank();
      class_2487 variantTag = encodeVariant(registries, variantToWrite);
      tag.method_10566("variant", variantTag);
      tag.method_10566("fluidVariant", variantTag);
      tag.method_10544("amount", Math.max(0L, this.amount));
      return tag;
   }

   public void readFromNBT(class_11368 input) {
      if (input.contains("variant")) {
         this.extract(input, "variant");
      } else {
         this.extract(input, "fluidVariant");
      }
   }

   private void extract(class_11368 input, String tg) {
      input.method_71426(tg, FluidVariant.CODEC).ifPresent(loadedVariant -> {
         long loadedAmount = input.method_71440("amount").orElse(0L);
         if (loadedAmount > 0L && !loadedVariant.isBlank()) {
            this.variant = loadedVariant;
            this.amount = Math.min(loadedAmount, this.capacity);
         } else {
            this.variant = FluidVariant.blank();
            this.amount = 0L;
         }
      });
   }

   @Deprecated
   public void readFromNBT(class_7874 registries, class_2487 tag) {
      Optional<class_2487> variantTag;
      if (tag.method_10545("variant")) {
         variantTag = tag.method_10562("variant");
      } else {
         variantTag = tag.method_10562("fluidVariant");
      }

      FluidVariant loadedVariant = decodeVariant(registries, variantTag.orElse(null));
      long loadedAmount = tag.method_10537("amount").orElse(0L);
      if (loadedAmount > 0L && !loadedVariant.isBlank()) {
         this.variant = loadedVariant;
         this.amount = Math.min(loadedAmount, this.capacity);
      } else {
         this.variant = FluidVariant.blank();
         this.amount = 0L;
      }
   }

   public long fill(FluidVariant resource, long maxAmount, CustomFluidTank.FluidAction action) {
      if (resource == null || resource.isBlank() || maxAmount <= 0L) {
         return 0L;
      }

      if (this.amount > 0L && !((FluidVariant)this.variant).isBlank()) {
         if (!((FluidVariant)this.variant).equals(resource)) {
            return 0L;
         }

         long space = this.capacity - this.amount;
         if (space <= 0L) {
            return 0L;
         }

         long filled = Math.min(space, maxAmount);
         if (filled > 0L && action.execute()) {
            this.amount += filled;
            if (this.onContentsChanged != null) {
               this.onContentsChanged.run();
            }
         }

         return filled;
      } else {
         long filled = Math.min(this.capacity, maxAmount);
         if (filled > 0L && action.execute()) {
            this.variant = resource;
            this.amount = filled;
            if (this.onContentsChanged != null) {
               this.onContentsChanged.run();
            }
         }

         return filled;
      }
   }

   public long fill(FluidVariant resource, int maxAmount, CustomFluidTank.FluidAction action) {
      return this.fill(resource, (long)maxAmount, action);
   }

   public long drain(FluidVariant resource, long maxAmount, CustomFluidTank.FluidAction action) {
      if (resource == null || resource.isBlank() || maxAmount <= 0L) {
         return 0L;
      } else if (this.amount > 0L && !((FluidVariant)this.variant).isBlank()) {
         return !((FluidVariant)this.variant).equals(resource) ? 0L : this.drain(maxAmount, action);
      } else {
         return 0L;
      }
   }

   public long drain(long maxAmount, CustomFluidTank.FluidAction action) {
      if (maxAmount > 0L && this.amount > 0L && !((FluidVariant)this.variant).isBlank()) {
         long drained = Math.min(maxAmount, this.amount);
         if (drained > 0L && action.execute()) {
            this.amount -= drained;
            if (this.amount <= 0L) {
               this.amount = 0L;
               this.variant = FluidVariant.blank();
            }

            if (this.onContentsChanged != null) {
               this.onContentsChanged.run();
            }
         }

         return drained;
      } else {
         return 0L;
      }
   }

   public long drain(int maxAmount, CustomFluidTank.FluidAction action) {
      return this.drain((long)maxAmount, action);
   }

   private static class_2487 encodeVariant(class_7874 registries, FluidVariant variant) {
      class_6903<class_2520> ops = class_6903.method_46632(class_2509.field_11560, registries);
      class_2520 encoded = (class_2520)FluidVariant.CODEC.encodeStart(ops, variant).result().orElse(new class_2487());
      return encoded instanceof class_2487 compound ? compound : new class_2487();
   }

   private static FluidVariant decodeVariant(class_7874 registries, @Nullable class_2487 tag) {
      if (tag == null) {
         return FluidVariant.blank();
      }

      class_6903<class_2520> ops = class_6903.method_46632(class_2509.field_11560, registries);
      return FluidVariant.CODEC.parse(ops, tag).result().orElse(FluidVariant.blank());
   }

   public enum FluidAction {
      EXECUTE,
      SIMULATE;

      public boolean execute() {
         return this == EXECUTE;
      }
   }
}
