package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import com.github.ysbbbbbb.kaleidoscopetavern.game.grape.GoldGrapePlant;
import com.github.ysbbbbbb.kaleidoscopetavern.game.grape.IceGrapePlant;
import com.github.ysbbbbbb.kaleidoscopetavern.game.grape.NormalGrapePlant;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.CancellableEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.IEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public final class PlantGrapeEvent extends CancellableEvent {
   private final class_2680 state;
   private final class_1937 level;
   private final class_2338 pos;
   private final class_1657 player;
   private final class_1268 hand;
   private final class_3965 hitResult;

   public static void register() {
      CALLBACK.register((IEvent.Callback<IEvent>)event -> {
         if (event instanceof PlantGrapeEvent plantGrapeEvent) {
            GoldGrapePlant.onPlant(plantGrapeEvent);
            IceGrapePlant.onPlant(plantGrapeEvent);
            NormalGrapePlant.onPlant(plantGrapeEvent);
         }
      });
   }

   public PlantGrapeEvent(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
      this.state = state;
      this.level = level;
      this.pos = pos;
      this.player = player;
      this.hand = hand;
      this.hitResult = hitResult;
   }

   public class_2680 state() {
      return this.state;
   }

   public class_1937 level() {
      return this.level;
   }

   public class_2338 pos() {
      return this.pos;
   }

   public class_1657 player() {
      return this.player;
   }

   public class_1268 hand() {
      return this.hand;
   }

   public class_3965 hitResult() {
      return this.hitResult;
   }

   @Override
   public void post() {
      ((IEvent.Callback)CALLBACK.invoker()).post(this);
   }
}
