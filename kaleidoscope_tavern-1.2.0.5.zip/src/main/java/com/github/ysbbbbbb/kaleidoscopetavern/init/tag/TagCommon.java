package com.github.ysbbbbbb.kaleidoscopetavern.init.tag;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public interface TagCommon {
   class_6862<class_1792> FRUITS_GRAPES = itemTag("fruits/grapes");
   class_6862<class_1792> FRUITS = dietTag("fruits");
   class_6862<class_1792> GRAINS = dietTag("grains");
   class_6862<class_1792> PROTEINS = dietTag("proteins");
   class_6862<class_1792> SUGARS = dietTag("sugars");
   class_6862<class_1792> DIET_VEGETABLES = dietTag("vegetables");
   class_6862<class_1792> SPRING_CROPS = seasonsItemTag("spring_crops");
   class_6862<class_1792> SUMMER_CROPS = seasonsItemTag("summer_crops");
   class_6862<class_1792> AUTUMN_CROPS = seasonsItemTag("autumn_crops");
   class_6862<class_1792> WINTER_CROPS = seasonsItemTag("winter_crops");
   class_6862<class_2248> SPRING_CROPS_BLOCK = seasonsBlockTag("spring_crops");
   class_6862<class_2248> SUMMER_CROPS_BLOCK = seasonsBlockTag("summer_crops");
   class_6862<class_2248> AUTUMN_CROPS_BLOCK = seasonsBlockTag("autumn_crops");
   class_6862<class_2248> WINTER_CROPS_BLOCK = seasonsBlockTag("winter_crops");
   class_6862<class_2248> DRY_AVERAGE = eclipticSeasonsTag("crops/dry_average");
   class_6862<class_2248> AVERAGE_MOIST = eclipticSeasonsTag("crops/average_moist");
   class_6862<class_2248> MOIST_HUMID = eclipticSeasonsTag("crops/moist_humid");
   class_6862<class_2248> HUMID_HUMID = eclipticSeasonsTag("crops/humid_humid");
   class_6862<class_2248> CARRYON_BLOCK_BLACKLIST = class_6862.method_40092(class_7924.field_41254, class_2960.method_60654("carryon:block_blacklist"));

   static class_6862<class_1792> itemTag(String name) {
      return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", name));
   }

   static class_6862<class_1792> dietTag(String name) {
      return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("diet", name));
   }

   static class_6862<class_1792> seasonsItemTag(String name) {
      return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("sereneseasons", name));
   }

   static class_6862<class_2248> seasonsBlockTag(String name) {
      return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("sereneseasons", name));
   }

   static class_6862<class_2248> blockTag(String name) {
      return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("forge", name));
   }

   static class_6862<class_2248> eclipticSeasonsTag(String name) {
      return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("eclipticseasons", name));
   }
}
