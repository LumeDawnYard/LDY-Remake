package com.github.ysbbbbbb.kaleidoscopetavern.event;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.LivingChangeTargetEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.effect.GrassStealthEffect;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class ChangeTargetEvent {
   public static void onTarget(LivingChangeTargetEvent event) {
      class_1309 newTarget = event.getNewTarget();
      if (newTarget != null && newTarget.method_5805()) {
         if (newTarget.method_6059(ModEffects.GRASS_STEALTH) && newTarget.method_5715()) {
            class_1937 level = newTarget.method_73183();
            class_2338 pos = newTarget.method_24515();
            class_2338 abovePos = pos.method_10084();
            if (GrassStealthEffect.notInGrassStealthPlant(level, pos) && GrassStealthEffect.notInGrassStealthPlant(level, abovePos)) {
               return;
            }

            event.setCanceled(true);
         }
      }
   }
}
