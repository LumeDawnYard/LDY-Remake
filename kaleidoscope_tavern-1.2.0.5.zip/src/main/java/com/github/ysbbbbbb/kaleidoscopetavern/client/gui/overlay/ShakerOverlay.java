package com.github.ysbbbbbb.kaleidoscopetavern.client.gui.overlay;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.ShakerBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ColorUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_10799;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
public class ShakerOverlay {
   private static final class_2960 IMG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/shaker.png");
   private static final class_2960 ICON = class_2960.method_60655("kaleidoscope_tavern", "gui/rhombus");

   public static void register() {
      HudRenderCallback.EVENT.register(ShakerOverlay::render);
   }

   public static void render(class_332 guiGraphics, class_9779 deltaTracker) {
      class_310 minecraft = class_310.method_1551();
      if (minecraft.field_1761 != null && minecraft.field_1761.method_2920() != class_1934.field_9219) {
         class_746 player = minecraft.field_1724;
         if (player != null) {
            int screenWidth = guiGraphics.method_51421();
            int screenHeight = guiGraphics.method_51443();
            float partialTick = deltaTracker.method_60637(false);
            renderShakerBlockTips(guiGraphics, screenWidth, screenHeight, minecraft, player);
            renderShakerProgress(guiGraphics, screenWidth, screenHeight, player, partialTick);
         }
      }
   }

   private static void renderShakerProgress(class_332 guiGraphics, int screenWidth, int screenHeight, class_746 player, float partialTick) {
      int remainingTicks = player.method_6014();
      if (remainingTicks > 0 && player.method_6030().method_31574(ModItems.SHAKER)) {
         guiGraphics.method_25290(class_10799.field_56883, IMG, screenWidth / 2 - 91, screenHeight / 2 + 32, 0.0F, 0.0F, 181, 17, 256, 256);
         int offsetX = (int)Math.round((player.method_6048() + partialTick) * 1.5);
         guiGraphics.method_25290(class_10799.field_56883, IMG, screenWidth / 2 - 91 + offsetX, screenHeight / 2 + 26, 181.0F, 0.0F, 11, 13, 256, 256);
      }
   }

   private static void renderShakerBlockTips(class_332 guiGraphics, int screenWidth, int screenHeight, class_310 minecraft, class_746 player) {
      if (minecraft.field_1765 instanceof class_3965 result) {
         class_1937 level = player.method_73183();
         class_2338 blockPos = result.method_17777();
         class_2680 blockState = player.method_73183().method_8320(blockPos);
         if (blockState.method_27852(ModBlocks.SHAKER)) {
            if (level.method_8321(blockPos) instanceof ShakerBlockEntity shaker) {
               class_327 font = class_310.method_1551().field_1772;
               int x = screenWidth / 2 - 28;
               int y = screenHeight / 2 + 26;
               ItemStackHandler storage = shaker.getStorage();

               for (int i = 0; i < storage.getSlots(); i++) {
                  class_1799 stack = storage.getStackInSlot(i);
                  if (!stack.method_7960()) {
                     class_124 chatFormatting = ColorUtils.ITEM_COLOR_CACHE.apply(stack.method_7909());
                     if (chatFormatting == class_124.field_1070) {
                        guiGraphics.method_51445(stack, x, y);
                        guiGraphics.method_51431(font, stack, x, y);
                     } else {
                        int color = Objects.requireNonNull(chatFormatting.method_532()) | 0xFF000000;
                        renderIcon(guiGraphics, x, y + 6, color);
                     }

                     x += 20;
                  }
               }
            }
         }
      }
   }

   private static void renderIcon(class_332 pGuiGraphics, int x, int y, int color) {
      class_1059 atlas = (class_1059)class_310.method_1551().method_1531().method_4619(class_1059.field_5275);
      class_1058 sprite = atlas.method_4608(ICON);
      pGuiGraphics.method_52710(class_10799.field_56883, sprite, x, y, 16, 16, color);
   }
}
