package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.TrellisType;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.EventHooks;
import java.util.function.Supplier;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class GrapevineTrellisBlock extends class_2248 implements class_3737, ITrellis, class_2256 {
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_2758 AGE = class_2741.field_12497;
   public static final int MAX_AGE = 3;
   public static final class_2350[] CHECK_DIRECTION = new class_2350[]{
      class_2350.field_11036, class_2350.field_11034, class_2350.field_11039, class_2350.field_11035, class_2350.field_11043
   };
   private final GrowPerTickProbability probability;
   private final Supplier<class_2680> grapeCrop;

   public GrapevineTrellisBlock(class_2251 properties, GrowPerTickProbability probability, Supplier<class_2680> grapeCrop) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_9640()
            .method_22488()
            .method_50012(class_3619.field_15971)
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(TYPE, TrellisType.SINGLE)).method_11657(AGE, 0))
            .method_11657(WATERLOGGED, false)
      );
      this.probability = probability;
      this.grapeCrop = grapeCrop;
   }

   @Deprecated(since = "1.1.0")
   public GrapevineTrellisBlock(class_2251 properties) {
      this(properties, (state, level, pos, random) -> 0.25F, ModBlocks.GRAPE_CROP::method_9564);
   }

   @NotNull
   public class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      class_1799 itemInHand = player.method_5998(hand);
      if (!itemInHand.method_31574(class_1802.field_8868)) {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }

      class_2680 newState = (class_2680)((class_2680)ModBlocks.TRELLIS.method_9564().method_11657(TYPE, (TrellisType)state.method_11654(TYPE)))
         .method_11657(WATERLOGGED, (Boolean)state.method_11654(WATERLOGGED));
      level.method_8501(pos, newState);
      class_2248.method_9577(level, pos, ModItems.GRAPEVINE.method_7854());
      itemInHand.method_7970(1, player, PortHelper.getSlotForHand(hand));
      player.method_43077(class_3417.field_20611);
      return class_1269.field_5812;
   }

   protected @NonNull class_2680 method_9559(
      class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      boolean xHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11048);
      boolean yHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11052);
      boolean zHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11051);
      TrellisType trellisType = ITrellis.updateType((TrellisType)blockState.method_11654(TYPE), xHas, yHas, zHas);
      blockState = (class_2680)blockState.method_11657(TYPE, trellisType);
      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Override
   public boolean sameType(class_2680 state) {
      return state.method_27852(ModBlocks.TRELLIS) || state.method_26164(TagMod.GRAPEVINE_TRELLISES);
   }

   public void method_9514(@NonNull class_2680 state, @NonNull class_3218 level, @NonNull class_2338 pos, class_5819 random) {
      if (EventHooks.onCropsGrowPre(level, pos, state, random.method_43058() < this.probability.getProbability(state, level, pos, random))) {
         this.doGrow(level, pos, state);
      }
   }

   public boolean isMaxAge(class_2680 state) {
      return (Integer)state.method_11654(AGE) >= 3;
   }

   public boolean canGrowInto(class_2680 checkState) {
      return checkState.method_27852(ModBlocks.TRELLIS) && !(Boolean)checkState.method_11654(TrellisBlock.WAXED);
   }

   public class_2680 getGrowIntoState(class_2350 direction, class_2680 checkState) {
      TrellisType type = checkState.method_28500(TYPE).orElse(TrellisType.SINGLE);
      boolean waterlogged = checkState.method_28500(WATERLOGGED).orElse(false);
      int age = direction == class_2350.field_11036 ? 0 : 3;
      return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(TYPE, type)).method_11657(AGE, age)).method_11657(WATERLOGGED, waterlogged);
   }

   public boolean canGrowGrape(class_4538 level, class_2338 pos) {
      return pos.method_10264() < level.method_31607() + 1 ? false : level.method_8320(pos.method_10074()).method_26215();
   }

   public boolean canGrow(class_4538 level, class_2338 pos, class_2680 state) {
      if (state.method_11654(TYPE) == TrellisType.SINGLE && !this.isMaxAge(state)) {
         return true;
      }

      if (this.isMaxAge(state)) {
         for (class_2350 direction : CHECK_DIRECTION) {
            class_2338 checkPos = pos.method_10093(direction);
            class_2680 checkState = level.method_8320(checkPos);
            if (this.canGrowInto(checkState)) {
               return true;
            }
         }

         return this.canGrowGrape(level, pos);
      } else {
         return true;
      }
   }

   public void doGrow(class_1937 level, class_2338 pos, class_2680 state) {
      if (state.method_11654(TYPE) == TrellisType.SINGLE && !this.isMaxAge(state)) {
         level.method_8501(pos, (class_2680)state.method_28493(AGE));
         EventHooks.onCropsGrowPost(level, pos, state);
      } else {
         if (this.isMaxAge(state)) {
            for (class_2350 direction : CHECK_DIRECTION) {
               class_2338 checkPos = pos.method_10093(direction);
               class_2680 checkState = level.method_8320(checkPos);
               if (this.canGrowInto(checkState)) {
                  class_2680 growIntoState = this.getGrowIntoState(direction, checkState);
                  level.method_8501(checkPos, growIntoState);
                  EventHooks.onCropsGrowPost(level, checkPos, checkState);
                  return;
               }
            }

            if (this.canGrowGrape(level, pos)) {
               level.method_8501(pos.method_10074(), this.grapeCrop.get());
               EventHooks.onCropsGrowPost(level, pos.method_10074(), state);
            }
         } else {
            level.method_8501(pos, (class_2680)state.method_11657(AGE, 3));
            EventHooks.onCropsGrowPost(level, pos, state);
         }
      }
   }

   public boolean method_9651(@NonNull class_4538 level, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return this.canGrow(level, pos, state);
   }

   public boolean method_9650(@NonNull class_1937 level, @NonNull class_5819 random, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return true;
   }

   public void method_9652(@NonNull class_3218 level, @NonNull class_5819 random, @NonNull class_2338 pos, @NonNull class_2680 state) {
      this.doGrow(level, pos, state);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{TYPE, AGE, WATERLOGGED});
   }

   @NotNull
   public class_265 method_9549(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      return this.collisionShape((TrellisType)state.method_11654(TYPE));
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      return this.selectShape((TrellisType)state.method_11654(TYPE));
   }

   protected @NonNull class_1799 method_9574(@NonNull class_4538 levelReader, @NonNull class_2338 blockPos, @NonNull class_2680 blockState, boolean bl) {
      return ModItems.GRAPEVINE.method_7854();
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }
}
