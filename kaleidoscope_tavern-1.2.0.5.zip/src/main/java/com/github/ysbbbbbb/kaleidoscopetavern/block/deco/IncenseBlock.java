package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.IncenseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class IncenseBlock extends class_2383 implements class_2343, class_3737 {
   private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 7.0, 11.0);
   private static final MapCodec<IncenseBlock> CODEC = method_54094(p -> new IncenseBlock(() -> class_2398.field_43379, () -> class_2398.field_43379));
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   private static final class_2746 POWERED = class_2741.field_12484;
   private static final class_2746 OPEN = class_2741.field_12537;
   private final Supplier<? extends class_2394> smallParticle;
   private final Supplier<? extends class_2394> largeParticle;
   private final double largeParticleYOffset;
   private final double largeParticleYRange;

   public IncenseBlock(Supplier<? extends class_2394> smallParticle, Supplier<? extends class_2394> largeParticle) {
      this(smallParticle, largeParticle, -2.0, 16.0);
   }

   public IncenseBlock(
      Supplier<? extends class_2394> smallParticle, Supplier<? extends class_2394> largeParticle, double largeParticleYOffset, double largeParticleYRange
   ) {
      super(class_2251.method_9637().method_9618().method_22488().method_50012(class_3619.field_15971).method_9626(class_2498.field_42771));
      this.smallParticle = smallParticle;
      this.largeParticle = largeParticle;
      this.largeParticleYOffset = largeParticleYOffset;
      this.largeParticleYRange = largeParticleYRange;
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
                  .method_11657(OPEN, false))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public IncenseBlock(class_2251 properties, Supplier<? extends class_2394> smallParticle, Supplier<? extends class_2394> largeParticle) {
      this(properties, smallParticle, largeParticle, -2.0, 16.0);
   }

   public IncenseBlock(
      class_2251 properties,
      Supplier<? extends class_2394> smallParticle,
      Supplier<? extends class_2394> largeParticle,
      double largeParticleYOffset,
      double largeParticleYRange
   ) {
      super(properties.method_9618().method_22488().method_50012(class_3619.field_15971).method_9626(class_2498.field_42771));
      this.smallParticle = smallParticle;
      this.largeParticle = largeParticle;
      this.largeParticleYOffset = largeParticleYOffset;
      this.largeParticleYRange = largeParticleYRange;
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
                  .method_11657(OPEN, false))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   public boolean method_9558(@NonNull class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
      class_2338 blockPos2 = blockPos.method_10074();
      class_2680 blockState2 = levelReader.method_8320(blockPos2);
      return this.canSurviveOn(levelReader, blockPos2, blockState2);
   }

   private boolean canSurviveOn(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState) {
      return blockState.method_26206(blockGetter, blockPos, class_2350.field_11036);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return !blockState.method_26184(levelReader, blockPos)
         ? class_2246.field_10124.method_9564()
         : super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   protected static <E extends class_2586, A extends class_2586> class_5558<A> createTickerHelper(
      class_2591<A> serverType, class_2591<E> clientType, class_5558<? super E> ticker
   ) {
      return clientType == serverType ? ticker : null;
   }

   @Nullable
   public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
      return !level.method_8608() && state.method_11654(OPEN) ? createTickerHelper(type, ModBlocks.INCENSE_BE, IncenseBlockEntity::serverTick) : null;
   }

   public @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      state = (class_2680)state.method_28493(OPEN);
      level.method_8652(pos, state, 2);
      this.playSound(state, level, pos);
      return level.method_8608() ? class_1269.field_5812 : class_1269.field_52422;
   }

   private void playSound(class_2680 state, class_1937 level, class_2338 pos) {
      class_3414 event = state.method_11654(OPEN) ? class_3417.field_14791 : class_3417.field_14954;
      level.method_45447(null, pos, event, class_3419.field_15245);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, OPEN, POWERED, WATERLOGGED});
   }

   public class_2680 method_9605(class_1750 context) {
      class_2350 opposite = context.method_8042().method_10153();
      boolean signal = context.method_8045().method_49803(context.method_8037());
      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      return (class_2680)((class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, opposite)).method_11657(OPEN, signal))
            .method_11657(WATERLOGGED, hasWater))
         .method_11657(POWERED, signal);
   }

   public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_9904 orientation, boolean isMoving) {
      if (!level.method_8608()) {
         boolean powered = level.method_49803(pos);
         if (powered != (Boolean)state.method_11654(POWERED)) {
            if ((Boolean)state.method_11654(OPEN) != powered) {
               state = (class_2680)state.method_11657(OPEN, powered);
               this.playSound(state, level, pos);
            }

            level.method_8652(pos, (class_2680)state.method_11657(POWERED, powered), 2);
         }
      }
   }

   public @NonNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
      return SHAPE;
   }

   public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
      boolean open = (Boolean)state.method_11654(OPEN);
      double x = pos.method_10263() + 0.5;
      double y = pos.method_10264() + 0.5;
      double z = pos.method_10260() + 0.5;
      if (random.method_43048(3) == 0) {
         double dx = random.method_43059() * 0.01;
         double dy = 0.02 + random.method_43058() * 0.01;
         double dz = random.method_43059() * 0.01;
         level.method_8406(this.smallParticle.get(), x, y, z, dx, dy, dz);
      }

      if (open) {
         for (int i = 0; i < 5; i++) {
            double ox = x + (random.method_43058() - 0.5) * 32.0;
            double oy = y + this.largeParticleYOffset + random.method_43058() * this.largeParticleYRange;
            double oz = z + (random.method_43058() - 0.5) * 32.0;
            level.method_8406(this.largeParticle.get(), ox, oy, oz, 0.0, 0.0, 0.0);
         }
      }
   }

   @Nullable
   public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
      return new IncenseBlockEntity(pPos, pState);
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
