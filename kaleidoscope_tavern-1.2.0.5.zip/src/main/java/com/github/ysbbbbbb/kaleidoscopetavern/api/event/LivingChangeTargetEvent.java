package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import com.github.ysbbbbbb.kaleidoscopetavern.event.ChangeTargetEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.CancellableEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.IEvent;
import net.minecraft.class_1309;

public class LivingChangeTargetEvent extends CancellableEvent {
   private final class_1309 entity;
   private final LivingChangeTargetEvent.ILivingTargetType targetType;
   private final class_1309 originalTarget;
   private class_1309 newTarget;

   public LivingChangeTargetEvent(class_1309 entity, class_1309 originalTarget, LivingChangeTargetEvent.ILivingTargetType targetType) {
      this.entity = entity;
      this.originalTarget = originalTarget;
      this.newTarget = originalTarget;
      this.targetType = targetType;
   }

   public class_1309 getNewTarget() {
      return this.newTarget;
   }

   public void setNewTarget(class_1309 newTarget) {
      this.newTarget = newTarget;
   }

   public LivingChangeTargetEvent.ILivingTargetType getTargetType() {
      return this.targetType;
   }

   public class_1309 getOriginalTarget() {
      return this.originalTarget;
   }

   public static void register() {
      CALLBACK.register((IEvent.Callback<IEvent>)event -> {
         if (event instanceof LivingChangeTargetEvent livingChangeTargetEvent) {
            ChangeTargetEvent.onTarget(livingChangeTargetEvent);
         }
      });
   }

   @Override
   public void post() {
      ((IEvent.Callback)CALLBACK.invoker()).post(this);
   }

   public interface ILivingTargetType {
   }

   public enum LivingTargetType implements LivingChangeTargetEvent.ILivingTargetType {
      MOB_TARGET,
      BEHAVIOR_TARGET;
   }
}
