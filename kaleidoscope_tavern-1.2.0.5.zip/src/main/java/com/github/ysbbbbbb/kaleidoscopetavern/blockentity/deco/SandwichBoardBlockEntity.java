package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class SandwichBoardBlockEntity extends TextBlockEntity {
   public SandwichBoardBlockEntity(class_2338 pos, class_2680 blockState) {
      super(ModBlocks.SANDWICH_BOARD_BE, pos, blockState);
   }

   @Override
   public int getMaxTextLength() {
      return 320;
   }
}
