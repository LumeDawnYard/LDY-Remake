package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11954;
import net.minecraft.class_2350;

@Environment(EnvType.CLIENT)
public class BarrelBlockEntityRenderState extends class_11954 {
   public class_2350 facing;
   public boolean isOpen = true;
   public CustomFluidTank fluidTank;
   public float time;
   public long seed;
   public List<BarrelBlockEntityRenderState.ItemEntry> itemStates = Collections.emptyList();

   public static class ItemEntry {
      public final class_10444 itemState = new class_10444();
      public int renderCount;
      public int slotIndex;
   }
}
