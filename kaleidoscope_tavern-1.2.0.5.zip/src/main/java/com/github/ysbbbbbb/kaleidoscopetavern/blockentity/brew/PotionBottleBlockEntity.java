package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public class PotionBottleBlockEntity extends BaseBlockEntity {
   private static final String ITEM_KEY = "Item";
   private class_1799 potionStack = class_1799.field_8037;

   public PotionBottleBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.POTION_BOTTLE_BE, pos, state);
   }

   public void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.potionStack = valueInput.method_71426("Item", class_1799.field_24671).orElse(class_1799.field_8037);
      this.refreshClientRendering();
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      valueOutput.method_71468("Item", class_1799.field_24671, this.potionStack);
   }

   private void refreshClientRendering() {
      if (this.field_11863 != null && this.field_11863.method_8608()) {
         class_2680 state = this.method_11010();
         this.field_11863.method_8413(this.field_11867, state, state, 8);
      }
   }

   public class_1799 getPotionStack() {
      return this.potionStack;
   }

   public void setPotionStack(class_1799 stack) {
      this.potionStack = stack.method_46651(1);
      this.refresh();
      this.refreshClientRendering();
   }
}
