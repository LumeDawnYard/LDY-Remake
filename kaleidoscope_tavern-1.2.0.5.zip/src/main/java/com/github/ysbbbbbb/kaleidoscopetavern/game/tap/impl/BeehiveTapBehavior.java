package com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.TapBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4481;
import org.jetbrains.annotations.Nullable;

public class BeehiveTapBehavior implements ITapBehavior {
   @Override
   public boolean isMatch(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      int honeyLevel = (Integer)sourceState.method_11654(class_4481.field_20420);
      return honeyLevel <= 0 ? false : destinationState.method_27852(ModBlocks.EMPTY_BOTTLE);
   }

   @Nullable
   @Override
   public class_2394 onStartExtract(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      return ModParticles.LAVA_TAP_DRIP;
   }

   @Override
   public void onEndExtract(class_1937 level, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState) {
      if (destinationState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
         class_2350 tapFacing = (class_2350)tapState.method_11654(TapBlock.FACING);
         class_2338 relative = tapPos.method_10093(tapFacing.method_10153());
         int honeyLevel = (Integer)sourceState.method_11654(class_4481.field_20420);
         level.method_8501(relative, (class_2680)sourceState.method_11657(class_4481.field_20420, honeyLevel - 1));
         level.method_8501(tapPos.method_10074(), ModBlocks.HONEY_BOTTLE.method_9564());
         level.method_8396(null, tapPos.method_10074(), class_3417.field_14978, class_3419.field_15245, 1.0F, 1.0F);
         ITapBehavior.sendParticles(level, tapPos);
      }
   }
}
