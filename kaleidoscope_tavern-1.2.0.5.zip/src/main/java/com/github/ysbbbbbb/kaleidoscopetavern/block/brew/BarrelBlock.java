package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.FluidUtils;
import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarrelBlock extends class_2237 {
   public static final MapCodec<BarrelBlock> CODEC = method_54094(BarrelBlock::new);
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2754<class_2738> LAYER = class_2754.method_11850("layer", class_2738.class);
   public static final class_2758 INDEX = class_2758.method_11867("index", 0, 8);
   private static final class_265 SHAPE_FULL = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);
   private static final class_265 SHAPE_CUT_LEFT = class_2248.method_9541(4.0, 0.0, 0.0, 16.0, 16.0, 16.0);
   private static final class_265 SHAPE_CUT_RIGHT = class_2248.method_9541(0.0, 0.0, 0.0, 12.0, 16.0, 16.0);
   private static final class_265 SHAPE_CUT_NEAR = class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 16.0, 16.0);
   private static final class_265 SHAPE_CUT_FAR = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 12.0);
   private static final class_2738[] LAYERS = new class_2738[]{class_2738.field_12475, class_2738.field_12471, class_2738.field_12473};

   public BarrelBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_9632(2.5F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50012(class_3619.field_15972)
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043))
               .method_11657(LAYER, class_2738.field_12475))
            .method_11657(INDEX, 4)
      );
   }

   public @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (hand != class_1268.field_5808) {
         return class_1269.field_5811;
      }

      BarrelBlockEntity barrelEntity = getBarrelEntity(level, pos, state);
      if (barrelEntity == null) {
         return class_1269.field_5811;
      }

      if (level.method_8608()) {
         return class_1269.field_5812;
      }

      if (this.isCeiling(state)) {
         if (!barrelEntity.isOpen()) {
            return (class_1269)(barrelEntity.openLid(player) ? class_1269.field_5812 : class_1269.field_5814);
         }

         boolean clickedLid = this.isLid(state);
         class_1799 itemInHand = player.method_5998(hand);
         if (itemInHand.method_7960() && !clickedLid) {
            return (class_1269)(barrelEntity.closeLid(player) ? class_1269.field_5812 : class_1269.field_5814);
         }

         if (clickedLid) {
            if (FluidUtils.isFluidContainer(itemInHand)) {
               if (barrelEntity.addFluid(player, itemInHand)) {
                  level.method_8396(
                     null,
                     pos,
                     barrelEntity.getFluid().getFluid() == class_3612.field_15908 ? class_3417.field_15010 : class_3417.field_14834,
                     class_3419.field_15245,
                     0.655F,
                     0.8F
                  );
                  return class_1269.field_5812;
               } else if (barrelEntity.removeFluid(player, itemInHand)) {
                  level.method_8396(
                     null,
                     pos,
                     barrelEntity.getFluid().getFluid() == class_3612.field_15908 ? class_3417.field_15202 : class_3417.field_15126,
                     class_3419.field_15245,
                     0.655F,
                     0.8F
                  );
                  return class_1269.field_5812;
               } else {
                  return class_1269.field_5814;
               }
            } else if (!itemInHand.method_7960() && barrelEntity.addIngredient(player, itemInHand)) {
               return class_1269.field_5812;
            } else {
               return (class_1269)(itemInHand.method_7960() && barrelEntity.removeIngredient(player) ? class_1269.field_5812 : class_1269.field_5814);
            }
         } else {
            return super.method_55765(stack, state, level, pos, player, hand, hitResult);
         }
      } else {
         barrelEntity.tipBrewInfo(player);
         return class_1269.field_5812;
      }
   }

   private boolean isLid(class_2680 state) {
      return state.method_11654(LAYER) == class_2738.field_12473 && (Integer)state.method_11654(INDEX) == 4;
   }

   private boolean isCeiling(class_2680 state) {
      return state.method_11654(LAYER) == class_2738.field_12473;
   }

   @Nullable
   public <T extends class_2586> class_5558<T> method_31645(class_1937 level, @NonNull class_2680 state, @NonNull class_2591<T> blockEntityType) {
      return level.method_8608() ? null : method_31618(blockEntityType, ModBlocks.BARREL_BE, (levelIn, pos, stateIn, barrel) -> barrel.tick(levelIn));
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_1937 level = context.method_8045();
      if (pos.method_10264() > level.method_31600() - 3) {
         return null;
      }

      for (int y = 0; y < 3; y++) {
         for (int z = -1; z <= 1; z++) {
            for (int x = -1; x <= 1; x++) {
               if (x != 0 || y != 0 || z != 0) {
                  class_2338 checkPos = pos.method_10069(x, y, z);
                  if (!level.method_8320(checkPos).method_26166(context)) {
                     return null;
                  }
               }
            }
         }
      }

      class_2350 facing = context.method_8042().method_10153();
      return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(FACING, facing)).method_11657(LAYER, class_2738.field_12475))
         .method_11657(INDEX, 4);
   }

   public void method_9567(class_1937 level, @NonNull class_2338 pos, @NonNull class_2680 state, @Nullable class_1309 entity, @NonNull class_1799 stack) {
      if (!level.method_8608()) {
         class_2350 facing = (class_2350)state.method_11654(FACING);

         for (int y = 0; y < 3; y++) {
            for (int row = 0; row < 3; row++) {
               for (int col = 0; col < 3; col++) {
                  if (y != 0 || row != 1 || col != 1) {
                     int index = row * 3 + col;
                     class_2338 targetPos = pos.method_10069(col - 1, y, row - 1);
                     level.method_8501(
                        targetPos,
                        (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(FACING, facing)).method_11657(LAYER, LAYERS[y]))
                           .method_11657(INDEX, index)
                     );
                  }
               }
            }
         }
      }
   }

   @NotNull
   public class_2680 method_9576(@NonNull class_1937 level, @NonNull class_2338 pos, @NonNull class_2680 state, @NonNull class_1657 player) {
      handleRemove(level, pos, state, player);
      return super.method_9576(level, pos, state, player);
   }

   public void method_9586(@NonNull class_3218 serverLevel, @NonNull class_2338 blockPos, @NonNull class_1927 explosion) {
      class_2680 state = serverLevel.method_8320(blockPos);
      if (isBarrelPart(state)) {
         handleRemove(serverLevel, blockPos, state, null);
      } else {
         cleanupNearbyBarrelParts(serverLevel, blockPos);
      }

      super.method_9586(serverLevel, blockPos, explosion);
   }

   public static class_2338 getOriginPos(class_2338 pos, class_2680 state) {
      if (!isBarrelPart(state)) {
         return pos;
      }

      class_2738 layer = (class_2738)state.method_11654(LAYER);
      int index = (Integer)state.method_11654(INDEX);
      int yOffset = layer == class_2738.field_12475 ? 0 : (layer == class_2738.field_12471 ? 1 : 2);
      int col = index % 3;
      int row = index / 3;
      return pos.method_10069(-(col - 1), -yOffset, -(row - 1));
   }

   @Nullable
   public static BarrelBlockEntity getBarrelEntity(class_1937 level, class_2338 clickPos, class_2680 clickState) {
      if (isBarrelPart(clickState)) {
         class_2338 origin = getOriginPos(clickPos, clickState);
         if (level.method_8321(origin) instanceof BarrelBlockEntity barrelEntity) {
            return barrelEntity;
         }
      }

      return null;
   }

   private static void handleRemove(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1657 player) {
      if (!level.method_8608() && isBarrelPart(state)) {
         boolean drop = player == null || !player.method_68878();
         class_2338 origin = getOriginPos(pos, state);
         destroyByOrigin(level, origin, drop);
      }
   }

   private static void cleanupNearbyBarrelParts(class_1937 level, class_2338 centerPos) {
      Set<class_2338> origins = new HashSet<>();

      for (class_2338 checkPos : class_2338.method_10097(centerPos.method_10069(-1, -1, -1), centerPos.method_10069(1, 1, 1))) {
         class_2680 checkState = level.method_8320(checkPos);
         if (isBarrelPart(checkState)) {
            origins.add(getOriginPos(checkPos, checkState));
         }
      }

      for (class_2338 origin : origins) {
         destroyByOrigin(level, origin, true);
      }
   }

   private static void destroyByOrigin(class_1937 level, class_2338 origin, boolean drop) {
      for (int y = 0; y < 3; y++) {
         for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
               class_2338 targetPos = origin.method_10069(c - 1, y, r - 1);
               class_2680 targetState = level.method_8320(targetPos);
               if (isBarrelPart(targetState) && getOriginPos(targetPos, targetState).equals(origin)) {
                  level.method_22352(targetPos, drop);
               }
            }
         }
      }
   }

   private static boolean isBarrelPart(class_2680 state) {
      return state.method_26204() instanceof BarrelBlock && state.method_28498(LAYER) && state.method_28498(INDEX);
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, @NonNull class_8568 builder) {
      return state.method_11654(LAYER) == class_2738.field_12475 && state.method_11654(INDEX) == 4
         ? super.method_9560(state, builder)
         : Collections.emptyList();
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, LAYER, INDEX});
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, class_2680 state) {
      class_2738 layer = (class_2738)state.method_11654(LAYER);
      int index = (Integer)state.method_11654(INDEX);
      return layer == class_2738.field_12475 && index == 4 ? new BarrelBlockEntity(pos, state) : null;
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      class_2350 facing = (class_2350)state.method_11654(FACING);
      int index = (Integer)state.method_11654(INDEX);
      int col = index % 3;
      int row = index / 3;

      return switch (facing) {
         case field_11043, field_11035 -> col == 0 ? SHAPE_CUT_LEFT : (col == 2 ? SHAPE_CUT_RIGHT : SHAPE_FULL);
         case field_11039, field_11034 -> row == 0 ? SHAPE_CUT_NEAR : (row == 2 ? SHAPE_CUT_FAR : SHAPE_FULL);
         default -> SHAPE_FULL;
      };
   }

   @NotNull
   public class_2464 method_9604(class_2680 state) {
      class_2738 layer = (class_2738)state.method_11654(LAYER);
      int index = (Integer)state.method_11654(INDEX);
      return layer == class_2738.field_12475 && index == 4 ? class_2464.field_11458 : class_2464.field_11455;
   }

   @NotNull
   public class_2680 method_9598(class_2680 state, class_2470 rot) {
      return (class_2680)state.method_11657(FACING, rot.method_10503((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   public class_2680 method_9569(class_2680 state, class_2415 mirror) {
      return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }
}
