package com.github.ysbbbbbb.kaleidoscopetavern.block.properties;

import java.util.Locale;
import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum TrellisType implements class_3542 {
   SINGLE,
   NORTH_SOUTH,
   EAST_WEST,
   SIX_DIRECTION,
   CROSS_NORTH_SOUTH,
   CROSS_EAST_WEST,
   CROSS_UP_DOWN;

   @NotNull
   public String method_15434() {
      return this.name().toLowerCase(Locale.ENGLISH);
   }

   @Override
   public String toString() {
      return this.method_15434();
   }
}
