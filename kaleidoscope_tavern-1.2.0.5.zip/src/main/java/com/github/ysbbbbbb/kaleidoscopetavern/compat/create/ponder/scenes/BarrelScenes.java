package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.TapBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.TapBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.utils.PonderBlockWrapper;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModFluids;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.zurrtum.create.catnip.math.Pointing;
import com.zurrtum.create.client.ponder.api.ParticleEmitter;
import com.zurrtum.create.client.ponder.api.scene.SceneBuilder;
import com.zurrtum.create.client.ponder.api.scene.SceneBuildingUtil;
import com.zurrtum.create.client.ponder.api.scene.Selection;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class BarrelScenes {
   public static void introduction(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         scene.title("barrel_introduction", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         Selection barrelSel = util.select().fromTo(1, 1, 1, 3, 3, 3);
         Selection ladderSel = util.select().fromTo(1, 1, 2, 1, 2, 2);
         PonderBlockWrapper barrel = new PonderBlockWrapper(2, 1, 2, scene, util);
         PonderBlockWrapper barrelTop = new PonderBlockWrapper(2, 3, 2, scene, util);
         PonderBlockWrapper tap = new PonderBlockWrapper(2, 2, 0, scene, util);
         PonderBlockWrapper bottle = new PonderBlockWrapper(2, 1, 0, scene, util);
         class_1799 grapeBucket = new class_1799(ModItems.GRAPE_BUCKET);
         bottle.setBlock(ModBlocks.EMPTY_BOTTLE.method_9564(), false);
         barrel.modifyBlockEntity(BarrelBlockEntity.class, be -> {
            be.setOpen(false);
            be.refresh();
         });
         scene.idle(20);
         scene.world().showSection(barrelSel, class_2350.field_11033);
         tap.showSection(class_2350.field_11033);
         scene.idle(4);
         scene.world().showSection(ladderSel, class_2350.field_11034);
         scene.idle(25);
         scene.overlay().showText(45).text("").pointAt(barrelTop.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(barrelTop.blockSurface(class_2350.field_11036), Pointing.DOWN, 35).rightClick();
         scene.idle(5);
         barrel.modifyBlockEntity(BarrelBlockEntity.class, be -> {
            be.setOpen(true);
            be.refresh();
         });
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(45).text("").pointAt(barrelTop.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(barrelTop.blockSurface(class_2350.field_11036), Pointing.DOWN, 35).rightClick().withItem(grapeBucket.method_7972());
         scene.idle(5);
         barrel.modifyBlockEntity(BarrelBlockEntity.class, be -> {
            be.getFluid().fill(FluidVariant.of(ModFluids.GRAPE_JUICE), 4000, CustomFluidTank.FluidAction.EXECUTE);
            be.refresh();
         });
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(45).text("").pointAt(barrelTop.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(barrelTop.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick();
         scene.idle(5);
         barrel.modifyBlockEntity(BarrelBlockEntity.class, be -> {
            be.setOpen(false);
            be.refresh();
         });
         scene.idle(45);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").pointAt(barrelTop.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showText(50).text("").placeNearTarget();
         scene.overlay().showControls(barrelTop.blockSurface(class_2350.field_11036), Pointing.DOWN, 40).withItem(new class_1799(class_1802.field_8557));
         scene.idle(65);
         scene.addKeyframe();
         scene.idle(15);
         bottle.showSection(class_2350.field_11035);
         scene.idle(15);
         scene.overlay().showText(85).text("").pointAt(barrelTop.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(tap.blockSurface(class_2350.field_11036), Pointing.DOWN, 25).rightClick();
         scene.idle(5);
         tap.modifyBlock(s -> (class_2680)s.method_11657(TapBlock.OPEN, true), false);
         tap.modifyBlockEntity(TapBlockEntity.class, be -> be.setState(1));
         barrel.modifyBlockEntity(BarrelBlockEntity.class, be -> be.doTapExtract(level, tap.pos));
         ParticleEmitter emitter = scene.effects().simpleParticleEmitter(ModParticles.WATER_TAP_DRIP, new class_243(0.0, -0.01, 0.0));

         for (int i = 0; i < 42; i++) {
            scene.effects().emitParticles(tap.blockSurface(class_2350.field_11033).method_43206(class_2350.field_11036, 0.25), emitter, 1.0F, 1);
            scene.idle(1);
         }

         scene.idle(38);
         bottle.setBlock(ModBlocks.WINE.method_9564(), false);
         scene.idle(25);
      }
   }
}
