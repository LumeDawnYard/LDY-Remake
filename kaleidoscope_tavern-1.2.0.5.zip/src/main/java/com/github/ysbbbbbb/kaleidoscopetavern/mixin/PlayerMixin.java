package com.github.ysbbbbbb.kaleidoscopetavern.mixin;

import com.github.ysbbbbbb.kaleidoscopetavern.api.entity.PlayerExtraData;
import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlayerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_9135;
import net.minecraft.class_2945.class_9222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 implements PlayerExtraData {
   @Unique
   private static final class_2941<class_2487> COMPOUND_TAG_SERIALIZER = class_2941.method_56031(class_9135.field_48556);
   @Unique
   private static final class_2940<class_2487> PERSISTENT_DATA = class_2945.method_12791(class_1657.class, COMPOUND_TAG_SERIALIZER);

   protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
      super(entityType, level);
   }

   @Inject(method = "method_5693", at = @At("TAIL"))
   public void defineSyncedData(class_9222 builder, CallbackInfo ci) {
      builder.method_56912(PERSISTENT_DATA, new class_2487());
   }

   @Inject(method = "method_5773", at = @At("HEAD"))
   public void tickPre(CallbackInfo ci) {
      ((PlayerTickEvents.Start)PlayerTickEvents.START.invoker()).onStartOfPlayerTick((class_1657)this);
   }

   @Inject(method = "method_5773", at = @At("TAIL"))
   public void tickPost(CallbackInfo ci) {
      ((PlayerTickEvents.End)PlayerTickEvents.END.invoker()).onEndOfPlayerTick((class_1657)this);
   }

   @Override
   public void kaleidoscope_tavern$setPersistentData(class_2487 compoundTag) {
      this.field_6011.method_12778(PERSISTENT_DATA, compoundTag);
   }

   @Override
   public class_2487 kaleidoscope_tavern$getPersistentData() {
      return (class_2487)this.field_6011.method_12789(PERSISTENT_DATA);
   }

   static {
      class_2943.method_12720(COMPOUND_TAG_SERIALIZER);
   }
}
