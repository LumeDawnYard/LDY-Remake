package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.entity.ThrownMolotovEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_9463;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class MolotovBlockItem extends BottleBlockItem implements class_9463 {
   public MolotovBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties.method_7889(16).method_63685());
   }

   public @NonNull class_1269 method_7836(@NonNull class_1937 level, class_1657 player, @NonNull class_1268 hand) {
      player.method_6019(hand);
      return class_1269.field_21466;
   }

   @NotNull
   public class_1269 method_7884(class_1838 context) {
      class_1657 player = context.method_8036();
      return (class_1269)(player != null && !player.method_5715() ? class_1269.field_5811 : this.method_7712(new class_1750(context)));
   }

   public boolean method_7840(@NonNull class_1799 stack, @NonNull class_1937 level, @NonNull class_1309 entity, int timeLeft) {
      if (entity instanceof class_1657 player) {
         int time = this.method_7881(stack, player) - timeLeft;
         if (time < 10) {
            return false;
         }

         player.method_7259(class_3468.field_15372.method_14956(this));
         if (level instanceof class_3218 serverLevel) {
            ThrownMolotovEntity thrownMolotov = new ThrownMolotovEntity(serverLevel, player);
            thrownMolotov.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 0.82F, 1.0F);
            serverLevel.method_8649(thrownMolotov);
         }

         level.method_43128(
            null,
            player.method_23317(),
            player.method_23318(),
            player.method_23321(),
            class_3417.field_14873,
            class_3419.field_15248,
            0.5F,
            0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F)
         );
         if (!player.method_68878()) {
            stack.method_7934(1);
         }

         return true;
      } else {
         return false;
      }
   }

   public @NonNull class_1839 method_7853(@NonNull class_1799 stack) {
      return class_1839.field_63380;
   }

   public int method_7881(@NonNull class_1799 stack, @NonNull class_1309 entity) {
      return 72000;
   }

   public @NonNull class_1676 method_58648(
      @NonNull class_1937 level, @NonNull class_2374 position, @NonNull class_1799 itemStack, @NonNull class_2350 direction
   ) {
      return new ThrownMolotovEntity(level, position.method_10216(), position.method_10214(), position.method_10215());
   }
}
