package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.pressing_tub;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu.SlotFillContext;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;

public class PressingTubViewRecipe implements ReliableClientRecipe {
   private final class_1799 result;
   private final class_1856 input;

   public PressingTubViewRecipe(PressingTubServerRecipe serverRecipe) {
      this.result = serverRecipe.getResult();
      this.input = serverRecipe.getInput();
   }

   public ReliableClientRecipeType getViewType() {
      return PressingTubViewType.INSTANCE;
   }

   public void bindSlots(SlotFillContext slotFillContext) {
      slotFillContext.bindSlot(0, SlotContent.of(this.input.method_8105().map(s -> ((class_1792)s.comp_349()).method_7854().method_46651(8)).toList()));
      slotFillContext.bindSlot(1, SlotContent.of(class_1856.method_8101(class_1802.field_8550)));
      slotFillContext.bindSlot(2, SlotContent.of(this.result));
   }

   public List<SlotContent> getIngredients() {
      return Collections.singletonList(SlotContent.of(this.input));
   }

   public List<SlotContent> getResults() {
      return Collections.singletonList(SlotContent.of(this.result));
   }
}
