package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.init;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.zurrtum.create.client.ponder.api.registration.PonderTagRegistrationHelper;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModPonderTags {
   public static final class_2960 BREWING = class_2960.method_60655("kaleidoscope_tavern", "brewing");

   public static void register(PonderTagRegistrationHelper<class_2960> helper) {
      helper.registerTag(BREWING).addToIndex().item(ModItems.WINE, true, false).title("").description("").register();
      helper.addToTag(BREWING)
         .add(Objects.requireNonNull(class_7923.field_41178.method_10221(ModItems.GRAPEVINE)))
         .add(Objects.requireNonNull(class_7923.field_41178.method_10221(ModItems.PRESSING_TUB)))
         .add(Objects.requireNonNull(class_7923.field_41178.method_10221(ModItems.BARREL)));
   }
}
