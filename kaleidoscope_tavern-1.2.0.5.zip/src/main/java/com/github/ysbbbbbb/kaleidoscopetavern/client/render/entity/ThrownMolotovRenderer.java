package com.github.ysbbbbbb.kaleidoscopetavern.client.render.entity;

import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.ThrownMolotovEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.ThrownMolotovEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_5617.class_5618;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public class ThrownMolotovRenderer extends class_897<ThrownMolotovEntity, ThrownMolotovEntityRenderState> {
   private final class_776 renderer;

   public ThrownMolotovRenderer(class_5618 context) {
      super(context);
      this.renderer = context.method_43337();
   }

   public ThrownMolotovEntityRenderState createRenderState() {
      return new ThrownMolotovEntityRenderState();
   }

   public void extractRenderState(ThrownMolotovEntity entity, ThrownMolotovEntityRenderState entityRenderState, float f) {
      super.method_62354(entity, entityRenderState, f);
      entityRenderState.partialTicks = f;
      entityRenderState.tickCount = entity.field_6012;
   }

   public void submit(
      ThrownMolotovEntityRenderState entityRenderState,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      poseStack.method_22903();
      poseStack.method_22905(0.5F, 0.5F, 0.5F);
      poseStack.method_22904(-0.5, 0.0, -0.5);
      float rotation = (entityRenderState.tickCount + entityRenderState.partialTicks) * 20.0F;
      poseStack.method_22904(0.5, 0.5, 0.5);
      poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
      poseStack.method_22907(class_7833.field_40714.rotationDegrees(rotation * 0.7F));
      poseStack.method_22904(-0.5, -0.5, -0.5);
      class_2680 blockState = ModBlocks.MOLOTOV.method_9564();
      class_1087 blockStateModel = this.renderer.method_3349(blockState);
      submitNodeCollector.method_73484(
         poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, entityRenderState.field_61820, class_4608.field_21444, 0
      );
      poseStack.method_22909();
      super.method_3936(entityRenderState, poseStack, submitNodeCollector, cameraRenderState);
   }
}
