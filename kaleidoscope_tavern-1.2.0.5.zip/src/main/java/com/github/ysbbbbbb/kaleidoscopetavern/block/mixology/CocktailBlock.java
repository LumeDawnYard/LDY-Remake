package com.github.ysbbbbbb.kaleidoscopetavern.block.mixology;

import net.minecraft.class_4970.class_2251;

public class CocktailBlock extends GlasswareBlock {
   public CocktailBlock(class_2251 properties) {
      super(properties);
   }

   public CocktailBlock() {
   }
}
