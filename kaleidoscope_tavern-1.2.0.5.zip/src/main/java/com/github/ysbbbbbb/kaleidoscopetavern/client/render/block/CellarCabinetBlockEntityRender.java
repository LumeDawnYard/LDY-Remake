package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.CellarCabinetBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.CellarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class CellarCabinetBlockEntityRender extends StorageBlockEntityRender<CellarCabinetBlockEntity, StorageBlockEntityRenderState> {
   public CellarCabinetBlockEntityRender(class_5615 context) {
      super(context);
   }

   public void extractRenderState(
      @NonNull CellarCabinetBlockEntity blockEntity,
      @NonNull StorageBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.extractRenderState(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(CellarCabinetBlock.field_11177);
   }

   public @NonNull StorageBlockEntityRenderState createRenderState() {
      return new StorageBlockEntityRenderState();
   }

   @Override
   public void submit(
      StorageBlockEntityRenderState state, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      class_2350 direction = state.facing;
      poseStack.method_22903();
      this.applyFacingRotation(direction, poseStack);

      for (int i = 0; i < state.items.size(); i++) {
         class_1799 stack = state.items.get(i);
         if (!stack.method_7960()) {
            int row = i / 3;
            int column = i % 3;
            double x = 0.825 - column * 0.325;
            double y = 0.78 - row * 0.29;
            this.renderStack(stack, poseStack, submitNodeCollector, state.field_62676, x, y, 0.875, 1.0F, 0.0, -90.0);
         }
      }

      poseStack.method_22909();
   }
}
