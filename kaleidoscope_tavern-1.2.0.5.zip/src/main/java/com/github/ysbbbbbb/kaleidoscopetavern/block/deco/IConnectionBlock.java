package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.ConnectionType;
import java.util.function.Function;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_4538;

public interface IConnectionBlock {
   class_2754<ConnectionType> CONNECTION = class_2754.method_11850("connection", ConnectionType.class);

   boolean sameType(class_2680 var1);

   default class_2680 updateShape(class_4538 level, class_2338 pos, class_2680 state, class_2350 update) {
      class_2350 facing = (class_2350)state.method_11654(class_2383.field_11177);
      boolean horizontalChange = update.method_10166() == facing.method_10170().method_10166();
      boolean frontChange = update == facing;
      if (!horizontalChange && !frontChange) {
         return state;
      }

      class_2350 left = facing.method_10170();
      class_2350 right = facing.method_10160();
      ConnectionType type = (ConnectionType)state.method_11654(CONNECTION);
      if (type == ConnectionType.LEFT_CORNER && update == left) {
         return state;
      }

      if (type == ConnectionType.RIGHT_CORNER && update == right) {
         return state;
      }

      class_2680 leftState = level.method_8320(pos.method_10093(left));
      class_2680 rightState = level.method_8320(pos.method_10093(right));
      class_2680 frontState = level.method_8320(pos.method_10093(facing));
      boolean leftConnected = leftConnected(leftState, facing, this::sameType);
      boolean rightConnected = rightConnected(rightState, facing, this::sameType);
      boolean frontLeftConnected = frontLeftConnected(frontState, facing, this::sameType);
      boolean frontRightConnected = frontRightConnected(frontState, facing, this::sameType);
      ConnectionType changedType = getConnectionType(leftConnected, rightConnected, frontLeftConnected, frontRightConnected);
      return (class_2680)state.method_11657(CONNECTION, changedType);
   }

   default ConnectionType getConnectionForPlacement(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 pos = context.method_8037();
      class_2350 direction = context.method_8042().method_10153();
      class_2350 left = direction.method_10170();
      class_2350 right = direction.method_10160();
      class_2680 leftState = level.method_8320(pos.method_10093(left));
      class_2680 rightState = level.method_8320(pos.method_10093(right));
      class_2680 frontState = level.method_8320(pos.method_10093(direction));
      boolean leftConnected = leftConnected(leftState, direction, this::sameType);
      boolean rightConnected = rightConnected(rightState, direction, this::sameType);
      boolean frontLeftConnected = frontLeftConnected(frontState, direction, this::sameType);
      boolean frontRightConnected = frontRightConnected(frontState, direction, this::sameType);
      return getConnectionType(leftConnected, rightConnected, frontLeftConnected, frontRightConnected);
   }

   static boolean leftConnected(class_2680 leftState, class_2350 self, Function<class_2680, Boolean> typeCheck) {
      if (typeCheck.apply(leftState)) {
         class_2350 check = (class_2350)leftState.method_11654(class_2383.field_11177);
         class_2350 right = self.method_10160();
         if (check != right) {
            return check == self;
         }

         ConnectionType connection = (ConnectionType)leftState.method_11654(CONNECTION);
         return connection == ConnectionType.SINGLE || connection == ConnectionType.RIGHT || connection == ConnectionType.RIGHT_CORNER;
      } else {
         return false;
      }
   }

   static boolean rightConnected(class_2680 rightState, class_2350 self, Function<class_2680, Boolean> typeCheck) {
      if (typeCheck.apply(rightState)) {
         class_2350 check = (class_2350)rightState.method_11654(class_2383.field_11177);
         class_2350 left = self.method_10170();
         if (check != left) {
            return check == self;
         }

         ConnectionType connection = (ConnectionType)rightState.method_11654(CONNECTION);
         return connection == ConnectionType.SINGLE || connection == ConnectionType.LEFT || connection == ConnectionType.LEFT_CORNER;
      } else {
         return false;
      }
   }

   static boolean frontLeftConnected(class_2680 frontState, class_2350 direction, Function<class_2680, Boolean> typeCheck) {
      if (typeCheck.apply(frontState)) {
         class_2350 check = (class_2350)frontState.method_11654(class_2383.field_11177);
         class_2350 left = direction.method_10170();
         ConnectionType connection = (ConnectionType)frontState.method_11654(CONNECTION);
         if (check == left) {
            return connection != ConnectionType.LEFT_CORNER;
         }
      }

      return false;
   }

   static boolean frontRightConnected(class_2680 frontState, class_2350 direction, Function<class_2680, Boolean> typeCheck) {
      if (typeCheck.apply(frontState)) {
         class_2350 check = (class_2350)frontState.method_11654(class_2383.field_11177);
         class_2350 right = direction.method_10160();
         ConnectionType connection = (ConnectionType)frontState.method_11654(CONNECTION);
         if (check == right) {
            return connection != ConnectionType.RIGHT_CORNER;
         }
      }

      return false;
   }

   static ConnectionType getConnectionType(boolean leftConnected, boolean rightConnected, boolean frontLeftConnected, boolean frontRightConnected) {
      if (leftConnected && rightConnected) {
         return ConnectionType.MIDDLE;
      } else if (frontLeftConnected) {
         return rightConnected ? ConnectionType.LEFT : ConnectionType.RIGHT_CORNER;
      } else if (frontRightConnected) {
         return leftConnected ? ConnectionType.RIGHT : ConnectionType.LEFT_CORNER;
      } else if (leftConnected) {
         return ConnectionType.RIGHT;
      } else {
         return rightConnected ? ConnectionType.LEFT : ConnectionType.SINGLE;
      }
   }
}
