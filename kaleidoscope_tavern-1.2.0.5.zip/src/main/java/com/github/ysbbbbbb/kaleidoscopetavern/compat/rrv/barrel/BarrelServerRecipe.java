package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.barrel;

import cc.cassian.rrv.api.TagUtil;
import cc.cassian.rrv.api.recipe.ReliableServerRecipe;
import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class BarrelServerRecipe implements ReliableServerRecipe {
   public static final ReliableServerRecipeType<BarrelServerRecipe> TYPE = ReliableServerRecipeType.register(
      class_2960.method_60655("kaleidoscope_tavern", "barrel"), () -> new BarrelServerRecipe(null, List.of(), null)
   );
   private class_1799 result;
   private List<class_1856> ingredients;
   private class_1856 carrier;

   public BarrelServerRecipe(class_1799 result, List<class_1856> ingredients, class_1856 carrier) {
      this.result = result;
      this.ingredients = ingredients;
      this.carrier = carrier;
   }

   public class_1799 getResult() {
      return this.result;
   }

   public class_1856 getCarrier() {
      return this.carrier;
   }

   public List<class_1856> getIngredients() {
      return this.ingredients;
   }

   public void writeToTag(class_2487 tag) {
      tag.method_10566("result", TagUtil.encodeItemStackOnServer(this.result));
      tag.method_10566("carrier", TagUtil.writeIngredient(this.carrier));

      for (int i = 0; i < this.ingredients.size(); i++) {
         tag.method_10566("ingredient_" + i, TagUtil.writeIngredient(this.ingredients.get(i)));
      }
   }

   public void loadFromTag(class_2487 tag) {
      this.result = TagUtil.decodeItemStackOnServer((class_2487)tag.method_10562("result").orElseGet(class_2487::new));
      this.carrier = TagUtil.readIngredient((class_2487)tag.method_10562("carrier").orElseGet(class_2487::new));
      this.ingredients = new ArrayList<>();
      int i = 0;

      while (true) {
         Optional<class_2487> ingredientTag = tag.method_10562("ingredient_" + i);
         if (ingredientTag.isEmpty()) {
            return;
         }

         this.ingredients.add(TagUtil.readIngredient(ingredientTag.get()));
         i++;
      }
   }

   public ReliableServerRecipeType<? extends ReliableServerRecipe> getRecipeType() {
      return TYPE;
   }
}
