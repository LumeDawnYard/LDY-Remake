package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class ChalkboardBlockEntity extends TextBlockEntity {
   private boolean isLarge = false;

   public ChalkboardBlockEntity(class_2338 pos, class_2680 blockState) {
      super(ModBlocks.CHALKBOARD_BE, pos, blockState);
   }

   public static ChalkboardBlockEntity small(class_2338 pos, class_2680 blockState) {
      ChalkboardBlockEntity be = new ChalkboardBlockEntity(pos, blockState);
      be.setLarge(false);
      return be;
   }

   public static ChalkboardBlockEntity large(class_2338 pos, class_2680 blockState) {
      ChalkboardBlockEntity be = new ChalkboardBlockEntity(pos, blockState);
      be.setLarge(true);
      return be;
   }

   @Override
   public int getMaxTextLength() {
      return this.isLarge() ? 1500 : 350;
   }

   public boolean isLarge() {
      return this.isLarge;
   }

   public void setLarge(boolean large) {
      this.isLarge = large;
   }
}
