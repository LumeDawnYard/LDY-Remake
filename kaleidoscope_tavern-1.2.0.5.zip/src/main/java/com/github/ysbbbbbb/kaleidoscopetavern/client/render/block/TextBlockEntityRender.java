package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.ChalkboardBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.SandwichBoardBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.TextBlockEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.util.TextAlignment;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1767;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.class_7718;
import net.minecraft.class_827;
import net.minecraft.class_9848;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_327.class_6415;
import net.minecraft.class_5614.class_5615;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public abstract class TextBlockEntityRender<T extends TextBlockEntity, M extends TextBlockEntityRenderState> implements class_827<T, M> {
   protected static final int OUTLINE_RENDER_DISTANCE = class_3532.method_34954(16);
   protected final class_327 font;

   public TextBlockEntityRender(class_5615 context) {
      this.font = context.comp_4540();
   }

   public abstract M createRenderState();

   public void extractRenderState(T blockEntity, M blockEntityRenderState, float f, @NonNull class_243 vec3, @Nullable class_11792 crumblingOverlay) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      class_2680 state = blockEntity.method_11010();
      if (state.method_26204() instanceof SandwichBoardBlock) {
         int rotation = (Integer)state.method_11654(SandwichBoardBlock.ROTATION);
         blockEntityRenderState.rotation = rotation;
         blockEntityRenderState.facing = class_7718.method_45480(rotation).orElse(class_2350.field_11043);
      } else {
         blockEntityRenderState.rotation = -1;
         blockEntityRenderState.facing = (class_2350)state.method_11654(ChalkboardBlock.FACING);
      }

      blockEntityRenderState.text = blockEntity.getText();
      blockEntityRenderState.color = blockEntity.getColor();
      blockEntityRenderState.glowing = blockEntity.isGlowing();
      blockEntityRenderState.textAlignment = blockEntity.getTextAlignment();
   }

   public final void submit(
      M blockEntityRenderState, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      this.renderModel(blockEntityRenderState, poseStack, submitNodeCollector, blockEntityRenderState.facing);
      if (cameraRenderState.field_63078.method_1022(class_243.method_24953(blockEntityRenderState.field_62673)) <= 48.0
         && StringUtils.isNotBlank(blockEntityRenderState.text)) {
         this.renderText(blockEntityRenderState, poseStack, submitNodeCollector, blockEntityRenderState.facing);
      }
   }

   protected abstract void renderModel(M var1, class_4587 var2, class_11659 var3, class_2350 var4);

   protected abstract void renderText(M var1, class_4587 var2, class_11659 var3, class_2350 var4);

   protected void doTextRender(
      M textBlockRenderState, class_4587 poseStack, String text, int maxWidth, float scale, int maxLines, int lineHeight, class_11659 submitNodeCollector
   ) {
      poseStack.method_22905(scale, -scale, scale);
      int darkColor = this.getDarkColor(textBlockRenderState.color, textBlockRenderState.glowing);
      int textColor;
      boolean hasOutline;
      int light;
      if (textBlockRenderState.glowing) {
         textColor = textBlockRenderState.color.method_16357();
         hasOutline = this.isOutlineVisible(textBlockRenderState.field_62673, textColor);
         light = 15728880;
      } else {
         textColor = darkColor;
         hasOutline = false;
         light = textBlockRenderState.field_62676;
      }

      int submitTextColor = class_9848.method_61334(textColor);
      int submitDarkColor = class_9848.method_61334(darkColor);
      class_2561 renderText = this.getRenderText(text);
      List<class_5481> splitLines = this.font.method_1728(renderText, maxWidth);
      int totalLines = Math.min(splitLines.size(), maxLines);

      for (int i = 0; i < totalLines; i++) {
         class_5481 line = splitLines.get(i);
         float posX = this.getPosX(textBlockRenderState, maxWidth, this.font.method_30880(line));
         float posY = i * lineHeight - 19;
         submitNodeCollector.method_73478(
            poseStack, posX, posY, line, false, class_6415.field_33995, light, submitTextColor, 0, hasOutline ? submitDarkColor : 0
         );
      }
   }

   protected class_2561 getRenderText(String text) {
      return class_2561.method_43470(text);
   }

   protected float getPosX(M textBlock, int maxWidth, int lineWidth) {
      TextAlignment alignment = textBlock.textAlignment;
      if (alignment == TextAlignment.LEFT) {
         return -maxWidth / 2.0F;
      } else {
         return alignment == TextAlignment.RIGHT ? maxWidth / 2.0F - lineWidth : -lineWidth / 2.0F;
      }
   }

   protected int getDarkColor(class_1767 color, boolean isGlowing) {
      int textColor = color.method_16357();
      if (textColor == class_1767.field_7963.method_16357() && isGlowing) {
         return -988212;
      }

      double darknessFactor = 0.6;
      int red = (int)(class_9848.method_61327(textColor) * darknessFactor);
      int green = (int)(class_9848.method_61329(textColor) * darknessFactor);
      int blue = (int)(class_9848.method_61331(textColor) * darknessFactor);
      return class_9848.method_61324(0, red, green, blue);
   }

   protected boolean isOutlineVisible(class_2338 blockPos, int textColor) {
      if (textColor == class_1767.field_7963.method_16357()) {
         return true;
      }

      class_310 mc = class_310.method_1551();
      class_746 player = mc.field_1724;
      if (player != null && mc.field_1690.method_31044().method_31034() && player.method_31550()) {
         return true;
      }

      class_1297 entity = mc.method_1560();
      return entity != null && entity.method_5707(class_243.method_24953(blockPos)) < OUTLINE_RENDER_DISTANCE;
   }
}
