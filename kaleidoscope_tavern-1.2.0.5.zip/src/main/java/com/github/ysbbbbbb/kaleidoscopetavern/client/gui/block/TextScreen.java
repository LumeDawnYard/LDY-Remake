package com.github.ysbbbbbb.kaleidoscopetavern.client.gui.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.network.message.TextUpdateC2SMessage;
import com.github.ysbbbbbb.kaleidoscopetavern.util.TextAlignment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7529;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public class TextScreen extends class_437 {
   private final TextBlockEntity blockEntity;
   private String text;
   private TextAlignment textAlignment;
   private class_7529 customSetting;

   public TextScreen(TextBlockEntity blockEntity) {
      super(class_2561.method_43470("Text Edit Screen"));
      this.blockEntity = blockEntity;
      this.text = blockEntity.getText();
      this.textAlignment = blockEntity.getTextAlignment();
   }

   protected void method_25426() {
      this.method_37067();
      int posX = this.field_22789 / 2 - 165;
      int posY = this.field_22790 / 2 - 80;
      int boxWidth = 256;
      int maxTextLength = this.blockEntity.getMaxTextLength();
      this.customSetting = (class_7529)this.method_37063(
         class_7529.method_71507()
            .method_71510(class_2561.method_43471("gui.kaleidoscope_tavern.text.edit.placeholder"))
            .method_71509(this.field_22793, boxWidth, 120, class_2561.method_43470("Custom Setting Box"))
      );
      this.customSetting.method_44400(this.text);
      this.customSetting.method_46421(posX);
      this.customSetting.method_46419(posY);
      this.customSetting.method_44402(maxTextLength);
      this.customSetting.method_44401(s -> this.text = s);
      this.method_37063(class_4185.method_46430(class_5244.field_24335, button -> this.method_25419()).method_46434(posX, posY + 135, 126, 20).method_46431());
      this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.onDone()).method_46434(posX + 130, posY + 135, 126, 20).method_46431());
      class_4185 left = class_4185.method_46430(class_2561.method_43471("gui.kaleidoscope_tavern.text.edit.text_alignment.left"), button -> {
         this.textAlignment = TextAlignment.LEFT;
         this.method_25426();
      }).method_46434(posX + boxWidth + 5, posY + 25, 80, 20).method_46431();
      class_4185 center = class_4185.method_46430(class_2561.method_43471("gui.kaleidoscope_tavern.text.edit.text_alignment.center"), button -> {
         this.textAlignment = TextAlignment.CENTER;
         this.method_25426();
      }).method_46434(posX + boxWidth + 5, posY + 50, 80, 20).method_46431();
      class_4185 right = class_4185.method_46430(class_2561.method_43471("gui.kaleidoscope_tavern.text.edit.text_alignment.right"), button -> {
         this.textAlignment = TextAlignment.RIGHT;
         this.method_25426();
      }).method_46434(posX + boxWidth + 5, posY + 75, 80, 20).method_46431();
      if (this.textAlignment == TextAlignment.LEFT) {
         left.field_22763 = false;
      } else if (this.textAlignment == TextAlignment.CENTER) {
         center.field_22763 = false;
      } else if (this.textAlignment == TextAlignment.RIGHT) {
         right.field_22763 = false;
      }

      this.method_37063(left);
      this.method_37063(center);
      this.method_37063(right);
   }

   public void method_25410(int i, int j) {
      String customSettingValue = this.customSetting.method_44405();
      super.method_25410(i, j);
      this.customSetting.method_44400(customSettingValue);
   }

   private void onDone() {
      ClientPlayNetworking.send(new TextUpdateC2SMessage(this.blockEntity.method_11016(), this.text, this.textAlignment));
      this.method_25419();
   }

   public boolean method_25406(@NonNull class_11909 mouseButtonEvent) {
      return super.method_25406(mouseButtonEvent) || this.customSetting.method_25406(mouseButtonEvent);
   }
}
