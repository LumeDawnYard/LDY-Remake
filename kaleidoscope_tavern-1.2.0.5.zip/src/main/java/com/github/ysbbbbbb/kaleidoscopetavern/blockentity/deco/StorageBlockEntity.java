package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public abstract class StorageBlockEntity extends BaseBlockEntity {
   private static final String ITEMS = "items";
   private final ItemStackHandler items;

   protected StorageBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state, int size) {
      super(type, pos, state);
      this.items = new ItemStackHandler(size) {
         @Override
         public int getSlotLimit(int slot) {
            return 1;
         }
      };
   }

   protected void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.items.deserializeNBT(valueInput, "items", "items_size");
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      this.items.serialize(valueOutput, "items", "items_size");
   }

   public ItemStackHandler getItems() {
      return this.items;
   }

   public boolean hasAnyItem() {
      for (int i = 0; i < this.items.getSlots(); i++) {
         if (!this.items.getStackInSlot(i).method_7960()) {
            return true;
         }
      }

      return false;
   }
}
