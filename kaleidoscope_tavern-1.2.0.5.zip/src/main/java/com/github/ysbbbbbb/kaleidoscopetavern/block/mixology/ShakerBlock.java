package com.github.ysbbbbbb.kaleidoscopetavern.block.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.ShakerBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.github.ysbbbbbb.kaleidoscopetavern.item.ShakerItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class ShakerBlock extends class_2248 implements class_2343, class_3737 {
   private static final class_265 SHAPE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public ShakerBlock() {
      super(class_2251.method_9637().method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_17734));
      this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(WATERLOGGED, false));
   }

   public ShakerBlock(class_2251 properties) {
      super(properties.method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_17734));
      this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(WATERLOGGED, false));
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return !blockState.method_26184(levelReader, blockPos)
         ? class_2246.field_10124.method_9564()
         : super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      if (hand != class_1268.field_5808) {
         return class_1269.field_5811;
      }

      if (level.method_8321(pos) instanceof ShakerBlockEntity shaker) {
         class_1799 itemInHand = player.method_5998(hand);
         if (itemInHand.method_7960() && level instanceof class_3218 serverLevel) {
            List<class_1799> drops = method_9562(state, serverLevel, pos, shaker);
            boolean handSet = false;

            for (class_1799 s : drops) {
               if (!s.method_7960()) {
                  if (!handSet) {
                     player.method_6122(class_1268.field_5808, s);
                     handSet = true;
                  } else {
                     ItemUtils.giveItemToPlayer(player, s);
                  }
               }
            }

            level.method_8652(pos, class_2246.field_10124.method_9564(), 35);
            level.method_45447(null, pos, class_3417.field_17745, class_3419.field_15245);
            return class_1269.field_5812;
         } else if (itemInHand.method_31573(TagMod.COCKTAIL_INGREDIENT)) {
            shaker.addIngredient(itemInHand, player);
            return class_1269.field_5812;
         } else {
            return class_1269.field_5811;
         }
      } else {
         return class_1269.field_5811;
      }
   }

   protected boolean method_9558(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
      class_2338 blockPos2 = blockPos.method_10074();
      class_2680 blockState2 = levelReader.method_8320(blockPos2);
      return this.canSurviveOn(levelReader, blockPos2, blockState2);
   }

   private boolean canSurviveOn(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState) {
      return blockState.method_26206(blockGetter, blockPos, class_2350.field_11036);
   }

   public void method_9567(class_1937 pLevel, class_2338 pPos, class_2680 pState, @Nullable class_1309 placer, class_1799 pStack) {
      if (ShakerItem.hasStorage(pStack) && pLevel.method_8321(pPos) instanceof ShakerBlockEntity shaker) {
         ItemStackHandler storage = ShakerItem.getStorage(pStack);
         shaker.setStorage(storage);
         if (ShakerItem.hasResult(pStack)) {
            shaker.setResult(ShakerItem.getResult(pStack));
         }

         shaker.refresh();
      }
   }

   public @NonNull List<class_1799> method_9560(class_2680 state, class_8568 params) {
      List<class_1799> stacks = Lists.newArrayList(super.method_9560(state, params));
      class_2586 blockEntity = (class_2586)params.method_51876(class_181.field_1228);
      if (blockEntity instanceof ShakerBlockEntity be) {
         class_1799 instance = ModItems.SHAKER.method_7854();
         ItemStackHandler storage = be.getStorage();
         ShakerItem.setStorage(instance, storage);
         if (!be.getResult().method_7960()) {
            ShakerItem.setResult(instance, be.getResult());
         }

         stacks.add(instance);
      }

      return stacks;
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      return (class_2680)this.method_9564().method_11657(WATERLOGGED, hasWater);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      super.method_9515(builder);
      builder.method_11667(new class_2769[]{WATERLOGGED});
   }

   @Nullable
   public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
      return new ShakerBlockEntity(pPos, pState);
   }

   public @NonNull class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
      return SHAPE;
   }
}
