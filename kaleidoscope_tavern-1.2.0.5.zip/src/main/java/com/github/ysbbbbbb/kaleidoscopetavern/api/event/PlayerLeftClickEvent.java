package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import com.github.ysbbbbbb.kaleidoscopetavern.client.event.LeftClickEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.CancellableEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.IEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;

public class PlayerLeftClickEvent extends CancellableEvent {
   @Nullable
   private final class_1657 player;
   private final class_1268 hand;

   public PlayerLeftClickEvent(@Nullable class_1657 player, class_1268 hand) {
      this.player = player;
      this.hand = hand;
   }

   @Nullable
   public class_1657 getPlayer() {
      return this.player;
   }

   public class_1268 getHand() {
      return this.hand;
   }

   public static void register() {
      CALLBACK.register((IEvent.Callback<IEvent>)event -> {
         if (event instanceof PlayerLeftClickEvent playerLeftClickEvent) {
            LeftClickEvent.onLeftClickItem(playerLeftClickEvent);
         }
      });
   }

   @Override
   public void post() {
      ((IEvent.Callback)CALLBACK.invoker()).post(this);
   }
}
