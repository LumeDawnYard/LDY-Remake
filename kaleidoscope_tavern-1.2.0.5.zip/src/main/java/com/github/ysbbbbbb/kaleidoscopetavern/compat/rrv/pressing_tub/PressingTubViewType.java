package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.pressing_tub;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu.SlotDefinition;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jspecify.annotations.Nullable;

public class PressingTubViewType implements ReliableClientRecipeType {
   public static final PressingTubViewType INSTANCE = new PressingTubViewType();

   private PressingTubViewType() {
   }

   public class_2561 getDisplayName() {
      return class_2561.method_43471("emi.category.kaleidoscope_tavern.pressing_tub");
   }

   public int getDisplayWidth() {
      return 112;
   }

   public int getDisplayHeight() {
      return 67;
   }

   public @Nullable class_2960 getGuiTexture() {
      return class_2960.method_60655("kaleidoscope_tavern", "textures/gui/eiv/pressing_tub.png");
   }

   public int getSlotCount() {
      return 3;
   }

   public void placeSlots(SlotDefinition slotDefinition) {
      slotDefinition.addItemSlot(0, 23, 13);
      slotDefinition.addItemSlot(1, 66, 4);
      slotDefinition.addItemSlot(2, 92, 26);
   }

   public class_2960 getId() {
      return class_2960.method_60656("kaleidoscope_pressing_tub");
   }

   public class_1799 getIcon() {
      return ModItems.PRESSING_TUB.method_7854();
   }
}
