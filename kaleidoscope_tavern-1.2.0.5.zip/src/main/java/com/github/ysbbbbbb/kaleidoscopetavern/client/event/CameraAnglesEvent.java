package com.github.ysbbbbbb.kaleidoscopetavern.client.event;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.ViewportEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class CameraAnglesEvent {
   public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null) {
         if (player.method_6059(ModEffects.SLIGHTLY_TIPSY)) {
            double t = player.field_6012 + event.getPartialTick();
            double wave1 = Math.sin(t / 19.0) * 0.6;
            double wave2 = Math.cos(t / 13.0) * 0.3;
            double wave3 = Math.sin(t / 9.0) * 0.1;
            double value = wave1 + wave2 + wave3;
            event.setRoll(event.getRoll() + (float)value);
         }
      }
   }
}
