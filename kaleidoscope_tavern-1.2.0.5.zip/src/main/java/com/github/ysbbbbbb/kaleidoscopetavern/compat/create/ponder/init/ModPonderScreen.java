package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.init;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes.BarrelScenes;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes.GrapevineScenes;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes.PressingTubScenes;
import com.zurrtum.create.client.ponder.api.registration.PonderSceneRegistrationHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public class ModPonderScreen {
   public static void register(PonderSceneRegistrationHelper<class_2960> helper) {
      helper.forComponents(new class_2960[]{class_2960.method_60655("kaleidoscope_tavern", "pressing_tub")})
         .addStoryBoard("pressing_tub/introduction", PressingTubScenes::introduction)
         .addStoryBoard("pressing_tub/introduction", PressingTubScenes::pressing)
         .addStoryBoard("pressing_tub/introduction", PressingTubScenes::variant);
      helper.forComponents(new class_2960[]{class_2960.method_60655("kaleidoscope_tavern", "barrel")})
         .addStoryBoard("barrel/introduction", BarrelScenes::introduction);
      helper.forComponents(new class_2960[]{class_2960.method_60655("kaleidoscope_tavern", "grapevine")})
         .addStoryBoard("grapevine/wild_generation", GrapevineScenes::wildGeneration)
         .addStoryBoard("grapevine/planting", GrapevineScenes::planting);
   }
}
