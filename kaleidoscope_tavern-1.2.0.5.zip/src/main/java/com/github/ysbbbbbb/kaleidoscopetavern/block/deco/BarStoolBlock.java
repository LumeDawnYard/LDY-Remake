package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.api.entity.ISittable;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.BarStoolBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.SitUtil;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarStoolBlock extends class_2237 implements class_3737, ISittable {
   public static final MapCodec<BarStoolBlock> CODEC = RecordCodecBuilder.mapCodec(
      builder -> builder.group(class_1767.field_41600.fieldOf("color").forGetter(o -> o.color), method_54096())
         .apply(builder, (dye, properties) -> new BarStoolBlock(properties, dye))
   );
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   private final class_1767 color;
   private static final class_265 SHAPE = class_259.method_17786(
      class_259.method_1081(0.3125, 0.0, 0.3125, 0.6875, 0.125, 0.6875),
      new class_265[]{class_259.method_1081(0.4375, 0.0625, 0.4375, 0.5625, 0.75, 0.5625), class_259.method_1081(0.125, 0.75, 0.125, 0.875, 0.9375, 0.875)}
   );
   public static final class_265 NORTH_SHAPE = class_259.method_17786(
      class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 2.0, 11.0),
      new class_265[]{
         class_2248.method_9541(7.0, 1.0, 7.0, 9.0, 12.0, 9.0),
         class_2248.method_9541(2.0, 12.0, 3.0, 14.0, 15.0, 14.0),
         class_2248.method_9541(2.0, 15.0, 11.0, 14.0, 21.0, 14.0)
      }
   );
   public static final class_265 SOUTH_SHAPE = class_259.method_17786(
      class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 2.0, 11.0),
      new class_265[]{
         class_2248.method_9541(7.0, 1.0, 7.0, 9.0, 12.0, 9.0),
         class_2248.method_9541(2.0, 12.0, 2.0, 14.0, 15.0, 13.0),
         class_2248.method_9541(2.0, 15.0, 2.0, 14.0, 21.0, 5.0)
      }
   );
   public static final class_265 EAST_SHAPE = class_259.method_17786(
      class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 2.0, 11.0),
      new class_265[]{
         class_2248.method_9541(7.0, 1.0, 7.0, 9.0, 12.0, 9.0),
         class_2248.method_9541(2.0, 12.0, 2.0, 13.0, 15.0, 14.0),
         class_2248.method_9541(2.0, 15.0, 2.0, 5.0, 21.0, 14.0)
      }
   );
   public static final class_265 WEST_SHAPE = class_259.method_17786(
      class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 2.0, 11.0),
      new class_265[]{
         class_2248.method_9541(7.0, 1.0, 7.0, 9.0, 12.0, 9.0),
         class_2248.method_9541(3.0, 12.0, 2.0, 14.0, 15.0, 14.0),
         class_2248.method_9541(11.0, 15.0, 2.0, 14.0, 21.0, 14.0)
      }
   );

   public BarStoolBlock(class_2251 properties, class_1767 color) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)).method_11657(WATERLOGGED, false)
      );
      this.color = color;
   }

   @NotNull
   protected class_2680 method_9559(
      @NotNull class_2680 blockState,
      @NotNull class_4538 levelReader,
      @NotNull class_10225 scheduledTickAccess,
      @NotNull class_2338 blockPos,
      @NotNull class_2350 direction,
      @NotNull class_2338 blockPos2,
      @NotNull class_2680 blockState2,
      @NotNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_3610 fluidState = context.method_8045().method_8316(context.method_8037());
      return (class_2680)((class_2680)this.method_9564().method_11657(FACING, context.method_8042().method_10153()))
         .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
   }

   public void method_9585(class_1936 levelAccessor, @NotNull class_2338 pos, @NotNull class_2680 state) {
      levelAccessor.method_18467(SitEntity.class, new class_238(pos)).forEach(class_1297::method_31472);
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   protected class_2680 method_9598(class_2680 blockState, class_2470 rotation) {
      return (class_2680)blockState.method_11657(FACING, rotation.method_10503((class_2350)blockState.method_11654(FACING)));
   }

   @NotNull
   protected class_2680 method_9569(class_2680 blockState, class_2415 mirror) {
      return blockState.method_26186(mirror.method_10345((class_2350)blockState.method_11654(FACING)));
   }

   @NotNull
   public class_265 method_9530(@NotNull class_2680 state, @NotNull class_1922 blockGetter, @NotNull class_2338 pos, @NotNull class_3726 ctx) {
      if (blockGetter.method_8321(pos) instanceof BarStoolBlockEntity barStool) {
         return switch (barStool.currentFacing(3.25F, state)) {
            case NORTH -> NORTH_SHAPE;
            case SOUTH -> SOUTH_SHAPE;
            case EAST -> EAST_SHAPE;
            case WEST -> WEST_SHAPE;
            case null, default -> SHAPE;
         };
      } else {
         return SHAPE;
      }
   }

   @NotNull
   public class_2464 method_9604(@NotNull class_2680 state) {
      return class_2464.field_11458;
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }

   @Override
   public float getSitHeight() {
      return 0.9483F;
   }

   protected @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      List<SitEntity> entities = level.method_18467(SitEntity.class, new class_238(pos));
      if (entities.isEmpty()) {
         if (!level.method_8608()) {
            SitEntity entitySit = new SitEntity(level, pos, 0.875);
            entitySit.method_36456(((class_2350)state.method_11654(FACING)).method_10144());
            SitUtil.addSitEntity(level, pos, entitySit, player.method_73189());
            level.method_8649(entitySit);
            player.method_5873(entitySit, true, false);
         }

         return class_1269.field_5812;
      } else {
         return class_1269.field_5811;
      }
   }

   @Nullable
   public class_2586 method_10123(@NotNull class_2338 blockPos, @NotNull class_2680 blockState) {
      return new BarStoolBlockEntity(blockPos, blockState, this.color);
   }

   public <T extends class_2586> class_5558<T> method_31645(class_1937 level, @NotNull class_2680 state, @NotNull class_2591<T> blockEntityType) {
      return level.method_8608() ? null : method_31618(blockEntityType, ModBlocks.BAR_STOOL_BE, BarStoolBlockEntity::tick);
   }
}
