package com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class WaterloggedBehavior implements ITapBehavior {
   @Override
   public boolean isMatch(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      if (!sourceState.method_28498(class_2741.field_12508) || !(Boolean)sourceState.method_11654(class_2741.field_12508)) {
         return false;
      } else if (destinationState.method_27852(class_2246.field_10593) || destinationState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
         return true;
      } else {
         return destinationState.method_27852(class_2246.field_27097) ? (Integer)destinationState.method_11654(class_2741.field_12513) < 3 : false;
      }
   }

   @Nullable
   @Override
   public class_2394 onStartExtract(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      return ModParticles.WATER_TAP_DRIP;
   }

   @Override
   public void onEndExtract(class_1937 level, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState) {
      if (!destinationState.method_27852(class_2246.field_10593) && !destinationState.method_27852(class_2246.field_27097)) {
         if (destinationState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
            level.method_8501(tapPos.method_10074(), ModBlocks.WATER_BOTTLE.method_9564());
            level.method_8396(null, tapPos.method_10074(), class_3417.field_14978, class_3419.field_15245, 1.0F, 1.0F);
            ITapBehavior.sendParticles(level, tapPos);
         }
      } else {
         class_2680 state = class_2246.field_27097.method_9564();
         state = (class_2680)state.method_11657(class_2741.field_12513, 3);
         level.method_8501(tapPos.method_10074(), state);
         level.method_8396(null, tapPos.method_10074(), class_3417.field_28292, class_3419.field_15245, 1.0F, 1.0F);
         ITapBehavior.sendParticles(level, tapPos);
      }
   }
}
