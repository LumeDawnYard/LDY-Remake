package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.google.common.collect.Lists;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2350.class_2353;
import org.jetbrains.annotations.NotNull;

public class VoxelShapeUtils {
   public static EnumMap<class_2350, class_265> horizontalShapes(@NotNull class_265 northShape) {
      EnumMap<class_2350, class_265> result = new EnumMap<>(class_2350.class);

      for (class_2350 direction : class_2353.field_11062) {
         result.put(direction, rotateShape(northShape, direction));
      }

      return result;
   }

   public static class_265 rotateShape(class_265 shape, class_2350 direction) {
      List<class_265> parts = Lists.newArrayList();
      shape.method_1089((x1, y1, z1, x2, y2, z2) -> {
         double rx1;
         double rz1;
         double rx2;
         double rz2;
         switch (direction) {
            case field_11034:
               rx1 = 1.0 - z2;
               rz1 = x1;
               rx2 = 1.0 - z1;
               rz2 = x2;
               break;
            case field_11035:
               rx1 = 1.0 - x2;
               rz1 = 1.0 - z2;
               rx2 = 1.0 - x1;
               rz2 = 1.0 - z1;
               break;
            case field_11039:
               rx1 = z1;
               rz1 = 1.0 - x2;
               rx2 = z2;
               rz2 = 1.0 - x1;
               break;
            default:
               rx1 = x1;
               rz1 = z1;
               rx2 = x2;
               rz2 = z2;
         }

         parts.add(class_259.method_1081(rx1, y1, rz1, rx2, y2, rz2));
      });
      return parts.stream().reduce(class_259.method_1073(), class_259::method_1084);
   }
}
