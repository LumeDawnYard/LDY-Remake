package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.StorageBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public abstract class StorageBlockEntityRender<T extends StorageBlockEntity, M extends StorageBlockEntityRenderState> implements class_827<T, M> {
   protected final class_776 blockRender;

   protected StorageBlockEntityRender(class_5615 context) {
      this.blockRender = context.comp_4535();
   }

   public void extractRenderState(
      @NonNull T blockEntity, @NonNull M blockEntityRenderState, float f, @NonNull class_243 vec3, @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      List<class_1799> stacks = new ArrayList<>();

      for (int i = 0; i < blockEntity.getItems().getSlots(); i++) {
         stacks.add(blockEntity.getItems().getStackInSlot(i));
      }

      blockEntityRenderState.items = stacks;
   }

   protected void applyFacingRotation(class_2350 direction, class_4587 poseStack) {
      float angle = 180.0F - direction.method_10161() * 90.0F;
      poseStack.method_22904(0.5, 0.0, 0.5);
      poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
      poseStack.method_22904(-0.5, 0.0, -0.5);
   }

   protected void renderStack(
      class_1799 stack,
      class_4587 poseStack,
      class_11659 submitNodeCollector,
      int packedLight,
      double x,
      double y,
      double z,
      float scale,
      double yRot,
      double xRot
   ) {
      if (!stack.method_7960() && stack.method_7909() instanceof class_1747 blockItem) {
         poseStack.method_22903();
         class_2680 var19 = blockItem.method_7711().method_9564();
         poseStack.method_22904(x, y, z);
         poseStack.method_22907(class_7833.field_40716.rotationDegrees((float)yRot));
         poseStack.method_22907(class_7833.field_40714.rotationDegrees((float)xRot));
         poseStack.method_22905(scale, scale, scale);
         poseStack.method_22904(-0.5, 0.0, -0.5);
         class_1087 blockStateModel = this.blockRender.method_3349(var19);
         submitNodeCollector.method_73484(poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, packedLight, class_4608.field_21444, 0);
         poseStack.method_22909();
      }
   }

   public abstract void submit(M var1, @NonNull class_4587 var2, @NonNull class_11659 var3, @NonNull class_12075 var4);
}
