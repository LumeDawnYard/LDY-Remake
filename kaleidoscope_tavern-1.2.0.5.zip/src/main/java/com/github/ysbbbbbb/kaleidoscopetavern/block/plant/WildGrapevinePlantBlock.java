package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4538;
import net.minecraft.class_4864;
import net.minecraft.class_4865;
import net.minecraft.class_5459;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class WildGrapevinePlantBlock extends class_4864 implements class_2256 {
   public static final MapCodec<WildGrapevinePlantBlock> CODEC = method_54094(WildGrapevinePlantBlock::new);
   private static final class_265 SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

   public WildGrapevinePlantBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_16004).method_9634().method_9618().method_9626(class_2498.field_28692).method_50012(class_3619.field_15971),
         class_2350.field_11033,
         SHAPE,
         false
      );
   }

   public boolean method_9558(@NonNull class_2680 state, class_4538 level, class_2338 pos) {
      class_2338 relative = pos.method_10093(this.field_22507.method_10153());
      class_2680 relativeState = level.method_8320(relative);
      return relativeState.method_27852(this.method_24945())
         || relativeState.method_27852(this.method_24946())
         || this.method_24947(relativeState)
         || relativeState.method_26206(level, relative, this.field_22507);
   }

   protected boolean method_24947(class_2680 state) {
      return state.method_26164(class_3481.field_15503);
   }

   @NotNull
   protected class_4865 method_24945() {
      return (class_4865)ModBlocks.WILD_GRAPEVINE;
   }

   public boolean method_9651(@NonNull class_4538 level, @NonNull class_2338 pos, class_2680 state) {
      class_4865 headBlock = this.method_24945();
      return class_5459.method_34851(level, pos, state.method_26204(), this.field_22507, headBlock).map(headPos -> {
         class_2680 blockState = level.method_8320(headPos);
         return blockState.method_27852(headBlock) && !(Boolean)blockState.method_11654(WildGrapevineBlock.SHEARED);
      }).orElse(false);
   }

   @NotNull
   protected MapCodec<? extends class_4864> method_53969() {
      return CODEC;
   }
}
