package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import com.github.ysbbbbbb.kaleidoscopetavern.util.event.IEvent;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_757;

public abstract class ViewportEvent implements IEvent {
   private final class_757 renderer;
   private final class_4184 camera;
   private final double partialTick;

   public ViewportEvent(class_757 renderer, class_4184 camera, double partialTick) {
      this.renderer = renderer;
      this.camera = camera;
      this.partialTick = partialTick;
   }

   public class_757 getRenderer() {
      return this.renderer;
   }

   public class_4184 getCamera() {
      return this.camera;
   }

   public double getPartialTick() {
      return this.partialTick;
   }

   public static class ComputeCameraAngles extends ViewportEvent {
      private float yaw;
      private float pitch;
      private float roll;

      public static void register() {
      }

      public ComputeCameraAngles(class_4184 camera, double renderPartialTicks, float yaw, float pitch, float roll) {
         super(class_310.method_1551().field_1773, camera, renderPartialTicks);
         this.setYaw(yaw);
         this.setPitch(pitch);
         this.setRoll(roll);
      }

      public float getPitch() {
         return this.pitch;
      }

      public float getYaw() {
         return this.yaw;
      }

      public float getRoll() {
         return this.roll;
      }

      private void setYaw(float yaw) {
         this.yaw = yaw;
      }

      private void setPitch(float pitch) {
         this.pitch = pitch;
      }

      public void setRoll(float roll) {
         this.roll = roll;
      }

      @Override
      public void post() {
         ((IEvent.Callback)CALLBACK.invoker()).post(this);
      }
   }
}
