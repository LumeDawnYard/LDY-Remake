package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.StorageBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class CellarCabinetBlockEntity extends StorageBlockEntity {
   public CellarCabinetBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.CELLAR_CABINET_BE, pos, state, 9);
   }
}
