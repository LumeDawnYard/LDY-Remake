package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.PressingTubBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.PressingTubBlockEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.util.RenderUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class PressingTubBlockEntityRender implements class_827<PressingTubBlockEntity, PressingTubBlockEntityRenderState> {
   private final class_10442 itemModelResolver;

   public PressingTubBlockEntityRender(class_5615 context) {
      this.itemModelResolver = context.comp_4536();
   }

   public void extractRenderState(
      @NonNull PressingTubBlockEntity blockEntity,
      @NonNull PressingTubBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.items = blockEntity.getItems();
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(PressingTubBlock.FACING);
      blockEntityRenderState.tilt = (Boolean)blockEntity.method_11010().method_11654(PressingTubBlock.TILT);
      blockEntityRenderState.seed = blockEntity.method_11016().method_10063();
      class_1799 stack = blockEntity.getItems().getStackInSlot(0);
      int count = stack.method_7947();
      if (count > 0) {
         this.itemModelResolver.method_65598(blockEntityRenderState.itemState, stack, class_811.field_4319, null, null, 0);
      }

      blockEntityRenderState.fluid = blockEntity.getFluid().getFluid();
      blockEntityRenderState.fluidAmount = blockEntity.getFluidAmount();
   }

   public @NonNull PressingTubBlockEntityRenderState createRenderState() {
      return new PressingTubBlockEntityRenderState();
   }

   public void submit(
      PressingTubBlockEntityRenderState blockEntityRenderState,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      class_1799 stack = blockEntityRenderState.items.getStackInSlot(0);
      int count = stack.method_7947();
      if (count > 0) {
         if (blockEntityRenderState.tilt) {
            poseStack.method_22903();
            poseStack.method_22904(0.5, 0.0, 0.5);
            poseStack.method_22907(class_7833.field_40715.rotationDegrees(180 - blockEntityRenderState.facing.method_10161() * 90));
            poseStack.method_22904(-0.5, 0.0, -0.5);
            if (blockEntityRenderState.facing.method_10166() == class_2351.field_11048) {
               poseStack.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
               poseStack.method_22904(0.0, 0.5, -0.5);
            } else {
               poseStack.method_22907(class_7833.field_40713.rotationDegrees(45.0F));
               poseStack.method_22904(0.0, -0.25, 0.25);
            }
         }

         for (int i = 0; i < count; i++) {
            poseStack.method_22903();
            float x = i % 4 % 2 == 0 ? -0.15F : 0.15F + RenderUtils.stableRandom(blockEntityRenderState.seed, i, 1) * 0.0625F;
            float z = i % 4 / 2 == 0 ? -0.15F : 0.15F + RenderUtils.stableRandom(blockEntityRenderState.seed, i, 2) * 0.0625F;
            float y = i / 4 * 0.03125F + RenderUtils.stableRandom(blockEntityRenderState.seed, i, 3) * 0.05F;
            float yRot = RenderUtils.stableRandom(blockEntityRenderState.seed, i, 4) * count / 10.0F;
            float zRot = RenderUtils.stableRandom(blockEntityRenderState.seed, i, 5) * 360.0F;
            poseStack.method_46416(0.5F + x, 0.2F + y, 0.5F + z);
            poseStack.method_22905(0.5F, 0.5F, 0.5F);
            poseStack.method_22907(class_7833.field_40713.rotationDegrees(90.0F));
            poseStack.method_22907(class_7833.field_40715.rotationDegrees(yRot));
            poseStack.method_22907(class_7833.field_40717.rotationDegrees(zRot));
            blockEntityRenderState.itemState.method_65604(poseStack, submitNodeCollector, blockEntityRenderState.field_62676, class_4608.field_21444, 0);
            poseStack.method_22909();
         }

         if (blockEntityRenderState.tilt) {
            poseStack.method_22909();
         }
      }

      class_4598 buffer = class_310.method_1551().method_22940().method_23000();
      int fluidAmount = blockEntityRenderState.fluidAmount;
      if (fluidAmount > 0 && !blockEntityRenderState.tilt) {
         float percent = fluidAmount / 1000.0F;
         float y = 0.125F + percent * 0.25F;
         class_3611 fluid = blockEntityRenderState.fluid;
         RenderUtils.renderFluid(fluid, poseStack, buffer, blockEntityRenderState.field_62676, 12, y);
      }
   }
}
