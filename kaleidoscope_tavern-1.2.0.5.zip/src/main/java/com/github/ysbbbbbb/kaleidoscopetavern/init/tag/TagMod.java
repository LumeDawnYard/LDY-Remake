package com.github.ysbbbbbb.kaleidoscopetavern.init.tag;

import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public interface TagMod {
   class_6862<class_2248> SOFA = blockTag("sofa");
   class_6862<class_2248> BAR_STOOL = blockTag("bar_stool");
   class_6862<class_2248> SANDWICH_BOARD = blockTag("sandwich_board");
   class_6862<class_2248> STRING_LIGHTS = blockTag("string_lights");
   class_6862<class_2248> PAINTING = blockTag("painting");
   class_6862<class_2248> SITTABLE = blockTag("sittable");
   class_6862<class_2248> GRAPEVINE_TRELLISES = blockTag("grapevine_trellises");
   class_6862<class_2248> CAN_GROW_GRAPE = blockTag("can_grow_grape");
   class_6862<class_2248> CAN_GROW_ICE_GRAPE = blockTag("can_grow_ice_grape");
   class_6862<class_2248> CAN_GROW_GOLD_GRAPE = blockTag("can_grow_gold_grape");
   class_6862<class_2248> GRASS_STEALTH_PLANTS = blockTag("grass_stealth_plants");
   class_6862<class_2248> ARDENT_HEAT_BREAKABLE = blockTag("ardent_heat_breakable");
   class_6862<class_1792> BAR_CABINET_IRREGULAR = itemTag("bar_cabinet_irregular");
   class_6862<class_1792> CELLAR_CABINET_BLOCKLIST = itemTag("cellar_cabinet_blocklist");
   class_6862<class_1792> TILTED_RACK_BLOCKLIST = itemTag("tilted_rack_blocklist");
   class_6862<class_1792> CIRCULAR_RACK_BLOCKLIST = itemTag("circular_rack_blocklist");
   class_6862<class_1792> HOLDER_BLOCKLIST = itemTag("holder_blocklist");
   class_6862<class_1792> COCKTAIL_INGREDIENT = itemTag("cocktail_ingredient");
   class_6862<class_1792> COCKTAIL_INGREDIENT_BLACK = itemTag("cocktail_ingredient_black");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_BLUE = itemTag("cocktail_ingredient_dark_blue");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_GREEN = itemTag("cocktail_ingredient_dark_green");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_AQUA = itemTag("cocktail_ingredient_dark_aqua");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_RED = itemTag("cocktail_ingredient_dark_red");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_PURPLE = itemTag("cocktail_ingredient_dark_purple");
   class_6862<class_1792> COCKTAIL_INGREDIENT_GOLD = itemTag("cocktail_ingredient_gold");
   class_6862<class_1792> COCKTAIL_INGREDIENT_GRAY = itemTag("cocktail_ingredient_gray");
   class_6862<class_1792> COCKTAIL_INGREDIENT_DARK_GRAY = itemTag("cocktail_ingredient_dark_gray");
   class_6862<class_1792> COCKTAIL_INGREDIENT_BLUE = itemTag("cocktail_ingredient_blue");
   class_6862<class_1792> COCKTAIL_INGREDIENT_GREEN = itemTag("cocktail_ingredient_green");
   class_6862<class_1792> COCKTAIL_INGREDIENT_AQUA = itemTag("cocktail_ingredient_aqua");
   class_6862<class_1792> COCKTAIL_INGREDIENT_RED = itemTag("cocktail_ingredient_red");
   class_6862<class_1792> COCKTAIL_INGREDIENT_LIGHT_PURPLE = itemTag("cocktail_ingredient_light_purple");
   class_6862<class_1792> COCKTAIL_INGREDIENT_YELLOW = itemTag("cocktail_ingredient_yellow");
   class_6862<class_1792> COCKTAIL_INGREDIENT_WHITE = itemTag("cocktail_ingredient_white");
   class_6862<class_1299<?>> TOMB_RAIDER_DISARMABLE = entityTag("tomb_raider_disarmable");

   static class_6862<class_1792> itemTag(String name) {
      return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("kaleidoscope_tavern", name));
   }

   static class_6862<class_2248> blockTag(String name) {
      return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("kaleidoscope_tavern", name));
   }

   static class_6862<class_1299<?>> entityTag(String name) {
      return class_6862.method_40092(class_7924.field_41266, class_2960.method_60655("kaleidoscope_tavern", name));
   }

   static class_6862<class_8110> damageTypeTag(String name) {
      return class_6862.method_40092(class_7924.field_42534, class_2960.method_60655("kaleidoscope_tavern", name));
   }
}
