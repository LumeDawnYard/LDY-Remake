package com.github.ysbbbbbb.kaleidoscopetavern.worldgen;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModTreeDecoratorTypes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5819;
import net.minecraft.class_4662.class_7402;
import org.jspecify.annotations.NonNull;

public class WildGrapevineDecorator extends class_4662 {
   public static final MapCodec<WildGrapevineDecorator> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            Codec.floatRange(0.0F, 1.0F).fieldOf("probability").forGetter(d -> d.probability),
            Codec.intRange(1, 16).fieldOf("max_vine_count").forGetter(d -> d.maxVineCount),
            Codec.intRange(1, 16).fieldOf("vine_chain_length").forGetter(d -> d.vineChainLength)
         )
         .apply(instance, WildGrapevineDecorator::new)
   );
   private final float probability;
   private final int maxVineCount;
   private final int vineChainLength;

   public WildGrapevineDecorator(float probability, int maxVineCount, int vineChainLength) {
      this.probability = probability;
      this.maxVineCount = maxVineCount;
      this.vineChainLength = vineChainLength;
   }

   protected @NonNull class_4663<?> method_28893() {
      return ModTreeDecoratorTypes.WILD_GRAPEVINE;
   }

   public void method_23469(class_7402 context) {
      class_5819 random = context.method_43320();
      int vineCount = random.method_43048(this.maxVineCount) + 1;
      int[] recordCount = new int[]{0};
      context.method_43322().forEach(pos -> {
         if (recordCount[0] < vineCount) {
            if (random.method_43057() < this.probability) {
               boolean belowIsAir = context.method_43317(pos.method_10074());
               boolean belowTwoIsAir = context.method_43317(pos.method_10087(2));
               if (belowIsAir && belowTwoIsAir) {
                  this.placeVineChain(context, pos.method_10074(), random.method_43048(this.vineChainLength) + 1);
                  recordCount[0]++;
               }
            }
         }
      });
   }

   private void placeVineChain(class_7402 context, class_2338 startPos, int chainLength) {
      class_2338 pos = startPos;

      for (int i = 0; i < chainLength && context.method_43317(pos) && i != chainLength - 1 && context.method_43317(pos.method_10074()); i++) {
         context.method_43318(pos, ModBlocks.WILD_GRAPEVINE_PLANT.method_9564());
         pos = pos.method_10074();
      }
   }
}
