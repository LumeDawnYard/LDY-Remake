package com.github.ysbbbbbb.kaleidoscopetavern.client.model.deco;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class BarStoolBodyModel extends class_3879<BarStoolBodyModel.State> {
   public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655("kaleidoscope_tavern", "bar_stool"), "main");
   private final class_630 bone = this.field_54014.method_32086("bone");

   public BarStoolBodyModel(class_630 modelPart) {
      super(modelPart, class_12249::method_75982);
   }

   public static class_5607 createBodyLayer() {
      class_5609 meshdefinition = new class_5609();
      class_5610 partdefinition = meshdefinition.method_32111();
      class_5610 bone = partdefinition.method_32117(
         "bone",
         class_5606.method_32108()
            .method_32101(0, 18)
            .method_32098(-6.0F, -15.0F, -5.0F, 12.0F, 3.0F, 11.0F, new class_5605(0.0F))
            .method_32101(0, 0)
            .method_32098(-6.0F, -21.0F, 3.0F, 12.0F, 6.0F, 3.0F, new class_5605(0.0F)),
         class_5603.method_32090(0.0F, 24.0F, 0.0F)
      );
      class_5610 cube_r1 = bone.method_32117(
         "cube_r1",
         class_5606.method_32108()
            .method_32101(46, 11)
            .method_32098(-1.0F, -0.5F, -3.5F, 2.0F, 4.0F, 7.0F, new class_5605(0.0F))
            .method_32101(46, 0)
            .method_32098(-13.0F, -0.5F, -3.5F, 2.0F, 4.0F, 7.0F, new class_5605(0.0F)),
         class_5603.method_32091(6.0F, -16.6F, 0.3F, 0.3927F, 0.0F, 0.0F)
      );
      return class_5607.method_32110(meshdefinition, 64, 32);
   }

   public void setupAnim(BarStoolBodyModel.State object) {
      super.method_2819(object);
   }

   @Environment(EnvType.CLIENT)
   public record State() {
   }
}
