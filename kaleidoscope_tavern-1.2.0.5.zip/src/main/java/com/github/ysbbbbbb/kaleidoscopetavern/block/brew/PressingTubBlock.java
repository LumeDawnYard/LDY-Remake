package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.IPressingTub;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PressingTubBlock extends class_2237 implements class_3737 {
   public static final MapCodec<PressingTubBlock> CODEC = method_54094(PressingTubBlock::new);
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2746 TILT = class_2746.method_11825("tilt");
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 SHAPE = class_259.method_1072(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(2.0, 4.0, 2.0, 14.0, 8.0, 14.0), class_247.field_16886
   );
   public static final class_265 TILTED_SHAPE_NORTH = class_259.method_17786(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 8.0),
      new class_265[]{class_2248.method_9541(0.0, 4.0, 4.0, 16.0, 12.0, 12.0), class_2248.method_9541(0.0, 8.0, 8.0, 16.0, 16.0, 16.0)}
   );
   public static final class_265 TILTED_SHAPE_SOUTH = class_259.method_17786(
      class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 8.0, 16.0),
      new class_265[]{class_2248.method_9541(0.0, 4.0, 4.0, 16.0, 12.0, 12.0), class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 16.0, 8.0)}
   );
   public static final class_265 TILTED_SHAPE_WEST = class_259.method_17786(
      class_2248.method_9541(0.0, 0.0, 0.0, 8.0, 8.0, 16.0),
      new class_265[]{class_2248.method_9541(4.0, 4.0, 0.0, 12.0, 12.0, 16.0), class_2248.method_9541(8.0, 8.0, 0.0, 16.0, 16.0, 16.0)}
   );
   public static final class_265 TILTED_SHAPE_EAST = class_259.method_17786(
      class_2248.method_9541(8.0, 0.0, 0.0, 16.0, 8.0, 16.0),
      new class_265[]{class_2248.method_9541(4.0, 4.0, 0.0, 12.0, 12.0, 16.0), class_2248.method_9541(0.0, 8.0, 0.0, 8.0, 16.0, 16.0)}
   );

   public PressingTubBlock(class_2251 p) {
      super(p);
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043))
               .method_11657(TILT, false))
            .method_11657(WATERLOGGED, false)
      );
   }

   @NotNull
   public class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (level.method_8321(pos) instanceof IPressingTub pressingTub) {
         class_1799 itemInHand = player.method_5998(hand);
         if (itemInHand.method_7960()) {
            int removeCount = player.method_21823() ? 64 : 1;
            return (class_1269)(pressingTub.removeIngredient(player, removeCount) ? class_1269.field_5812 : class_1269.field_5811);
         } else if (pressingTub.getResult(player, itemInHand)) {
            return class_1269.field_5812;
         } else {
            return (class_1269)(pressingTub.addIngredient(itemInHand) ? class_1269.field_5812 : class_1269.field_5811);
         }
      } else {
         return class_1269.field_5811;
      }
   }

   public void method_9554(@NonNull class_1937 level, @NonNull class_2680 blockState, @NonNull class_2338 blockPos, @NonNull class_1297 entity, double d) {
      if ((Boolean)blockState.method_11654(TILT)) {
         super.method_9554(level, blockState, blockPos, entity, d);
      } else {
         if (entity instanceof class_1309 livingEntity) {
            if (!(level.method_8321(blockPos) instanceof IPressingTub pressingTub)) {
               return;
            }

            if (pressingTub.press(livingEntity, (float)d)) {
               return;
            }
         }

         super.method_9554(level, blockState, blockPos, entity, d);
      }
   }

   @NotNull
   public List<class_1799> method_9560(@NonNull class_2680 pState, @NonNull class_8568 pParams) {
      List<class_1799> stacks = super.method_9560(pState, pParams);
      class_2586 blockEntity = (class_2586)pParams.method_51876(class_181.field_1228);
      if (blockEntity instanceof IPressingTub pressingTub) {
         class_1799 drop = pressingTub.getItems().getStackInSlot(0).method_7972();
         if (!drop.method_7960()) {
            stacks.add(drop);
         }
      }

      return stacks;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, TILT, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2350 clickedFace;
      boolean isTilting;
      if (context.method_8038().method_10166().method_10178()) {
         clickedFace = context.method_8042().method_10153();
         isTilting = false;
      } else {
         clickedFace = context.method_8038();
         isTilting = true;
      }

      return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(FACING, clickedFace)).method_11657(TILT, isTilting))
         .method_11657(WATERLOGGED, context.method_8045().method_22351(context.method_8037()));
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      if ((Boolean)state.method_11654(TILT)) {
         return switch ((class_2350)state.method_11654(FACING)) {
            case field_11043 -> TILTED_SHAPE_NORTH;
            case field_11035 -> TILTED_SHAPE_SOUTH;
            case field_11039 -> TILTED_SHAPE_WEST;
            case field_11034 -> TILTED_SHAPE_EAST;
            default -> SHAPE;
         };
      } else {
         return SHAPE;
      }
   }

   @NotNull
   public class_2464 method_9604(@NonNull class_2680 state) {
      return class_2464.field_11458;
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, @NonNull class_2680 state) {
      return new PressingTubBlockEntity(pos, state);
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   public boolean method_9498(@NonNull class_2680 blockState) {
      return true;
   }

   protected int method_9572(@NonNull class_2680 blockState, @NonNull class_1937 level, @NonNull class_2338 blockPos, @NonNull class_2350 direction) {
      return level.method_8321(blockPos) instanceof IPressingTub pressingTub ? pressingTub.getFluidAmount() : 0;
   }

   public @NonNull class_1799 method_9700(
      @Nullable class_1309 livingEntity, @NonNull class_1936 level, @NonNull class_2338 blockPos, @NonNull class_2680 blockState
   ) {
      class_1799 stack = super.method_9700(livingEntity, level, blockPos, blockState);
      if (!stack.method_7960()) {
         return stack;
      }

      if (level.method_8608()) {
         return stack;
      }

      if (level.method_8321(blockPos) instanceof PressingTubBlockEntity pressingTub) {
         if (pressingTub.getFluidAmount() < 1000) {
            return stack;
         }

         CustomFluidTank fluidTank = pressingTub.getFluid();
         class_3611 fluid = fluidTank.getFluid();
         class_1792 bucket = fluid.method_15774();
         if (bucket instanceof class_1755) {
            FluidVariant variant = fluidTank.getFluidVariant();
            Transaction transaction = Transaction.openOuter();

            class_1799 var15;
            label72: {
               try {
                  long extracted = fluidTank.extract(variant, 81000L, transaction);
                  if (extracted == 81000L) {
                     transaction.commit();
                     var15 = bucket.method_7854();
                     break label72;
                  }
               } catch (Throwable var17) {
                  if (transaction != null) {
                     try {
                        transaction.close();
                     } catch (Throwable var16) {
                        var17.addSuppressed(var16);
                     }
                  }

                  throw var17;
               }

               if (transaction != null) {
                  transaction.close();
               }

               return stack;
            }

            if (transaction != null) {
               transaction.close();
            }

            return var15;
         } else {
            return stack;
         }
      } else {
         return stack;
      }
   }

   @NotNull
   public class_2680 method_9598(class_2680 state, class_2470 rot) {
      return (class_2680)state.method_11657(FACING, rot.method_10503((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   public class_2680 method_9569(class_2680 state, class_2415 mirror) {
      return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }
}
