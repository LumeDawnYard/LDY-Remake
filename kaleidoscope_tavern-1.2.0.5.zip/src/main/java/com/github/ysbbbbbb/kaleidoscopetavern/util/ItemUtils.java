package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.IItemHandler;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.PlayerMainInvWrapper;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import org.apache.commons.lang3.tuple.Pair;

public class ItemUtils {
   public static void getItemToLivingEntity(class_1309 entity, class_1799 stack) {
      if (!stack.method_7960()) {
         if (entity.method_6047().method_7960()) {
            class_5819 random = entity.method_73183().method_8409();
            entity.method_6122(class_1268.field_5808, stack);
            entity.method_5783(class_3417.field_15197, 0.2F, ((random.method_43057() - random.method_43057()) * 0.7F + 1.0F) * 2.0F);
         } else if (entity instanceof class_1657 player) {
            player.method_31548().method_7398(stack);
         } else if (entity.method_73183() instanceof class_3218 serverLevel) {
            class_1542 dropItem = entity.method_5775(serverLevel, stack);
            if (dropItem != null) {
               dropItem.method_6982(0);
            }
         }
      }
   }

   public static void getItemToLivingEntity(class_1309 entity, class_1799 stack, int preferredSlot) {
      if (!stack.method_7960()) {
         if (entity.method_6047().method_7960()) {
            class_5819 random = entity.method_73183().field_9229;
            entity.method_6122(class_1268.field_5808, stack);
            entity.method_5783(class_3417.field_15197, 0.2F, ((random.method_43057() - random.method_43057()) * 0.7F + 1.0F) * 2.0F);
         } else if (entity instanceof class_1657 player) {
            giveItemToPlayer(player, stack, preferredSlot);
         } else if (entity.method_73183() instanceof class_3218 serverLevel) {
            class_1542 dropItem = entity.method_5775(serverLevel, stack);
            if (dropItem != null) {
               dropItem.method_6982(0);
            }
         }
      }
   }

   public static Pair<Integer, class_1799> getLastStack(class_2371<class_1799> itemList) {
      for (int i = itemList.size(); i > 0; i--) {
         int index = i - 1;
         class_1799 stack = (class_1799)itemList.get(index);
         if (!stack.method_7960()) {
            return Pair.of(index, stack);
         }
      }

      return Pair.of(0, class_1799.field_8037);
   }

   public static void giveItemToPlayer(class_1657 player, class_1799 stack) {
      giveItemToPlayer(player, stack, -1);
   }

   public static void giveItemToPlayer(class_1657 player, class_1799 stack, int preferredSlot) {
      if (!stack.method_7960()) {
         IItemHandler inventory = new PlayerMainInvWrapper(player.method_31548());
         class_1937 level = player.method_73183();
         class_1799 remainder = stack.method_7972();
         if (preferredSlot >= 0 && preferredSlot < inventory.getSlots()) {
            remainder = inventory.insertItem(preferredSlot, stack, false);
         }

         if (!remainder.method_7960()) {
            remainder = insertItemStacked(inventory, remainder, false);
         }

         if (remainder.method_7960() || remainder.method_7947() != stack.method_7947()) {
            level.method_43128(
               null,
               player.method_23317(),
               player.method_23318() + 0.5,
               player.method_23321(),
               class_3417.field_15197,
               class_3419.field_15248,
               0.2F,
               ((level.field_9229.method_43057() - level.field_9229.method_43057()) * 0.7F + 1.0F) * 2.0F
            );
         }

         if (!remainder.method_7960() && !level.method_8608()) {
            class_1542 entityItem = new class_1542(level, player.method_23317(), player.method_23318() + 0.5, player.method_23321(), remainder);
            entityItem.method_6982(40);
            entityItem.method_18799(entityItem.method_18798().method_18805(0.0, 1.0, 0.0));
            level.method_8649(entityItem);
         }
      }
   }

   public static class_1799 insertItem(IItemHandler dest, class_1799 stack, boolean simulate) {
      if (dest != null && !stack.method_7960()) {
         for (int i = 0; i < dest.getSlots(); i++) {
            stack = dest.insertItem(i, stack, simulate);
            if (stack.method_7960()) {
               return class_1799.field_8037;
            }
         }
      }

      return stack;
   }

   public static class_1799 insertItemStacked(IItemHandler inventory, class_1799 stack, boolean simulate) {
      if (inventory == null || stack.method_7960()) {
         return stack;
      }

      if (!stack.method_7946()) {
         return insertItem(inventory, stack, simulate);
      }

      int sizeInventory = inventory.getSlots();

      for (int i = 0; i < sizeInventory; i++) {
         class_1799 slot = inventory.getStackInSlot(i);
         if (class_1799.method_31577(slot, stack)) {
            stack = inventory.insertItem(i, stack, simulate);
            if (stack.method_7960()) {
               break;
            }
         }
      }

      if (!stack.method_7960()) {
         for (int i = 0; i < sizeInventory; i++) {
            if (inventory.getStackInSlot(i).method_7960()) {
               stack = inventory.insertItem(i, stack, simulate);
               if (stack.method_7960()) {
                  break;
               }
            }
         }
      }

      return stack;
   }
}
