package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.GlasswareHolderBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class GlasswareHolderBlock extends class_2383 implements class_2343, class_3737 {
   public static final class_265 NORTH_SOUTH_SHAPE = class_2248.method_9541(0.0, 11.0, 1.0, 16.0, 16.0, 15.0);
   public static final class_265 EAST_WEST_SHAPE = class_2248.method_9541(1.0, 11.0, 0.0, 15.0, 16.0, 16.0);
   private static final MapCodec<GlasswareHolderBlock> CODEC = method_54094(p -> new GlasswareHolderBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public GlasswareHolderBlock() {
      super(
         class_2251.method_9637().method_31710(class_3620.field_16005).method_9632(0.8F).method_9626(class_2498.field_11533).method_9631(s -> 8).method_22488()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(WATERLOGGED, false))
            .method_11657(field_11177, class_2350.field_11043)
      );
   }

   public GlasswareHolderBlock(class_2251 properties) {
      super(properties.method_31710(class_3620.field_16005).method_9632(0.8F).method_9626(class_2498.field_11533).method_9631(s -> 8).method_22488());
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(WATERLOGGED, false))
            .method_11657(field_11177, class_2350.field_11043)
      );
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      if (hand != class_1268.field_5808) {
         return class_1269.field_5811;
      }

      if (level.method_8321(pos) instanceof GlasswareHolderBlockEntity be) {
         int slot = this.getSlotFromHit(hitResult, pos);
         class_1799 itemInHand = player.method_5998(hand);
         if (itemInHand.method_31574(ModItems.EMPTY_GLASSWARE)) {
            return this.putOn(level, pos, player, be, slot);
         } else {
            return (class_1269)(itemInHand.method_7960() ? this.takeOut(level, pos, player, be, slot) : class_1269.field_5811);
         }
      } else {
         return class_1269.field_5811;
      }
   }

   private class_1269 takeOut(class_1937 level, class_2338 pos, class_1657 player, GlasswareHolderBlockEntity be, int slot) {
      ItemStackHandler items = be.getItems();
      if (items.getStackInSlot(slot).method_7960()) {
         return class_1269.field_5811;
      }

      if (!level.method_8608()) {
         class_1799 extracted = items.extractItem(slot, 1, false);
         player.method_6122(class_1268.field_5808, extracted);
         be.refresh();
         level.method_45447(null, pos, class_3417.field_26940, class_3419.field_15245);
      }

      return level.method_8608() ? class_1269.field_5812 : class_1269.field_52422;
   }

   private class_1269 putOn(class_1937 level, class_2338 pos, class_1657 player, GlasswareHolderBlockEntity be, int slot) {
      ItemStackHandler items = be.getItems();
      if (!items.getStackInSlot(slot).method_7960()) {
         return class_1269.field_21466;
      }

      class_1799 itemInHand = player.method_6047();
      if (!level.method_8608()) {
         items.setStackInSlot(slot, itemInHand.method_46651(1));
         if (!player.method_31549().field_7477) {
            itemInHand.method_7934(1);
         }

         be.refresh();
         level.method_45447(null, pos, class_3417.field_26940, class_3419.field_15245);
      }

      return level.method_8608() ? class_1269.field_5812 : class_1269.field_52422;
   }

   private int getSlotFromHit(class_3965 hitResult, class_2338 pos) {
      class_243 hit = hitResult.method_17784();
      double localX = hit.field_1352 - pos.method_10263();
      double localZ = hit.field_1350 - pos.method_10260();
      if (localX > 0.5) {
         return localZ > 0.5 ? 3 : 1;
      } else {
         return localZ > 0.5 ? 2 : 0;
      }
   }

   @Nullable
   public class_2586 method_10123(class_2338 pos, class_2680 state) {
      return new GlasswareHolderBlockEntity(pos, state);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      class_2350 opposite = context.method_8042().method_10153();
      return (class_2680)((class_2680)this.method_9564().method_11657(field_11177, opposite)).method_11657(WATERLOGGED, hasWater);
   }

   public @NonNull List<class_1799> method_9560(class_2680 state, class_8568 builder) {
      List<class_1799> stacks = super.method_9560(state, builder);
      class_2586 blockEntity = (class_2586)builder.method_51876(class_181.field_1228);
      if (blockEntity instanceof GlasswareHolderBlockEntity be) {
         ItemStackHandler items = be.getItems();

         for (int i = 0; i < items.getSlots(); i++) {
            class_1799 stack = items.getStackInSlot(i);
            if (!stack.method_7960()) {
               stacks.add(stack);
            }
         }

         return stacks;
      } else {
         return stacks;
      }
   }

   public @NonNull class_265 method_9530(class_2680 state, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
      return switch ((class_2350)state.method_11654(field_11177)) {
         case field_11043, field_11035 -> NORTH_SOUTH_SHAPE;
         default -> EAST_WEST_SHAPE;
      };
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
