package com.github.ysbbbbbb.kaleidoscopetavern.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_663;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class TapDripParticle extends class_663 {
   private final class_2394 fallingParticle;

   public TapDripParticle(class_638 pLevel, double pX, double pY, double pZ, class_3611 pType, class_2394 fallingParticle, class_1058 sprite) {
      super(pLevel, pX, pY, pZ, pType, sprite);
      this.fallingParticle = fallingParticle;
      this.field_3844 *= 0.02F;
      this.field_3847 = 18;
   }

   protected void method_18821() {
      super.method_18821();
      this.field_3851.method_8406(this.fallingParticle, this.field_3874, this.field_3854, this.field_3871, this.field_3852, this.field_3869, this.field_3850);
   }

   protected void method_18822() {
      this.field_3852 *= 0.02;
      this.field_3869 *= 0.02;
      this.field_3850 *= 0.02;
   }

   public static class LavaProvider implements class_707<class_2400> {
      private final class_4002 sprites;

      public LavaProvider(class_4002 pSprites) {
         this.sprites = pSprites;
      }

      public @Nullable class_703 createParticle(
         @NonNull class_2400 type,
         @NonNull class_638 level,
         double pX,
         double pY,
         double pZ,
         double pXSpeed,
         double pYSpeed,
         double pZSpeed,
         @NonNull class_5819 randomSource
      ) {
         TapDripParticle dripParticle = new TapDripParticle(
            level, pX, pY, pZ, class_3612.field_15908, class_2398.field_28077, this.sprites.method_18139(randomSource)
         );
         dripParticle.method_74306(this.sprites);
         return dripParticle;
      }
   }

   public static class WaterProvider implements class_707<class_2400> {
      private final class_4002 sprites;

      public WaterProvider(class_4002 pSprites) {
         this.sprites = pSprites;
      }

      public @Nullable class_703 createParticle(
         @NonNull class_2400 pType,
         @NonNull class_638 level,
         double pX,
         double pY,
         double pZ,
         double pXSpeed,
         double pYSpeed,
         double pZSpeed,
         @NonNull class_5819 randomSource
      ) {
         class_663 dripparticle = new TapDripParticle(
            level, pX, pY, pZ, class_3612.field_15910, class_2398.field_28079, this.sprites.method_18139(randomSource)
         );
         dripparticle.method_74305(0.2F, 0.3F, 1.0F);
         dripparticle.method_74306(this.sprites);
         return dripparticle;
      }
   }
}
