package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.init;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;

@Environment(EnvType.CLIENT)
public class PonderCompat {
   public static final String ID = "create";
   public static boolean PONDER_LOADED = false;

   @Environment(EnvType.CLIENT)
   public static void init() {
      if (FabricLoader.getInstance().isModLoaded("create")) {
         PONDER_LOADED = true;
         TavernPonderPlugin.init();
      }
   }
}
