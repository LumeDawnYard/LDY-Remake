package com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_6885;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class ShakerRecipeSerializer implements class_1865<ShakerRecipe> {
   public static final int MAX_INGREDIENTS = 3;
   private static final MapCodec<ShakerRecipe> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            class_1856.field_52596
               .listOf()
               .optionalFieldOf("ingredients", List.of())
               .forGetter(
                  recipe -> recipe.ingredients().stream().filter(i -> !i.method_65799()).map(i -> class_6885.method_40242(i.method_8105().toList())).toList()
               ),
            class_1799.field_24671.fieldOf("result").forGetter(ShakerRecipe::result)
         )
         .apply(
            instance,
            (ingredients, result) -> new ShakerRecipe(
               ingredients.stream()
                  .filter(s -> !s.method_62680() || s.method_40247() > 0)
                  .map(class_1856::method_8106)
                  .collect(Collectors.toCollection(class_2371::method_10211)),
               result,
               Int2ObjectMaps.emptyMap()
            )
         )
   );
   private static final class_9139<class_9129, ShakerRecipe> STREAM_CODEC = new class_9139<class_9129, ShakerRecipe>() {
      @NotNull
      public ShakerRecipe decode(class_9129 buf) {
         int size = Math.min(3, buf.method_10816());
         class_2371<class_1856> ingredients = class_2371.method_10211();

         for (int i = 0; i < size; i++) {
            ingredients.add((class_1856)class_1856.field_48355.decode(buf));
         }

         class_1799 result = (class_1799)class_1799.field_48349.decode(buf);
         Int2ObjectMap<class_124> ingredientColors = new Int2ObjectOpenHashMap();
         int colorSize = buf.method_10816();

         for (int i = 0; i < colorSize; i++) {
            int index = buf.method_10816();
            class_124 formatting = class_124.method_534(buf.method_10816());
            if (formatting != null) {
               ingredientColors.put(index, formatting);
            }
         }

         return new ShakerRecipe(ingredients, result, ingredientColors);
      }

      public void encode(class_9129 buf, ShakerRecipe recipe) {
         List<class_1856> nonEmpty = recipe.ingredients().stream().filter(i -> !i.method_65799()).toList();
         buf.method_10804(nonEmpty.size());

         for (class_1856 ingredient : nonEmpty) {
            class_1856.field_48355.encode(buf, ingredient);
         }

         class_1799.field_48349.encode(buf, recipe.result());
         Int2ObjectMap<class_124> ingredientColors = recipe.ingredientColors();
         buf.method_10804(ingredientColors.size());
         ingredientColors.forEach((index, formatting) -> {
            buf.method_10804(index);
            buf.method_10804(formatting.method_536());
         });
      }
   };

   @NotNull
   public MapCodec<ShakerRecipe> method_53736() {
      return CODEC;
   }

   @NotNull
   public class_9139<class_9129, ShakerRecipe> method_56104() {
      return STREAM_CODEC;
   }
}
