package com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.google.common.collect.Lists;
import java.util.List;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeHolderType;
import mezz.jei.api.recipe.types.IRecipeType;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_638;
import net.minecraft.class_8786;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PressingTubCategory implements IRecipeCategory<class_8786<PressingTubRecipe>> {
   public static final IRecipeHolderType<PressingTubRecipe> TYPE = IRecipeType.create(ModRecipes.PRESSING_TUB_RECIPE);
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/pressing_tub.png");
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.pressing_tub");
   public static final int WIDTH = 155;
   public static final int HEIGHT = 50;
   private final IDrawable bgDraw;
   private final IDrawable iconDraw;

   public PressingTubCategory(IGuiHelper guiHelper) {
      this.bgDraw = guiHelper.createDrawable(BG, 0, 0, 155, 50);
      this.iconDraw = guiHelper.createDrawableItemLike(ModItems.PRESSING_TUB);
   }

   public static List<class_8786<PressingTubRecipe>> getRecipes() {
      class_638 level = class_310.method_1551().field_1687;
      if (level == null) {
         return List.of();
      }

      List<class_8786<PressingTubRecipe>> recipes = Lists.newArrayList();
      recipes.addAll(level.method_8433().getSynchronizedRecipes().getAllOfType(ModRecipes.PRESSING_TUB_RECIPE));
      return recipes;
   }

   public void draw(
      class_8786<PressingTubRecipe> holder, @NonNull IRecipeSlotsView recipeSlotsView, @NonNull class_332 guiGraphics, double mouseX, double mouseY
   ) {
      this.bgDraw.draw(guiGraphics);
      PressingTubRecipe recipe = (PressingTubRecipe)holder.comp_1933();
      int needPressCount = 1000 / recipe.getFluidAmount();
      if (needPressCount * recipe.getFluidAmount() < 1000) {
         needPressCount++;
      }

      class_2561 tip = class_2561.method_43469("jei.kaleidoscope_tavern.pressing_tub.need_press_count", new Object[]{needPressCount});
      this.drawCenteredString(guiGraphics, tip);
   }

   private void drawCenteredString(class_332 guiGraphics, class_2561 text) {
      class_327 font = class_310.method_1551().field_1772;
      class_5481 sequence = text.method_30937();
      guiGraphics.method_51430(font, sequence, 155 - font.method_30880(sequence) - 5, 42, 5592405, false);
   }

   public void setRecipe(@NonNull IRecipeLayoutBuilder builder, class_8786<PressingTubRecipe> holder, @NonNull IFocusGroup focuses) {
      PressingTubRecipe recipe = (PressingTubRecipe)holder.comp_1933();
      int needPressCount = 1000 / recipe.getFluidAmount();
      if (needPressCount * recipe.getFluidAmount() < 1000) {
         needPressCount++;
      }

      class_1856 input = recipe.getIngredient();
      int finalNeedPressCount = needPressCount;
      List<class_1799> list = input.method_8105().map(s -> ((class_1792)s.comp_349()).method_7854().method_46651(finalNeedPressCount)).toList();
      builder.addSlot(RecipeIngredientRole.INPUT, 32, 13).addIngredients(VanillaTypes.ITEM_STACK, list);
      builder.addSlot(RecipeIngredientRole.OUTPUT, 128, 18).add(recipe.getFluid().method_15774());
   }

   public @NonNull IRecipeType<class_8786<PressingTubRecipe>> getRecipeType() {
      return TYPE;
   }

   @NotNull
   public class_2561 getTitle() {
      return TITLE;
   }

   public int getWidth() {
      return 155;
   }

   public int getHeight() {
      return 50;
   }

   @Nullable
   public IDrawable getIcon() {
      return this.iconDraw;
   }
}
