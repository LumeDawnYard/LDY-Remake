package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.AbstractStorageBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TiltedRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class TiltedRackBlock extends AbstractStorageBlock implements class_3737 {
   public static final class_265 NORTH_SHAPE = class_2248.method_9541(0.0, 0.0, 5.0, 16.0, 14.0, 15.0);
   public static final class_265 SOUTH_SHAPE = class_2248.method_9541(0.0, 0.0, 1.0, 16.0, 14.0, 11.0);
   public static final class_265 EAST_SHAPE = class_2248.method_9541(1.0, 0.0, 0.0, 11.0, 14.0, 16.0);
   public static final class_265 WEST_SHAPE = class_2248.method_9541(5.0, 0.0, 0.0, 15.0, 14.0, 16.0);
   private static final MapCodec<TiltedRackBlock> CODEC = method_54094(p -> new TiltedRackBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public TiltedRackBlock() {
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public TiltedRackBlock(class_2251 properties) {
      super(properties);
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   @Override
   public class_2680 method_9605(class_1750 context) {
      class_2680 stateForPlacement = super.method_9605(context);
      if (stateForPlacement == null) {
         return null;
      }

      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      return (class_2680)stateForPlacement.method_11657(WATERLOGGED, hasWater);
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      return super.handleUse(state, level, pos, player, hand, hitResult);
   }

   @Override
   protected boolean blockListCheck(class_1799 stack) {
      return stack.method_31573(TagMod.TILTED_RACK_BLOCKLIST);
   }

   @Override
   protected int getClickedSlot(class_2350 direction, class_2338 pos, class_3965 hitResult) {
      double localX = this.getLocalX(direction, pos, hitResult);
      if (localX < 0.3333333333333333) {
         return 0;
      } else {
         return localX < 0.6666666666666666 ? 1 : 2;
      }
   }

   @Override
   protected class_243 getShootPos(class_2350 direction, class_2338 pos, int slot) {
      direction = direction.method_10153();
      class_243 center = class_243.method_24954(pos).method_1031(0.5, 0.875, 0.5);
      class_243 scale = class_243.method_24954(new class_2382(direction.method_10148(), direction.method_10164(), direction.method_10165())).method_1021(0.5);
      return center.method_1019(scale);
   }

   @Override
   protected class_243 getMovement(class_2350 direction, class_2338 pos, int slot) {
      direction = direction.method_10153();
      class_2382 normal = new class_2382(direction.method_10148(), direction.method_10164(), direction.method_10165());
      double factor = Math.random() + 0.5;
      return class_243.method_49273(normal, 0.0, 0.75, 0.0).method_1021(factor);
   }

   @Override
   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      super.method_9515(builder);
      builder.method_11667(new class_2769[]{WATERLOGGED});
   }

   @Nullable
   public class_2586 method_10123(class_2338 pos, class_2680 state) {
      return new TiltedRackBlockEntity(pos, state);
   }

   public @NonNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
      return switch ((class_2350)state.method_11654(field_11177)) {
         case field_11035 -> SOUTH_SHAPE;
         case field_11034 -> EAST_SHAPE;
         case field_11039 -> WEST_SHAPE;
         default -> NORTH_SHAPE;
      };
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
