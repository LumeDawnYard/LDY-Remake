package com.github.ysbbbbbb.kaleidoscopetavern.fluid;

import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_2689.class_2690;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public abstract class JuiceFluid extends class_3609 {
   private final Supplier<? extends class_3609> flowing;
   private final Supplier<? extends class_3609> still;
   private final Supplier<? extends class_1792> bucket;
   private final Supplier<? extends class_2248> block;
   private final int tickRate;
   private final int slopeFindDistance;
   private final int dropOff;
   private final float blastResistance;

   protected JuiceFluid(
      Supplier<? extends class_3609> flowing, Supplier<? extends class_3609> still, Supplier<? extends class_1792> bucket, Supplier<? extends class_2248> block
   ) {
      this(flowing, still, bucket, block, 5, 4, 1, 100.0F);
   }

   protected JuiceFluid(
      Supplier<? extends class_3609> flowing,
      Supplier<? extends class_3609> still,
      Supplier<? extends class_1792> bucket,
      Supplier<? extends class_2248> block,
      int tickRate,
      int slopeFindDistance,
      int dropOff,
      float blastResistance
   ) {
      this.flowing = flowing;
      this.still = still;
      this.bucket = bucket;
      this.block = block;
      this.tickRate = tickRate;
      this.slopeFindDistance = slopeFindDistance;
      this.dropOff = dropOff;
      this.blastResistance = blastResistance;
   }

   @NotNull
   public class_3611 method_15750() {
      return (class_3611)this.flowing.get();
   }

   @NotNull
   public class_3611 method_15751() {
      return (class_3611)this.still.get();
   }

   @NotNull
   public class_1792 method_15774() {
      return this.bucket.get();
   }

   protected int method_15733(@NonNull class_4538 world) {
      return this.slopeFindDistance;
   }

   protected int method_15739(@NonNull class_4538 world) {
      return this.dropOff;
   }

   public int method_15789(@NonNull class_4538 world) {
      return this.tickRate;
   }

   protected float method_15784() {
      return this.blastResistance;
   }

   @NotNull
   public class_2680 method_15790(@NonNull class_3610 state) {
      return (class_2680)this.block.get().method_9564().method_11657(class_2404.field_11278, method_15741(state));
   }

   protected void method_15730(@NonNull class_1936 world, @NonNull class_2338 pos, class_2680 state) {
      class_2586 blockEntity = state.method_31709() ? world.method_8321(pos) : null;
      class_2248.method_9610(state, world, pos, blockEntity);
   }

   public boolean method_15777(
      @NonNull class_3610 state, @NonNull class_1922 world, @NonNull class_2338 pos, @NonNull class_3611 fluid, @NonNull class_2350 direction
   ) {
      return direction == class_2350.field_11033 && !fluid.method_15780(this);
   }

   public boolean method_15780(@NonNull class_3611 fluid) {
      return fluid == this.method_15750() || fluid == this.method_15751();
   }

   public static class Flowing extends JuiceFluid {
      public Flowing(
         Supplier<? extends class_3609> flowing,
         Supplier<? extends class_3609> still,
         Supplier<? extends class_1792> bucket,
         Supplier<? extends class_2248> block
      ) {
         super(flowing, still, bucket, block);
      }

      protected void method_15775(@NonNull class_2690<class_3611, class_3610> builder) {
         super.method_15775(builder);
         builder.method_11667(new class_2769[]{field_15900});
      }

      protected boolean method_15737(@NonNull class_3218 serverLevel) {
         return false;
      }

      public int method_15779(class_3610 state) {
         return (Integer)state.method_11654(field_15900);
      }

      public boolean method_15793(@NonNull class_3610 state) {
         return false;
      }
   }

   public static class Still extends JuiceFluid {
      public Still(
         Supplier<? extends class_3609> flowing,
         Supplier<? extends class_3609> still,
         Supplier<? extends class_1792> bucket,
         Supplier<? extends class_2248> block
      ) {
         super(flowing, still, bucket, block);
      }

      protected boolean method_15737(@NonNull class_3218 serverLevel) {
         return false;
      }

      public int method_15779(@NonNull class_3610 state) {
         return 8;
      }

      public boolean method_15793(@NonNull class_3610 state) {
         return true;
      }
   }
}
