package com.github.ysbbbbbb.kaleidoscopetavern.client.model.deco;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class LargeChalkboardModel extends class_3879<LargeChalkboardModel.State> {
   public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655("kaleidoscope_tavern", "large_chalk"), "main");
   private final class_630 bone;

   public LargeChalkboardModel(class_630 root) {
      super(root, class_12249::method_75982);
      this.bone = root.method_32086("bone");
   }

   public static class_5607 createBodyLayer() {
      class_5609 meshdefinition = new class_5609();
      class_5610 partdefinition = meshdefinition.method_32111();
      partdefinition.method_32117(
         "bone",
         class_5606.method_32108().method_32101(0, 0).method_32098(-32.0F, -30.0F, 15.0F, 48.0F, 28.0F, 1.0F, new class_5605(0.0F)),
         class_5603.method_32090(8.0F, 24.0F, -8.0F)
      );
      return class_5607.method_32110(meshdefinition, 128, 64);
   }

   @Environment(EnvType.CLIENT)
   public record State() {
   }
}
