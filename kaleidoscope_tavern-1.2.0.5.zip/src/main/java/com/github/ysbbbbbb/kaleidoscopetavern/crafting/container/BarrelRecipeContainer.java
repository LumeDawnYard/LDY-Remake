package com.github.ysbbbbbb.kaleidoscopetavern.crafting.container;

import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.IItemHandler;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_9695;
import org.jetbrains.annotations.NotNull;

public class BarrelRecipeContainer implements class_9695 {
   private final class_2371<class_1799> items;
   private final class_3611 fluid;

   public BarrelRecipeContainer(IItemHandler itemHandler, CustomFluidTank fluid) {
      this.items = class_2371.method_10213(itemHandler.getSlots(), class_1799.field_8037);

      for (int i = 0; i < itemHandler.getSlots(); i++) {
         this.items.set(i, itemHandler.getStackInSlot(i));
      }

      this.fluid = fluid.getFluid();
   }

   @NotNull
   public class_1799 method_59984(int index) {
      return (class_1799)this.items.get(index);
   }

   public int method_59983() {
      return this.items.size();
   }

   public boolean method_59987() {
      return this.fluid.method_15780(class_3612.field_15906);
   }

   public class_3611 getFluid() {
      return this.fluid;
   }

   public class_2371<class_1799> getItems() {
      return this.items;
   }

   public List<class_1799> getNonEmptyItems() {
      List<class_1799> nonEmpty = new ArrayList<>(this.items.size());

      for (class_1799 stack : this.items) {
         if (!stack.method_7960()) {
            nonEmpty.add(stack);
         }
      }

      return nonEmpty;
   }

   public boolean hasUnitCount(int requiredCount) {
      for (class_1799 stack : this.items) {
         if (!stack.method_7960() && stack.method_7947() < requiredCount) {
            return false;
         }
      }

      return true;
   }

   public boolean itemsIsEmpty() {
      return this.items.stream().allMatch(class_1799::method_7960);
   }
}
