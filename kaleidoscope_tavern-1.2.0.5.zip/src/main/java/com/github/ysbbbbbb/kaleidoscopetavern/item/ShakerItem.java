package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.GlasswareBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.SignatureCocktailBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.container.SimpleInput;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModDataComponents;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModSounds;
import com.github.ysbbbbbb.kaleidoscopetavern.util.CocktailEffectHelper;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ColorUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_11979;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_5455;
import net.minecraft.class_5894;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;

public class ShakerItem extends class_1747 {
   private static final int STORAGE_SIZE = 3;

   public ShakerItem() {
      super(ModBlocks.SHAKER, new class_1793().method_7889(1));
   }

   public ShakerItem(class_1793 properties) {
      super(ModBlocks.SHAKER, properties);
   }

   public static ItemStackHandler getStorage(class_1799 stack) {
      ItemStackHandler handler = new ItemStackHandler(3);
      List<class_1799> items = (List<class_1799>)stack.method_58695(ModDataComponents.SHAKER_STORAGE, List.of());

      for (int i = 0; i < Math.min(handler.getSlots(), items.size()); i++) {
         handler.setStackInSlot(i, items.get(i).method_7972());
      }

      return handler;
   }

   public static void setStorage(class_1799 stack, ItemStackHandler handler) {
      List<class_1799> items = Lists.newArrayList();

      for (int i = 0; i < handler.getSlots(); i++) {
         items.add(handler.getStackInSlot(i));
      }

      stack.method_57379(ModDataComponents.SHAKER_STORAGE, items);
   }

   public static boolean hasStorage(class_1799 stack) {
      return stack.method_57826(ModDataComponents.SHAKER_STORAGE);
   }

   public static class_1799 getResult(class_1799 stack) {
      return ((ShakerItem.Result)stack.method_58695(ModDataComponents.SHAKER_RESULT, ShakerItem.Result.EMPTY)).stack();
   }

   public static void setResult(class_1799 stack, class_1799 result) {
      stack.method_57379(ModDataComponents.SHAKER_RESULT, new ShakerItem.Result(result.method_7972()));
   }

   public static boolean hasResult(class_1799 stack) {
      return stack.method_57826(ModDataComponents.SHAKER_RESULT) && !getResult(stack).method_7960();
   }

   public static void removeAll(class_1799 stack) {
      stack.method_57381(ModDataComponents.SHAKER_RESULT);
      stack.method_57381(ModDataComponents.SHAKER_STORAGE);
   }

   @NotNull
   public class_1269 method_7884(class_1838 context) {
      class_1937 level = context.method_8045();
      class_1799 stack = context.method_8041();
      class_2338 pos = context.method_8037();
      class_2680 rawState = level.method_8320(pos);
      if (hasResult(stack) && rawState.method_27852(ModBlocks.EMPTY_GLASSWARE)) {
         this.pourResult(level, stack, pos, rawState);
         return class_1269.field_5812;
      } else {
         return super.method_7884(context);
      }
   }

   private void pourResult(class_1937 level, class_1799 stack, class_2338 pos, class_2680 rawState) {
      class_1799 result = getResult(stack);
      if (result.method_7909() instanceof class_1747 blockItem) {
         class_2680 blockState = blockItem.method_7711().method_9564();
         if (blockState.method_28498(GlasswareBlock.ROTATION)) {
            blockState = (class_2680)blockState.method_11657(GlasswareBlock.ROTATION, (Integer)rawState.method_11654(GlasswareBlock.ROTATION));
         }

         level.method_8501(pos, blockState);
      }

      if (level.method_8321(pos) instanceof SignatureCocktailBlockEntity ordinary) {
         ItemStackHandler storage = getStorage(stack);
         CocktailEffectHelper.CollectedData data = CocktailEffectHelper.collectFromStorage(storage);
         List<DrinkEffectData.Entry> mergedEffects = CocktailEffectHelper.mergeEffects(data.effects());
         int finalColor = ColorUtils.mixColors(data.colors());
         ordinary.setColor(finalColor);
         ordinary.setEffects(mergedEffects);
         ordinary.refresh();
      }

      removeAll(stack);
      if (level instanceof class_3218 serverLevel) {
         serverLevel.method_65096(
            class_11979.method_74418(class_2398.field_11213, 0.5F, 0.3F, 1.0F, 1.0F),
            pos.method_10263() + 0.5,
            pos.method_10264() + 0.5,
            pos.method_10260() + 0.5,
            20,
            0.1,
            0.1,
            0.1,
            0.5
         );
         serverLevel.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
      }
   }

   @NotNull
   public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
      class_1799 itemInHand = player.method_5998(hand);
      if (hasResult(itemInHand)) {
         return class_1269.field_5811;
      }

      if (!this.hasStorageItem(itemInHand)) {
         return class_1269.field_5811;
      }

      ItemStackHandler storage = getStorage(itemInHand);

      for (int i = 0; i < storage.getSlots(); i++) {
         class_1799 stack = storage.getStackInSlot(i);
         if (stack.method_7960()) {
            if (player instanceof class_3222 serverPlayer) {
               class_2561 message = class_2561.method_43471("message.kaleidoscope_tavern.shaker.amount_too_low");
               serverPlayer.field_13987.method_14364(new class_5894(message));
            }

            return class_1269.field_5811;
         }
      }

      player.method_6019(hand);
      return class_1269.field_21466;
   }

   private boolean hasStorageItem(class_1799 itemInHand) {
      if (!hasStorage(itemInHand)) {
         return false;
      }

      ItemStackHandler storage = getStorage(itemInHand);

      for (int i = 0; i < storage.getSlots(); i++) {
         class_1799 stack = storage.getStackInSlot(i);
         if (!stack.method_7960()) {
            return true;
         }
      }

      return false;
   }

   public void method_7852(class_1937 level, class_1309 entity, class_1799 stack, int remainingUseDuration) {
      if (remainingUseDuration % 10 == 0) {
         entity.method_5783(ModSounds.SHAKER_SHAKING, level.field_9229.method_43057() * 0.2F + 0.75F, level.field_9229.method_43057() * 0.2F + 0.8F);
      }

      if (entity.method_6048() > 110) {
         entity.method_6075();
      }
   }

   public boolean method_7840(class_1799 stack, class_1937 level, class_1309 entity, int timeLeft) {
      int time = this.method_7881(stack, entity) - timeLeft;
      if (time < 19) {
         return false;
      }

      if (!level.method_8608()) {
         if (time < 69) {
            setResult(stack, new class_1799(ModItems.MYSTERY_COCKTAIL));
         } else if (time < 89) {
            setResult(stack, new class_1799(ModItems.SIGNATURE_COCKTAIL));
         } else if (time < 99) {
            this.handRecipe(level, stack);
         } else {
            setResult(stack, new class_1799(ModItems.MYSTERY_COCKTAIL));
         }
      }

      entity.method_43077(ModSounds.SHAKER_END);
      return true;
   }

   private void handRecipe(class_1937 level, class_1799 stack) {
      ItemStackHandler handler = getStorage(stack);
      List<class_1799> stacks = Lists.newArrayList();

      for (int i = 0; i < handler.getSlots(); i++) {
         class_1799 ingredient = handler.getStackInSlot(i);
         if (!ingredient.method_7960()) {
            stacks.add(ingredient);
         }
      }

      SimpleInput container = new SimpleInput(stacks);
      class_1863 manager = ((class_3218)level).method_8503().method_3772();
      class_5455 access = level.method_30349();
      manager.method_8132(ModRecipes.SHAKER_RECIPE, container, level)
         .ifPresentOrElse(
            recipe -> setResult(stack, ((ShakerRecipe)recipe.comp_1933()).assemble(container, access)),
            () -> setResult(stack, new class_1799(ModItems.SIGNATURE_COCKTAIL))
         );
   }

   public int method_7881(class_1799 pStack, class_1309 entity) {
      return 72000;
   }

   public boolean method_7838(class_1799 stack) {
      return false;
   }

   public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 flag) {
      if (hasResult(stack)) {
         class_1799 result = getResult(stack);
         if (result.method_7964() instanceof class_5250 component) {
            class_5250 text = component.method_27692(class_124.field_1080);
            consumer.accept(class_2561.method_43470("▶ ").method_27692(class_124.field_1080).method_10852(text));
         }
      } else if (hasStorage(stack)) {
         ItemStackHandler storage = getStorage(stack);

         for (int i = 0; i < storage.getSlots(); i++) {
            class_1799 ingredient = storage.getStackInSlot(i);
            if (!ingredient.method_7960() && ingredient.method_7964() instanceof class_5250 component) {
               class_124 chatFormatting = ColorUtils.ITEM_COLOR_CACHE.apply(ingredient.method_7909());
               if (chatFormatting == class_124.field_1070) {
                  chatFormatting = class_124.field_1080;
               }

               class_5250 text = component.method_27692(chatFormatting);
               consumer.accept(class_2561.method_43470("▶ ").method_27692(class_124.field_1080).method_10852(text));
            }
         }
      }
   }

   public record Result(class_1799 stack) {
      public static final Codec<ShakerItem.Result> CODEC = RecordCodecBuilder.create(
         instance -> instance.group(class_1799.field_49266.fieldOf("stack").forGetter(ShakerItem.Result::stack)).apply(instance, ShakerItem.Result::new)
      );
      public static final class_9139<class_9129, ShakerItem.Result> STREAM_CODEC = class_9139.method_56434(
         class_1799.field_49268, ShakerItem.Result::stack, ShakerItem.Result::new
      );
      public static final ShakerItem.Result EMPTY = new ShakerItem.Result(class_1799.field_8037);
   }
}
