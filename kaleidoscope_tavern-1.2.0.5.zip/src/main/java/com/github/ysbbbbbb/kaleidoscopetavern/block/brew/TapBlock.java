package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.TapBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.TapBehaviorManager;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.VoxelShapeUtils;
import com.mojang.serialization.MapCodec;
import java.util.EnumMap;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class TapBlock extends class_2237 implements class_3737 {
   public static final MapCodec<TapBlock> CODEC = method_54094(TapBlock::new);
   public static final class_2754<class_2350> FACING = class_2741.field_12481;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_2746 TRIGGERED = class_2741.field_12522;
   public static final class_2746 OPEN = class_2741.field_12537;
   public final EnumMap<class_2350, class_265> shapes;

   public TapBlock(class_2251 properties) {
      super(properties.method_31710(class_3620.field_16005).method_9632(0.8F).method_9626(class_2498.field_11533));
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043))
                  .method_11657(OPEN, false))
               .method_11657(TRIGGERED, false))
            .method_11657(WATERLOGGED, false)
      );
      this.shapes = VoxelShapeUtils.horizontalShapes(class_2248.method_9541(5.0, 5.0, 6.0, 11.0, 13.0, 16.0));
   }

   protected void method_9612(
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_2248 block,
      @Nullable class_9904 orientation,
      boolean isMoving
   ) {
      boolean hasSignal = level.method_49803(pos) || level.method_49803(pos.method_10084());
      boolean triggered = (Boolean)state.method_11654(TRIGGERED);
      if (hasSignal && !triggered) {
         if (!(Boolean)state.method_11654(OPEN)) {
            this.tryOpen(state, level, pos, null);
         }

         class_2680 newState = level.method_8320(pos);
         level.method_8652(pos, (class_2680)newState.method_11657(TRIGGERED, true), 260);
      } else if (!hasSignal && triggered) {
         class_2680 newState = level.method_8320(pos);
         level.method_8652(pos, (class_2680)newState.method_11657(TRIGGERED, false), 260);
      }
   }

   @NotNull
   public class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (hand == class_1268.field_5808) {
         if ((Boolean)state.method_11654(OPEN)) {
            state = (class_2680)state.method_11657(OPEN, false);
            level.method_8501(pos, state);
            level.method_8396(null, pos, class_3417.field_15131, class_3419.field_15245, 1.0F, 0.8F);
            return class_1269.field_5812;
         } else {
            this.tryOpen(state, level, pos, player);
            return class_1269.field_5812;
         }
      } else {
         return class_1269.field_5811;
      }
   }

   private void tryOpen(class_2680 state, class_1937 level, class_2338 pos, @Nullable class_1657 player) {
      class_2350 tapFacing = (class_2350)state.method_11654(FACING);
      class_2338 sourcePos = pos.method_10093(tapFacing.method_10153());
      class_2680 sourceState = level.method_8320(sourcePos);
      class_2248 sourceBlock = sourceState.method_26204();
      if (!TapBehaviorManager.contains(sourceBlock)) {
         this.emptyOpen(level, pos, state);
      } else {
         class_2338 belowPos = pos.method_10074();
         class_2680 belowState = level.method_8320(belowPos);
         ITapBehavior behavior = TapBehaviorManager.get(sourceBlock);
         if (behavior.isMatch(level, player, pos, state, sourceState, belowState)) {
            class_2394 particle = behavior.onStartExtract(level, player, pos, state, sourceState, belowState);
            if (level.method_8321(pos) instanceof TapBlockEntity tapEntity) {
               if (particle != null) {
                  tapEntity.setParticle(particle);
               }

               tapEntity.setState(1);
            }

            state = (class_2680)state.method_11657(OPEN, true);
            level.method_8501(pos, state);
            level.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 1.0F, 0.8F);
            level.method_64310(pos, this, 30);
         } else {
            this.emptyOpen(level, pos, state);
         }
      }
   }

   private void emptyOpen(class_1937 level, class_2338 pos, class_2680 blockState) {
      level.method_8501(pos, (class_2680)blockState.method_11657(OPEN, true));
      level.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 1.0F, 0.8F);
      if (level.method_8321(pos) instanceof TapBlockEntity tapEntity) {
         tapEntity.setState(2);
      }
   }

   public void method_9588(class_2680 state, @NonNull class_3218 level, @NonNull class_2338 pos, @NonNull class_5819 random) {
      if ((Boolean)state.method_11654(OPEN)) {
         class_2350 tapFacing = (class_2350)state.method_11654(FACING);
         class_2338 sourcePos = pos.method_10093(tapFacing.method_10153());
         class_2680 sourceState = level.method_8320(sourcePos);
         class_2248 sourceBlock = sourceState.method_26204();
         level.method_8501(pos, (class_2680)state.method_11657(OPEN, false));
         level.method_8396(null, pos, class_3417.field_15131, class_3419.field_15245, 1.0F, 0.8F);
         if (level.method_8321(pos) instanceof TapBlockEntity tapEntity) {
            tapEntity.setParticle(null);
            tapEntity.setState(0);
         }

         if (TapBehaviorManager.contains(sourceBlock)) {
            class_2338 belowPos = pos.method_10074();
            class_2680 belowState = level.method_8320(belowPos);
            ITapBehavior behavior = TapBehaviorManager.get(sourceBlock);
            if (behavior.isMatch(level, null, pos, state, sourceState, belowState)) {
               behavior.onEndExtract(level, pos, state, sourceState, belowState);
            }
         }
      }
   }

   @NotNull
   public class_2464 method_9604(@NonNull class_2680 state) {
      return class_2464.field_11458;
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, @NonNull class_2680 state) {
      return new TapBlockEntity(pos, state);
   }

   @Nullable
   public <T extends class_2586> class_5558<T> method_31645(class_1937 level, @NonNull class_2680 state, @NonNull class_2591<T> blockEntityType) {
      return level.method_8608() ? null : method_31618(blockEntityType, ModBlocks.TAP_BE, (levelIn, pos, stateIn, tap) -> tap.tick(levelIn));
   }

   private boolean isValidConnection(class_2680 barrelState, class_2350 tapFacing) {
      class_2350 barrelFacing = (class_2350)barrelState.method_11654(BarrelBlock.FACING);
      class_2738 layer = (class_2738)barrelState.method_11654(BarrelBlock.LAYER);
      int index = (Integer)barrelState.method_11654(BarrelBlock.INDEX);
      if (layer == class_2738.field_12471) {
         if (barrelFacing == class_2350.field_11043 && index == 1) {
            return tapFacing == class_2350.field_11043;
         }

         if (barrelFacing == class_2350.field_11035 && index == 7) {
            return tapFacing == class_2350.field_11035;
         }

         if (barrelFacing == class_2350.field_11039 && index == 3) {
            return tapFacing == class_2350.field_11039;
         }

         if (barrelFacing == class_2350.field_11034 && index == 5) {
            return tapFacing == class_2350.field_11034;
         }
      }

      return false;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_2350 clickedFace = context.method_8038();
      if (clickedFace.method_10166().method_10178()) {
         clickedFace = context.method_8042().method_10153();
      }

      return (class_2680)((class_2680)this.method_9564().method_11657(FACING, clickedFace)).method_11657(WATERLOGGED, context.method_8045().method_22351(pos));
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{FACING, OPEN, TRIGGERED, WATERLOGGED});
   }

   @NotNull
   public class_265 method_9530(class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      class_2350 direction = (class_2350)pState.method_11654(FACING);
      return this.shapes.getOrDefault(direction, class_259.method_1077());
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_2680 method_9598(class_2680 state, class_2470 rot) {
      return (class_2680)state.method_11657(FACING, rot.method_10503((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   public class_2680 method_9569(class_2680 state, class_2415 mirror) {
      return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }
}
