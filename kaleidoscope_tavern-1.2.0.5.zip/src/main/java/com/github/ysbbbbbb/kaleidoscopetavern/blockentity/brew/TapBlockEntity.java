package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.TapBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class TapBlockEntity extends BaseBlockEntity {
   public static final int TAKE_DRINK_TICKS = 30;
   public static final int TAKE_DRINK_PARTICLE_TICKS = 5;
   public static final int EMPTY_OPEN_TICKS = 5;
   public static final int DEFAULT_STATE = 0;
   public static final int TAKE_DRINK_STATE = 1;
   public static final int EMPTY_OPEN_STATE = 2;
   private int state = 0;
   @Nullable
   private class_2394 particle = null;
   private int tickCounter = 0;

   public TapBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.TAP_BE, pos, state);
   }

   public void tick(class_1937 level) {
      class_2680 blockState = this.method_11010();
      if ((Boolean)blockState.method_11654(TapBlock.OPEN)) {
         this.tickCounter++;
         if (this.state == 1) {
            this.onTakeDrink(level);
         } else if (this.state == 2) {
            this.onEmptyOpen(level);
         }
      }
   }

   private void onTakeDrink(class_1937 level) {
      if (this.particle != null) {
         if (this.tickCounter > 30) {
            this.state = 0;
            this.particle = null;
         } else if (this.tickCounter <= 5) {
            if (level instanceof class_3218 serverLevel) {
               class_2338 pos = this.method_11016();
               serverLevel.method_65096(this.particle, pos.method_10263() + 0.5, pos.method_10264() + 0.25, pos.method_10260() + 0.5, 1, 0.0, 0.0, 0.0, 0.0);
            }
         }
      }
   }

   private void onEmptyOpen(class_1937 level) {
      class_2338 pos = this.method_11016();
      if (level instanceof class_3218 serverLevel && this.tickCounter % 2 == 0) {
         serverLevel.method_65096(class_2398.field_11204, pos.method_10263() + 0.5, pos.method_10264() + 0.25, pos.method_10260() + 0.5, 1, 0.1, 0.1, 0.1, 0.01);
      }

      if (this.tickCounter > 5) {
         this.state = 0;
         this.particle = null;
         class_2680 blockState = this.method_11010();
         blockState = (class_2680)blockState.method_11657(TapBlock.OPEN, false);
         level.method_8501(pos, blockState);
         level.method_8396(null, pos, class_3417.field_15131, class_3419.field_15245, 1.0F, 0.8F);
      }
   }

   public void setParticle(@Nullable class_2394 particle) {
      this.particle = particle;
      this.tickCounter = 0;
   }

   public void setState(int state) {
      this.state = state;
      this.tickCounter = 0;
   }
}
