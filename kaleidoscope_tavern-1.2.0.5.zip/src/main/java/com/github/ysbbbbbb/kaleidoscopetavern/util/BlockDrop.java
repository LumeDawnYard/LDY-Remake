package com.github.ysbbbbbb.kaleidoscopetavern.util;

import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

public final class BlockDrop {
   private BlockDrop() {
   }

   public static void popResource(class_1937 level, class_2338 pos, double yOffset, class_1799 stack) {
      if (!level.method_8608() && !stack.method_7960() && (Boolean)((class_3218)level).method_64395().method_76185(class_1928.field_19392)) {
         double itemHalfHeight = class_1299.field_6052.method_17686() / 2.0;
         double range = 0.1;
         double x = pos.method_10263() + 0.5 + class_3532.method_15366(level.field_9229, -range, range);
         double y = pos.method_10264() + 0.5 + class_3532.method_15366(level.field_9229, -range, range) - itemHalfHeight + yOffset;
         double z = pos.method_10260() + 0.5 + class_3532.method_15366(level.field_9229, -range, range);
         class_1542 itemEntity = new class_1542(level, x, y, z, stack);
         itemEntity.method_6988();
         level.method_8649(itemEntity);
      }
   }
}
