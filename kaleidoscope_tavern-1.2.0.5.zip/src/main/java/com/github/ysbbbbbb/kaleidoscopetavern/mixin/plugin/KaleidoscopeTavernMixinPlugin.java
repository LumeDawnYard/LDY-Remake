package com.github.ysbbbbbb.kaleidoscopetavern.mixin.plugin;

import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public class KaleidoscopeTavernMixinPlugin implements IMixinConfigPlugin {
   private static final String DRAGONLIB_BLOCK_MODEL_COMPAT = "com.github.ysbbbbbb.kaleidoscopetavern.mixin.compat.dragonlib.DragonLibBlockModelCompatMixin";

   public void onLoad(String mixinPackage) {
   }

   public String getRefMapperConfig() {
      return null;
   }

   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
      if ("com.github.ysbbbbbb.kaleidoscopetavern.mixin.compat.dragonlib.DragonLibBlockModelCompatMixin".equals(mixinClassName)) {
         FabricLoader loader = FabricLoader.getInstance();
         return loader.isModLoaded("dragonlib");
      } else {
         return true;
      }
   }

   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
   }

   public List<String> getMixins() {
      return List.of();
   }

   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }

   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }
}
