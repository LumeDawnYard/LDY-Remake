package com.github.ysbbbbbb.kaleidoscopetavern.game.grape;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlantGrapeEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.TrellisBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;

public final class NormalGrapePlant {
   public static void onPlant(PlantGrapeEvent event) {
      class_1937 level = event.level();
      class_2338 pos = event.pos();
      class_1657 player = event.player();
      class_1799 itemInHand = player.method_5998(event.hand());
      class_2680 state = event.state();
      class_2680 belowState = level.method_8320(pos.method_10074());
      if (belowState.method_26164(class_3481.field_29822)) {
         class_2680 plantedState = (class_2680)ModBlocks.GRAPEVINE_TRELLIS
            .method_9564()
            .method_11657(TrellisBlock.WATERLOGGED, (Boolean)state.method_11654(TrellisBlock.WATERLOGGED));
         level.method_8501(pos, plantedState);
         level.method_45447(null, pos, class_3417.field_17611, class_3419.field_15245);
         if (!player.method_68878()) {
            itemInHand.method_7934(1);
         }

         event.setCanceled(true);
      }
   }
}
