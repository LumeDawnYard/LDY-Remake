package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.pressing_tub;

import cc.cassian.rrv.api.TagUtil;
import cc.cassian.rrv.api.recipe.ReliableServerRecipe;
import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class PressingTubServerRecipe implements ReliableServerRecipe {
   public static final ReliableServerRecipeType<PressingTubServerRecipe> TYPE = ReliableServerRecipeType.register(
      class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"), () -> new PressingTubServerRecipe(null, null)
   );
   private class_1799 result;
   private class_1856 input;

   public PressingTubServerRecipe(class_1799 result, class_1856 input) {
      this.result = result;
      this.input = input;
   }

   public class_1799 getResult() {
      return this.result;
   }

   public class_1856 getInput() {
      return this.input;
   }

   public void writeToTag(class_2487 tag) {
      tag.method_10566("result", TagUtil.encodeItemStackOnServer(this.result));
      tag.method_10566("input", TagUtil.writeIngredient(this.input));
   }

   public void loadFromTag(class_2487 tag) {
      this.result = TagUtil.decodeItemStackOnServer((class_2487)tag.method_10562("result").orElseGet(class_2487::new));
      this.input = TagUtil.readIngredient((class_2487)tag.method_10562("input").orElseGet(class_2487::new));
   }

   public ReliableServerRecipeType<? extends ReliableServerRecipe> getRecipeType() {
      return TYPE;
   }
}
