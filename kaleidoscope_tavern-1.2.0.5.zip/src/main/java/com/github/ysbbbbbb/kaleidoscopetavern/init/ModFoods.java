package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.DrinkBlock;
import net.minecraft.class_2248;
import net.minecraft.class_259;
import net.minecraft.class_4174;
import net.minecraft.class_4174.class_4175;

public interface ModFoods {
   class_4174 GRAPE = new class_4175().method_19238(2).method_19237(0.5F).method_19240().method_19242();

   interface ModWines {
      class_2248 WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("wine")
         .build();
      class_2248 CHAMPAGNE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("champagne")
         .build();
      class_2248 VODKA = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .setId("vodka")
         .build();
      class_2248 BRANDY = DrinkBlock.create()
         .maxCount(3)
         .irregular()
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .setId("brandy")
         .build();
      class_2248 CARIGNAN = DrinkBlock.create()
         .maxCount(3)
         .irregular()
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .setId("carignan")
         .build();
      class_2248 SAKURA_WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("sakura_wine")
         .build();
      class_2248 PLUM_WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 12.0, 10.0),
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 12.0, 10.0),
            class_259.method_1084(class_2248.method_9541(3.0, 0.0, 9.0, 13.0, 12.0, 13.0), class_2248.method_9541(6.0, 0.0, 3.0, 10.0, 12.0, 13.0)),
            class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 12.0, 13.0)
         )
         .setId("plum_wine")
         .build();
      class_2248 WHISKEY = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("whiskey")
         .build();
      class_2248 ICE_WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("ice_wine")
         .build();
      class_2248 POLARIS_SWEET_WHITE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("polar_sweet_white")
         .build();
      class_2248 HONEY_WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("honey_wine")
         .build();
      class_2248 RED_QUEEN = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("red_queen")
         .build();
      class_2248 MINERS_STAR = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("miners_star")
         .build();
      class_2248 RUM = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("rum")
         .build();
      class_2248 RIESLING_DRY_WHITE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .setId("riesling_dry_white")
         .build();
      class_2248 SUNSET_GLOW = DrinkBlock.create()
         .maxCount(3)
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .setId("sunset_glow")
         .build();
      class_2248 MADAME_SHEXIANG = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .setId("madame_shexiang")
         .build();
      class_2248 SWEET_BERRY_WINE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .setId("sweet_berry_wine")
         .build();
      class_2248 SHERRY = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("sherry")
         .build();
      class_2248 MOTHER_SNOW = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .setId("mother_snow")
         .build();
      class_2248 LUMINOUS_BRIDE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("luminous_bride")
         .build();
      class_2248 GLOWFLOWER_BREW = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("glowflower_brew")
         .build();
      class_2248 SAUVIGNON_BLANC_DRY_WHITE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("sauvignon_blanc_dry_white")
         .build();
      class_2248 VINEGAR = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("vinegar")
         .build();
      class_2248 WATERMELON_JUICE = DrinkBlock.create()
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .setId("watermelon_juice")
         .build();
   }
}
