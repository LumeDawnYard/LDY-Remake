package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarrelBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.brew.BarrelModel;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.BarrelBlockEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.util.RenderUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class BarrelBlockEntityRender implements class_827<BarrelBlockEntity, BarrelBlockEntityRenderState> {
   private static final class_2960 LARGE_TEXTURE = class_2960.method_60655("kaleidoscope_tavern", "textures/entity/brew/barrel.png");
   private static final class_310 minecraft = class_310.method_1551();
   private final class_10442 itemModelResolver;
   private final BarrelModel model;

   public BarrelBlockEntityRender(class_5615 context) {
      this.itemModelResolver = context.comp_4536();
      this.model = new BarrelModel(context.method_32140(BarrelModel.LAYER_LOCATION));
   }

   public void extractRenderState(
      @NonNull BarrelBlockEntity blockEntity,
      @NonNull BarrelBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(BarrelBlock.FACING);
      blockEntityRenderState.isOpen = blockEntity.isOpen();
      blockEntityRenderState.fluidTank = blockEntity.getFluid();
      if (blockEntity.method_10997() != null) {
         blockEntityRenderState.time = (float)blockEntity.method_10997().method_75260() + f;
      }

      blockEntityRenderState.seed = blockEntity.method_11016().method_10063();
      ItemStackHandler items = blockEntity.getIngredient();
      blockEntityRenderState.itemStates = new ArrayList<>();

      for (int index = 0; index < items.getSlots(); index++) {
         class_1799 stack = items.getStackInSlot(index);
         if (!stack.method_7960()) {
            BarrelBlockEntityRenderState.ItemEntry entry = new BarrelBlockEntityRenderState.ItemEntry();
            this.itemModelResolver.method_65598(entry.itemState, stack, class_811.field_4319, null, null, (int)(blockEntityRenderState.seed + index));
            entry.renderCount = Math.min(8, stack.method_7947() / 2 + 1);
            entry.slotIndex = index;
            blockEntityRenderState.itemStates.add(entry);
         }
      }
   }

   private void renderBody(BarrelBlockEntityRenderState barrel, class_4587 poseStack, @NonNull class_11659 submitNodeCollector) {
      poseStack.method_22903();
      poseStack.method_22904(0.5, 1.5, 0.5);
      poseStack.method_22907(class_7833.field_40717.rotationDegrees(180.0F));
      poseStack.method_22907(class_7833.field_40715.rotationDegrees(180 - barrel.facing.method_10161() * 90));
      BarrelModel.State state = new BarrelModel.State(barrel.isOpen);
      this.model.setupAnim(state);
      class_1921 renderType = class_12249.method_75994(LARGE_TEXTURE);
      submitNodeCollector.method_73489(this.model, state, poseStack, renderType, barrel.field_62676, class_4608.field_21444, 0, null);
      poseStack.method_22909();
   }

   private void renderFluid(BarrelBlockEntityRenderState barrel, class_4587 poseStack, class_4597 buffer) {
      CustomFluidTank fluidTank = barrel.fluidTank;
      int fluidAmount = fluidTank.getFluidAmountMb();
      if (fluidAmount > 0) {
         poseStack.method_22903();
         poseStack.method_46416(0.0F, 2.0F, 0.0F);
         float percent = fluidAmount / 4000.0F;
         float y = percent * 0.65F;
         class_3611 fluid = fluidTank.getFluid();
         if (fluid == class_3612.field_15910) {
            RenderUtils.renderWaterFluid(minecraft.field_1687, barrel.field_62673, fluid, poseStack, buffer, barrel.field_62676, 16, y);
         } else {
            RenderUtils.renderFluid(fluid, poseStack, buffer, barrel.field_62676, 16, y);
         }

         poseStack.method_22909();
      }
   }

   private void renderItems(BarrelBlockEntityRenderState barrel, class_4587 poseStack, @NonNull class_11659 submitNodeCollector) {
      int globalIndex = 0;

      for (BarrelBlockEntityRenderState.ItemEntry item : barrel.itemStates) {
         if (!item.itemState.method_65606()) {
            for (int i = 0; i < item.renderCount; i++) {
               poseStack.method_22903();
               float x = RenderUtils.stableRandom(barrel.seed, globalIndex, item.slotIndex + 1) * 0.4F;
               float z = RenderUtils.stableRandom(barrel.seed, globalIndex, item.slotIndex + 2) * 0.4F;
               float y = globalIndex / 4 * 0.025F + RenderUtils.stableRandom(barrel.seed, globalIndex, item.slotIndex + 3) * 0.05F;
               y += (float)(Math.sin(barrel.time / 10.0F + globalIndex) * 0.02F);
               float yRot = RenderUtils.stableRandom(barrel.seed, globalIndex, item.slotIndex + 4) * 5.0F;
               float zRot = RenderUtils.stableRandom(barrel.seed, globalIndex, item.slotIndex + 5) * 360.0F;
               poseStack.method_46416(0.5F + x, 2.7F + y, 0.5F + z);
               poseStack.method_22905(0.5F, 0.5F, 0.5F);
               poseStack.method_22907(class_7833.field_40713.rotationDegrees(90.0F));
               poseStack.method_22907(class_7833.field_40715.rotationDegrees(yRot));
               poseStack.method_22907(class_7833.field_40717.rotationDegrees(zRot));
               item.itemState.method_65604(poseStack, submitNodeCollector, barrel.field_62676, class_4608.field_21444, 0);
               poseStack.method_22909();
               globalIndex++;
            }
         }
      }
   }

   public @NonNull BarrelBlockEntityRenderState createRenderState() {
      return new BarrelBlockEntityRenderState();
   }

   public void submit(
      @NonNull BarrelBlockEntityRenderState barrel,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      this.renderBody(barrel, poseStack, submitNodeCollector);
      if (barrel.isOpen) {
         class_4598 buffer = minecraft.method_22940().method_23000();
         this.renderFluid(barrel, poseStack, buffer);
         this.renderItems(barrel, poseStack, submitNodeCollector);
      }
   }
}
