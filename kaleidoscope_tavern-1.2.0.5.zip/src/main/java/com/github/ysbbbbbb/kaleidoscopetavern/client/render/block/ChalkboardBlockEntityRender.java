package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.ChalkboardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.deco.LargeChalkboardModel;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.deco.SmallChalkboardModel;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.ChalkboardBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class ChalkboardBlockEntityRender extends TextBlockEntityRender<ChalkboardBlockEntity, ChalkboardBlockEntityRenderState> {
   private static final class_2960 SMALL_TEXTURE = class_2960.method_60655("kaleidoscope_tavern", "textures/entity/deco/small_chalkboard.png");
   private static final class_2960 LARGE_TEXTURE = class_2960.method_60655("kaleidoscope_tavern", "textures/entity/deco/large_chalkboard.png");
   private static final float TEXT_SCALE = 0.012F;
   private static final int LINE_HEIGHT = 12;
   private static final int MAX_LINES = 11;
   private final SmallChalkboardModel small;
   private final SmallChalkboardModel large;

   public ChalkboardBlockEntityRender(class_5615 context) {
      super(context);
      this.small = new SmallChalkboardModel(context.method_32140(SmallChalkboardModel.LAYER_LOCATION));
      this.large = new SmallChalkboardModel(context.method_32140(LargeChalkboardModel.LAYER_LOCATION));
   }

   public void extractRenderState(
      @NonNull ChalkboardBlockEntity blockEntity,
      @NonNull ChalkboardBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.extractRenderState(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.large = blockEntity.isLarge();
   }

   public @NonNull ChalkboardBlockEntityRenderState createRenderState() {
      return new ChalkboardBlockEntityRenderState();
   }

   protected void renderModel(ChalkboardBlockEntityRenderState textBlockRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_2350 facing) {
      poseStack.method_22903();
      poseStack.method_22904(0.5, 1.5, 0.5);
      poseStack.method_22907(class_7833.field_40717.rotationDegrees(180.0F));
      poseStack.method_22907(class_7833.field_40715.rotationDegrees(180 - facing.method_10161() * 90));
      if (textBlockRenderState.large) {
         submitNodeCollector.method_73489(
            this.large,
            new SmallChalkboardModel.State(),
            poseStack,
            class_12249.method_75982(LARGE_TEXTURE),
            textBlockRenderState.field_62676,
            class_4608.field_21444,
            0,
            null
         );
      } else {
         submitNodeCollector.method_73489(
            this.small,
            new SmallChalkboardModel.State(),
            poseStack,
            class_12249.method_75982(SMALL_TEXTURE),
            textBlockRenderState.field_62676,
            class_4608.field_21444,
            0,
            null
         );
      }

      poseStack.method_22909();
   }

   protected void renderText(ChalkboardBlockEntityRenderState textBlockRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_2350 facing) {
      poseStack.method_22903();
      if (facing == class_2350.field_11034) {
         poseStack.method_22904(0.08, 1.535, 0.5);
      } else if (facing == class_2350.field_11039) {
         poseStack.method_22904(0.92, 1.535, 0.5);
      } else if (facing == class_2350.field_11035) {
         poseStack.method_22904(0.5, 1.535, 0.08);
      } else {
         poseStack.method_22904(0.5, 1.535, 0.92);
      }

      poseStack.method_22907(class_7833.field_40715.rotationDegrees(facing.method_10161() * 90));
      int maxWidth = textBlockRenderState.large ? 232 : 63;
      if (StringUtils.isNotBlank(textBlockRenderState.text)) {
         this.doTextRender(textBlockRenderState, poseStack, textBlockRenderState.text, maxWidth, 0.012F, 11, 12, submitNodeCollector);
      }

      poseStack.method_22909();
   }
}
