package com.github.ysbbbbbb.kaleidoscopetavern.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class RenderUtils {
   private static final int ALPHA_MASK = -16777216;

   public static void renderFluid(class_3611 fluid, class_4587 poseStack, class_4597 buffer, int light, int size, float y) {
      class_1058 sprite = getStillFluidSprite(null, null, fluid);
      int color = getFluidColor(null, null, fluid);
      renderSurface(poseStack, buffer, sprite, color, light, class_3532.method_15340(size, 1, 16), y);
   }

   public static void renderWaterFluid(
      class_1920 level, class_2338 pos, class_3611 fluid, class_4587 poseStack, class_4597 buffer, int light, int size, float y
   ) {
      class_1058 sprite = getStillFluidSprite(level, pos, fluid);
      renderSurface(poseStack, buffer, sprite, -12618012, light, class_3532.method_15340(size, 1, 16), y);
   }

   public static void renderSurface(class_4587 poseStack, class_4597 buffer, class_1058 sprite, int color, int light, int size, float y) {
      class_4588 vertexConsumer = buffer.method_73477(class_4722.method_76545());
      Matrix4f matrix = poseStack.method_23760().method_23761();
      int margin = (16 - size) / 2;
      float min = margin / 16.0F;
      float max = 1.0F - margin / 16.0F;
      float spriteSize = size / 16.0F;
      vertexConsumer.method_22918(matrix, min, y, min)
         .method_39415(color)
         .method_22913(sprite.method_4594(), sprite.method_4593())
         .method_22922(class_4608.field_21444)
         .method_60803(light)
         .method_22914(0.0F, 1.0F, 0.0F);
      vertexConsumer.method_22918(matrix, min, y, max)
         .method_39415(color)
         .method_22913(sprite.method_4594(), sprite.method_4570(spriteSize))
         .method_22922(class_4608.field_21444)
         .method_60803(light)
         .method_22914(0.0F, 1.0F, 0.0F);
      vertexConsumer.method_22918(matrix, max, y, max)
         .method_39415(color)
         .method_22913(sprite.method_4580(spriteSize), sprite.method_4570(spriteSize))
         .method_22922(class_4608.field_21444)
         .method_60803(light)
         .method_22914(0.0F, 1.0F, 0.0F);
      vertexConsumer.method_22918(matrix, max, y, min)
         .method_39415(color)
         .method_22913(sprite.method_4580(spriteSize), sprite.method_4593())
         .method_22922(class_4608.field_21444)
         .method_60803(light)
         .method_22914(0.0F, 1.0F, 0.0F);
   }

   public static float stableRandom(long posSeed, int index, int channel) {
      long h = posSeed ^ index * -7046029254386353131L ^ channel * 7809847782465536322L;
      h = (h ^ h >>> 30) * -4658895280553007687L;
      h = (h ^ h >>> 27) * -7723592293110705685L;
      h ^= h >>> 31;
      return (int)h / 2.1474836E9F;
   }

   private static class_1058 getStillFluidSprite(class_1920 level, class_2338 pos, class_3611 fluid) {
      class_3610 state = fluid.method_15785();
      FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(fluid);
      if (handler != null) {
         class_1058[] sprites = handler.getFluidSprites(level, pos, state);
         if (sprites.length > 0 && sprites[0] != null) {
            return sprites[0];
         }
      }

      class_2960 missing = class_1047.method_4539();
      return class_310.method_1551().method_1554().field_61870.method_73030(new class_4730(class_1059.field_5275, missing));
   }

   private static int getFluidColor(class_1920 level, class_2338 pos, class_3611 fluid) {
      if (level != null && pos != null) {
         class_3610 state = fluid.method_15785();
         FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(fluid);
         return handler == null ? -1 : handler.getFluidColor(level, pos, state);
      } else {
         return -1;
      }
   }

   private static int ensureAlpha(int color) {
      return (color & 0xFF000000) == 0 ? color | 0xFF000000 : color;
   }
}
