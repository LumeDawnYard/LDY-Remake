package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.api.entity.ISittable;
import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.ConnectionType;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.util.SitUtil;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class SofaBlock extends class_2383 implements class_3737, IConnectionBlock, ISittable {
   public static final MapCodec<SofaBlock> CODEC = method_54094(SofaBlock::new);
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 NORTH_SHAPE = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(0.0, 8.0, 11.0, 16.0, 18.0, 16.0)
   );
   public static final class_265 SOUTH_SHAPE = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 18.0, 5.0)
   );
   public static final class_265 WEST_SHAPE = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(11.0, 8.0, 0.0, 16.0, 18.0, 16.0)
   );
   public static final class_265 EAST_SHAPE = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0), class_2248.method_9541(0.0, 8.0, 0.0, 5.0, 18.0, 16.0)
   );
   public static final class_265 NORTH_LEFT_CORNER_SHAPE = class_259.method_1084(NORTH_SHAPE, class_2248.method_9541(11.0, 8.0, 0.0, 16.0, 18.0, 16.0));
   public static final class_265 NORTH_RIGHT_CORNER_SHAPE = class_259.method_1084(NORTH_SHAPE, class_2248.method_9541(0.0, 8.0, 0.0, 5.0, 18.0, 16.0));
   public static final class_265 SOUTH_LEFT_CORNER_SHAPE = class_259.method_1084(SOUTH_SHAPE, class_2248.method_9541(0.0, 8.0, 0.0, 5.0, 18.0, 16.0));
   public static final class_265 SOUTH_RIGHT_CORNER_SHAPE = class_259.method_1084(SOUTH_SHAPE, class_2248.method_9541(11.0, 8.0, 0.0, 16.0, 18.0, 16.0));
   public static final class_265 WEST_LEFT_CORNER_SHAPE = class_259.method_1084(WEST_SHAPE, class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 18.0, 5.0));
   public static final class_265 WEST_RIGHT_CORNER_SHAPE = class_259.method_1084(WEST_SHAPE, class_2248.method_9541(0.0, 8.0, 11.0, 16.0, 18.0, 16.0));
   public static final class_265 EAST_LEFT_CORNER_SHAPE = class_259.method_1084(EAST_SHAPE, class_2248.method_9541(0.0, 8.0, 11.0, 16.0, 18.0, 16.0));
   public static final class_265 EAST_RIGHT_CORNER_SHAPE = class_259.method_1084(EAST_SHAPE, class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 18.0, 5.0));

   public SofaBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15979)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11543)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(CONNECTION, ConnectionType.SINGLE))
            .method_11657(WATERLOGGED, false)
      );
   }

   @Override
   public boolean sameType(class_2680 state) {
      return state.method_26204() instanceof SofaBlock;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      blockState = this.updateShape(levelReader, blockPos, blockState, direction);
      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, CONNECTION, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 pos = context.method_8037();
      class_2350 direction = context.method_8042().method_10153();
      ConnectionType connectionType = this.getConnectionForPlacement(context);
      class_3610 fluidState = level.method_8316(pos);
      return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, direction)).method_11657(CONNECTION, connectionType))
         .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
   }

   public void method_9585(class_1936 levelAccessor, @NonNull class_2338 pos, @NonNull class_2680 state) {
      levelAccessor.method_18467(SitEntity.class, new class_238(pos)).forEach(class_1297::method_31472);
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      ConnectionType type = (ConnectionType)pState.method_11654(CONNECTION);
      class_2350 direction = (class_2350)pState.method_11654(field_11177);
      if (direction == class_2350.field_11043) {
         return switch (type) {
            case LEFT_CORNER -> NORTH_LEFT_CORNER_SHAPE;
            case RIGHT_CORNER -> NORTH_RIGHT_CORNER_SHAPE;
            default -> NORTH_SHAPE;
         };
      } else if (direction == class_2350.field_11035) {
         return switch (type) {
            case LEFT_CORNER -> SOUTH_LEFT_CORNER_SHAPE;
            case RIGHT_CORNER -> SOUTH_RIGHT_CORNER_SHAPE;
            default -> SOUTH_SHAPE;
         };
      } else if (direction == class_2350.field_11039) {
         return switch (type) {
            case LEFT_CORNER -> WEST_LEFT_CORNER_SHAPE;
            case RIGHT_CORNER -> WEST_RIGHT_CORNER_SHAPE;
            default -> WEST_SHAPE;
         };
      } else {
         return switch (type) {
            case LEFT_CORNER -> EAST_LEFT_CORNER_SHAPE;
            case RIGHT_CORNER -> EAST_RIGHT_CORNER_SHAPE;
            default -> EAST_SHAPE;
         };
      }
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }

   @Override
   public float getSitHeight() {
      return 0.55F;
   }

   protected @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      List<SitEntity> entities = level.method_18467(SitEntity.class, new class_238(pos));
      if (entities.isEmpty()) {
         if (!level.method_8608()) {
            SitEntity entitySit = new SitEntity(level, pos, 0.5125);
            entitySit.method_36456(((class_2350)state.method_11654(field_11177)).method_10144());
            SitUtil.addSitEntity(level, pos, entitySit, player.method_73189());
            level.method_8649(entitySit);
            player.method_5873(entitySit, true, false);
         }

         return class_1269.field_5812;
      } else {
         return class_1269.field_5811;
      }
   }
}
