package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.worldgen.WildGrapevineDecorator;
import net.minecraft.class_2378;
import net.minecraft.class_4663;
import net.minecraft.class_7923;

public interface ModTreeDecoratorTypes {
   class_4663<WildGrapevineDecorator> WILD_GRAPEVINE = (class_4663<WildGrapevineDecorator>)class_2378.method_10226(
      class_7923.field_41153, "wild_grapevine", new class_4663(WildGrapevineDecorator.CODEC)
   );
}
