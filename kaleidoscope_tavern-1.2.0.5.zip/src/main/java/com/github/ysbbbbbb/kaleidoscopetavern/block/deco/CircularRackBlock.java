package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.block.AbstractStorageBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.CircularRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class CircularRackBlock extends AbstractStorageBlock implements class_3737 {
   public static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);
   private static final MapCodec<CircularRackBlock> CODEC = method_54094(p -> new CircularRackBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public CircularRackBlock() {
      super(
         class_2251.method_9637()
            .method_31710(class_3620.field_15996)
            .method_9632(2.5F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_9631(s -> 14)
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public CircularRackBlock(class_2251 properties) {
      super(properties);
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(WATERLOGGED, false))
            .method_11657(POWERED, false)
      );
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   @Override
   public class_2680 method_9605(class_1750 context) {
      class_2680 stateForPlacement = super.method_9605(context);
      if (stateForPlacement == null) {
         return null;
      }

      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      return (class_2680)stateForPlacement.method_11657(WATERLOGGED, hasWater);
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      return super.handleUse(state, level, pos, player, hand, hitResult);
   }

   @Override
   protected boolean blockListCheck(class_1799 stack) {
      return stack.method_31573(TagMod.CIRCULAR_RACK_BLOCKLIST);
   }

   @Override
   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      super.method_9515(builder);
      builder.method_11667(new class_2769[]{WATERLOGGED});
   }

   @Override
   protected int getClickedSlot(class_2350 direction, class_2338 pos, class_3965 hitResult) {
      double localX = this.getLocalX(direction, pos, hitResult);
      double localZ = this.getLocalZ(direction, pos, hitResult);
      double angle = Math.atan2(localZ - 0.5, localX - 0.5) * 180.0F / (float)Math.PI;
      angle = (angle + 360.0) % 360.0;
      if (angle > 300.0) {
         return 5;
      } else if (angle > 240.0) {
         return 0;
      } else if (angle > 180.0) {
         return 1;
      } else if (angle > 120.0) {
         return 2;
      } else {
         return angle > 60.0 ? 3 : 4;
      }
   }

   @Override
   protected class_243 getShootPos(class_2350 direction, class_2338 pos, int slot) {
      return class_243.method_24953(pos);
   }

   @Override
   protected class_243 getMovement(class_2350 direction, class_2338 pos, int slot) {
      double factor = Math.random() * 2.0 + 0.5;
      return new class_243(0.0, factor, 0.0);
   }

   public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
      if (random.method_43048(8) == 0) {
         if (level.method_8321(pos) instanceof CircularRackBlockEntity rack && rack.hasAnyItem()) {
            double x = pos.method_10263();
            double y = pos.method_10264();
            double z = pos.method_10260();
            x = random.method_43056() ? x + 0.125 + random.method_43058() * 0.25 : x + 0.875 - random.method_43058() * 0.25;
            y += random.method_43058();
            z = random.method_43056() ? z + 0.125 + random.method_43058() * 0.25 : z + 0.875 - random.method_43058() * 0.25;
            level.method_8406(class_2398.field_11207, x, y, z, 0.01, 0.01, 0.01);
         }
      }
   }

   @Nullable
   public class_2586 method_10123(class_2338 pos, class_2680 state) {
      return new CircularRackBlockEntity(pos, state);
   }

   public @NonNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
      return SHAPE;
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
