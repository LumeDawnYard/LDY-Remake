package com.github.ysbbbbbb.kaleidoscopetavern.entity;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEntities;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.github.ysbbbbbb.kaleidoscopetavern.util.SitUtil;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1538;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3231;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_2945.class_9222;
import org.jspecify.annotations.NonNull;

public class SitEntity extends class_1297 {
   private int passengerTick = 0;

   public SitEntity(class_1299<? extends SitEntity> type, class_1937 level) {
      super(type, level);
      this.field_5960 = true;
   }

   public SitEntity(class_1937 level, class_2338 pos) {
      this(ModEntities.SIT, level);
      this.method_5814(pos.method_10263() + 0.5, pos.method_10264() + 0.4375, pos.method_10260() + 0.5);
   }

   public SitEntity(class_1937 level, class_2338 pos, double y) {
      this(ModEntities.SIT, level);
      this.method_5814(pos.method_10263() + 0.5, pos.method_10264() + y, pos.method_10260() + 0.5);
   }

   public @NonNull class_243 method_52538(class_1297 entity) {
      return super.method_52538(entity).method_1031(0.0, -0.0625, 0.0);
   }

   protected void method_5693(@NonNull class_9222 builder) {
   }

   public void method_5749(@NonNull class_11368 nbt) {
   }

   public void method_5652(@NonNull class_11372 nbt) {
   }

   public @NonNull class_2596<class_2602> method_18002(@NonNull class_3231 serverEntity) {
      return new class_2604(this, serverEntity);
   }

   public void method_5773() {
      if (!this.method_73183().method_8608()) {
         this.method_31473();
         this.checkPassengers();
         if (this.field_6012 % 20 == 0) {
            class_2680 blockState = this.method_73183().method_8320(this.method_24515());
            if (!blockState.method_26164(TagMod.SITTABLE)) {
               this.method_31472();
            }
         }
      }
   }

   private void checkPassengers() {
      if (this.method_5685().isEmpty()) {
         this.passengerTick++;
      } else {
         this.passengerTick = 0;
      }

      if (this.passengerTick > 10) {
         this.method_31472();
      }
   }

   public void method_5650(@NonNull class_5529 reason) {
      super.method_5650(reason);
      SitUtil.removeSitEntity(this.method_73183(), this.method_24515());
   }

   public boolean method_5698(class_1297 targetEntity) {
      return true;
   }

   public boolean method_64397(@NonNull class_3218 level, @NonNull class_1282 source, float amount) {
      return false;
   }

   public void method_5784(@NonNull class_1313 moverType, @NonNull class_243 movement) {
   }

   public void method_5697(@NonNull class_1297 pushedEntity) {
   }

   public void method_5762(double x, double y, double z) {
   }

   protected boolean method_5638() {
      return false;
   }

   public void method_5800(@NonNull class_3218 serverLevel, @NonNull class_1538 lightningBolt) {
   }

   public void method_18382() {
   }

   public boolean method_30949(@NonNull class_1297 entity) {
      return false;
   }

   public boolean method_5727(double x, double y, double z) {
      return false;
   }
}
