package com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.IPressingTub;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.ModJadePlugin;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import org.jspecify.annotations.NonNull;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IServerDataProvider;

public enum PressingTubDataProvider implements IServerDataProvider<BlockAccessor> {
   INSTANCE;

   private static final String KEY_FLUID = "kt_fluid";
   private static final String KEY_AMOUNT = "kt_amount";
   private static final String KEY_CAPACITY = "kt_capacity";
   private static final String KEY_NBT = "kt_nbt";

   public void appendServerData(@NonNull class_2487 data, BlockAccessor blockAccessor) {
      if (blockAccessor.getBlockEntity() instanceof IPressingTub pressingTub) {
         CustomFluidTank tank = pressingTub.getFluid();
         if (tank != null) {
            data.method_10569("kt_capacity", 1000);
            int amount = tank.getFluidAmountMb();
            if (amount > 0 && !tank.getFluidVariant().isBlank()) {
               FluidVariant variant = tank.getFluidVariant();
               class_2960 id = class_7923.field_41173.method_10221(variant.getFluid());
               class_6903<class_2520> ops = class_6903.method_46632(class_2509.field_11560, blockAccessor.getLevel().method_30349());
               data.method_10582("kt_fluid", id.toString());
               data.method_10569("kt_amount", amount);
               class_2520 encoded = (class_2520)FluidVariant.CODEC.encodeStart(ops, variant).result().orElse(new class_2487());
               data.method_10566("kt_nbt", encoded);
            } else {
               data.method_10582("kt_fluid", "");
               data.method_10569("kt_amount", 0);
               data.method_10551("kt_nbt");
            }
         }
      }
   }

   public @NonNull class_2960 getUid() {
      return ModJadePlugin.PRESSING_TUB;
   }
}
