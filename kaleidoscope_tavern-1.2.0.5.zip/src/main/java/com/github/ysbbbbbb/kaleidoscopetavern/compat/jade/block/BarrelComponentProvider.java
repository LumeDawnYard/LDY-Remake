package com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarrelBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.ModJadePlugin;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3544;
import org.jspecify.annotations.NonNull;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum BarrelComponentProvider implements IBlockComponentProvider {
   INSTANCE;

   public void appendTooltip(@NonNull ITooltip tooltip, BlockAccessor accessor, @NonNull IPluginConfig pluginConfig) {
      BarrelBlockEntity be = BarrelBlock.getBarrelEntity(accessor.getLevel(), accessor.getPosition(), accessor.getBlockState());
      if (be != null) {
         int brewLevel = be.getBrewLevel();
         class_1799 result = be.getOutput().getStackInSlot(0);
         class_2561 resultText = class_2561.method_43469(
            "jade.plugin_kaleidoscope_tavern.item_and_count", new Object[]{result.method_7964(), result.method_7947()}
         );
         class_2561 levelText = class_2561.method_43471("message.kaleidoscope_tavern.barrel.brew_level.%d".formatted(brewLevel));
         if (!be.isBrewing()) {
            class_2561 message = class_2561.method_43471("message.kaleidoscope_tavern.barrel.not_brewing");
            tooltip.add(message);
         } else if (be.isMaxBrewLevel()) {
            tooltip.add(resultText);
            tooltip.add(class_2561.method_43469("jade.plugin_kaleidoscope_tavern.barrel.level", new Object[]{levelText}));
            tooltip.add(class_2561.method_43471("jade.plugin_kaleidoscope_tavern.barrel.max_level").method_27692(class_124.field_1065));
         } else {
            class_2561 timeText = class_2561.method_43470(class_3544.method_15439(Math.max(be.getBrewTime(), 0), 20.0F));
            tooltip.add(resultText);
            tooltip.add(class_2561.method_43469("jade.plugin_kaleidoscope_tavern.barrel.level", new Object[]{levelText}));
            tooltip.add(class_2561.method_43469("jade.plugin_kaleidoscope_tavern.barrel.next_level", new Object[]{timeText}));
         }
      }
   }

   public @NonNull class_2960 getUid() {
      return ModJadePlugin.BARREL;
   }
}
