package com.github.ysbbbbbb.kaleidoscopetavern.blockentity;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225.class_7874;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class BaseBlockEntity extends class_2586 {
   public BaseBlockEntity(class_2591<?> entityType, class_2338 pos, class_2680 state) {
      super(entityType, pos, state);
   }

   public void refresh() {
      this.method_5431();
      if (this.field_11863 != null) {
         class_2680 state = this.field_11863.method_8320(this.field_11867);
         this.field_11863.method_8413(this.field_11867, state, state, 3);
      }
   }

   @NotNull
   public class_2487 method_16887(class_7874 registries) {
      return this.method_58692(registries);
   }

   @Nullable
   public class_2596<class_2602> method_38235() {
      return class_2622.method_38585(this);
   }
}
