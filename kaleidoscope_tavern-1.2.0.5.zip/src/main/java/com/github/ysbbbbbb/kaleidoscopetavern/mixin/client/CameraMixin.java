package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.ViewportEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_4184.class)
public class CameraMixin {
   @Shadow
   private float field_47549;

   @WrapOperation(method = "method_19321", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_4184;method_19325(FF)V", ordinal = 0))
   private void setup(class_4184 instance, float f, float g, Operation<Void> original) {
      ViewportEvent.ComputeCameraAngles cameraSetup = new ViewportEvent.ComputeCameraAngles((class_4184)this, this.field_47549, f, g, 0.0F);
      cameraSetup.post();
      original.call(new Object[]{instance, cameraSetup.getYaw(), cameraSetup.getPitch()});
   }
}
