package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.BarStoolBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.model.deco.BarStoolBodyModel;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.BarStoolBlockEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1767;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class BarStoolBlockEntityRender implements class_827<BarStoolBlockEntity, BarStoolBlockEntityRenderState> {
   private final Function<class_1767, class_2960> TEXTURE_CACHE = class_156.method_34866(color -> {
      String path = "textures/entity/deco/bar_stool/%s.png".formatted(color.method_7792());
      return class_2960.method_60655("kaleidoscope_tavern", path);
   });
   private static final int MAX_ROT_CACHE_SIZE = 4096;
   private static final float MIN_SMOOTH_FACTOR = 0.2F;
   private static final float MAX_SMOOTH_FACTOR = 0.58F;
   private static final float SENSITIVITY_SCALE = 0.007F;
   private static final float PASSENGER_VELOCITY_BLEND = 0.22F;
   private static final float PASSENGER_PREDICT_TICKS = 0.18F;
   private static final float PASSENGER_MIN_STEP = 2.0F;
   private static final float PASSENGER_STEP_SCALE = 0.26F;
   private static final float RESTORE_SMOOTH_FACTOR = 0.35F;
   private final BarStoolBodyModel model;
   private final Map<Long, Float> renderRotCache = new ConcurrentHashMap<>();

   public BarStoolBlockEntityRender(class_5615 context) {
      this.model = new BarStoolBodyModel(context.method_32140(BarStoolBodyModel.LAYER_LOCATION));
   }

   private static float getSampleTime(float partialTick) {
      class_638 level = class_310.method_1551().field_1687;
      return level == null ? partialTick : (float)level.method_75260() + partialTick;
   }

   private static float smoothPassengerRotation(float currentRot, float targetRot, float angularVelocity) {
      float velocityAbs = Math.abs(angularVelocity);
      float smoothFactor = class_3532.method_15363(0.2F + velocityAbs * 0.007F, 0.2F, 0.58F);
      float lerped = class_3532.method_17821(smoothFactor, currentRot, targetRot);
      float rawStep = class_3532.method_15393(lerped - currentRot);
      float maxStep = 2.0F + velocityAbs * 0.26F;
      float clampedStep = class_3532.method_15363(rawStep, -maxStep, maxStep);
      return class_3532.method_15393(currentRot + clampedStep);
   }

   private static @Nullable class_1309 resolvePassenger(BarStoolBlockEntityRenderState state) {
      class_638 level = class_310.method_1551().field_1687;
      if (level == null) {
         return null;
      }

      for (SitEntity sitEntity : level.method_18467(SitEntity.class, new class_238(state.field_62673))) {
         if (sitEntity.method_5805() && !sitEntity.method_5685().isEmpty() && sitEntity.method_31483() instanceof class_1309 livingEntity) {
            return livingEntity;
         }
      }

      return null;
   }

   private float getRenderRot(BarStoolBlockEntityRenderState state) {
      if (this.renderRotCache.size() > 4096) {
         this.renderRotCache.clear();
      }

      long key = state.field_62673.method_10063();
      float cachedRot = state.cachedRot;
      float currentRot = this.renderRotCache.getOrDefault(key, cachedRot);
      class_1309 passenger = resolvePassenger(state);
      if (passenger == null) {
         float restoredRot = class_3532.method_17821(0.35F, currentRot, cachedRot);
         if (class_3532.method_15356(restoredRot, cachedRot) < 0.5F) {
            this.renderRotCache.remove(key);
            return cachedRot;
         } else {
            this.renderRotCache.put(key, restoredRot);
            return restoredRot;
         }
      } else {
         float bodyRot = class_3532.method_17821(state.partialTicks, passenger.field_6220, passenger.field_6283);
         float angularVelocity = class_3532.method_15393(passenger.field_6283 - passenger.field_6220);
         float predictedRot = bodyRot + angularVelocity * 0.18F;
         float wobble = class_3532.method_15374(getSampleTime(state.partialTicks) * 0.007F) * angularVelocity * 0.22F;
         float targetRot = class_3532.method_15393(class_3532.method_17821(0.22F, bodyRot, predictedRot) + wobble);
         float smoothedRot = smoothPassengerRotation(currentRot, targetRot, angularVelocity);
         this.renderRotCache.put(key, smoothedRot);
         return smoothedRot;
      }
   }

   public @NonNull BarStoolBlockEntityRenderState createRenderState() {
      return new BarStoolBlockEntityRenderState();
   }

   public void extractRenderState(
      @NonNull BarStoolBlockEntity blockEntity,
      @NonNull BarStoolBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.color = blockEntity.getColor();
      blockEntityRenderState.cachedRot = blockEntity.getCachedRot();
      blockEntityRenderState.partialTicks = f;
   }

   public void submit(
      @NonNull BarStoolBlockEntityRenderState blockEntityRenderState,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      float renderRot = this.getRenderRot(blockEntityRenderState);
      class_2960 texture = this.TEXTURE_CACHE.apply(blockEntityRenderState.color);
      poseStack.method_22903();
      poseStack.method_22904(0.5, 1.5, 0.5);
      poseStack.method_22907(class_7833.field_40717.rotationDegrees(180.0F));
      poseStack.method_22907(class_7833.field_40715.rotationDegrees(180.0F - renderRot));
      BarStoolBodyModel.State state = new BarStoolBodyModel.State();
      submitNodeCollector.method_73489(
         this.model, state, poseStack, class_12249.method_75994(texture), blockEntityRenderState.field_62676, class_4608.field_21444, 0, null
      );
      poseStack.method_22909();
   }
}
