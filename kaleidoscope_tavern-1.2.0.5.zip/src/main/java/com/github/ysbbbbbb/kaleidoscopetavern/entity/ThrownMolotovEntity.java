package com.github.ysbbbbbb.kaleidoscopetavern.entity;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEntities;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1682;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4770;
import net.minecraft.class_5819;
import net.minecraft.class_2945.class_9222;

public class ThrownMolotovEntity extends class_1682 {
   public ThrownMolotovEntity(class_1299<? extends class_1682> type, class_1937 level) {
      super(type, level);
   }

   public ThrownMolotovEntity(class_1937 level, class_1309 shooter) {
      super(ModEntities.THROWN_MOLOTOV, shooter.method_23317(), shooter.method_23320() - 0.1F, shooter.method_23321(), level);
      this.method_7432(shooter);
   }

   public ThrownMolotovEntity(class_1937 level, double pX, double pY, double pZ) {
      super(ModEntities.THROWN_MOLOTOV, pX, pY, pZ, level);
   }

   protected void method_5693(class_9222 builder) {
   }

   public class_1799 getItem() {
      return new class_1799(ModItems.MOLOTOV);
   }

   protected void method_7488(class_239 result) {
      super.method_7488(result);
      int radius = 3;
      if (!this.method_73183().method_8608()) {
         class_2338 center = this.method_24515();
         class_5819 random = this.method_73183().method_8409();

         for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
               double distSq = dx * dx + dz * dz;
               double radiusSq = radius * radius;
               if (distSq > radiusSq) {
                  double overshoot = Math.sqrt(distSq) - radius;
                  if (overshoot > 2.0 || random.method_43057() >= (1.0F - (float)overshoot / 2.0F) * 0.6F) {
                     continue;
                  }
               }

               for (int dy = -1; dy <= 1; dy++) {
                  class_2338 pos = center.method_10069(dx, dy, dz);
                  if (this.method_73183().method_22347(pos) && class_4770.method_30032(this.method_73183(), pos, this.method_5735())) {
                     this.method_73183().method_8501(pos, class_4770.method_24416(this.method_73183(), pos));
                     break;
                  }
               }
            }
         }

         this.method_73183()
            .method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(), class_3417.field_15013, class_3419.field_15245, 2.0F, 1.0F);
         this.method_73183()
            .method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(), class_3417.field_15081, class_3419.field_15245, 2.0F, 1.0F);
         if (this.method_73183() instanceof class_3218 serverLevel) {
            serverLevel.method_65096(class_2398.field_11240, this.method_23317(), this.method_23318() + 0.5, this.method_23321(), 30, radius, 1.0, radius, 0.1);
            serverLevel.method_65096(class_2398.field_11251, this.method_23317(), this.method_23318() + 0.5, this.method_23321(), 20, radius, 1.0, radius, 0.1);
         }

         this.method_31472();
      }
   }
}
