package com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.ReiUtil;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.client.registry.display.DisplayRegistry;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;

public class ReiBarrelRecipeCategory implements DisplayCategory<ReiBarrelRecipeCategory.BarrelRecipeDisplay> {
   public static final CategoryIdentifier<ReiBarrelRecipeCategory.BarrelRecipeDisplay> ID = CategoryIdentifier.of("kaleidoscope_tavern", "plugin/barrel");
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.barrel");
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/barrel.png");
   public static final int WIDTH = 180;
   public static final int HEIGHT = 150;

   public CategoryIdentifier<? extends ReiBarrelRecipeCategory.BarrelRecipeDisplay> getCategoryIdentifier() {
      return ID;
   }

   public List<Widget> setupDisplay(ReiBarrelRecipeCategory.BarrelRecipeDisplay display, Rectangle bounds) {
      List<Widget> widgets = new ArrayList<>();
      int startX = bounds.x;
      int startY = bounds.y;
      widgets.add(Widgets.createRecipeBase(bounds));
      widgets.add(Widgets.createTexturedWidget(BG, startX, startY, 0.0F, 0.0F, 180, 150));
      List<EntryIngredient> inputs = display.getInputEntries();

      for (int i = 0; i < inputs.size(); i++) {
         EntryIngredient ingredient = inputs.get(i);
         if (i == 0) {
            widgets.add(Widgets.createSlot(new Point(startX + 10, startY + 9)).entries(ingredient).markInput());
         } else {
            int offsetX = (i - 1) * 18;
            widgets.add(Widgets.createSlot(new Point(startX + 30 + offsetX, startY + 9)).entries(ingredient).markInput());
         }
      }

      if (!display.carrier.isEmpty()) {
         widgets.add(Widgets.createSlot(new Point(startX + 84, startY + 117)).entries(display.carrier).disableBackground().markInput());
      }

      widgets.add(
         Widgets.createSlot(new Point(startX + 152, startY + 86)).entries((Collection)display.getOutputEntries().getFirst()).disableBackground().markOutput()
      );
      return widgets;
   }

   public int getDisplayWidth(ReiBarrelRecipeCategory.BarrelRecipeDisplay display) {
      return 180;
   }

   public int getDisplayHeight() {
      return 150;
   }

   public class_2561 getTitle() {
      return TITLE;
   }

   public Renderer getIcon() {
      return EntryStacks.of(ModItems.BARREL);
   }

   public static void registerCategories(CategoryRegistry registry) {
      registry.add(new ReiBarrelRecipeCategory());
      registry.addWorkstations(ID, new EntryIngredient[]{ReiUtil.ofItem(ModItems.BARREL)});
   }

   @Deprecated
   public static void registerDisplays(DisplayRegistry registry) {
      ReiUtil.INSTANCE
         .barrelRecipes()
         .forEach(
            holder -> {
               BarrelRecipe recipe = (BarrelRecipe)holder.comp_1933();
               List<EntryIngredient> inputs = Lists.newArrayList();
               inputs.addFirst(ReiUtil.ofItemStack(new class_1799(recipe.fluid().method_15774(), 4)));
               recipe.ingredients().stream().map(i -> ReiUtil.ofIngredient(i, 16)).forEach(inputs::add);
               EntryIngredient carrier = ((BarrelRecipe)holder.comp_1933()).carrier().method_65799()
                  ? EntryIngredient.empty()
                  : ReiUtil.ofIngredient(((BarrelRecipe)holder.comp_1933()).carrier());
               List<EntryIngredient> outputs = List.of(ReiUtil.ofItemStack(recipe.result().method_46651(16)));
               registry.add(
                  new ReiBarrelRecipeCategory.BarrelRecipeDisplay(
                     holder.comp_1932().method_29177(), inputs, outputs, carrier, ((BarrelRecipe)holder.comp_1933()).unitTime()
                  )
               );
            }
         );
   }

   public static class BarrelRecipeDisplay extends BasicDisplay {
      public final EntryIngredient carrier;
      public final int unitTime;
      public static final DisplaySerializer<ReiBarrelRecipeCategory.BarrelRecipeDisplay> SERIALIZER = DisplaySerializer.of(
         RecordCodecBuilder.mapCodec(
            inst -> inst.group(
                  class_2960.field_25139.fieldOf("location").forGetter(r -> r.getDisplayLocation().orElse(class_2960.method_60656("air"))),
                  EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(BasicDisplay::getInputEntries),
                  EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(BasicDisplay::getOutputEntries),
                  EntryIngredient.codec().fieldOf("carrier").forGetter(ReiBarrelRecipeCategory.BarrelRecipeDisplay::getCarrier),
                  Codec.INT.fieldOf("unitTime").forGetter(ReiBarrelRecipeCategory.BarrelRecipeDisplay::getUnitTime)
               )
               .apply(inst, ReiBarrelRecipeCategory.BarrelRecipeDisplay::new)
         ),
         class_9139.method_56906(
            class_2960.field_48267,
            r -> r.getDisplayLocation().orElse(class_2960.method_60656("air")),
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getInputEntries,
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getOutputEntries,
            EntryIngredient.streamCodec(),
            ReiBarrelRecipeCategory.BarrelRecipeDisplay::getCarrier,
            class_9135.field_49675,
            i -> i.unitTime,
            ReiBarrelRecipeCategory.BarrelRecipeDisplay::new
         )
      );

      public BarrelRecipeDisplay(class_2960 location, List<EntryIngredient> inputs, List<EntryIngredient> outputs, EntryIngredient carrier, int unitTime) {
         super(inputs, outputs, Optional.of(location));
         this.carrier = carrier;
         this.unitTime = unitTime;
      }

      public BarrelRecipeDisplay(class_8786<BarrelRecipe> holder) {
         this(
            holder.comp_1932().method_29177(),
            ReiUtil.ofIngredients(((BarrelRecipe)holder.comp_1933()).ingredients(), ((BarrelRecipe)holder.comp_1933()).fluid()),
            ReiUtil.ofItemStacks(((BarrelRecipe)holder.comp_1933()).result()),
            ReiUtil.ofIngredient(((BarrelRecipe)holder.comp_1933()).carrier()),
            ((BarrelRecipe)holder.comp_1933()).unitTime()
         );
      }

      public EntryIngredient getCarrier() {
         return this.carrier;
      }

      public int getUnitTime() {
         return this.unitTime;
      }

      public CategoryIdentifier<?> getCategoryIdentifier() {
         return ReiBarrelRecipeCategory.ID;
      }

      @Nullable
      public DisplaySerializer<? extends Display> getSerializer() {
         return SERIALIZER;
      }
   }
}
