package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.block.AbstractStorageBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.PositionType;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.CellarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class CellarCabinetBlock extends AbstractStorageBlock implements class_3737 {
   private static final MapCodec<CellarCabinetBlock> CODEC = method_54094(p -> new CellarCabinetBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public CellarCabinetBlock() {
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
                  .method_11657(POWERED, false))
               .method_11657(WATERLOGGED, false))
            .method_11657(BarCabinetBlock.POSITION, PositionType.SINGLE)
      );
   }

   public CellarCabinetBlock(class_2251 properties) {
      super(properties);
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
                  .method_11657(POWERED, false))
               .method_11657(WATERLOGGED, false))
            .method_11657(BarCabinetBlock.POSITION, PositionType.SINGLE)
      );
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      return super.handleUse(state, level, pos, player, hand, hitResult);
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @Override
   protected boolean blockListCheck(class_1799 stack) {
      return stack.method_31573(TagMod.CELLAR_CABINET_BLOCKLIST);
   }

   @Override
   protected int getClickedSlot(class_2350 direction, class_2338 pos, class_3965 hitResult) {
      if (hitResult.method_17780() != direction) {
         return -1;
      }

      double localX = this.getLocalX(direction, pos, hitResult);
      double relativeY = hitResult.method_17784().field_1351 - pos.method_10264();
      int column = (int)(localX * 3.0) % 3;
      int row = 2 - (int)(relativeY * 3.0) % 3;
      return column + row * 3;
   }

   @Override
   protected class_243 getShootPos(class_2350 direction, class_2338 pos, int slot) {
      class_243 center = class_243.method_24954(pos).method_1031(0.5, 0.5, 0.5);
      class_243 scale = class_243.method_24954(new class_2382(direction.method_10148(), direction.method_10164(), direction.method_10165())).method_1021(0.5);
      return center.method_1019(scale);
   }

   @Override
   protected class_243 getMovement(class_2350 direction, class_2338 pos, int slot) {
      double factor = Math.random() * 2.0 + 0.5;
      class_243 normal = class_243.method_49273(new class_2382(direction.method_10148(), direction.method_10164(), direction.method_10165()), 0.0, 0.1, 0.0);
      return normal.method_1021(factor);
   }

   protected @NonNull class_2680 method_9559(
      class_2680 state,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 pos,
      @NonNull class_2350 direction,
      @NonNull class_2338 neighborPos,
      @NonNull class_2680 neighborState,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)state.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      class_2350 self = (class_2350)state.method_11654(field_11177);
      class_2350 left = self.method_10170();
      class_2350 right = self.method_10160();
      if (direction == left) {
         boolean leftIsCabinet = neighborState.method_27852(this) && neighborState.method_11654(field_11177) == self;
         PositionType position = (PositionType)state.method_11654(BarCabinetBlock.POSITION);
         if (leftIsCabinet) {
            if (position == PositionType.SINGLE) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.RIGHT);
            }

            if (position == PositionType.LEFT) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.MIDDLE);
            }
         } else {
            if (position == PositionType.RIGHT) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.SINGLE);
            }

            if (position == PositionType.MIDDLE) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.LEFT);
            }
         }
      } else if (direction == right) {
         boolean rightIsCabinet = neighborState.method_27852(this) && neighborState.method_11654(field_11177) == self;
         PositionType position = (PositionType)state.method_11654(BarCabinetBlock.POSITION);
         if (rightIsCabinet) {
            if (position == PositionType.SINGLE) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.LEFT);
            }

            if (position == PositionType.RIGHT) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.MIDDLE);
            }
         } else {
            if (position == PositionType.LEFT) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.SINGLE);
            }

            if (position == PositionType.MIDDLE) {
               return (class_2680)state.method_11657(BarCabinetBlock.POSITION, PositionType.RIGHT);
            }
         }
      }

      return super.method_9559(state, levelReader, scheduledTickAccess, pos, direction, neighborPos, neighborState, randomSource);
   }

   @Nullable
   @Override
   public class_2680 method_9605(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 pos = context.method_8037();
      class_2350 opposite = context.method_8042().method_10153();
      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      class_2680 left = level.method_8320(pos.method_10093(opposite.method_10170()));
      class_2680 right = level.method_8320(pos.method_10093(opposite.method_10160()));
      PositionType position = PositionType.SINGLE;
      boolean leftIsCabinet = left.method_27852(this) && left.method_11654(field_11177) == opposite;
      boolean rightIsCabinet = right.method_27852(this) && right.method_11654(field_11177) == opposite;
      if (leftIsCabinet && rightIsCabinet) {
         position = PositionType.MIDDLE;
      } else if (leftIsCabinet) {
         position = PositionType.RIGHT;
      } else if (rightIsCabinet) {
         position = PositionType.LEFT;
      }

      boolean signal = level.method_49803(pos);
      return (class_2680)((class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, opposite)).method_11657(POWERED, signal))
            .method_11657(WATERLOGGED, hasWater))
         .method_11657(BarCabinetBlock.POSITION, position);
   }

   @Nullable
   public class_2586 method_10123(class_2338 pos, class_2680 state) {
      return new CellarCabinetBlockEntity(pos, state);
   }

   @Override
   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, POWERED, BarCabinetBlock.POSITION, WATERLOGGED});
   }

   @Override
   public float method_9575(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
      return 0.2F;
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
