package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class ShriekAttackEffect extends BaseEffect {
   private static final double MAX_DISTANCE = 32.0;
   private static final double WAVE_THICKNESS = 1.0;
   private static final double HORIZONTAL_SPEED = 0.63;
   private static final double VERTICAL_SPEED = 0.28;

   public ShriekAttackEffect(int color) {
      super(color);
   }

   public boolean method_5561() {
      return true;
   }

   @Override
   public void method_5564(
      class_3218 serverLevel, @Nullable class_1297 source, @Nullable class_1297 indirectSource, class_1309 livingEntity, int amplifier, double health
   ) {
      this.performEffect(livingEntity);
   }

   @Override
   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      this.performEffect(livingEntity);
      return true;
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return duration == 1;
   }

   private void performEffect(class_1309 user) {
      class_1937 level = user.method_73183();
      if (!level.method_8608()) {
         class_243 eyePos = user.method_33571();
         class_243 lookVec = user.method_5720();
         float damage = user.method_6032() * 1.2F;
         level.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_38830, class_3419.field_15248, 1.0F, 1.0F);
         class_238 searchArea = user.method_5829().method_1014(32.0);
         List<class_1309> targets = level.method_8390(class_1309.class, searchArea, e -> e != user && e.method_5805());
         class_243 horizComponent = new class_243(lookVec.field_1352, 0.0, lookVec.field_1350);
         if (horizComponent.method_1027() < 0.001) {
            horizComponent = class_243.field_1353;
         } else {
            horizComponent = horizComponent.method_1029();
         }

         for (class_1309 target : targets) {
            class_243 targetCenter = target.method_73189().method_1031(0.0, target.method_17682() / 2.0, 0.0);
            class_243 toTarget = targetCenter.method_1020(eyePos);
            double dot = toTarget.method_1026(lookVec);
            if (!(dot < 0.0) && !(dot > 32.0)) {
               class_243 closestPoint = eyePos.method_1019(lookVec.method_1021(dot));
               double perpDistance = closestPoint.method_1022(targetCenter);
               if (!(perpDistance > 1.0 + target.method_17681() / 2.0)) {
                  target.method_64419(level.method_48963().method_48821(user), damage);
                  target.method_18799(target.method_18798().method_1031(horizComponent.field_1352 * 0.63, 0.28, horizComponent.field_1350 * 0.63));
                  target.field_6037 = true;
               }
            }
         }

         if (level instanceof class_3218 serverLevel) {
            class_243 particlePos = eyePos;

            for (int i = 0; i < 16; i++) {
               particlePos = particlePos.method_1019(lookVec.method_1021(2.0));
               serverLevel.method_65096(class_2398.field_38908, particlePos.field_1352, particlePos.field_1351, particlePos.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            }
         }
      }
   }
}
