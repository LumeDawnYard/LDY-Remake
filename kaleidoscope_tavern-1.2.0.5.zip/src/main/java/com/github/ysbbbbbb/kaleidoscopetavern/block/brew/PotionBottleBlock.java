package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PotionBottleBlockEntity;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PotionBottleBlock extends BottleBlock implements class_2343 {
   public PotionBottleBlock(class_2251 properties) {
      super(properties, false);
   }

   public @NonNull List<class_1799> method_9560(class_2680 state, class_8568 params) {
      List<class_1799> drops = super.method_9560(state, params);
      class_2586 blockEntity = (class_2586)params.method_51876(class_181.field_1228);
      if (blockEntity instanceof PotionBottleBlockEntity be && !be.getPotionStack().method_7960()) {
         drops.add(be.getPotionStack().method_46651(1));
      }

      return drops;
   }

   public @NonNull class_1799 method_9574(@NonNull class_4538 level, @NonNull class_2338 pos, @NonNull class_2680 state, boolean bl) {
      return level.method_8321(pos) instanceof PotionBottleBlockEntity be && !be.getPotionStack().method_7960()
         ? be.getPotionStack().method_46651(1)
         : super.method_9574(level, pos, state, bl);
   }

   @Nullable
   public class_2586 method_10123(class_2338 pos, class_2680 state) {
      return new PotionBottleBlockEntity(pos, state);
   }

   @Override
   public @NonNull class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
      return BottleBlock.SHAPE;
   }
}
