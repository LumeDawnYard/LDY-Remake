package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PendantLampBlock extends class_2383 implements class_3737 {
   public static final class_2754<class_2756> HALF = class_2741.field_12533;
   public static final class_265 UPPER_NORTH_SOUTH_SHAPE = class_2248.method_9541(1.0, 0.0, 5.0, 15.0, 16.0, 11.0);
   public static final class_265 UPPER_EAST_WEST_SHAPE = class_2248.method_9541(5.0, 0.0, 1.0, 11.0, 16.0, 15.0);
   public static final class_265 LOWER_NORTH_SOUTH_SHAPE = class_2248.method_9541(1.0, 1.0, 5.0, 15.0, 16.0, 11.0);
   public static final class_265 LOWER_EAST_WEST_SHAPE = class_2248.method_9541(5.0, 1.0, 1.0, 11.0, 16.0, 15.0);
   private static final MapCodec<PendantLampBlock> CODEC = method_54094(p -> new PendantLampBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;

   public PendantLampBlock() {
      super(
         class_2251.method_9637()
            .method_31710(class_3620.field_16005)
            .method_9632(0.8F)
            .method_9626(class_2498.field_24119)
            .method_9631(state -> state.method_11654(HALF) == class_2756.field_12609 ? 0 : 13)
            .method_22488()
            .method_9634()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(HALF, class_2756.field_12607))
               .method_11657(WATERLOGGED, false))
            .method_11657(field_11177, class_2350.field_11043)
      );
   }

   public PendantLampBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_16005)
            .method_9632(0.8F)
            .method_9626(class_2498.field_24119)
            .method_9631(state -> state.method_11654(HALF) == class_2756.field_12609 ? 0 : 13)
            .method_22488()
            .method_9634()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(HALF, class_2756.field_12607))
               .method_11657(WATERLOGGED, false))
            .method_11657(field_11177, class_2350.field_11043)
      );
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 state,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 pos,
      @NonNull class_2350 direction,
      @NonNull class_2338 neighborPos,
      @NonNull class_2680 neighborState,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)state.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      class_2756 half = (class_2756)state.method_11654(HALF);
      boolean isLowerHalf = half == class_2756.field_12607 && direction == class_2350.field_11036;
      boolean isUpperHalf = half == class_2756.field_12609 && direction == class_2350.field_11033;
      if (direction.method_10166() == class_2351.field_11052 && (isLowerHalf || isUpperHalf)) {
         return neighborState.method_27852(this) && neighborState.method_11654(HALF) != half
            ? (class_2680)state.method_11657(field_11177, (class_2350)neighborState.method_11654(field_11177))
            : class_2246.field_10124.method_9564();
      } else {
         return super.method_9559(state, levelReader, scheduledTickAccess, pos, direction, neighborPos, neighborState, randomSource);
      }
   }

   public @NonNull class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
      if (!level.method_8608() && player.method_68878() && state.method_11654(HALF) == class_2756.field_12609) {
         class_2338 below = pos.method_10074();
         class_2680 belowState = level.method_8320(below);
         if (belowState.method_27852(state.method_26204()) && belowState.method_11654(HALF) == class_2756.field_12607) {
            class_2680 airBlockState = belowState.method_26227().method_39360(class_3612.field_15910)
               ? class_2246.field_10382.method_9564()
               : class_2246.field_10124.method_9564();
            level.method_8652(below, airBlockState, 35);
            level.method_8444(player, 2001, below, class_2248.method_9507(belowState));
         }
      }

      return super.method_9576(level, pos, state, player);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_1937 level = context.method_8045();
      boolean hasWater = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
      return pos.method_10264() > level.method_31607() + 1 && level.method_8320(pos.method_10074()).method_26166(context)
         ? (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, context.method_8042())).method_11657(WATERLOGGED, hasWater))
            .method_11657(HALF, class_2756.field_12609)
         : null;
   }

   public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
      class_2338 below = pos.method_10074();
      boolean hasWater = level.method_8316(below).method_15772() == class_3612.field_15910;
      class_2680 blockState = (class_2680)((class_2680)state.method_11657(HALF, class_2756.field_12607)).method_11657(WATERLOGGED, hasWater);
      level.method_8501(below, blockState);
   }

   public @NonNull List<class_1799> method_9560(class_2680 state, class_8568 lootParamsBuilder) {
      return state.method_11654(HALF) == class_2756.field_12607 ? super.method_9560(state, lootParamsBuilder) : Collections.emptyList();
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, HALF, WATERLOGGED});
   }

   public @NonNull class_265 method_9530(class_2680 state, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
      boolean isLower = state.method_11654(HALF) == class_2756.field_12607;

      return switch ((class_2350)state.method_11654(field_11177)) {
         case field_11043, field_11035 -> isLower ? LOWER_NORTH_SOUTH_SHAPE : UPPER_NORTH_SOUTH_SHAPE;
         default -> isLower ? LOWER_EAST_WEST_SHAPE : UPPER_EAST_WEST_SHAPE;
      };
   }

   protected @NonNull MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
