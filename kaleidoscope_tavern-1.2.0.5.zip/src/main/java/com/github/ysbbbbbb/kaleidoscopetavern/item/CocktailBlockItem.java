package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10128;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1844;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_5244;
import net.minecraft.class_5328;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;

public class CocktailBlockItem extends GlasswareBlockItem implements IHasContainer {
   public CocktailBlockItem(class_2248 block) {
      super(block);
   }

   public CocktailBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties.method_57349(class_9334.field_53964, class_10128.method_62859().method_62851()));
   }

   public int method_7881(class_1799 stack, class_1309 entity) {
      return 32;
   }

   @NotNull
   public class_1839 method_7853(class_1799 stack) {
      return class_1839.field_8946;
   }

   @NotNull
   public class_1269 method_7884(class_1838 context) {
      class_1657 player = context.method_8036();
      if (player != null && !player.method_5715()) {
         class_1937 level = context.method_8045();
         class_1269 result = this.method_7836(level, player, context.method_20287());
         return (class_1269)(result == class_1269.field_21466 ? class_1269.field_5812 : result);
      } else {
         return this.method_7712(new class_1750(context));
      }
   }

   @NotNull
   public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
      return class_5328.method_29282(level, player, hand);
   }

   @NotNull
   public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
      if (entity instanceof class_3222 serverPlayer) {
         class_174.field_1198.method_8821(serverPlayer, stack);
         serverPlayer.method_7259(class_3468.field_15372.method_14956(this));
      }

      this.addDrinkEffect(stack, level, entity);
      if (entity instanceof class_1657 player && !player.method_68878()) {
         stack.method_7934(1);
      }

      return this.returnContainerToEntity(stack, level, entity);
   }

   protected void addDrinkEffect(class_1799 drink, class_1937 level, class_1309 entity) {
      DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(drink.method_7909());
      if (effectData != null) {
         List<List<DrinkEffectData.Entry>> effects = effectData.effects();
         if (!effects.isEmpty()) {
            for (DrinkEffectData.Entry entry : effects.getFirst()) {
               if (!level.method_8608() && level.field_9229.method_43057() < entry.probability()) {
                  class_1291 effect = (class_1291)entry.effect().comp_349();
                  int amplifier = entry.amplifier();
                  if (effect.method_5561()) {
                     effect.method_5564((class_3218)level, entity, entity, entity, amplifier, 1.0);
                  } else {
                     int duration = entry.duration() * 20;
                     class_1293 instance = new class_1293(entry.effect(), duration, amplifier);
                     entity.method_6092(instance);
                  }
               }
            }
         }
      }
   }

   public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 flag) {
      DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(stack.method_7909());
      if (effectData != null && !effectData.effects().isEmpty()) {
         List<class_1293> effectsShow = Lists.newArrayList();

         for (DrinkEffectData.Entry entry : effectData.effects().getFirst()) {
            if (entry.probability() >= 1.0F) {
               int duration = entry.duration() * 20;
               int amplifier = entry.amplifier();
               effectsShow.add(new class_1293(entry.effect(), duration, amplifier));
            }
         }

         if (!effectsShow.isEmpty()) {
            consumer.accept(class_5244.method_48320());
            class_1844.method_8065(effectsShow, consumer, 1.0F, context.method_59531());
         }
      }
   }

   @Override
   public class_1792 getContainerItem() {
      return ModItems.EMPTY_GLASSWARE;
   }
}
