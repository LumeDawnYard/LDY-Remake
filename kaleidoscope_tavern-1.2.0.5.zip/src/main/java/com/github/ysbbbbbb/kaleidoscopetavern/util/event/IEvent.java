package com.github.ysbbbbbb.kaleidoscopetavern.util.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

public interface IEvent {
   Event<IEvent.Callback<IEvent>> CALLBACK = EventFactory.createArrayBacked(IEvent.Callback.class, callbacks -> event -> {
      for (IEvent.Callback<IEvent> callback : callbacks) {
         callback.post(event);
      }
   });

   void post();

   @Deprecated
   static <T extends IEvent> void post(T event) {
      ((IEvent.Callback)CALLBACK.invoker()).post(event);
   }

   interface Callback<T extends IEvent> {
      void post(T var1);
   }
}
