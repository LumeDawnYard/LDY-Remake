package com.github.ysbbbbbb.kaleidoscopetavern.mixin;

import java.util.UUID;
import net.minecraft.class_1641;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1641.class)
public interface ZombieVillagerAccessor {
   @Invoker("method_7199")
   void invokeStartConverting(UUID var1, int var2);
}
