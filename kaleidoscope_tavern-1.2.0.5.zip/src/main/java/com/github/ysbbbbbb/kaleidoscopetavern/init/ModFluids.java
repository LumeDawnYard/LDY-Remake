package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.fluid.JuiceFluid;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1792;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2404;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import net.minecraft.class_4970.class_2251;

public final class ModFluids {
   public static final class_3609 GRAPE_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_GRAPE_JUICE, () -> GRAPE_JUICE, () -> ModItems.GRAPE_BUCKET, () -> ModFluids.GRAPE_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_GRAPE_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_GRAPE_JUICE, () -> GRAPE_JUICE, () -> ModItems.GRAPE_BUCKET, () -> ModFluids.GRAPE_JUICE_BLOCK
   );
   public static final class_2404 GRAPE_JUICE_BLOCK = new class_2404(
      GRAPE_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("grape_juice"))
   );
   public static final class_3609 SWEET_BERRIES_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_SWEET_BERRIES_JUICE, () -> SWEET_BERRIES_JUICE, () -> ModItems.SWEET_BERRIES_BUCKET, () -> ModFluids.SWEET_BERRIES_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_SWEET_BERRIES_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_SWEET_BERRIES_JUICE, () -> SWEET_BERRIES_JUICE, () -> ModItems.SWEET_BERRIES_BUCKET, () -> ModFluids.SWEET_BERRIES_JUICE_BLOCK
   );
   public static final class_2404 SWEET_BERRIES_JUICE_BLOCK = new class_2404(
      SWEET_BERRIES_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("sweet_berries_juice"))
   );
   public static final class_3609 GLOW_BERRIES_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_GLOW_BERRIES_JUICE, () -> GLOW_BERRIES_JUICE, () -> ModItems.GLOW_BERRIES_BUCKET, () -> ModFluids.GLOW_BERRIES_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_GLOW_BERRIES_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_GLOW_BERRIES_JUICE, () -> GLOW_BERRIES_JUICE, () -> ModItems.GLOW_BERRIES_BUCKET, () -> ModFluids.GLOW_BERRIES_JUICE_BLOCK
   );
   public static final class_2404 GLOW_BERRIES_JUICE_BLOCK = new class_2404(
      GLOW_BERRIES_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("glow_berries_juice"))
   );
   public static final class_3609 ICE_GRAPE_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_ICE_GRAPE_JUICE, () -> ICE_GRAPE_JUICE, () -> ModItems.ICE_GRAPE_BUCKET, () -> ModFluids.ICE_GRAPE_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_ICE_GRAPE_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_ICE_GRAPE_JUICE, () -> ICE_GRAPE_JUICE, () -> ModItems.ICE_GRAPE_BUCKET, () -> ModFluids.ICE_GRAPE_JUICE_BLOCK
   );
   public static final class_2404 ICE_GRAPE_JUICE_BLOCK = new class_2404(
      ICE_GRAPE_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("ice_grape_juice"))
   );
   public static final class_3609 GOLD_GRAPE_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_GOLD_GRAPE_JUICE, () -> GOLD_GRAPE_JUICE, () -> ModItems.GOLD_GRAPE_BUCKET, () -> ModFluids.GOLD_GRAPE_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_GOLD_GRAPE_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_GOLD_GRAPE_JUICE, () -> GOLD_GRAPE_JUICE, () -> ModItems.GOLD_GRAPE_BUCKET, () -> ModFluids.GOLD_GRAPE_JUICE_BLOCK
   );
   public static final class_2404 GOLD_GRAPE_JUICE_BLOCK = new class_2404(
      GOLD_GRAPE_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("gold_grape_juice"))
   );
   public static final class_3609 GREEN_GRAPE_JUICE = new JuiceFluid.Still(
      () -> ModFluids.FLOWING_GREEN_GRAPE_JUICE, () -> GREEN_GRAPE_JUICE, () -> ModItems.GREEN_GRAPE_BUCKET, () -> ModFluids.GREEN_GRAPE_JUICE_BLOCK
   );
   public static final class_3609 FLOWING_GREEN_GRAPE_JUICE = new JuiceFluid.Flowing(
      () -> FLOWING_GREEN_GRAPE_JUICE, () -> GREEN_GRAPE_JUICE, () -> ModItems.GREEN_GRAPE_BUCKET, () -> ModFluids.GREEN_GRAPE_JUICE_BLOCK
   );
   public static final class_2404 GREEN_GRAPE_JUICE_BLOCK = new class_2404(
      GREEN_GRAPE_JUICE, class_2251.method_9630(class_2246.field_10382).method_63500(PortHelper.createBlockId("green_grape_juice"))
   );

   public static void registerFluids() {
      register("grape_juice", GRAPE_JUICE, FLOWING_GRAPE_JUICE, GRAPE_JUICE_BLOCK, ModItems.GRAPE_BUCKET);
      register("sweet_berries_juice", SWEET_BERRIES_JUICE, FLOWING_SWEET_BERRIES_JUICE, SWEET_BERRIES_JUICE_BLOCK, ModItems.SWEET_BERRIES_BUCKET);
      register("glow_berries_juice", GLOW_BERRIES_JUICE, FLOWING_GLOW_BERRIES_JUICE, GLOW_BERRIES_JUICE_BLOCK, ModItems.GLOW_BERRIES_BUCKET);
      register("ice_grape_juice", ICE_GRAPE_JUICE, FLOWING_ICE_GRAPE_JUICE, ICE_GRAPE_JUICE_BLOCK, ModItems.ICE_GRAPE_BUCKET);
      register("gold_grape_juice", GOLD_GRAPE_JUICE, FLOWING_GOLD_GRAPE_JUICE, GOLD_GRAPE_JUICE_BLOCK, ModItems.GOLD_GRAPE_BUCKET);
      register("green_grape_juice", GREEN_GRAPE_JUICE, FLOWING_GREEN_GRAPE_JUICE, GREEN_GRAPE_JUICE_BLOCK, ModItems.GREEN_GRAPE_BUCKET);
   }

   @Environment(EnvType.CLIENT)
   public static void registerFluidRenderers() {
      registerRender(GRAPE_JUICE, FLOWING_GRAPE_JUICE, "block/grape_juice_still", "block/grape_juice_flow", -1);
      registerRender(SWEET_BERRIES_JUICE, FLOWING_SWEET_BERRIES_JUICE, "block/sweet_berries_juice_still", "block/sweet_berries_juice_flow", -1);
      registerRender(GLOW_BERRIES_JUICE, FLOWING_GLOW_BERRIES_JUICE, "block/glow_berries_juice_still", "block/glow_berries_juice_flow", -1);
      registerRender(ICE_GRAPE_JUICE, FLOWING_ICE_GRAPE_JUICE, "block/ice_grape_juice_still", "block/ice_grape_juice_flow", -1);
      registerRender(GOLD_GRAPE_JUICE, FLOWING_GOLD_GRAPE_JUICE, "block/gold_grape_juice_still", "block/gold_grape_juice_flow", -1);
      registerRender(GREEN_GRAPE_JUICE, FLOWING_GREEN_GRAPE_JUICE, "block/green_grape_juice_still", "block/green_grape_juice_flow", -1);
   }

   private static void register(String name, class_3609 still, class_3609 flowing, class_2248 block, class_1792 bucket) {
      class_2378.method_10230(class_7923.field_41173, id(name), still);
      class_2378.method_10230(class_7923.field_41173, id("flowing_" + name), flowing);
      class_2378.method_10230(class_7923.field_41175, id(name), block);
   }

   @Environment(EnvType.CLIENT)
   private static void registerRender(class_3611 still, class_3611 flowing, String stillTexture, String flowTexture, int color) {
      class_2960 stillId = id(stillTexture);
      class_2960 flowId = id(flowTexture);
      FluidRenderHandlerRegistry.INSTANCE.register(still, flowing, new SimpleFluidRenderHandler(stillId, flowId, stillId, color));
      registration(still, color, stillId, flowId);
      registration(flowing, color, stillId, flowId);
   }

   @Environment(EnvType.CLIENT)
   private static void registration(class_3611 fluid, int color, class_2960 stillId, class_2960 flowId) {
      FluidVariantRendering.register(fluid, new FluidVariantRenderHandler() {
         public class_1058[] getSprites(FluidVariant fluidVariant) {
            class_1059 stillAtlas = (class_1059)class_310.method_1551().method_1531().method_4619(class_1059.field_5275);
            class_1058 stillSprite = stillAtlas.method_4608(stillId);
            class_1058 flowSprite = stillAtlas.method_4608(flowId);
            return new class_1058[]{stillSprite, flowSprite};
         }

         public int getColor(FluidVariant fluidVariant, class_1920 view, class_2338 pos) {
            return color;
         }
      });
   }

   private static class_2960 id(String path) {
      return class_2960.method_60655("kaleidoscope_tavern", path);
   }
}
