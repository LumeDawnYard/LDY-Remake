package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.client.render.entity.StringLightsLayer;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1007;
import net.minecraft.class_1299;
import net.minecraft.class_3300;
import net.minecraft.class_742;
import net.minecraft.class_7920;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_898.class)
public class EntityRendererDispatcherMixin {
   @Shadow
   private Map<class_1299<?>, class_897<?, ?>> field_4696 = ImmutableMap.of();
   @Shadow
   private Map<class_7920, class_1007<class_742>> field_4687 = Map.of();

   @Inject(method = "method_14491", at = @At("TAIL"))
   private void onResourceManagerReload(class_3300 resourceManager, CallbackInfo ci) {
      for (class_1007<class_742> renderer : this.field_4687.values()) {
         renderer.method_4046(new StringLightsLayer(renderer));
      }

      class_897<?, ?> armorStandRenderer = this.field_4696.get(class_1299.field_6131);
      if (armorStandRenderer instanceof class_922 livingEntityRenderer) {
         livingEntityRenderer.method_4046(new StringLightsLayer(livingEntityRenderer));
      }
   }
}
