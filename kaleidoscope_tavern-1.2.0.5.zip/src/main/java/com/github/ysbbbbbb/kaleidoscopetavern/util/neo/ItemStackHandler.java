package com.github.ysbbbbbb.kaleidoscopetavern.util.neo;

import net.minecraft.class_11343;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_11372.class_11373;

public class ItemStackHandler implements IItemHandler {
   private static final String DEFAULT_ITEMS_KEY = "Items";
   private static final String DEFAULT_SIZE_KEY = "Size";
   protected class_2371<class_1799> stacks;

   public ItemStackHandler() {
      this(1);
   }

   public ItemStackHandler(int size) {
      this.stacks = class_2371.method_10213(size, class_1799.field_8037);
   }

   public ItemStackHandler(class_2371<class_1799> stacks) {
      this.stacks = stacks;
   }

   public ItemStackHandler(class_1661 inventory) {
      this(inventory.method_5439());

      for (int i = 0; i < inventory.method_5439(); i++) {
         this.stacks.set(i, inventory.method_5438(i));
      }
   }

   public void setSize(int size) {
      this.stacks = class_2371.method_10213(size, class_1799.field_8037);
   }

   @Override
   public void setStackInSlot(int slot, class_1799 stack) {
      this.validateSlotIndex(slot);
      this.stacks.set(slot, stack);
      this.onContentsChanged(slot);
   }

   @Override
   public int getSlots() {
      return this.stacks.size();
   }

   @Override
   public class_1799 getStackInSlot(int slot) {
      this.validateSlotIndex(slot);
      return (class_1799)this.stacks.get(slot);
   }

   @Override
   public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
      if (stack.method_7960()) {
         return class_1799.field_8037;
      }

      if (!this.isItemValid(slot, stack)) {
         return stack;
      }

      this.validateSlotIndex(slot);
      class_1799 existing = (class_1799)this.stacks.get(slot);
      int limit = this.getStackLimit(slot, stack);
      if (!existing.method_7960()) {
         if (!class_1799.method_31577(stack, existing)) {
            return stack;
         }

         limit -= existing.method_7947();
      }

      if (limit <= 0) {
         return stack;
      }

      boolean reachedLimit = stack.method_7947() > limit;
      if (!simulate) {
         if (existing.method_7960()) {
            this.stacks.set(slot, reachedLimit ? stack.method_46651(limit) : stack);
         } else {
            existing.method_7933(reachedLimit ? limit : stack.method_7947());
         }

         this.onContentsChanged(slot);
      }

      return reachedLimit ? stack.method_46651(stack.method_7947() - limit) : class_1799.field_8037;
   }

   @Override
   public class_1799 extractItem(int slot, int amount, boolean simulate) {
      if (amount == 0) {
         return class_1799.field_8037;
      }

      this.validateSlotIndex(slot);
      class_1799 existing = (class_1799)this.stacks.get(slot);
      if (existing.method_7960()) {
         return class_1799.field_8037;
      }

      int toExtract = Math.min(amount, existing.method_7914());
      if (existing.method_7947() <= toExtract) {
         if (!simulate) {
            this.stacks.set(slot, class_1799.field_8037);
            this.onContentsChanged(slot);
            return existing;
         } else {
            return existing.method_7972();
         }
      } else {
         if (!simulate) {
            this.stacks.set(slot, existing.method_46651(existing.method_7947() - toExtract));
            this.onContentsChanged(slot);
         }

         return existing.method_46651(toExtract);
      }
   }

   @Override
   public int getSlotLimit(int slot) {
      return 99;
   }

   protected int getStackLimit(int slot, class_1799 stack) {
      return Math.min(this.getSlotLimit(slot), stack.method_7914());
   }

   @Override
   public boolean isItemValid(int slot, class_1799 stack) {
      return true;
   }

   public void serialize(class_11372 output) {
      this.serialize(output, "Items", "Size");
   }

   public void serialize(class_11372 output, String itemsKey, String sizeKey) {
      class_11373<class_11343> itemList = output.method_71467(itemsKey, class_11343.field_60354);

      for (int i = 0; i < this.stacks.size(); i++) {
         class_1799 stack = (class_1799)this.stacks.get(i);
         if (!stack.method_7960()) {
            itemList.method_71484(new class_11343(i, stack));
         }
      }

      output.method_71465(sizeKey, this.stacks.size());
   }

   public class_2487 serializeNBT(class_11372 output) {
      this.serialize(output);
      class_2499 nbtTagList = new class_2499();

      for (int i = 0; i < this.stacks.size(); i++) {
         if (!((class_1799)this.stacks.get(i)).method_7960()) {
            class_2487 itemTag = new class_2487();
            itemTag.method_10569("Slot", i);
            nbtTagList.add((class_2520)class_1799.field_24671.encode((class_1799)this.stacks.get(i), class_2509.field_11560, itemTag).getOrThrow());
         }
      }

      class_2487 nbt = new class_2487();
      nbt.method_10566("Items", nbtTagList);
      nbt.method_10569("Size", this.stacks.size());
      return nbt;
   }

   public void deserializeNBT(class_11368 input) {
      this.deserializeNBT(input, "Items", "Size");
   }

   public void deserializeNBT(class_11368 input, String itemsKey, String sizeKey) {
      this.setSize(input.method_71424(sizeKey, this.stacks.size()));
      input.method_71437(itemsKey, class_11343.field_60354).forEach(slot -> {
         if (slot.method_71368(this.stacks.size())) {
            this.stacks.set(slot.comp_4211(), slot.comp_4212());
         }
      });
      this.onLoad();
   }

   protected void validateSlotIndex(int slot) {
      if (slot < 0 || slot >= this.stacks.size()) {
         throw new RuntimeException("Slot " + slot + " not in valid range - [0," + this.stacks.size() + ")");
      }
   }

   protected void onLoad() {
   }

   protected void onContentsChanged(int slot) {
   }

   public class_2371<class_1799> getStacks() {
      return this.stacks;
   }
}
