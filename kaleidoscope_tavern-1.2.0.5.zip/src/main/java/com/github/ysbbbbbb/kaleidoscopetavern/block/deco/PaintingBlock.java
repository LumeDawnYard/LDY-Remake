package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PaintingBlock extends class_2383 implements class_3737 {
   public static final MapCodec<PaintingBlock> CODEC = method_54094(PaintingBlock::new);
   public static final class_2754<class_2738> ATTACH_FACE = class_2741.field_12555;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 NORTH_SHAPE = class_2248.method_9541(1.0, 1.0, 15.0, 15.0, 15.0, 16.0);
   public static final class_265 SOUTH_SHAPE = class_2248.method_9541(1.0, 1.0, 0.0, 15.0, 15.0, 1.0);
   public static final class_265 WEST_SHAPE = class_2248.method_9541(15.0, 1.0, 1.0, 16.0, 15.0, 15.0);
   public static final class_265 EAST_SHAPE = class_2248.method_9541(0.0, 1.0, 1.0, 1.0, 15.0, 15.0);
   public static final class_265 FLOOR_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 1.0, 15.0);
   public static final class_265 CEILING_SHAPE = class_2248.method_9541(1.0, 15.0, 1.0, 15.0, 16.0, 15.0);
   @Nullable
   private String tooltipKey;

   public PaintingBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12645)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(ATTACH_FACE, class_2738.field_12471))
            .method_11657(WATERLOGGED, false)
      );
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, ATTACH_FACE, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2350 clickedFace = context.method_8038();
      class_2738 attachFace = class_2738.field_12471;
      if (clickedFace.method_10166().method_10178()) {
         attachFace = clickedFace == class_2350.field_11036 ? class_2738.field_12475 : class_2738.field_12473;
         class_2350 horizontalDirection = context.method_8042();
         clickedFace = clickedFace == class_2350.field_11036 ? horizontalDirection.method_10153() : horizontalDirection;
      }

      boolean waterLogged = context.method_8045().method_22351(context.method_8037());
      return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, clickedFace)).method_11657(ATTACH_FACE, attachFace))
         .method_11657(WATERLOGGED, waterLogged);
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      class_2738 attachFace = (class_2738)pState.method_11654(ATTACH_FACE);
      if (attachFace == class_2738.field_12475) {
         return FLOOR_SHAPE;
      }

      if (attachFace == class_2738.field_12473) {
         return CEILING_SHAPE;
      }

      return switch ((class_2350)pState.method_11654(field_11177)) {
         case field_11035 -> SOUTH_SHAPE;
         case field_11034 -> EAST_SHAPE;
         case field_11039 -> WEST_SHAPE;
         default -> NORTH_SHAPE;
      };
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
