package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.scenes;

import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.GrapeCropBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.GrapevineTrellisBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.WildGrapevineBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.TrellisType;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.utils.PonderBlockWrapper;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.zurrtum.create.catnip.math.Pointing;
import com.zurrtum.create.client.ponder.api.element.ElementLink;
import com.zurrtum.create.client.ponder.api.element.EntityElement;
import com.zurrtum.create.client.ponder.api.scene.SceneBuilder;
import com.zurrtum.create.client.ponder.api.scene.SceneBuildingUtil;
import com.zurrtum.create.client.ponder.api.scene.Selection;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class GrapevineScenes {
   public static void wildGeneration(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         scene.title("grapevine_wild_generation", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         Selection fullSel = util.select().everywhere().substract(util.select().position(0, 5, 0));
         PonderBlockWrapper vine = new PonderBlockWrapper(1, 2, 0, scene, util);
         PonderBlockWrapper top = new PonderBlockWrapper(0, 5, 0, scene, util);
         class_1799 vineStack = new class_1799(ModItems.GRAPEVINE);
         scene.world().showSection(fullSel, class_2350.field_11036);
         scene.idle(25);
         scene.overlay().showText(140).text("").placeNearTarget();
         scene.idle(20);
         scene.rotateCameraY(120.0F);
         scene.idle(45);
         scene.rotateCameraY(120.0F);
         scene.idle(45);
         scene.rotateCameraY(135.0F);
         scene.idle(45);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(40).text("").pointAt(vine.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(vine.blockSurface(class_2350.field_11043), Pointing.RIGHT, 25).leftClick();
         scene.idle(5);
         scene.world().destroyBlock(vine.pos);
         scene.world().setBlock(vine.pos.method_10084(), ModBlocks.WILD_GRAPEVINE.method_9564(), false);
         ElementLink<EntityElement> itemLink = scene.world().createItemEntity(vine.pos.method_46558(), class_243.field_1353, vineStack.method_7972());
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         top.setBlock(class_2246.field_10161.method_9564(), false);
         top.showSection(class_2350.field_11033);
         scene.idle(15);
         scene.overlay().showText(45).text("").pointAt(top.blockSurface(class_2350.field_11039).method_43206(class_2350.field_11033, 0.5)).placeNearTarget();
         scene.idle(5);
         scene.overlay()
            .showControls(top.blockSurface(class_2350.field_11033).method_43206(class_2350.field_11033, 1.0), Pointing.UP, 25)
            .rightClick()
            .withItem(vineStack.method_7972());
         scene.idle(5);
         scene.world().setBlock(top.pos.method_10074(), ModBlocks.WILD_GRAPEVINE.method_9564(), false);
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(50).text("").placeNearTarget();
         scene.idle(20);
         vine.setBlock(ModBlocks.WILD_GRAPEVINE.method_9564(), true);
         scene.world().setBlock(vine.pos.method_10084(), ModBlocks.WILD_GRAPEVINE_PLANT.method_9564(), false);
         scene.world().setBlock(top.pos.method_10074(), ModBlocks.WILD_GRAPEVINE_PLANT.method_9564(), false);
         scene.world().setBlock(top.pos.method_10074().method_10074(), ModBlocks.WILD_GRAPEVINE.method_9564(), true);
         scene.idle(50);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(60).text("").placeNearTarget();
         scene.idle(5);
         scene.overlay()
            .showControls(top.blockSurface(class_2350.field_11033).method_43206(class_2350.field_11033, 2.0), Pointing.UP, 25)
            .rightClick()
            .withItem(new class_1799(class_1802.field_8868));
         scene.idle(5);
         scene.world().modifyBlock(top.pos.method_10074().method_10074(), s -> (class_2680)s.method_11657(WildGrapevineBlock.SHEARED, true), false);
         scene.idle(40);
         scene.overlay().showControls(vine.blockSurface(class_2350.field_11033), Pointing.UP, 25).rightClick().withItem(new class_1799(class_1802.field_8868));
         scene.idle(5);
         scene.world().modifyBlock(vine.pos, s -> (class_2680)s.method_11657(WildGrapevineBlock.SHEARED, true), false);
         scene.idle(50);
      }
   }

   public static void planting(SceneBuilder scene, SceneBuildingUtil util) {
      class_1937 level = class_310.method_1551().field_1687;
      if (level != null) {
         scene.title("grapevine_planting", "");
         scene.configureBasePlate(0, 0, 5);
         scene.showBasePlate();
         PonderBlockWrapper root = new PonderBlockWrapper(0, 1, 1, scene, util);
         Selection grapeSel = util.select().fromTo(0, 3, 1, 4, 3, 4);
         grapeSel = grapeSel.substract(util.select().position(util.grid().at(0, 3, 1)));
         grapeSel = grapeSel.substract(util.select().position(util.grid().at(4, 3, 1)));
         grapeSel = grapeSel.substract(util.select().position(util.grid().at(0, 3, 4)));
         grapeSel = grapeSel.substract(util.select().position(util.grid().at(4, 3, 4)));
         scene.world().showSection(util.select().everywhere(), class_2350.field_11036);
         scene.idle(25);
         scene.overlay().showText(40).text("").pointAt(root.blockSurface(class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(root.blockSurface(class_2350.field_11034), Pointing.RIGHT, 25).rightClick().withItem(new class_1799(ModItems.GRAPEVINE));
         scene.idle(5);
         root.setBlock(ModBlocks.GRAPEVINE_TRELLIS.method_9564(), false);
         scene.idle(45);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(55).text("").placeNearTarget();
         scene.idle(5);
         growToMaxAge(scene, root.pos);
         scene.world().setBlock(root.pos.method_10084(), ModBlocks.GRAPEVINE_TRELLIS.method_9564(), false);
         growToMaxAge(scene, util.grid().at(0, 2, 1));
         scene.world().setBlock(root.pos.method_10084().method_10084(), ModBlocks.GRAPEVINE_TRELLIS.method_9564(), false);
         growToMaxAge(scene, util.grid().at(0, 3, 1));
         scene.world()
            .setBlock(
               util.grid().at(0, 4, 1),
               (class_2680)ModBlocks.GRAPEVINE_TRELLIS.method_9564().method_11657(GrapevineTrellisBlock.TYPE, TrellisType.SIX_DIRECTION),
               false
            );
         scene.idle(25);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(65).text("").placeNearTarget();
         scene.idle(10);
         toCrossVine(scene, util.grid().at(1, 4, 1));
         toCrossVine(scene, util.grid().at(0, 4, 2));
         scene.idle(10);
         toCrossVine(scene, util.grid().at(2, 4, 1));
         toCrossVine(scene, util.grid().at(1, 4, 2));
         toCrossVine(scene, util.grid().at(0, 4, 3));
         scene.idle(10);
         toCrossVine(scene, util.grid().at(3, 4, 1));
         toCrossVine(scene, util.grid().at(2, 4, 2));
         toCrossVine(scene, util.grid().at(1, 4, 3));
         scene.world()
            .setBlock(
               util.grid().at(0, 4, 4),
               (class_2680)ModBlocks.GRAPEVINE_TRELLIS.method_9564().method_11657(GrapevineTrellisBlock.TYPE, TrellisType.SIX_DIRECTION),
               false
            );
         scene.idle(10);
         toCrossVine(scene, util.grid().at(3, 4, 2));
         toCrossVine(scene, util.grid().at(2, 4, 3));
         toCrossVine(scene, util.grid().at(1, 4, 4));
         scene.world()
            .setBlock(
               util.grid().at(4, 4, 1),
               (class_2680)ModBlocks.GRAPEVINE_TRELLIS.method_9564().method_11657(GrapevineTrellisBlock.TYPE, TrellisType.SIX_DIRECTION),
               false
            );
         scene.idle(10);
         toCrossVine(scene, util.grid().at(4, 4, 2));
         toCrossVine(scene, util.grid().at(3, 4, 3));
         toCrossVine(scene, util.grid().at(2, 4, 4));
         scene.idle(10);
         toCrossVine(scene, util.grid().at(4, 4, 3));
         toCrossVine(scene, util.grid().at(3, 4, 4));
         scene.idle(10);
         scene.world()
            .setBlock(
               util.grid().at(4, 4, 4),
               (class_2680)ModBlocks.GRAPEVINE_TRELLIS.method_9564().method_11657(GrapevineTrellisBlock.TYPE, TrellisType.SIX_DIRECTION),
               false
            );
         scene.idle(30);
         scene.addKeyframe();
         scene.idle(15);
         scene.overlay().showText(65).text("").placeNearTarget();
         scene.idle(8);
         scene.world().setBlocks(grapeSel, ModBlocks.GRAPE_CROP.method_9564(), false);
         scene.idle(8);
         scene.world().modifyBlocks(grapeSel, s -> (class_2680)s.method_11657(GrapeCropBlock.AGE, 1), false);
         scene.idle(8);
         scene.world().modifyBlocks(grapeSel, s -> (class_2680)s.method_11657(GrapeCropBlock.AGE, 2), false);
         scene.idle(8);
         scene.world().modifyBlocks(grapeSel, s -> (class_2680)s.method_11657(GrapeCropBlock.AGE, 3), false);
         scene.idle(8);
         scene.world().modifyBlocks(grapeSel, s -> (class_2680)s.method_11657(GrapeCropBlock.AGE, 4), false);
         scene.idle(8);
         scene.world().modifyBlocks(grapeSel, s -> (class_2680)s.method_11657(GrapeCropBlock.AGE, 5), false);
         scene.idle(25);
         scene.addKeyframe();
         class_2338 grape = util.grid().at(1, 3, 1);
         class_2338 grape1 = util.grid().at(3, 3, 1);
         scene.idle(15);
         scene.overlay().showText(35).text("").pointAt(util.vector().blockSurface(grape, class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay().showControls(util.vector().blockSurface(grape, class_2350.field_11033), Pointing.UP, 25).leftClick();
         scene.idle(5);
         scene.world().destroyBlock(grape);
         scene.world().createItemEntity(grape.method_46558(), class_243.field_1353, new class_1799(ModItems.GRAPE));
         scene.idle(45);
         scene.overlay().showText(35).text("").pointAt(util.vector().blockSurface(grape1, class_2350.field_11039)).placeNearTarget();
         scene.idle(5);
         scene.overlay()
            .showControls(util.vector().blockSurface(grape1, class_2350.field_11033), Pointing.UP, 25)
            .leftClick()
            .withItem(new class_1799(class_1802.field_8868));
         scene.idle(5);
         scene.world().destroyBlock(grape1);
         scene.world().createItemEntity(grape1.method_46558(), class_243.field_1353, new class_1799(ModItems.GRAPE, 3));
         scene.idle(45);
      }
   }

   private static void growToMaxAge(SceneBuilder scene, class_2338 pos) {
      scene.idle(4);

      for (int i = 1; i < 4; i++) {
         int j = i;
         scene.world().modifyBlock(pos, s -> (class_2680)s.method_11657(GrapevineTrellisBlock.AGE, j), false);
         scene.idle(4);
      }
   }

   private static void toCrossVine(SceneBuilder scene, class_2338 pos) {
      scene.world()
         .setBlock(pos, (class_2680)ModBlocks.GRAPEVINE_TRELLIS.method_9564().method_11657(GrapevineTrellisBlock.TYPE, TrellisType.CROSS_UP_DOWN), false);
   }
}
