package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;

public class GrapevineItem extends class_1747 {
   public GrapevineItem() {
      super(ModBlocks.WILD_GRAPEVINE, new class_1793());
   }

   public GrapevineItem(class_1793 properties) {
      super(ModBlocks.WILD_GRAPEVINE, properties);
   }

   public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 flag) {
      consumer.accept(class_2561.method_43471("tooltip.kaleidoscope_tavern.grapevine.1").method_27692(class_124.field_1080));
      consumer.accept(class_2561.method_43471("tooltip.kaleidoscope_tavern.grapevine.2").method_27692(class_124.field_1080));
      consumer.accept(class_2561.method_43471("tooltip.kaleidoscope_tavern.grapevine.3").method_27692(class_124.field_1080));
   }
}
