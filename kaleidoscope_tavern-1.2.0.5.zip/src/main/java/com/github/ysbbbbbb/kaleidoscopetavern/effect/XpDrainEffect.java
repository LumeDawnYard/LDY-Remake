package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public class XpDrainEffect extends BaseEffect {
   private static final double PULL_RADIUS = 8.0;
   private static final double TOUCH_DISTANCE = 1.5;

   public XpDrainEffect(int color) {
      super(color);
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return true;
   }

   @Override
   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      if (livingEntity instanceof class_1657 player) {
         class_1937 level = player.method_73183();
         if (level.method_8608()) {
            return true;
         }

         player.field_7504 = 0;
         if (player.field_6012 % 5 != 0) {
            return true;
         }

         class_238 area = player.method_5829().method_1014(8.0);

         for (class_1303 orb : level.method_18467(class_1303.class, area)) {
            if (orb.method_5805()) {
               double dist = orb.method_5739(player);
               if (dist < 1.5) {
                  orb.method_5694(player);
                  player.field_7504 = 0;
               } else {
                  class_243 direction = player.method_73189().method_1031(0.0, 0.5, 0.0).method_1020(orb.method_73189()).method_1029();
                  double speed = Math.min(0.5 + 1.0 / dist, 1.5);
                  orb.method_18799(direction.method_1021(speed));
               }
            }
         }

         return true;
      } else {
         return true;
      }
   }
}
