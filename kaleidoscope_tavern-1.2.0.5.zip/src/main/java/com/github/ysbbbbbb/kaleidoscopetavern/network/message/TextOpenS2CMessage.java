package com.github.ysbbbbbb.kaleidoscopetavern.network.message;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.gui.block.TextScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.Context;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.class_8710.class_9154;
import org.jetbrains.annotations.NotNull;

public record TextOpenS2CMessage(class_2338 pos) implements class_8710 {
   public static final class_9154<TextOpenS2CMessage> TYPE = new class_9154(class_2960.method_60655("kaleidoscope_tavern", "text_open"));
   public static final class_9139<class_2540, TextOpenS2CMessage> STREAM_CODEC = new class_9139<class_2540, TextOpenS2CMessage>() {
      @NotNull
      public TextOpenS2CMessage decode(class_2540 buf) {
         return new TextOpenS2CMessage(buf.method_10811());
      }

      public void encode(class_2540 buf, TextOpenS2CMessage msg) {
         buf.method_10807(msg.pos());
      }
   };

   @NotNull
   public class_9154<? extends class_8710> method_56479() {
      return TYPE;
   }

   @Environment(EnvType.CLIENT)
   private static void onHandle(TextOpenS2CMessage message) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1687 != null) {
         class_1657 player = mc.field_1724;
         if (player != null) {
            if (mc.field_1687.method_8477(message.pos)) {
               class_1937 level = mc.field_1687;
               class_2338 pos = message.pos();
               if (level.method_8321(pos) instanceof TextBlockEntity textBlock) {
                  if (textBlock.isWaxed()) {
                     return;
                  }

                  if (textBlock.playerIsTooFarAwayToEdit(player.method_5667())) {
                     return;
                  }

                  mc.method_1507(new TextScreen(textBlock));
               }
            }
         }
      }
   }

   public static void receive(TextOpenS2CMessage textOpenS2CMessage, Context context) {
      onHandle(textOpenS2CMessage);
   }
}
