package com.github.ysbbbbbb.kaleidoscopetavern.util.fluids;

import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3414;

public class FluidUtils {
   public static boolean emptyItem(class_1309 user, class_1799 bucket, Storage<FluidVariant> handler, int amount) {
      if (!bucket.method_7960() && handler != null) {
         class_1799 copy = bucket.method_46651(1);
         ContainerItemContext context = ContainerItemContext.withConstant(copy);
         Storage<FluidVariant> itemStorage = (Storage<FluidVariant>)context.find(FluidStorage.ITEM);
         if (itemStorage == null) {
            return false;
         }

         long maxTransfer = toTransferAmount(amount);
         if (maxTransfer <= 0L) {
            return false;
         }

         FluidVariant resource = getFirstResource(itemStorage);
         if (resource.isBlank()) {
            return false;
         }

         Transaction transaction = Transaction.openOuter();

         boolean var25;
         label97: {
            boolean var26;
            label98: {
               boolean var19;
               label106: {
                  try {
                     long available = getFirstAmount(itemStorage);
                     long moveAmount = Math.min(maxTransfer, available);
                     if (moveAmount <= 0L) {
                        var25 = false;
                        break label97;
                     }

                     long inserted = handler.insert(resource, moveAmount, transaction);
                     if (inserted <= 0L) {
                        var26 = false;
                        break label98;
                     }

                     long extracted = itemStorage.extract(resource, inserted, transaction);
                     if (extracted != inserted) {
                        var19 = false;
                        break label106;
                     }

                     transaction.commit();
                  } catch (Throwable var21) {
                     if (transaction != null) {
                        try {
                           transaction.close();
                        } catch (Throwable var20) {
                           var21.addSuppressed(var20);
                        }
                     }

                     throw var21;
                  }

                  if (transaction != null) {
                     transaction.close();
                  }

                  ItemVariant resultVariant = context.getItemVariant();
                  class_1799 result = resultVariant.toStack((int)Math.min(2147483647L, context.getAmount()));
                  if (!(user instanceof class_1657 player && player.method_68878())) {
                     bucket.method_7934(1);
                  }

                  ItemUtils.getItemToLivingEntity(user, onConsumed(result));
                  class_3414 sound = FluidVariantAttributes.getEmptySound(resource);
                  if (sound != null) {
                     user.method_43077(sound);
                  }

                  return true;
               }

               if (transaction != null) {
                  transaction.close();
               }

               return var19;
            }

            if (transaction != null) {
               transaction.close();
            }

            return var26;
         }

         if (transaction != null) {
            transaction.close();
         }

         return var25;
      } else {
         return false;
      }
   }

   public static class_1799 onConsumed(class_1799 stack) {
      return isFluidContainer(stack) && !stack.method_31574(class_1802.field_8550) ? class_1802.field_8550.method_7854() : stack;
   }

   public static boolean fillItem(class_1309 user, class_1799 bucket, Storage<FluidVariant> handler, int amount) {
      if (!bucket.method_7960() && handler != null) {
         class_1799 copy = bucket.method_46651(1);
         ContainerItemContext context = ContainerItemContext.withConstant(copy);
         Storage<FluidVariant> itemStorage = (Storage<FluidVariant>)context.find(FluidStorage.ITEM);
         if (itemStorage == null) {
            return false;
         }

         long maxTransfer = toTransferAmount(amount);
         if (maxTransfer <= 0L) {
            return false;
         }

         FluidVariant resource = getFirstResource(handler);
         if (resource.isBlank()) {
            return false;
         }

         long available = getFirstAmount(handler);
         long moveAmount = Math.min(maxTransfer, available);
         if (moveAmount <= 0L) {
            return false;
         }

         Transaction transaction = Transaction.openOuter();

         boolean var24;
         label89: {
            boolean var19;
            label98: {
               try {
                  long inserted = itemStorage.insert(resource, moveAmount, transaction);
                  if (inserted <= 0L) {
                     var24 = false;
                     break label89;
                  }

                  long extracted = handler.extract(resource, inserted, transaction);
                  if (extracted != inserted) {
                     var19 = false;
                     break label98;
                  }

                  transaction.commit();
               } catch (Throwable var21) {
                  if (transaction != null) {
                     try {
                        transaction.close();
                     } catch (Throwable var20) {
                        var21.addSuppressed(var20);
                     }
                  }

                  throw var21;
               }

               if (transaction != null) {
                  transaction.close();
               }

               if (!(user instanceof class_1657 player && player.method_68878())) {
                  bucket.method_7934(1);
               }

               ItemUtils.getItemToLivingEntity(user, resource.getFluid().method_15774().method_7854());
               class_3414 sound = FluidVariantAttributes.getFillSound(resource);
               if (sound != null) {
                  user.method_43077(sound);
               }

               return true;
            }

            if (transaction != null) {
               transaction.close();
            }

            return var19;
         }

         if (transaction != null) {
            transaction.close();
         }

         return var24;
      } else {
         return false;
      }
   }

   public static boolean isFluidContainer(class_1799 stack) {
      if (stack.method_7960()) {
         return false;
      }

      ContainerItemContext context = ContainerItemContext.withConstant(stack);
      return context.find(FluidStorage.ITEM) != null;
   }

   private static long toTransferAmount(int milliBuckets) {
      return milliBuckets <= 0 ? 0L : milliBuckets * 81000L / 1000L;
   }

   private static FluidVariant getFirstResource(Storage<FluidVariant> storage) {
      for (StorageView<FluidVariant> view : storage) {
         if (!view.isResourceBlank() && view.getAmount() > 0L) {
            return (FluidVariant)view.getResource();
         }
      }

      return FluidVariant.blank();
   }

   private static long getFirstAmount(Storage<FluidVariant> storage) {
      for (StorageView<FluidVariant> view : storage) {
         if (!view.isResourceBlank() && view.getAmount() > 0L) {
            return view.getAmount();
         }
      }

      return 0L;
   }
}
