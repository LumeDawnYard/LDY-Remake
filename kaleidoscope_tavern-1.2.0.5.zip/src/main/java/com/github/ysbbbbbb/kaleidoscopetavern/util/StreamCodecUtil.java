package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.mojang.datafixers.util.Function9;
import java.util.function.Function;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public interface StreamCodecUtil {
   static <B, C, T1, T2, T3, T4, T5, T6, T7, T8, T9> class_9139<B, C> composite(
      class_9139<? super B, T1> codec1,
      Function<C, T1> getter1,
      class_9139<? super B, T2> codec2,
      Function<C, T2> getter2,
      class_9139<? super B, T3> codec3,
      Function<C, T3> getter3,
      class_9139<? super B, T4> codec4,
      Function<C, T4> getter4,
      class_9139<? super B, T5> codec5,
      Function<C, T5> getter5,
      class_9139<? super B, T6> codec6,
      Function<C, T6> getter6,
      class_9139<? super B, T7> codec7,
      Function<C, T7> getter7,
      class_9139<? super B, T8> codec8,
      Function<C, T8> getter8,
      class_9139<? super B, T9> codec9,
      Function<C, T9> getter9,
      Function9<T1, T2, T3, T4, T5, T6, T7, T8, T9, C> factory
   ) {
      return new class_9139<B, C>() {
         @NotNull
         public C decode(B buf) {
            T1 v1 = (T1)codec1.decode(buf);
            T2 v2 = (T2)codec2.decode(buf);
            T3 v3 = (T3)codec3.decode(buf);
            T4 v4 = (T4)codec4.decode(buf);
            T5 v5 = (T5)codec5.decode(buf);
            T6 v6 = (T6)codec6.decode(buf);
            T7 v7 = (T7)codec7.decode(buf);
            T8 v8 = (T8)codec8.decode(buf);
            T9 v9 = (T9)codec9.decode(buf);
            return (C)factory.apply(v1, v2, v3, v4, v5, v6, v7, v8, v9);
         }

         public void encode(B buf, C value) {
            codec1.encode(buf, getter1.apply(value));
            codec2.encode(buf, getter2.apply(value));
            codec3.encode(buf, getter3.apply(value));
            codec4.encode(buf, getter4.apply(value));
            codec5.encode(buf, getter5.apply(value));
            codec6.encode(buf, getter6.apply(value));
            codec7.encode(buf, getter7.apply(value));
            codec8.encode(buf, getter8.apply(value));
            codec9.encode(buf, getter9.apply(value));
         }
      };
   }
}
