package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModDataComponents;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_5244;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;

public class SignatureCocktailBlockItem extends CocktailBlockItem {
   public SignatureCocktailBlockItem(class_2248 block) {
      super(block);
   }

   public SignatureCocktailBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties);
   }

   public static boolean hasEffects(class_1799 stack) {
      return stack.method_57826(ModDataComponents.SIGNATURE_COCKTAIL_EFFECTS);
   }

   public static List<DrinkEffectData.Entry> getEffects(class_1799 stack) {
      return (List<DrinkEffectData.Entry>)stack.method_58695(ModDataComponents.SIGNATURE_COCKTAIL_EFFECTS, List.of());
   }

   public static void setEffects(class_1799 stack, List<DrinkEffectData.Entry> effects) {
      stack.method_57379(ModDataComponents.SIGNATURE_COCKTAIL_EFFECTS, List.copyOf(effects));
   }

   public static int getColor(class_1799 stack) {
      return (Integer)stack.method_58695(ModDataComponents.SIGNATURE_COCKTAIL_COLOR, 5592575);
   }

   public static void setColor(class_1799 stack, int color) {
      stack.method_57379(ModDataComponents.SIGNATURE_COCKTAIL_COLOR, color);
   }

   @Override
   protected void addDrinkEffect(class_1799 drink, class_1937 level, class_1309 entity) {
      for (DrinkEffectData.Entry entry : getEffects(drink)) {
         if (!level.method_8608() && level.field_9229.method_43057() < entry.probability()) {
            class_1291 effect = (class_1291)entry.effect().comp_349();
            int amplifier = entry.amplifier();
            if (effect.method_5561()) {
               effect.method_5564((class_3218)level, entity, entity, entity, amplifier, 1.0);
            } else {
               int duration = entry.duration() * 20;
               class_1293 instance = new class_1293(entry.effect(), duration, amplifier);
               entity.method_6092(instance);
            }
         }
      }
   }

   @Override
   public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 flag) {
      List<DrinkEffectData.Entry> effects = getEffects(stack);
      List<class_1293> effectsShow = Lists.newArrayList();

      for (DrinkEffectData.Entry entry : effects) {
         if (entry.probability() >= 1.0F) {
            int duration = entry.duration() * 20;
            int amplifier = entry.amplifier();
            effectsShow.add(new class_1293(entry.effect(), duration, amplifier));
         }
      }

      if (!effectsShow.isEmpty()) {
         consumer.accept(class_5244.method_48320());
         class_1844.method_8065(effectsShow, consumer, 1.0F, context.method_59531());
      }
   }
}
