package com.github.ysbbbbbb.kaleidoscopetavern.network.message;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.item.ShakerItem;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.Context;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.class_8710.class_9154;
import org.jetbrains.annotations.NotNull;

public record ClearShakerC2SMessage() implements class_8710 {
   public static final class_9154<ClearShakerC2SMessage> TYPE = new class_9154(class_2960.method_60655("kaleidoscope_tavern", "clear_shaker"));
   public static final class_9139<class_2540, ClearShakerC2SMessage> STREAM_CODEC = class_9139.method_56431(new ClearShakerC2SMessage());

   public static void receive(ClearShakerC2SMessage message, Context context) {
      if (context.player() != null) {
         class_1799 stack = context.player().method_6047();
         if (stack.method_31574(ModItems.SHAKER) && ShakerItem.hasStorage(stack)) {
            ShakerItem.removeAll(stack);
            context.player().method_51469().method_45447(null, context.player().method_24515(), class_3417.field_14779, class_3419.field_15248);
         }
      }
   }

   @NotNull
   public class_9154<? extends class_8710> method_56479() {
      return TYPE;
   }
}
