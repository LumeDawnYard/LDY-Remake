package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11954;
import net.minecraft.class_1767;

@Environment(EnvType.CLIENT)
public class BarStoolBlockEntityRenderState extends class_11954 {
   public float cachedRot;
   public class_1767 color;
   public float partialTicks;
}
