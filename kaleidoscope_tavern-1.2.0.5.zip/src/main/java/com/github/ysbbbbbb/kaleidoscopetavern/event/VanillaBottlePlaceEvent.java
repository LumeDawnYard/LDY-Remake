package com.github.ysbbbbbb.kaleidoscopetavern.event;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PotionBottleBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.config.GeneralConfig;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_9334;

public class VanillaBottlePlaceEvent {
   public static void register() {
      UseBlockCallback.EVENT.register(VanillaBottlePlaceEvent::onRightClickBlock);
   }

   private static class_1269 onRightClickBlock(class_1657 player, class_1937 level, class_1268 interactionHand, class_3965 blockHitResult) {
      if (!player.method_5715()) {
         return class_1269.field_5811;
      }

      class_1799 stack = player.method_5998(interactionHand);
      VanillaBottlePlaceEvent.Placement placement = getPlacement(stack);
      if (placement != null && placement.enabled()) {
         class_1750 context = new class_1750(player, interactionHand, stack, blockHitResult);
         if (!context.method_7716()) {
            return class_1269.field_5811;
         }

         class_2680 state = placement.block().method_9605(context);
         if (state == null) {
            return class_1269.field_5811;
         }

         class_2338 placePos = context.method_8037();
         if (!state.method_26184(level, placePos)) {
            return class_1269.field_5811;
         }

         if (level.method_8608()) {
            return class_1269.field_5812;
         }

         if (!level.method_8652(placePos, state, 3)) {
            return class_1269.field_21466;
         }

         if (placement.storePotionStack() && level.method_8321(placePos) instanceof PotionBottleBlockEntity be) {
            be.setPotionStack(stack);
         }

         level.method_8396(null, placePos, class_3417.field_14843, class_3419.field_15245, 1.0F, 1.0F);
         if (!player.method_31549().field_7477) {
            stack.method_7934(1);
         }

         return class_1269.field_21466;
      } else {
         return class_1269.field_5811;
      }
   }

   private static VanillaBottlePlaceEvent.Placement getPlacement(class_1799 stack) {
      if (stack.method_31574(class_1802.field_8574)) {
         class_1844 potion = (class_1844)stack.method_58694(class_9334.field_49651);
         return potion != null && !potion.method_57401(class_1847.field_8991)
            ? new VanillaBottlePlaceEvent.Placement(ModBlocks.POTION_BOTTLE, (Boolean)GeneralConfig.POTION_BOTTLE_PLACEMENT.get(), true)
            : new VanillaBottlePlaceEvent.Placement(ModBlocks.WATER_BOTTLE, (Boolean)GeneralConfig.WATER_BOTTLE_PLACEMENT.get(), false);
      } else if (stack.method_31574(class_1802.field_20417)) {
         return new VanillaBottlePlaceEvent.Placement(ModBlocks.HONEY_BOTTLE, (Boolean)GeneralConfig.HONEY_BOTTLE_PLACEMENT.get(), false);
      } else if (stack.method_31574(class_1802.field_8613)) {
         return new VanillaBottlePlaceEvent.Placement(ModBlocks.DRAGON_BREATH_BOTTLE, (Boolean)GeneralConfig.DRAGON_BREATH_BOTTLE_PLACEMENT.get(), false);
      } else {
         return stack.method_31574(class_1802.field_8287)
            ? new VanillaBottlePlaceEvent.Placement(ModBlocks.XP_BOTTLE, (Boolean)GeneralConfig.EXPERIENCE_BOTTLE_PLACEMENT.get(), false)
            : null;
      }
   }

   private record Placement(class_2248 block, boolean enabled, boolean storePotionStack) {
   }
}
