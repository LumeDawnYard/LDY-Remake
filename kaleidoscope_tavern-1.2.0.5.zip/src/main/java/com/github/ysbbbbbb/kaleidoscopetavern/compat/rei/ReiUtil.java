package com.github.ysbbbbbb.kaleidoscopetavern.compat.rei;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.fabricmc.fabric.api.recipe.v1.sync.SynchronizedRecipes;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_638;
import net.minecraft.class_8786;

public enum ReiUtil {
   INSTANCE;

   private final SynchronizedRecipes synchronizedRecipes;

   ReiUtil() {
      class_310 minecraft = class_310.method_1551();
      class_638 level = minecraft.field_1687;
      if (level != null) {
         this.synchronizedRecipes = level.method_8433().getSynchronizedRecipes();
      } else {
         throw new NullPointerException("minecraft world must not be null.");
      }
   }

   public List<class_8786<BarrelRecipe>> barrelRecipes() {
      return List.copyOf(this.synchronizedRecipes.getAllOfType(ModRecipes.BARREL_RECIPE));
   }

   public List<class_8786<PressingTubRecipe>> pressingTubRecipes() {
      return List.copyOf(this.synchronizedRecipes.getAllOfType(ModRecipes.PRESSING_TUB_RECIPE));
   }

   public static EntryIngredient ofIngredient(class_1856 ingredient) {
      return EntryIngredient.of(ingredient.method_8105().map(r -> EntryStacks.of((class_1935)r.comp_349())).toList());
   }

   public static EntryIngredient ofIngredient(class_1856 ingredient, int count) {
      return EntryIngredient.of(ingredient.method_8105().map(s -> EntryStacks.of(((class_1792)s.comp_349()).method_7854().method_46651(count))).toList());
   }

   public static List<EntryIngredient> ofIngredients(List<class_1856> ingredients, class_3611 base) {
      if (ingredients.size() == 0) {
         return ImmutableList.of(ofItem(base.method_15774(), 4));
      }

      List<EntryIngredient> result = new ArrayList<>(ingredients.size() + 1);
      result.addFirst(ofItemStack(new class_1799(base.method_15774(), 4)));

      for (int i = 0; i < ingredients.size(); i++) {
         class_1856 ingredient = ingredients.get(i);
         EntryIngredient entryIngredient = ofIngredient(ingredient, 16);
         if (!entryIngredient.isEmpty()) {
            result.add(entryIngredient);
         }
      }

      return ImmutableList.copyOf(result);
   }

   public static EntryIngredient ofItem(class_1792 item) {
      return EntryIngredient.of(EntryStacks.of(item));
   }

   public static EntryIngredient ofItem(class_1792 item, int count) {
      return EntryIngredient.of(EntryStacks.of(new class_1799(item, count)));
   }

   public static EntryIngredient ofItemStack(class_1799 itemStack) {
      return EntryIngredient.of(EntryStacks.of(itemStack));
   }

   public static List<EntryIngredient> ofItems(class_1792... items) {
      return Arrays.stream(items).map(ReiUtil::ofItem).toList();
   }

   public static List<EntryIngredient> ofItemStacks(class_1799... items) {
      return Arrays.stream(items).map(ReiUtil::ofItemStack).toList();
   }

   public static List<EntryIngredient> ofItems(List<class_1792> items) {
      return items.stream().map(ReiUtil::ofItem).toList();
   }

   public static List<EntryIngredient> ofIngredients(class_1856... ingredients) {
      return Arrays.stream(ingredients).map(ReiUtil::ofIngredient).toList();
   }
}
