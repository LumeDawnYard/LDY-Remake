package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.utils;

import com.zurrtum.create.client.ponder.api.scene.SceneBuilder;
import com.zurrtum.create.client.ponder.api.scene.SceneBuildingUtil;
import com.zurrtum.create.client.ponder.api.scene.Selection;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class PonderBlockWrapper {
   protected final SceneBuilder scene;
   protected final SceneBuildingUtil util;
   protected final Selection selection;
   public final class_2338 pos;

   public PonderBlockWrapper(class_2338 pos, SceneBuilder scene, SceneBuildingUtil util) {
      this.scene = scene;
      this.util = util;
      this.pos = pos;
      this.selection = util.select().position(pos);
   }

   public PonderBlockWrapper(int x, int y, int z, SceneBuilder scene, SceneBuildingUtil util) {
      this(util.grid().at(x, y, z), scene, util);
   }

   public Selection selection() {
      return this.selection;
   }

   public class_243 blockSurface(class_2350 face) {
      return this.util.vector().blockSurface(this.pos, face);
   }

   public void setBlock(class_2680 blockState, boolean spawnParticles) {
      this.scene.world().setBlock(this.pos, blockState, spawnParticles);
   }

   public void modifyBlock(UnaryOperator<class_2680> stateFunc, boolean spawnParticles) {
      this.scene.world().modifyBlock(this.pos, stateFunc, spawnParticles);
   }

   public <T extends class_2586> void modifyBlockEntity(Class<T> beType, Consumer<T> consumer) {
      this.scene.world().modifyBlockEntity(this.pos, beType, consumer);
   }

   public void showSection(class_2350 direction) {
      this.scene.world().showSection(this.selection(), direction);
   }

   public void hideSection(class_2350 direction) {
      this.scene.world().hideSection(this.selection(), direction);
   }
}
