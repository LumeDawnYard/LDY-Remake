package com.github.ysbbbbbb.kaleidoscopetavern.client.render.misc;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.SignatureCocktailBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.item.SignatureCocktailBlockItem;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10401;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public class SignatureCocktailColor {
   private static final int OPAQUE_MASK = -33554432;

   private static int opaque(int color) {
      return -33554432 | color & 16777215;
   }

   public static class Block implements class_322 {
      public int getColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int tintIndex) {
         if (tintIndex == 0 && level != null && pos != null) {
            return level.method_8321(pos) instanceof SignatureCocktailBlockEntity be
               ? SignatureCocktailColor.opaque(be.getColor())
               : SignatureCocktailColor.opaque(16777215);
         } else {
            return SignatureCocktailColor.opaque(16777215);
         }
      }
   }

   public static class Item implements class_10401 {
      public int method_65389(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity) {
         return SignatureCocktailColor.opaque(SignatureCocktailBlockItem.getColor(stack));
      }

      public MapCodec<? extends class_10401> method_65387() {
         return MapCodec.unit(this);
      }
   }
}
