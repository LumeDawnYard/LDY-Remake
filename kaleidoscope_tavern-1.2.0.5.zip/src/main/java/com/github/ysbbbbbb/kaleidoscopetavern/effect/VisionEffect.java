package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModSounds;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import org.jspecify.annotations.NonNull;

public class VisionEffect extends BaseEffect {
   public VisionEffect(int color) {
      super(color);
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return duration % 50 == 0;
   }

   @Override
   public boolean method_5572(@NonNull class_3218 serverLevel, class_1309 living, int amplifier) {
      class_1937 level = living.method_73183();
      double radius = Math.min(amplifier + 1, 3) * 6;
      class_238 range = living.method_5829().method_1014(radius);
      Predicate<class_1309> filter = entityx -> entityx != living && entityx.method_5805();
      List<class_1309> entities = level.method_8390(class_1309.class, range, filter);
      if (entities.isEmpty()) {
         return true;
      }

      boolean apply = false;

      for (class_1309 entity : entities) {
         if (!entity.method_6059(class_1294.field_5912)) {
            apply = true;
         }

         entity.method_6092(new class_1293(class_1294.field_5912, 60));
      }

      if (apply) {
         living.method_43077(ModSounds.EFFECT_VISION);
      }

      return true;
   }
}
