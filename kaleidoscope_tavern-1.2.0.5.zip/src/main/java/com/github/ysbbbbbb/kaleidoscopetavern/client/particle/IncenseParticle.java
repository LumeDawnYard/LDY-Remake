package com.github.ysbbbbbb.kaleidoscopetavern.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_707;
import net.minecraft.class_3940.class_11941;
import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public class IncenseParticle extends class_3940 {
   protected final float baseAlpha;

   protected IncenseParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites) {
      super(level, x, y, z, sprites.method_18139(level.field_9229));
      this.field_3852 = xSpeed;
      this.field_3869 = ySpeed;
      this.field_3850 = zSpeed;
      this.field_3847 = 40 + level.field_9229.method_43048(20);
      this.field_3844 = -0.002F;
      this.field_17867 = 0.15F + level.field_9229.method_43057() * 0.05F;
      this.baseAlpha = 0.8F;
      this.field_62636 = this.baseAlpha;
      this.field_3862 = false;
   }

   @NotNull
   public class_11941 method_74255() {
      return class_11941.field_62641;
   }

   public void method_3070() {
      this.field_3858 = this.field_3874;
      this.field_3838 = this.field_3854;
      this.field_3856 = this.field_3871;
      if (this.field_3866++ >= this.field_3847) {
         this.method_3085();
      } else {
         this.field_3852 = this.field_3852 + (this.field_3840.method_43058() - 0.5) * 0.001;
         this.field_3850 = this.field_3850 + (this.field_3840.method_43058() - 0.5) * 0.001;
         float progress = (float)this.field_3866 / this.field_3847;
         if (progress > 0.75F) {
            this.field_62636 = this.baseAlpha * (1.0F - (progress - 0.75F) * 4.0F);
         }

         this.method_3069(this.field_3852, this.field_3869, this.field_3850);
         this.field_3852 *= 0.95;
         this.field_3850 *= 0.95;
      }
   }

   public static class Provider implements class_707<class_2400> {
      private final class_4002 sprites;

      public Provider(class_4002 sprites) {
         this.sprites = sprites;
      }

      public class_3940 createParticle(
         @NotNull class_2400 type,
         @NotNull class_638 level,
         double x,
         double y,
         double z,
         double xSpeed,
         double ySpeed,
         double zSpeed,
         @NotNull class_5819 randomSource
      ) {
         return new IncenseParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
      }
   }
}
