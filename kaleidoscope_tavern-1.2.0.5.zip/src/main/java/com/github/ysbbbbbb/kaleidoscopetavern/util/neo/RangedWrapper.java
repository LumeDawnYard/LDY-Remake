package com.github.ysbbbbbb.kaleidoscopetavern.util.neo;

import com.google.common.base.Preconditions;
import net.minecraft.class_1799;

public class RangedWrapper implements IItemHandler {
   private final IItemHandler compose;
   private final int minSlot;
   private final int maxSlot;

   public RangedWrapper(IItemHandler compose, int minSlot, int maxSlotExclusive) {
      Preconditions.checkArgument(maxSlotExclusive > minSlot, "Max slot must be greater than min slot");
      this.compose = compose;
      this.minSlot = minSlot;
      this.maxSlot = maxSlotExclusive;
   }

   @Override
   public int getSlots() {
      return this.maxSlot - this.minSlot;
   }

   @Override
   public class_1799 getStackInSlot(int slot) {
      return this.checkSlot(slot) ? this.compose.getStackInSlot(slot + this.minSlot) : class_1799.field_8037;
   }

   @Override
   public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
      return this.checkSlot(slot) ? this.compose.insertItem(slot + this.minSlot, stack, simulate) : stack;
   }

   @Override
   public class_1799 extractItem(int slot, int amount, boolean simulate) {
      return this.checkSlot(slot) ? this.compose.extractItem(slot + this.minSlot, amount, simulate) : class_1799.field_8037;
   }

   @Override
   public void setStackInSlot(int slot, class_1799 stack) {
      if (this.checkSlot(slot)) {
         this.compose.setStackInSlot(slot + this.minSlot, stack);
      }
   }

   @Override
   public int getSlotLimit(int slot) {
      return this.checkSlot(slot) ? this.compose.getSlotLimit(slot + this.minSlot) : 0;
   }

   @Override
   public boolean isItemValid(int slot, class_1799 stack) {
      return this.checkSlot(slot) && this.compose.isItemValid(slot + this.minSlot, stack);
   }

   private boolean checkSlot(int localSlot) {
      return localSlot + this.minSlot < this.maxSlot;
   }
}
