package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.SandwichBoardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.SandwichBoardBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_124;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_5614.class_5615;
import org.apache.commons.lang3.StringUtils;
import org.joml.Quaternionf;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public class SandwichBlockEntityRender extends TextBlockEntityRender<SandwichBoardBlockEntity, SandwichBoardBlockEntityRenderState> {
   private static final float TEXT_SCALE = 0.01F;
   private static final int LINE_HEIGHT = 10;
   private static final int MAX_LINES = 8;

   public SandwichBlockEntityRender(class_5615 context) {
      super(context);
   }

   protected void renderModel(
      SandwichBoardBlockEntityRenderState textBlockRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_2350 facing
   ) {
   }

   protected void renderText(SandwichBoardBlockEntityRenderState textBlockRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_2350 facing) {
      int rotation = textBlockRenderState.rotation;
      if (rotation < 0) {
         rotation = 0;
      }

      float angle = rotation * 22.5F + 180.0F;
      float radians = (float)Math.toRadians(angle);
      float xOffset = (float)(-Math.sin(radians) * 0.06F);
      float zOffset = (float)(Math.cos(radians) * 0.06F);
      float tiltAxisX = (float)(-Math.cos(radians));
      float tiltAxisZ = (float)(-Math.sin(radians));
      poseStack.method_22903();
      poseStack.method_22904(0.5 + xOffset, 1.06, 0.5 + zOffset);
      poseStack.method_22907(new Quaternionf().rotateAxis((float)Math.toRadians(22.5), tiltAxisX, 0.0F, tiltAxisZ));
      poseStack.method_22907(class_7833.field_40715.rotationDegrees(angle));
      int maxWidth = 55;
      if (StringUtils.isNotBlank(textBlockRenderState.text)) {
         this.doTextRender(textBlockRenderState, poseStack, textBlockRenderState.text, maxWidth, 0.01F, 8, 10, submitNodeCollector);
      }

      poseStack.method_22909();
   }

   @Override
   protected class_2561 getRenderText(String text) {
      return class_2561.method_43470(text).method_27692(class_124.field_1067);
   }

   public @NonNull SandwichBoardBlockEntityRenderState createRenderState() {
      return new SandwichBoardBlockEntityRenderState();
   }
}
