package com.github.ysbbbbbb.kaleidoscopetavern.event;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

public class EffectEvent {
   public static void register() {
      ServerLivingEntityEvents.ALLOW_DEATH.register(EffectEvent::onLivingDeath);
   }

   private static boolean onLivingDeath(class_1309 livingEntity, class_1282 damageSource, float v) {
      if (livingEntity.method_73183().method_8608()) {
         return true;
      } else if (!(damageSource.method_5529() instanceof class_1309 living && living.method_6059(ModEffects.BLOODY_MARY))) {
         return true;
      } else if (livingEntity == living) {
         return true;
      } else {
         int healAmount = (int)Math.floor(livingEntity.method_6063() / 3.0F);
         if (healAmount > 0) {
            living.method_6025(healAmount);
            return false;
         } else {
            return true;
         }
      }
   }
}
