package com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.ReiUtil;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.client.registry.display.DisplayRegistry;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;

public class ReiPressingTubRecipeCategory implements DisplayCategory<ReiPressingTubRecipeCategory.PressingTubRecipeDisplay> {
   public static final CategoryIdentifier<ReiPressingTubRecipeCategory.PressingTubRecipeDisplay> ID = CategoryIdentifier.of(
      "kaleidoscope_tavern", "plugin/pressing_tub"
   );
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.pressing_tub");
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/pressing_tub.png");
   public static final int WIDTH = 155;
   public static final int HEIGHT = 54;

   public CategoryIdentifier<? extends ReiPressingTubRecipeCategory.PressingTubRecipeDisplay> getCategoryIdentifier() {
      return ID;
   }

   public List<Widget> setupDisplay(ReiPressingTubRecipeCategory.PressingTubRecipeDisplay display, Rectangle bounds) {
      List<Widget> widgets = new ArrayList<>();
      int startX = bounds.x;
      int startY = bounds.y;
      widgets.add(Widgets.createRecipeBase(bounds));
      widgets.add(Widgets.createTexturedWidget(BG, startX, startY, 0.0F, 0.0F, 155, 54));
      widgets.add(
         Widgets.createSlot(new Point(startX + 32, startY + 13)).entries((Collection)display.getInputEntries().getFirst()).disableBackground().markInput()
      );
      widgets.add(
         Widgets.createSlot(new Point(startX + 128, startY + 18)).entries((Collection)display.getOutputEntries().getFirst()).disableBackground().markOutput()
      );
      int needPressCount = display.needPressCount;
      class_2561 tip = class_2561.method_43469("jei.kaleidoscope_tavern.pressing_tub.need_press_count", new Object[]{needPressCount});
      widgets.add(
         Widgets.withTranslate(Widgets.createDrawableWidget((guiGraphics, mouseX, mouseY, v) -> this.drawCenteredString(guiGraphics, tip)), startX, startY)
      );
      return widgets;
   }

   private void drawCenteredString(class_332 guiGraphics, class_2561 text) {
      class_327 font = class_310.method_1551().field_1772;
      class_5481 sequence = text.method_30937();
      guiGraphics.method_51430(font, sequence, 155 - font.method_30880(sequence) - 5, 42, 5592405, false);
   }

   public int getDisplayWidth(ReiPressingTubRecipeCategory.PressingTubRecipeDisplay display) {
      return 155;
   }

   public int getDisplayHeight() {
      return 54;
   }

   public class_2561 getTitle() {
      return TITLE;
   }

   public Renderer getIcon() {
      return EntryStacks.of(ModItems.PRESSING_TUB);
   }

   public static void registerCategories(CategoryRegistry registry) {
      registry.add(new ReiPressingTubRecipeCategory());
      registry.addWorkstations(ID, new EntryIngredient[]{ReiUtil.ofItem(ModItems.PRESSING_TUB)});
   }

   @Deprecated
   public static void registerDisplays(DisplayRegistry registry) {
      ReiUtil.INSTANCE
         .pressingTubRecipes()
         .forEach(
            holder -> {
               PressingTubRecipe recipe = (PressingTubRecipe)holder.comp_1933();
               int needPressCount = 1000 / recipe.getFluidAmount();
               if (needPressCount * recipe.getFluidAmount() < 1000) {
                  needPressCount++;
               }

               int finalNeedPressCount = needPressCount;
               class_1856 inputs = recipe.getIngredient();
               EntryIngredient entryStacks = ReiUtil.ofIngredient(inputs, finalNeedPressCount);
               List<EntryIngredient> outputs = List.of(ReiUtil.ofItem(recipe.getFluid().method_15774()));
               registry.add(
                  new ReiPressingTubRecipeCategory.PressingTubRecipeDisplay(
                     holder.comp_1932().method_29177(),
                     Collections.singletonList(entryStacks),
                     outputs,
                     1000 / ((PressingTubRecipe)holder.comp_1933()).getFluidAmount()
                  )
               );
            }
         );
   }

   public static class PressingTubRecipeDisplay extends BasicDisplay {
      public final int needPressCount;
      public static final DisplaySerializer<ReiPressingTubRecipeCategory.PressingTubRecipeDisplay> SERIALIZER = DisplaySerializer.of(
         RecordCodecBuilder.mapCodec(
            instance -> instance.group(
                  class_2960.field_25139.fieldOf("location").forGetter(r -> r.getDisplayLocation().orElse(class_2960.method_60656("air"))),
                  EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(BasicDisplay::getInputEntries),
                  EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(BasicDisplay::getOutputEntries),
                  Codec.INT.fieldOf("needPressCount").forGetter(ReiPressingTubRecipeCategory.PressingTubRecipeDisplay::getNeedPressCount)
               )
               .apply(instance, ReiPressingTubRecipeCategory.PressingTubRecipeDisplay::new)
         ),
         class_9139.method_56905(
            class_2960.field_48267,
            r -> r.getDisplayLocation().orElse(class_2960.method_60656("air")),
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getInputEntries,
            EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
            BasicDisplay::getOutputEntries,
            class_9135.field_49675,
            i -> i.needPressCount,
            ReiPressingTubRecipeCategory.PressingTubRecipeDisplay::new
         )
      );

      public PressingTubRecipeDisplay(class_2960 location, List<EntryIngredient> inputs, List<EntryIngredient> outputs, int needPressCount) {
         super(inputs, outputs, Optional.of(location));
         this.needPressCount = needPressCount;
      }

      public int getNeedPressCount() {
         return this.needPressCount;
      }

      public PressingTubRecipeDisplay(class_8786<PressingTubRecipe> holder) {
         this(
            holder.comp_1932().method_29177(),
            List.of(
               ReiUtil.ofIngredient(((PressingTubRecipe)holder.comp_1933()).getIngredient(), 1000 / ((PressingTubRecipe)holder.comp_1933()).getFluidAmount())
            ),
            List.of(ReiUtil.ofItem(((PressingTubRecipe)holder.comp_1933()).getFluid().method_15774())),
            1000 / ((PressingTubRecipe)holder.comp_1933()).getFluidAmount()
         );
      }

      public CategoryIdentifier<?> getCategoryIdentifier() {
         return ReiPressingTubRecipeCategory.ID;
      }

      @Nullable
      public DisplaySerializer<? extends Display> getSerializer() {
         return SERIALIZER;
      }
   }
}
