package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2760;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class StepladderBlock extends class_2383 implements class_3737 {
   public static final MapCodec<StepladderBlock> CODEC = method_54094(StepladderBlock::new);
   public static final class_2754<class_2760> HALF = class_2741.field_12518;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 DOWN_SOUTH = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 12.0), class_2248.method_9541(0.0, 0.0, 12.0, 16.0, 8.0, 16.0)
   );
   public static final class_265 DOWN_NORTH = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 16.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 4.0)
   );
   public static final class_265 DOWN_EAST = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 12.0, 16.0, 16.0), class_2248.method_9541(12.0, 0.0, 0.0, 16.0, 8.0, 16.0)
   );
   public static final class_265 DOWN_WEST = class_259.method_1084(
      class_2248.method_9541(4.0, 0.0, 0.0, 16.0, 16.0, 16.0), class_2248.method_9541(0.0, 0.0, 0.0, 4.0, 8.0, 16.0)
   );
   public static final class_265 UP_SOUTH = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 4.0), class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 8.0, 8.0)
   );
   public static final class_265 UP_NORTH = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 12.0, 16.0, 16.0, 16.0), class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 8.0, 12.0)
   );
   public static final class_265 UP_EAST = class_259.method_1084(
      class_2248.method_9541(0.0, 0.0, 0.0, 4.0, 16.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 8.0, 8.0, 16.0)
   );
   public static final class_265 UP_WEST = class_259.method_1084(
      class_2248.method_9541(12.0, 0.0, 0.0, 16.0, 16.0, 16.0), class_2248.method_9541(8.0, 0.0, 0.0, 12.0, 8.0, 16.0)
   );

   public StepladderBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
               .method_11657(HALF, class_2760.field_12617))
            .method_11657(WATERLOGGED, false)
      );
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      class_2760 half = (class_2760)blockState.method_11654(HALF);
      boolean isBottom = half == class_2760.field_12617 && direction == class_2350.field_11036;
      boolean isTop = half == class_2760.field_12619 && direction == class_2350.field_11033;
      if (direction.method_10166() == class_2351.field_11052 && (isBottom || isTop)) {
         return blockState2.method_27852(this) && blockState2.method_11654(HALF) != half
            ? (class_2680)blockState.method_11657(field_11177, (class_2350)blockState2.method_11654(field_11177))
            : class_2246.field_10124.method_9564();
      } else {
         return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
      }
   }

   @NotNull
   public class_2680 method_9576(class_1937 level, @NonNull class_2338 pos, @NonNull class_2680 state, @NonNull class_1657 player) {
      if (!level.method_8608() && player.method_68878() && state.method_11654(HALF) == class_2760.field_12619) {
         class_2338 below = pos.method_10074();
         class_2680 belowState = level.method_8320(below);
         if (belowState.method_27852(state.method_26204()) && belowState.method_11654(HALF) == class_2760.field_12617) {
            class_2680 airBlockState = belowState.method_26227().method_39360(class_3612.field_15910)
               ? class_2246.field_10382.method_9564()
               : class_2246.field_10124.method_9564();
            level.method_8652(below, airBlockState, 35);
            level.method_8444(player, 2001, below, class_2248.method_9507(belowState));
         }
      }

      return super.method_9576(level, pos, state, player);
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, HALF, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_1937 level = context.method_8045();
      return pos.method_10264() < level.method_31600() - 1 && level.method_8320(pos.method_10084()).method_26166(context)
         ? (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11177, context.method_8042().method_10153()))
               .method_11657(HALF, class_2760.field_12617))
            .method_11657(WATERLOGGED, level.method_22351(pos))
         : null;
   }

   public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, @NonNull class_1799 stack) {
      class_2338 above = pos.method_10084();
      class_2680 blockState = (class_2680)((class_2680)state.method_11657(HALF, class_2760.field_12619)).method_11657(WATERLOGGED, level.method_22351(above));
      level.method_8501(above, blockState);
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, @NonNull class_8568 lootParamsBuilder) {
      return state.method_11654(HALF) == class_2760.field_12617 ? super.method_9560(state, lootParamsBuilder) : Collections.emptyList();
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      class_2350 facing = (class_2350)state.method_11654(field_11177);
      class_2760 half = (class_2760)state.method_11654(HALF);

      return switch (half) {
         case field_12619 -> {
            switch (facing) {
               case field_11035:
                  yield UP_SOUTH;
               case field_11039:
                  yield UP_WEST;
               case field_11034:
                  yield UP_EAST;
               default:
                  yield UP_NORTH;
            }
         }
         case field_12617 -> {
            switch (facing) {
               case field_11035:
                  yield DOWN_SOUTH;
               case field_11039:
                  yield DOWN_WEST;
               case field_11034:
                  yield DOWN_EAST;
               default:
                  yield DOWN_NORTH;
            }
         }
         default -> throw new MatchException(null, null);
      };
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
