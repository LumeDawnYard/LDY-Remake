package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarCabinetBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarrelBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BottleBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.CellarCabinetBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.DrinkBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.MolotovBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.PotionBottleBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.PressingTubBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.TapBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.BarCounterBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.BarStoolBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.ChalkboardBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.CircularRackBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.GlasswareHolderBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.HolderBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.IncenseBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.PaintingBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.PendantLampBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.SandwichBoardBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.SofaBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.StepladderBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.StringLightsBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.TableBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.deco.TiltedRackBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.CocktailBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.GlasswareBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.MysteryCocktailBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.ShakerBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.mixology.SignatureCocktailBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.GrapeCropBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.GrapevineTrellisBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.TrellisBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.WildGrapevineBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.plant.WildGrapevinePlantBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.CellarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.DrinkBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PotionBottleBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.TapBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.BarStoolBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.ChalkboardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.CircularRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.GlasswareHolderBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.HolderBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.IncenseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.SandwichBoardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TiltedRackBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.ShakerBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology.SignatureCocktailBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import java.util.function.Function;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_4970.class_2251;

public final class ModBlocks {
   public static final class_2248 WHITE_SOFA = registerBlock("white_sofa", SofaBlock::new);
   public static final class_2248 LIGHT_GRAY_SOFA = registerBlock("light_gray_sofa", SofaBlock::new);
   public static final class_2248 GRAY_SOFA = registerBlock("gray_sofa", SofaBlock::new);
   public static final class_2248 BLACK_SOFA = registerBlock("black_sofa", SofaBlock::new);
   public static final class_2248 BROWN_SOFA = registerBlock("brown_sofa", SofaBlock::new);
   public static final class_2248 RED_SOFA = registerBlock("red_sofa", SofaBlock::new);
   public static final class_2248 ORANGE_SOFA = registerBlock("orange_sofa", SofaBlock::new);
   public static final class_2248 YELLOW_SOFA = registerBlock("yellow_sofa", SofaBlock::new);
   public static final class_2248 LIME_SOFA = registerBlock("lime_sofa", SofaBlock::new);
   public static final class_2248 GREEN_SOFA = registerBlock("green_sofa", SofaBlock::new);
   public static final class_2248 CYAN_SOFA = registerBlock("cyan_sofa", SofaBlock::new);
   public static final class_2248 LIGHT_BLUE_SOFA = registerBlock("light_blue_sofa", SofaBlock::new);
   public static final class_2248 BLUE_SOFA = registerBlock("blue_sofa", SofaBlock::new);
   public static final class_2248 PURPLE_SOFA = registerBlock("purple_sofa", SofaBlock::new);
   public static final class_2248 MAGENTA_SOFA = registerBlock("magenta_sofa", SofaBlock::new);
   public static final class_2248 PINK_SOFA = registerBlock("pink_sofa", SofaBlock::new);
   public static final class_2248 WHITE_BAR_STOOL = registerBlock("white_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7952));
   public static final class_2248 LIGHT_GRAY_BAR_STOOL = registerBlock("light_gray_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7967));
   public static final class_2248 GRAY_BAR_STOOL = registerBlock("gray_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7944));
   public static final class_2248 BLACK_BAR_STOOL = registerBlock("black_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7963));
   public static final class_2248 BROWN_BAR_STOOL = registerBlock("brown_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7957));
   public static final class_2248 RED_BAR_STOOL = registerBlock("red_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7964));
   public static final class_2248 ORANGE_BAR_STOOL = registerBlock("orange_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7946));
   public static final class_2248 YELLOW_BAR_STOOL = registerBlock("yellow_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7947));
   public static final class_2248 LIME_BAR_STOOL = registerBlock("lime_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7961));
   public static final class_2248 GREEN_BAR_STOOL = registerBlock("green_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7942));
   public static final class_2248 CYAN_BAR_STOOL = registerBlock("cyan_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7955));
   public static final class_2248 LIGHT_BLUE_BAR_STOOL = registerBlock("light_blue_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7951));
   public static final class_2248 BLUE_BAR_STOOL = registerBlock("blue_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7966));
   public static final class_2248 PURPLE_BAR_STOOL = registerBlock("purple_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7945));
   public static final class_2248 MAGENTA_BAR_STOOL = registerBlock("magenta_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7958));
   public static final class_2248 PINK_BAR_STOOL = registerBlock("pink_bar_stool", p -> new BarStoolBlock(p, class_1767.field_7954));
   public static final class_2248 BASE_SANDWICH_BOARD = registerBlock("base_sandwich_board", p -> new SandwichBoardBlock(p));
   public static final class_2248 GRASS_SANDWICH_BOARD = registerBlock("grass_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_8602));
   public static final class_2248 ALLIUM_SANDWICH_BOARD = registerBlock(
      "allium_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17500, class_1802.field_17501, class_1802.field_17512, class_1802.field_17514)
   );
   public static final class_2248 AZURE_BLUET_SANDWICH_BOARD = registerBlock(
      "azure_bluet_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17501, class_1802.field_17512, class_1802.field_17514)
   );
   public static final class_2248 CORNFLOWER_SANDWICH_BOARD = registerBlock("cornflower_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17513));
   public static final class_2248 ORCHID_SANDWICH_BOARD = registerBlock("orchid_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17499));
   public static final class_2248 PEONY_SANDWICH_BOARD = registerBlock(
      "peony_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17529, class_1802.field_17526)
   );
   public static final class_2248 PINK_PETALS_SANDWICH_BOARD = registerBlock(
      "pink_petals_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_42696)
   );
   public static final class_2248 PITCHER_PLANT_SANDWICH_BOARD = registerBlock(
      "pitcher_plant_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_43192)
   );
   public static final class_2248 POPPY_SANDWICH_BOARD = registerBlock(
      "poppy_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_8880, class_1802.field_17527)
   );
   public static final class_2248 SUNFLOWER_SANDWICH_BOARD = registerBlock(
      "sunflower_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17525, class_1802.field_8491)
   );
   public static final class_2248 TORCHFLOWER_SANDWICH_BOARD = registerBlock(
      "torchflower_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_42695)
   );
   public static final class_2248 TULIP_SANDWICH_BOARD = registerBlock(
      "tulip_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17502, class_1802.field_17509, class_1802.field_17510, class_1802.field_17511)
   );
   public static final class_2248 WITHER_ROSE_SANDWICH_BOARD = registerBlock(
      "wither_rose_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_17515)
   );
   public static final class_2248 EYEBLOSSOM_SANDWICH_BOARD = registerBlock(
      "eyeblossom_sandwich_board", p -> new SandwichBoardBlock(p, class_1802.field_55035, class_1802.field_55036)
   );
   public static final class_2248 STRING_LIGHTS_COLORLESS = registerBlock("string_lights_colorless", p -> new StringLightsBlock(p, null));
   public static final class_2248 STRING_LIGHTS_WHITE = registerBlock("string_lights_white", p -> new StringLightsBlock(p, class_1802.field_8446));
   public static final class_2248 STRING_LIGHTS_LIGHT_GRAY = registerBlock("string_lights_light_gray", p -> new StringLightsBlock(p, class_1802.field_8851));
   public static final class_2248 STRING_LIGHTS_GRAY = registerBlock("string_lights_gray", p -> new StringLightsBlock(p, class_1802.field_8298));
   public static final class_2248 STRING_LIGHTS_BLACK = registerBlock("string_lights_black", p -> new StringLightsBlock(p, class_1802.field_8226));
   public static final class_2248 STRING_LIGHTS_BROWN = registerBlock("string_lights_brown", p -> new StringLightsBlock(p, class_1802.field_8099));
   public static final class_2248 STRING_LIGHTS_RED = registerBlock("string_lights_red", p -> new StringLightsBlock(p, class_1802.field_8264));
   public static final class_2248 STRING_LIGHTS_ORANGE = registerBlock("string_lights_orange", p -> new StringLightsBlock(p, class_1802.field_8492));
   public static final class_2248 STRING_LIGHTS_YELLOW = registerBlock("string_lights_yellow", p -> new StringLightsBlock(p, class_1802.field_8192));
   public static final class_2248 STRING_LIGHTS_LIME = registerBlock("string_lights_lime", p -> new StringLightsBlock(p, class_1802.field_8131));
   public static final class_2248 STRING_LIGHTS_GREEN = registerBlock("string_lights_green", p -> new StringLightsBlock(p, class_1802.field_8408));
   public static final class_2248 STRING_LIGHTS_CYAN = registerBlock("string_lights_cyan", p -> new StringLightsBlock(p, class_1802.field_8632));
   public static final class_2248 STRING_LIGHTS_LIGHT_BLUE = registerBlock("string_lights_light_blue", p -> new StringLightsBlock(p, class_1802.field_8273));
   public static final class_2248 STRING_LIGHTS_BLUE = registerBlock("string_lights_blue", p -> new StringLightsBlock(p, class_1802.field_8345));
   public static final class_2248 STRING_LIGHTS_PURPLE = registerBlock("string_lights_purple", p -> new StringLightsBlock(p, class_1802.field_8296));
   public static final class_2248 STRING_LIGHTS_MAGENTA = registerBlock("string_lights_magenta", p -> new StringLightsBlock(p, class_1802.field_8669));
   public static final class_2248 STRING_LIGHTS_PINK = registerBlock("string_lights_pink", p -> new StringLightsBlock(p, class_1802.field_8330));
   public static final class_2248 YSBB_PAINTING = registerBlock("ysbb_painting", PaintingBlock::new);
   public static final class_2248 TARTARIC_ACID_PAINTING = registerBlock("tartaric_acid_painting", PaintingBlock::new);
   public static final class_2248 CR019_PAINTING = registerBlock("cr019_painting", PaintingBlock::new);
   public static final class_2248 UNKNOWN_PAINTING = registerBlock("unknown_painting", PaintingBlock::new);
   public static final class_2248 MASTER_MARISA_PAINTING = registerBlock("master_marisa_painting", PaintingBlock::new);
   public static final class_2248 SON_OF_MAN_PAINTING = registerBlock("son_of_man_painting", PaintingBlock::new);
   public static final class_2248 DAVID_PAINTING = registerBlock("david_painting", PaintingBlock::new);
   public static final class_2248 GIRL_WITH_PEARL_EARRING_PAINTING = registerBlock("girl_with_pearl_earring_painting", PaintingBlock::new);
   public static final class_2248 STARRY_NIGHT_PAINTING = registerBlock("starry_night_painting", PaintingBlock::new);
   public static final class_2248 VAN_GOGH_SELF_PORTRAIT_PAINTING = registerBlock("van_gogh_self_portrait_painting", PaintingBlock::new);
   public static final class_2248 FATHER_PAINTING = registerBlock("father_painting", PaintingBlock::new);
   public static final class_2248 GREAT_WAVE_PAINTING = registerBlock("great_wave_painting", PaintingBlock::new);
   public static final class_2248 MONA_LISA_PAINTING = registerBlock("mona_lisa_painting", PaintingBlock::new);
   public static final class_2248 MONDRIAN_PAINTING = registerBlock("mondrian_painting", PaintingBlock::new);
   public static final class_2248 NIGHT_EPIPHANY_PAINTING = registerBlock("night_epiphany_painting", PaintingBlock::new);
   public static final class_2248 TABLE = registerBlock("table", TableBlock::new);
   public static final class_2248 PRESSING_TUB = registerBlock(
      "pressing_tub",
      p -> new PressingTubBlock(
         p.method_31710(class_3620.field_15996).method_51368(class_2766.field_12654).method_9632(0.8F).method_9626(class_2498.field_11547).method_50013()
      )
   );
   public static final class_2248 EMPTY_BOTTLE = registerBlock("empty_bottle", p -> new BottleBlock(p, false));
   public static final class_2248 EMPTY_GLASSWARE = registerBlock("empty_glassware", GlasswareBlock::new);
   public static final class_2248 GLASSWARE_HOLDER = registerBlock("glassware_holder", GlasswareHolderBlock::new);
   public static final class_2248 SIGNATURE_COCKTAIL = registerBlock("signature_cocktail", p -> new SignatureCocktailBlock(p));
   public static final class_2248 MYSTERY_COCKTAIL = registerBlock("mystery_cocktail", p -> new MysteryCocktailBlock(p));
   public static final class_2248 WHITE_LADY = registerBlock("white_lady", p -> new CocktailBlock(p));
   public static final class_2248 EMERALD = registerBlock("emerald", p -> new CocktailBlock(p));
   public static final class_2248 BRASS_HEART = registerBlock("brass_heart", p -> new CocktailBlock(p));
   public static final class_2248 GODFATHER = registerBlock("godfather", p -> new CocktailBlock(p));
   public static final class_2248 GRASSHOPPER = registerBlock("grasshopper", p -> new CocktailBlock(p));
   public static final class_2248 SCREWDRIVER = registerBlock("screwdriver", p -> new CocktailBlock(p));
   public static final class_2248 MOJITO = registerBlock("mojito", p -> new CocktailBlock(p));
   public static final class_2248 ALLIUM_GARDEN = registerBlock("allium_garden", p -> new CocktailBlock(p));
   public static final class_2248 DEPTH_CHARGE = registerBlock("depth_charge", p -> new CocktailBlock(p));
   public static final class_2248 NETHER_SPECIAL = registerBlock("nether_special", p -> new CocktailBlock(p));
   public static final class_2248 BLOODY_MARY = registerBlock("bloody_mary", p -> new CocktailBlock(p));
   public static final class_2248 SCULK_SPECIAL = registerBlock("sculk_special", p -> new CocktailBlock(p));
   public static final class_2248 WATER_BOTTLE = registerBlock("water_bottle", p -> new BottleBlock(p, false));
   public static final class_2248 HONEY_BOTTLE = registerBlock("honey_bottle", p -> new BottleBlock(p, false));
   public static final class_2248 DRAGON_BREATH_BOTTLE = registerBlock("dragon_breath_bottle", p -> new BottleBlock(p, false));
   public static final class_2248 POTION_BOTTLE = registerBlock("potion_bottle", p -> new PotionBottleBlock(p));
   public static final class_2248 XP_BOTTLE = registerBlock("xp_bottle", p -> new BottleBlock(p, false));
   public static final class_2248 BARREL = registerBlock("barrel", BarrelBlock::new);
   public static final class_2248 BAR_CABINET = registerBlock("bar_cabinet", BarCabinetBlock::new);
   public static final class_2248 GLASS_BAR_CABINET = registerBlock("glass_bar_cabinet", BarCabinetBlock::new);
   public static final class_2248 CELLAR_CABINET = registerBlock("cellar_cabinet", CellarCabinetBlock::new);
   public static final class_2248 TILTED_RACK = registerBlock("tilted_rack", TiltedRackBlock::new);
   public static final class_2248 CIRCULAR_RACK = registerBlock("circular_rack", CircularRackBlock::new);
   public static final class_2248 HOLDER = registerBlock("holder", HolderBlock::new);
   public static final class_2248 SHAKER = registerBlock("shaker", ShakerBlock::new);
   public static final class_2248 WILD_GRAPEVINE = registerBlock("wild_grapevine", WildGrapevineBlock::new);
   public static final class_2248 WILD_GRAPEVINE_PLANT = registerBlock("wild_grapevine_plant", WildGrapevinePlantBlock::new);
   public static final class_2248 TRELLIS = registerBlock("trellis", TrellisBlock::new);
   public static final class_2248 GRAPE_CROP = registerBlock(
      "grape_crop", p -> new GrapeCropBlock(p, (state, level, pos, random) -> 0.25F, () -> new class_1799(ModItems.GRAPE, 3))
   );
   public static final class_2248 ICE_GRAPE_CROP = registerBlock(
      "ice_grape_crop",
      p -> new GrapeCropBlock(
         p,
         (state, level, pos, random) -> ((class_1959)level.method_23753(pos).comp_349()).method_8712() < 0.15F ? 0.8F : 0.25F,
         () -> new class_1799(ModItems.ICE_GRAPE, 3)
      )
   );
   public static final class_2248 GOLD_GRAPE_CROP = registerBlock(
      "gold_grape_crop",
      p -> new GrapeCropBlock(
         p,
         (state, level, pos, random) -> ((class_1959)level.method_23753(pos).comp_349()).method_8712() > 1.0F ? 0.8F : 0.25F,
         () -> new class_1799(ModItems.GOLD_GRAPE, 3)
      )
   );
   public static final class_2248 GRAPEVINE_TRELLIS = registerBlock(
      "grapevine_trellis", p -> new GrapevineTrellisBlock(p, (state, level, pos, random) -> 0.25F, GRAPE_CROP::method_9564)
   );
   public static final class_2248 ICE_GRAPEVINE_TRELLIS = registerBlock(
      "ice_grapevine_trellis",
      p -> new GrapevineTrellisBlock(
         p, (state, level, pos, random) -> ((class_1959)level.method_23753(pos).comp_349()).method_8712() < 0.15F ? 0.8F : 0.25F, ICE_GRAPE_CROP::method_9564
      )
   );
   public static final class_2248 GOLD_GRAPEVINE_TRELLIS = registerBlock(
      "gold_grapevine_trellis",
      p -> new GrapevineTrellisBlock(
         p, (state, level, pos, random) -> ((class_1959)level.method_23753(pos).comp_349()).method_8712() > 1.0F ? 0.8F : 0.25F, GOLD_GRAPE_CROP::method_9564
      )
   );
   public static final class_2248 MOLOTOV = registerBlock("molotov", MolotovBlock::new);
   public static final class_2248 TAP = registerBlock("tap", TapBlock::new);
   public static final class_2248 BAR_COUNTER = registerBlock("bar_counter", BarCounterBlock::new);
   public static final class_2248 STEPLADDER = registerBlock("stepladder", StepladderBlock::new);
   public static final class_2248 CHALKBOARD = registerBlock("chalkboard", ChalkboardBlock::new);
   public static final class_2248 BELL_PENDANT_LAMP = registerBlock("bell_pendant_lamp", PendantLampBlock::new);
   public static final class_2248 YELLOW_PENDANT_LAMP = registerBlock("yellow_pendant_lamp", PendantLampBlock::new);
   public static final class_2248 BLUE_PENDANT_LAMP = registerBlock("blue_pendant_lamp", PendantLampBlock::new);
   public static final class_2248 SAKURA_INCENSE = registerBlock(
      "sakura_incense", p -> new IncenseBlock(p, () -> ModParticles.SAKURA_INCENSE_PARTICLE, () -> class_2398.field_43379)
   );
   public static final class_2248 PINE_INCENSE = registerBlock(
      "pine_incense", p -> new IncenseBlock(p, () -> ModParticles.PINE_INCENSE_PARTICLE, () -> ModParticles.PINE_INCENSE_LARGE_PARTICLE)
   );
   public static final class_2248 GINKGO_INCENSE = registerBlock(
      "ginkgo_incense", p -> new IncenseBlock(p, () -> ModParticles.GINKGO_INCENSE_PARTICLE, () -> ModParticles.GINKGO_INCENSE_LARGE_PARTICLE)
   );
   public static final class_2248 SPORE_INCENSE = registerBlock(
      "spore_incense", p -> new IncenseBlock(p, () -> ModParticles.SPORE_INCENSE_PARTICLE, () -> class_2398.field_28803)
   );
   public static final class_2248 CATNIP_INCENSE = registerBlock(
      "catnip_incense", p -> new IncenseBlock(p, () -> ModParticles.CATNIP_INCENSE_PARTICLE, () -> ModParticles.CATNIP_INCENSE_LARGE_PARTICLE)
   );
   public static final class_2248 SNOW_INCENSE = registerBlock(
      "snow_incense", p -> new IncenseBlock(p, () -> ModParticles.SNOW_INCENSE_PARTICLE, () -> ModParticles.SNOW_INCENSE_LARGE_PARTICLE)
   );
   public static final class_2248 BUTTERFLY_INCENSE = registerBlock(
      "butterfly_incense", p -> new IncenseBlock(p, () -> ModParticles.BUTTERFLY_INCENSE_PARTICLE, () -> ModParticles.BUTTERFLY_INCENSE_LARGE_PARTICLE)
   );
   public static final class_2248 FIREFLY_INCENSE = registerBlock(
      "firefly_incense", p -> new IncenseBlock(p, () -> ModParticles.FIREFLY_INCENSE_PARTICLE, () -> ModParticles.FIREFLY_INCENSE_LARGE_PARTICLE, -0.67, 5.33)
   );
   public static final class_2248 WINE = registerBlock(
      "wine",
      p -> DrinkBlock.create()
         .setId("wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 CHAMPAGNE = registerBlock(
      "champagne",
      p -> DrinkBlock.create()
         .setId("champagne")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 VODKA = registerBlock(
      "vodka",
      p -> DrinkBlock.create()
         .setId("vodka")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .build()
   );
   public static final class_2248 BRANDY = registerBlock(
      "brandy",
      p -> DrinkBlock.create()
         .setId("brandy")
         .maxCount(3)
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .build()
   );
   public static final class_2248 CARIGNAN = registerBlock(
      "carignan",
      p -> DrinkBlock.create()
         .setId("carignan")
         .maxCount(3)
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .build()
   );
   public static final class_2248 SAKURA_WINE = registerBlock(
      "sakura_wine",
      p -> DrinkBlock.create()
         .setId("sakura_wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 PLUM_WINE = registerBlock(
      "plum_wine",
      p -> DrinkBlock.create()
         .setId("plum_wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 12.0, 10.0),
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 12.0, 10.0),
            class_259.method_1084(class_2248.method_9541(3.0, 0.0, 9.0, 13.0, 12.0, 13.0), class_2248.method_9541(6.0, 0.0, 3.0, 10.0, 12.0, 13.0)),
            class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 12.0, 13.0)
         )
         .build()
   );
   public static final class_2248 WHISKEY = registerBlock(
      "whiskey",
      p -> DrinkBlock.create()
         .setId("whiskey")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 ICE_WINE = registerBlock(
      "ice_wine",
      p -> DrinkBlock.create()
         .setId("ice_wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 POLARIS_SWEET_WHITE = registerBlock(
      "polaris_sweet_white",
      p -> DrinkBlock.create()
         .setId("polaris_sweet_white")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 HONEY_WINE = registerBlock(
      "honey_wine",
      p -> DrinkBlock.create()
         .setId("honey_wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 RED_QUEEN = registerBlock(
      "red_queen",
      p -> DrinkBlock.create()
         .setId("red_queen")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 MINERS_STAR = registerBlock(
      "miners_star",
      p -> DrinkBlock.create()
         .setId("miners_star")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 RUM = registerBlock(
      "rum",
      p -> DrinkBlock.create()
         .setId("rum")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 RIESLING_DRY_WHITE = registerBlock(
      "riesling_dry_white",
      p -> DrinkBlock.create()
         .setId("riesling_dry_white")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .build()
   );
   public static final class_2248 SUNSET_GLOW = registerBlock(
      "sunset_glow",
      p -> DrinkBlock.create()
         .setId("sunset_glow")
         .maxCount(3)
         .shapes(
            class_2248.method_9541(3.0, 0.0, 6.0, 13.0, 13.0, 10.0),
            class_2248.method_9541(1.0, 0.0, 3.0, 15.0, 12.0, 12.0),
            class_2248.method_9541(1.0, 0.0, 1.0, 16.0, 12.0, 13.0)
         )
         .build()
   );
   public static final class_2248 MADAME_SHEXIANG = registerBlock(
      "madame_shexiang",
      p -> DrinkBlock.create()
         .setId("madame_shexiang")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .build()
   );
   public static final class_2248 SWEET_BERRY_WINE = registerBlock(
      "sweet_berry_wine",
      p -> DrinkBlock.create()
         .setId("sweet_berry_wine")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .build()
   );
   public static final class_2248 SHERRY = registerBlock(
      "sherry",
      p -> DrinkBlock.create()
         .setId("sherry")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 MOTHER_SNOW = registerBlock(
      "mother_snow",
      p -> DrinkBlock.create()
         .setId("mother_snow")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 15.0, 12.0),
            class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 15.0, 12.0),
            class_259.method_1084(class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 15.0, 16.0), class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 16.0)),
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0)
         )
         .build()
   );
   public static final class_2248 LUMINOUS_BRIDE = registerBlock(
      "luminous_bride",
      p -> DrinkBlock.create()
         .setId("luminous_bride")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 GLOWFLOWER_BREW = registerBlock(
      "glowflower_brew",
      p -> DrinkBlock.create()
         .setId("glowflower_brew")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 SAUVIGNON_BLANC_DRY_WHITE = registerBlock(
      "sauvignon_blanc_dry_white",
      p -> DrinkBlock.create()
         .setId("sauvignon_blanc_dry_white")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 VINEGAR = registerBlock(
      "vinegar",
      p -> DrinkBlock.create()
         .setId("vinegar")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2248 WATERMELON_JUICE = registerBlock(
      "watermelon_juice",
      p -> DrinkBlock.create()
         .setId("watermelon_juice")
         .maxCount(4)
         .shapes(
            class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 16.0, 10.0),
            class_2248.method_9541(2.0, 0.0, 6.0, 14.0, 16.0, 10.0),
            class_259.method_1084(class_2248.method_9541(2.0, 0.0, 10.0, 14.0, 16.0, 14.0), class_2248.method_9541(6.0, 0.0, 2.0, 10.0, 16.0, 14.0)),
            class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0)
         )
         .build()
   );
   public static final class_2591<SandwichBoardBlockEntity> SANDWICH_BOARD_BE = FabricBlockEntityTypeBuilder.create(
         SandwichBoardBlockEntity::new,
         new class_2248[]{
            BASE_SANDWICH_BOARD,
            GRASS_SANDWICH_BOARD,
            ALLIUM_SANDWICH_BOARD,
            AZURE_BLUET_SANDWICH_BOARD,
            CORNFLOWER_SANDWICH_BOARD,
            ORCHID_SANDWICH_BOARD,
            PEONY_SANDWICH_BOARD,
            PINK_PETALS_SANDWICH_BOARD,
            PITCHER_PLANT_SANDWICH_BOARD,
            POPPY_SANDWICH_BOARD,
            SUNFLOWER_SANDWICH_BOARD,
            TORCHFLOWER_SANDWICH_BOARD,
            TULIP_SANDWICH_BOARD,
            WITHER_ROSE_SANDWICH_BOARD,
            EYEBLOSSOM_SANDWICH_BOARD
         }
      )
      .build();
   public static final class_2591<BarStoolBlockEntity> BAR_STOOL_BE = FabricBlockEntityTypeBuilder.create(
         BarStoolBlockEntity::new,
         new class_2248[]{
            BLUE_BAR_STOOL,
            GREEN_BAR_STOOL,
            ORANGE_BAR_STOOL,
            PURPLE_BAR_STOOL,
            YELLOW_BAR_STOOL,
            BLACK_BAR_STOOL,
            WHITE_BAR_STOOL,
            GRAY_BAR_STOOL,
            BROWN_BAR_STOOL,
            LIME_BAR_STOOL,
            MAGENTA_BAR_STOOL,
            CYAN_BAR_STOOL,
            LIGHT_BLUE_BAR_STOOL,
            PINK_BAR_STOOL,
            LIGHT_GRAY_BAR_STOOL,
            RED_BAR_STOOL
         }
      )
      .build();
   public static final class_2591<ChalkboardBlockEntity> CHALKBOARD_BE = FabricBlockEntityTypeBuilder.create(
         ChalkboardBlockEntity::new, new class_2248[]{CHALKBOARD}
      )
      .build();
   public static final class_2591<PressingTubBlockEntity> PRESSING_TUB_BE = FabricBlockEntityTypeBuilder.create(
         PressingTubBlockEntity::new, new class_2248[]{PRESSING_TUB}
      )
      .build();
   public static final class_2591<BarrelBlockEntity> BARREL_BE = FabricBlockEntityTypeBuilder.create(BarrelBlockEntity::new, new class_2248[]{BARREL}).build();
   public static final class_2591<TapBlockEntity> TAP_BE = FabricBlockEntityTypeBuilder.create(TapBlockEntity::new, new class_2248[]{TAP}).build();
   public static final class_2591<ShakerBlockEntity> SHAKER_BE = FabricBlockEntityTypeBuilder.create(ShakerBlockEntity::new, new class_2248[]{SHAKER}).build();
   public static final class_2591<PotionBottleBlockEntity> POTION_BOTTLE_BE = FabricBlockEntityTypeBuilder.create(
         PotionBottleBlockEntity::new, new class_2248[]{POTION_BOTTLE}
      )
      .build();
   public static final class_2591<IncenseBlockEntity> INCENSE_BE = FabricBlockEntityTypeBuilder.create(
         IncenseBlockEntity::new,
         new class_2248[]{SAKURA_INCENSE, PINE_INCENSE, GINKGO_INCENSE, SPORE_INCENSE, CATNIP_INCENSE, SNOW_INCENSE, BUTTERFLY_INCENSE, FIREFLY_INCENSE}
      )
      .build();
   public static final class_2591<BarCabinetBlockEntity> BAR_CABINET_BE = FabricBlockEntityTypeBuilder.create(
         BarCabinetBlockEntity::new, new class_2248[]{BAR_CABINET, GLASS_BAR_CABINET}
      )
      .build();
   public static final class_2591<SignatureCocktailBlockEntity> SIGNATURE_COCKTAIL_BE = FabricBlockEntityTypeBuilder.create(
         SignatureCocktailBlockEntity::new, new class_2248[]{SIGNATURE_COCKTAIL}
      )
      .build();
   public static final class_2591<CellarCabinetBlockEntity> CELLAR_CABINET_BE = FabricBlockEntityTypeBuilder.create(
         CellarCabinetBlockEntity::new, new class_2248[]{CELLAR_CABINET}
      )
      .build();
   public static final class_2591<TiltedRackBlockEntity> TILTED_RACK_BE = FabricBlockEntityTypeBuilder.create(
         TiltedRackBlockEntity::new, new class_2248[]{TILTED_RACK}
      )
      .build();
   public static final class_2591<GlasswareHolderBlockEntity> GLASSWARE_HOLDER_BE = FabricBlockEntityTypeBuilder.create(
         GlasswareHolderBlockEntity::new, new class_2248[]{GLASSWARE_HOLDER}
      )
      .build();
   public static final class_2591<CircularRackBlockEntity> CIRCULAR_RACK_BE = FabricBlockEntityTypeBuilder.create(
         CircularRackBlockEntity::new, new class_2248[]{CIRCULAR_RACK}
      )
      .build();
   public static final class_2591<HolderBlockEntity> HOLDER_BE = FabricBlockEntityTypeBuilder.create(HolderBlockEntity::new, new class_2248[]{HOLDER}).build();
   public static final class_2591<DrinkBlockEntity> DRINK_BE = FabricBlockEntityTypeBuilder.create(
         DrinkBlockEntity::new,
         new class_2248[]{
            WINE,
            CHAMPAGNE,
            VODKA,
            BRANDY,
            CARIGNAN,
            SAKURA_WINE,
            PLUM_WINE,
            WHISKEY,
            ICE_WINE,
            POLARIS_SWEET_WHITE,
            HONEY_WINE,
            RED_QUEEN,
            MINERS_STAR,
            RUM,
            RIESLING_DRY_WHITE,
            SUNSET_GLOW,
            MADAME_SHEXIANG,
            SWEET_BERRY_WINE,
            SHERRY,
            MOTHER_SNOW,
            LUMINOUS_BRIDE,
            GLOWFLOWER_BREW,
            SAUVIGNON_BLANC_DRY_WHITE,
            VINEGAR,
            WATERMELON_JUICE
         }
      )
      .build();

   private static class_2248 registerBlock(String id, Function<class_2251, class_2248> factory) {
      class_5321<class_2248> key = PortHelper.createBlockId(id);
      return (class_2248)class_2378.method_39197(class_7923.field_41175, key, factory.apply(class_2251.method_9637().method_63500(key)));
   }

   public static void registerBlocks() {
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "sandwich_board"), SANDWICH_BOARD_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "bar_stool"), BAR_STOOL_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "chalkboard"), CHALKBOARD_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"), PRESSING_TUB_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "barrel"), BARREL_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "tap"), TAP_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "shaker"), SHAKER_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "potion_bottle"), POTION_BOTTLE_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "incense"), INCENSE_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "bar_cabinet"), BAR_CABINET_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "signature_cocktail"), SIGNATURE_COCKTAIL_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "cellar_cabinet"), CELLAR_CABINET_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "tilted_rack"), TILTED_RACK_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "glassware_holder"), GLASSWARE_HOLDER_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "circular_rack"), CIRCULAR_RACK_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "holder"), HOLDER_BE);
      class_2378.method_10230(class_7923.field_41181, class_2960.method_60655("kaleidoscope_tavern", "drink"), DRINK_BE);
   }
}
