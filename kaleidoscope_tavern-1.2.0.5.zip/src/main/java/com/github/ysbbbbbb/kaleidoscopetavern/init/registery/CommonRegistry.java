package com.github.ysbbbbbb.kaleidoscopetavern.init.registery;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.LivingChangeTargetEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlantGrapeEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.block.dispenser.BottleBlockDispenseBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import com.github.ysbbbbbb.kaleidoscopetavern.event.AddFeaturesEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.event.EffectEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.TapBehaviorManager;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.BarrelTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.BeehiveTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.DragonHeadTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.LavaCauldronTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.WaterCauldronTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl.WatermelonTapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.network.NetworkHandler;
import net.fabricmc.fabric.api.registry.FuelRegistryEvents;
import net.fabricmc.fabric.api.registry.FuelRegistryEvents.BuildCallback;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.minecraft.class_2246;
import net.minecraft.class_2315;
import net.minecraft.class_2960;
import net.minecraft.class_3264;

public final class CommonRegistry {
   public static void init() {
      NetworkHandler.init();
      ResourceLoader.get(class_3264.field_14190)
         .registerReloader(class_2960.method_60655("kaleidoscope_tavern", "drink_effect"), new DrinkEffectDataReloadListener());
      dispenseRegister();
      storageRegister();
      events();
      addTapBehavior();
      fuelRegistry();
      modCompat();
   }

   private static void addTapBehavior() {
      TapBehaviorManager.register(ModBlocks.BARREL, new BarrelTapBehavior());
      TapBehaviorManager.register(class_2246.field_27097, new WaterCauldronTapBehavior());
      TapBehaviorManager.register(class_2246.field_27098, new LavaCauldronTapBehavior());
      TapBehaviorManager.register(class_2246.field_20421, new BeehiveTapBehavior());
      TapBehaviorManager.register(class_2246.field_20422, new BeehiveTapBehavior());
      TapBehaviorManager.register(class_2246.field_10337, new DragonHeadTapBehavior());
      TapBehaviorManager.register(class_2246.field_10472, new DragonHeadTapBehavior());
      TapBehaviorManager.register(class_2246.field_46283, new WatermelonTapBehavior());
   }

   public static void events() {
      AddFeaturesEvent.addFeatures();
      EffectEvent.register();
      PlantGrapeEvent.register();
      LivingChangeTargetEvent.register();
   }

   public static void fuelRegistry() {
      FuelRegistryEvents.BUILD.register((BuildCallback)(builder, context) -> builder.method_61762(ModItems.GRAPEVINE, context.baseSmeltTime()));
   }

   public static void dispenseRegister() {
      class_2315.method_10009(ModItems.WHISKEY, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.BRANDY, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.SAKURA_WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.PLUM_WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.CHAMPAGNE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.VODKA, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.CARIGNAN, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.EMPTY_BOTTLE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.ICE_WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.VINEGAR, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.MOLOTOV, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.POLARIS_SWEET_WHITE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.MOTHER_SNOW, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.SHERRY, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.SWEET_BERRY_WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.RED_QUEEN, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.RUM, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.MINERS_STAR, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.HONEY_WINE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.MADAME_SHEXIANG, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.SUNSET_GLOW, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.SAUVIGNON_BLANC_DRY_WHITE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.RIESLING_DRY_WHITE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.LUMINOUS_BRIDE, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.GLOWFLOWER_BREW, new BottleBlockDispenseBehavior());
      class_2315.method_10009(ModItems.WATERMELON_JUICE, new BottleBlockDispenseBehavior());
   }

   public static void modCompat() {
   }

   public static void storageRegister() {
      ItemStorage.SIDED.registerForBlockEntity(PressingTubBlockEntity::getItemStorage, ModBlocks.PRESSING_TUB_BE);
   }
}
