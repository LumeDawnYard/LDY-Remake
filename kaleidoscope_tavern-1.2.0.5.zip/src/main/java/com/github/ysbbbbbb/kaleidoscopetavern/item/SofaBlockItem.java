package com.github.ysbbbbbb.kaleidoscopetavern.item;

import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_1792.class_1793;

public class SofaBlockItem extends class_1747 {
   public SofaBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties.method_63685());
   }
}
