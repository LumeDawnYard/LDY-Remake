package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarCabinetBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarCabinetBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.BarCabinetBlockEntityRenderState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class BarCabinetBlockEntityRender implements class_827<BarCabinetBlockEntity, BarCabinetBlockEntityRenderState> {
   private final class_776 blockRender;

   public BarCabinetBlockEntityRender(class_5615 context) {
      this.blockRender = context.comp_4535();
   }

   public void extractRenderState(
      @NonNull BarCabinetBlockEntity blockEntity,
      @NonNull BarCabinetBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      blockEntityRenderState.leftItem = blockEntity.getLeftItem();
      blockEntityRenderState.rightItem = blockEntity.getRightItem();
      blockEntityRenderState.facing = (class_2350)blockEntity.method_11010().method_11654(BarCabinetBlock.FACING);
      blockEntityRenderState.isSingle = blockEntity.isSingle();
   }

   public @NonNull BarCabinetBlockEntityRenderState createRenderState() {
      return new BarCabinetBlockEntityRenderState();
   }

   public void submit(
      BarCabinetBlockEntityRenderState blockEntityRenderState,
      @NonNull class_4587 poseStack,
      @NonNull class_11659 submitNodeCollector,
      @NonNull class_12075 cameraRenderState
   ) {
      class_1799 leftStack = blockEntityRenderState.leftItem;
      class_1799 rightStack = blockEntityRenderState.rightItem;
      float scale = 0.9F;
      float angle = 180.0F - blockEntityRenderState.facing.method_10161() * 90.0F;
      if (blockEntityRenderState.isSingle) {
         if (!leftStack.method_7960() && leftStack.method_7909() instanceof class_1747 blockItem) {
            poseStack.method_22903();
            class_2680 state = blockItem.method_7711().method_9564();
            poseStack.method_22904(0.5, 0.0, 0.5);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
            poseStack.method_22904(0.0, 0.0625, 0.0);
            poseStack.method_22905(scale, scale, scale);
            poseStack.method_22904(-0.5, 0.0, -0.5);
            class_1087 blockStateModel = this.blockRender.method_3349(state);
            submitNodeCollector.method_73484(
               poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, blockEntityRenderState.field_62676, class_4608.field_21444, 0
            );
            poseStack.method_22909();
         }
      } else {
         if (!leftStack.method_7960() && leftStack.method_7909() instanceof class_1747 blockItem) {
            poseStack.method_22903();
            class_2680 state = blockItem.method_7711().method_9564();
            poseStack.method_22904(0.5, 0.0, 0.5);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
            poseStack.method_22904(blockEntityRenderState.facing.method_10166() == class_2351.field_11051 ? 0.25 : -0.25, 0.0625, 0.0);
            poseStack.method_22905(scale, scale, scale);
            poseStack.method_22904(-0.5, 0.0, -0.5);
            class_1087 blockStateModel = this.blockRender.method_3349(state);
            submitNodeCollector.method_73484(
               poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, blockEntityRenderState.field_62676, class_4608.field_21444, 0
            );
            poseStack.method_22909();
         }

         if (!rightStack.method_7960() && rightStack.method_7909() instanceof class_1747 blockItem) {
            poseStack.method_22903();
            class_2680 state = blockItem.method_7711().method_9564();
            poseStack.method_22904(0.5, 0.0, 0.5);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(angle));
            poseStack.method_22904(blockEntityRenderState.facing.method_10166() == class_2351.field_11051 ? -0.25 : 0.25, 0.0625, 0.0);
            poseStack.method_22905(scale, scale, scale);
            poseStack.method_22904(-0.5, 0.0, -0.5);
            class_1087 blockStateModel = this.blockRender.method_3349(state);
            submitNodeCollector.method_73484(
               poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, blockEntityRenderState.field_62676, class_4608.field_21444, 0
            );
            poseStack.method_22909();
         }
      }
   }
}
