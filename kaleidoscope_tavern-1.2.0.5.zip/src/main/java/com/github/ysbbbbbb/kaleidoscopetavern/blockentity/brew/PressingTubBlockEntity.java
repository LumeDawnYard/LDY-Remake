package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.IPressingTub;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.config.GeneralConfig;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1863;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_9696;
import net.minecraft.class_1863.class_7266;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class PressingTubBlockEntity extends BaseBlockEntity implements IPressingTub, class_1263, SidedStorageBlockEntity {
   private final class_7266<class_9696, PressingTubRecipe> quickCheck = class_1863.method_42302(ModRecipes.PRESSING_TUB_RECIPE);
   private final ItemStackHandler items = new ItemStackHandler(1) {
      @Override
      protected void onContentsChanged(int slot) {
         PressingTubBlockEntity.this.refresh();
      }
   };
   private final CustomFluidTank fluid = new CustomFluidTank(81000L, this::refresh);

   public PressingTubBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.PRESSING_TUB_BE, pos, state);
   }

   protected void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.items.deserializeNBT(valueInput);
      this.fluid.readFromNBT(valueInput);
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      this.items.serialize(valueOutput);
      this.fluid.writeToNBT(valueOutput);
   }

   @Override
   public boolean addIngredient(class_1799 stack) {
      int count = stack.method_7947();
      class_1799 remaining = this.items.insertItem(0, stack.method_7972(), false);
      if (remaining.method_7947() >= count) {
         return false;
      }

      stack.method_7934(count - remaining.method_7947());
      if (this.field_11863 instanceof class_3218) {
         this.field_11863
            .method_43128(
               null,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               class_3417.field_14667,
               class_3419.field_15245,
               0.5F + this.field_11863.field_9229.method_43057(),
               this.field_11863.field_9229.method_43057() * 0.7F + 0.6F
            );
      }

      return true;
   }

   @Override
   public boolean removeIngredient(class_1309 target, int count) {
      class_1799 removed = this.items.extractItem(0, count, false);
      if (removed.method_7960()) {
         return false;
      }

      ItemUtils.getItemToLivingEntity(target, removed);
      if (this.field_11863 instanceof class_3218) {
         this.field_11863
            .method_43128(
               null,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               class_3417.field_14770,
               class_3419.field_15245,
               0.5F + this.field_11863.field_9229.method_43057(),
               this.field_11863.field_9229.method_43057() * 0.7F + 0.6F
            );
      }

      return true;
   }

   @Override
   public boolean press(class_1309 target, float fallDistance) {
      if (this.field_11863 == null) {
         return false;
      }

      if (fallDistance < 0.5F) {
         return false;
      }

      class_1799 stack = this.items.getStackInSlot(0);
      if (stack.method_7960()) {
         if (this.getFluidAmount() > 0) {
            this.playSuccessPressEffect(null);
         } else {
            this.playFailPressEffect(null);
         }

         return false;
      } else {
         class_9696 container = new class_9696(stack);
         if (this.field_11863 instanceof class_3218 serverLevel) {
            return this.quickCheck.method_42303(container, serverLevel).map(holder -> {
               PressingTubRecipe recipe = (PressingTubRecipe)holder.comp_1933();
               FluidVariant fluidVariant = FluidVariant.of(recipe.getFluid());
               FluidVariant fluidInTub = this.fluid.getFluidVariant();
               if (!fluidInTub.isBlank() && !fluidVariant.equals(fluidInTub)) {
                  this.playFailPressEffect(stack);
                  if ((Boolean)GeneralConfig.PRESSING_TUB_DROP_CONTENTS_ON_NON_JUICEABLE.get() && this.dropContents()) {
                     this.refresh();
                  }

                  return false;
               } else {
                  if (this.fluid.getFluidAmountTransfer() >= 81000L) {
                     this.playFinishedPressEffect();
                     return false;
                  }

                  class_1799 output = recipe.method_59998(container, serverLevel.method_30349());
                  if (output.method_7960()) {
                     this.playFailPressEffect(stack);
                     return false;
                  }

                  long insertAmount = toTransferAmount(recipe.getFluidAmount());
                  boolean inserted = false;
                  Transaction transaction = Transaction.openOuter();

                  try {
                     long actual = this.fluid.insert(fluidVariant, insertAmount, transaction);
                     if (actual > 0L) {
                        inserted = true;
                        transaction.commit();
                     }
                  } catch (Throwable var16) {
                     if (transaction != null) {
                        try {
                           transaction.close();
                        } catch (Throwable var15) {
                           var16.addSuppressed(var15);
                        }
                     }

                     throw var16;
                  }

                  if (transaction != null) {
                     transaction.close();
                  }

                  if (!inserted) {
                     this.playFinishedPressEffect();
                     return false;
                  } else {
                     this.items.extractItem(0, 1, false);
                     this.playSuccessPressEffect(stack);
                     return true;
                  }
               }
            }).orElseGet(() -> {
               this.playFailPressEffect(stack);
               if ((Boolean)GeneralConfig.PRESSING_TUB_DROP_CONTENTS_ON_NON_JUICEABLE.get() && this.dropContents()) {
                  this.refresh();
               }

               return false;
            });
         } else {
            this.playFailPressEffect(stack);
            return false;
         }
      }
   }

   private static long toTransferAmount(int milliBuckets) {
      return milliBuckets <= 0 ? 0L : milliBuckets * 81000L / 1000L;
   }

   private void playSuccessPressEffect(@Nullable class_1799 stack) {
      if (this.field_11863 instanceof class_3218 serverLevel) {
         this.field_11863
            .method_43128(
               null,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               class_3417.field_14560,
               class_3419.field_15245,
               0.5F + this.field_11863.field_9229.method_43057(),
               this.field_11863.field_9229.method_43057() * 0.3F + 0.7F
            );
         if (stack == null) {
            serverLevel.method_65096(
               class_2398.field_11242,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               10,
               0.25,
               0.2,
               0.25,
               0.05
            );
         } else {
            class_2392 option = new class_2392(class_2398.field_11218, stack);
            serverLevel.method_65096(
               option,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               10,
               0.25,
               0.2,
               0.25,
               0.05
            );
         }
      }
   }

   private void playFailPressEffect(@Nullable class_1799 stack) {
      if (this.field_11863 instanceof class_3218 serverLevel) {
         this.field_11863
            .method_43128(
               null,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               class_3417.field_14607,
               class_3419.field_15245,
               0.5F + this.field_11863.field_9229.method_43057(),
               this.field_11863.field_9229.method_43057() * 0.3F + 0.7F
            );
         if (stack == null) {
            class_2680 state = ModBlocks.PRESSING_TUB.method_9564();
            class_2388 option = new class_2388(class_2398.field_11217, state);
            serverLevel.method_65096(
               option,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               10,
               0.25,
               0.2,
               0.25,
               0.05
            );
         } else {
            class_2392 option = new class_2392(class_2398.field_11218, stack);
            serverLevel.method_65096(
               option,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               10,
               0.25,
               0.2,
               0.25,
               0.05
            );
         }
      }
   }

   private void playFinishedPressEffect() {
      if (this.field_11863 instanceof class_3218 serverLevel) {
         this.field_11863
            .method_43128(
               null,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.5,
               this.field_11867.method_10260() + 0.5,
               class_3417.field_21072,
               class_3419.field_15245,
               0.5F + this.field_11863.field_9229.method_43057(),
               this.field_11863.field_9229.method_43057() * 0.3F + 0.7F
            );
         serverLevel.method_65096(
            class_2398.field_11242,
            this.field_11867.method_10263() + 0.5,
            this.field_11867.method_10264() + 0.5,
            this.field_11867.method_10260() + 0.5,
            10,
            0.25,
            0.2,
            0.25,
            0.05
         );
      }
   }

   @Override
   public boolean getResult(class_1309 target, class_1799 carriedStack) {
      if (this.field_11863 == null) {
         return false;
      }

      if (this.fluid.getFluidAmountTransfer() < 81000L) {
         return false;
      }

      FluidVariant fluidVariant = this.fluid.getFluidVariant();
      if (fluidVariant.isBlank()) {
         return false;
      }

      if (carriedStack.method_31574(class_1802.field_8550)) {
         class_1792 bucketItem = fluidVariant.getFluid().method_15774();
         if (!bucketItem.method_7854().method_7960()) {
            Transaction transaction = Transaction.openOuter();

            boolean var25;
            label150: {
               try {
                  long extracted = this.fluid.extract(fluidVariant, 81000L, transaction);
                  if (extracted != 81000L) {
                     var25 = false;
                     break label150;
                  }

                  transaction.commit();
               } catch (Throwable var15) {
                  if (transaction != null) {
                     try {
                        transaction.close();
                     } catch (Throwable var14) {
                        var15.addSuppressed(var14);
                     }
                  }

                  throw var15;
               }

               if (transaction != null) {
                  transaction.close();
               }

               class_1799 resultStack = bucketItem.method_7854();
               if (!(target instanceof class_1657 player && player.method_68878())) {
                  carriedStack.method_7934(1);
               }

               ItemUtils.getItemToLivingEntity(target, resultStack);
               class_3414 sound = getBucketFillSound(fluidVariant);
               if (sound != null) {
                  target.method_43077(sound);
               }

               return true;
            }

            if (transaction != null) {
               transaction.close();
            }

            return var25;
         }
      }

      class_1799 copy = carriedStack.method_46651(1);
      ContainerItemContext context = ContainerItemContext.withConstant(copy);
      Storage<FluidVariant> itemStorage = (Storage<FluidVariant>)context.find(FluidStorage.ITEM);
      if (itemStorage == null) {
         return false;
      }

      Transaction transaction = Transaction.openOuter();

      boolean var27;
      label139: {
         boolean var12;
         label151: {
            try {
               long extracted = this.fluid.extract(fluidVariant, 81000L, transaction);
               if (extracted != 81000L) {
                  var27 = false;
                  break label139;
               }

               long inserted = itemStorage.insert(fluidVariant, extracted, transaction);
               if (inserted != extracted) {
                  var12 = false;
                  break label151;
               }

               transaction.commit();
            } catch (Throwable var16) {
               if (transaction != null) {
                  try {
                     transaction.close();
                  } catch (Throwable var13) {
                     var16.addSuppressed(var13);
                  }
               }

               throw var16;
            }

            if (transaction != null) {
               transaction.close();
            }

            ItemVariant resultVariant = context.getItemVariant();
            class_1799 resultStack = resultVariant.toStack((int)Math.min(2147483647L, context.getAmount()));
            if (!(target instanceof class_1657 player && player.method_68878())) {
               carriedStack.method_7934(1);
            }

            ItemUtils.getItemToLivingEntity(target, resultStack);
            class_3414 sound = getBucketFillSound(fluidVariant);
            if (sound != null) {
               target.method_43077(sound);
            }

            return true;
         }

         if (transaction != null) {
            transaction.close();
         }

         return var12;
      }

      if (transaction != null) {
         transaction.close();
      }

      return var27;
   }

   private static class_3414 getBucketFillSound(FluidVariant variant) {
      return variant.isBlank() ? null : FluidVariantAttributes.getFillSound(variant);
   }

   public boolean dropContents() {
      if (this.field_11863 == null) {
         return false;
      }

      class_1799 stack = this.items.extractItem(0, 64, false);
      if (stack.method_7960()) {
         return false;
      }

      int totalCount = stack.method_7947();
      int directionCount = Math.min(8, totalCount);
      double s = 1.0 / Math.sqrt(2.0);
      double[][] dirs = new double[][]{{1.0, 0.0}, {s, s}, {0.0, 1.0}, {-s, s}, {-1.0, 0.0}, {-s, -s}, {0.0, -1.0}, {s, -s}};
      int base = totalCount / directionCount;
      int remainder = totalCount % directionCount;

      for (int i = 0; i < directionCount; i++) {
         int count = base + (i < remainder ? 1 : 0);
         class_1799 split = stack.method_46651(count);
         double dx = dirs[i][0];
         double dz = dirs[i][1];
         double spawnX = this.field_11867.method_10263() + 0.5 + dx * 0.3 + class_3532.method_15366(this.field_11863.field_9229, -0.05, 0.05);
         double spawnY = this.field_11867.method_10264() + 0.5 + class_3532.method_15366(this.field_11863.field_9229, 0.0, 0.1);
         double spawnZ = this.field_11867.method_10260() + 0.5 + dz * 0.3 + class_3532.method_15366(this.field_11863.field_9229, -0.05, 0.05);
         double velX = dx * 0.15 + class_3532.method_15366(this.field_11863.field_9229, -0.02, 0.02);
         double velY = 0.1 + class_3532.method_15366(this.field_11863.field_9229, -0.02, 0.02);
         double velZ = dz * 0.15 + class_3532.method_15366(this.field_11863.field_9229, -0.02, 0.02);
         this.popResource(this.field_11863, () -> new class_1542(this.field_11863, spawnX, spawnY, spawnZ, split, velX, velY, velZ), split);
      }

      return true;
   }

   private void popResource(class_1937 level, Supplier<class_1542> supplier, class_1799 stack) {
      if (!level.method_8608()
         && level instanceof class_3218 serverLevel
         && !stack.method_7960()
         && (Boolean)serverLevel.method_64395().method_76185(class_1928.field_19392)) {
         class_1542 entity = supplier.get();
         entity.method_6988();
         level.method_8649(entity);
      }
   }

   @Override
   public ItemStackHandler getItems() {
      return this.items;
   }

   @Override
   public CustomFluidTank getFluid() {
      return this.fluid;
   }

   @Override
   public int getFluidAmount() {
      return this.fluid.getFluidAmountMb();
   }

   public int method_5439() {
      return this.items.getSlots();
   }

   public boolean method_5442() {
      return this.items.getStackInSlot(0).method_7960();
   }

   @NotNull
   public class_1799 method_5438(int i) {
      return this.items.getStackInSlot(i);
   }

   @NotNull
   public class_1799 method_5434(int i, int j) {
      return this.items.extractItem(i, j, false);
   }

   @NotNull
   public class_1799 method_5441(int i) {
      class_1799 current = this.items.getStackInSlot(i);
      return current.method_7960() ? class_1799.field_8037 : this.items.extractItem(i, current.method_7947(), false);
   }

   public void method_5431() {
      super.method_5431();
      if (this.field_11863 != null) {
         class_2680 state = this.field_11863.method_8320(this.field_11867);
         this.field_11863.method_8413(this.field_11867, state, state, 3);
      }
   }

   public void method_5447(int i, @NonNull class_1799 itemStack) {
      this.items.setStackInSlot(i, itemStack);
   }

   public boolean method_5443(@NonNull class_1657 player) {
      return this.field_11863 != null && this.field_11863.method_8321(this.field_11867) == this
         ? player.method_5649(this.field_11867.method_10263() + 0.5, this.field_11867.method_10264() + 0.5, this.field_11867.method_10260() + 0.5) <= 64.0
         : false;
   }

   public void method_5448() {
      this.items.setStackInSlot(0, class_1799.field_8037);
   }

   public boolean method_5437(int slot, @NonNull class_1799 stack) {
      return this.items.isItemValid(slot, stack);
   }

   @Nullable
   public Storage<ItemVariant> getItemStorage(@Nullable class_2350 side) {
      return (Storage<ItemVariant>)(side == class_2350.field_11033 ? Storage.empty() : InventoryStorage.of(this, side));
   }
}
