package com.github.ysbbbbbb.kaleidoscopetavern.client.event;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlayerLeftClickEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.item.ShakerItem;
import com.github.ysbbbbbb.kaleidoscopetavern.network.message.ClearShakerC2SMessage;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1799;

public class LeftClickEvent {
   public static void onLeftClickItem(PlayerLeftClickEvent event) {
      if (event.getPlayer() != null) {
         if (event.getPlayer().method_21823() && event.getHand() == class_1268.field_5808) {
            class_1799 stack = event.getPlayer().method_6047();
            if (stack.method_31574(ModItems.SHAKER) && ShakerItem.hasStorage(stack)) {
               ClientPlayNetworking.send(new ClearShakerC2SMessage());
            }
         }
      }
   }
}
