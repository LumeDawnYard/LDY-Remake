package com.github.ysbbbbbb.kaleidoscopetavern.compat.jade;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarrelBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.PressingTubBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.PressingTubBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block.BarrelComponentProvider;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block.PressingTubComponentProvider;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jade.block.PressingTubDataProvider;
import net.minecraft.class_2960;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaCommonRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;

@WailaPlugin
public class ModJadePlugin implements IWailaPlugin {
   public static final class_2960 PRESSING_TUB = class_2960.method_60655("kaleidoscope_tavern", "pressing_tub");
   public static final class_2960 BARREL = class_2960.method_60655("kaleidoscope_tavern", "barrel");

   public void registerClient(IWailaClientRegistration registration) {
      registration.registerBlockComponent(BarrelComponentProvider.INSTANCE, BarrelBlock.class);
      registration.registerBlockComponent(PressingTubComponentProvider.INSTANCE, PressingTubBlock.class);
   }

   public void register(IWailaCommonRegistration registration) {
      registration.registerBlockDataProvider(PressingTubDataProvider.INSTANCE, PressingTubBlockEntity.class);
   }
}
