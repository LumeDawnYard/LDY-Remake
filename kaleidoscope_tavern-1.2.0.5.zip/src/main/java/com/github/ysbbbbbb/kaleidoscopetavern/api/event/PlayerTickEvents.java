package com.github.ysbbbbbb.kaleidoscopetavern.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;

public class PlayerTickEvents {
   public static final Event<PlayerTickEvents.Start> START = EventFactory.createArrayBacked(PlayerTickEvents.Start.class, callbacks -> player -> {
      for (PlayerTickEvents.Start callback : callbacks) {
         callback.onStartOfPlayerTick(player);
      }
   });
   public static final Event<PlayerTickEvents.End> END = EventFactory.createArrayBacked(PlayerTickEvents.End.class, callbacks -> player -> {
      for (PlayerTickEvents.End callback : callbacks) {
         callback.onEndOfPlayerTick(player);
      }
   });

   @FunctionalInterface
   public interface End {
      void onEndOfPlayerTick(class_1657 var1);
   }

   @FunctionalInterface
   public interface Start {
      void onStartOfPlayerTick(class_1657 var1);
   }
}
