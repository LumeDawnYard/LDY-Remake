package com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.container.BarrelRecipeContainer;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.RecipeMatcher;
import java.util.List;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.minecraft.class_9887;
import net.minecraft.class_7225.class_7874;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public record BarrelRecipe(class_2371<class_1856> ingredients, class_3611 fluid, class_1856 carrier, class_1799 result, int unitTime)
   implements class_1860<BarrelRecipeContainer> {
   public static final int INGREDIENT_UNIT_COUNT = 16;

   public boolean matches(BarrelRecipeContainer container, @NonNull class_1937 level) {
      class_2371<class_1856> effectiveIngredients = this.effectiveIngredients();
      List<class_1799> nonEmptyInputs = container.getNonEmptyItems();
      boolean emptyIngredients = effectiveIngredients.isEmpty();
      return emptyIngredients
         ? container.getFluid().method_15780(this.fluid) && container.itemsIsEmpty()
         : container.getFluid().method_15780(this.fluid)
            && container.hasUnitCount(16)
            && RecipeMatcher.findMatches(nonEmptyInputs, effectiveIngredients) != null;
   }

   @NotNull
   public class_1799 assemble(BarrelRecipeContainer container, @NonNull class_7874 registries) {
      int count = 16;

      for (class_1799 itemStack : container.getItems()) {
         if (!itemStack.method_7960()) {
            count = Math.min(count, itemStack.method_7947());
         }
      }

      return this.result.method_46651(count);
   }

   public boolean method_8118() {
      return true;
   }

   public @NonNull class_1865<? extends class_1860<BarrelRecipeContainer>> method_8119() {
      return ModRecipes.BARREL_SERIALIZER;
   }

   public @NonNull class_3956<? extends class_1860<BarrelRecipeContainer>> method_17716() {
      return ModRecipes.BARREL_RECIPE;
   }

   public @NonNull class_9887 method_61671() {
      return class_9887.method_61686(this.effectiveIngredients());
   }

   public @NonNull class_10355 method_64668() {
      return (class_10355)class_2378.method_10230(class_7923.field_54927, class_2960.method_60655("kaleidoscope_tavern", "barrel"), new class_10355());
   }

   private class_2371<class_1856> effectiveIngredients() {
      class_2371<class_1856> filtered = class_2371.method_10211();

      for (class_1856 ingredient : this.ingredients) {
         if (!ingredient.method_65799()) {
            filtered.add(ingredient);
         }
      }

      return filtered;
   }

   public class_2371<class_1856> requiredIngredients() {
      return this.effectiveIngredients();
   }
}
