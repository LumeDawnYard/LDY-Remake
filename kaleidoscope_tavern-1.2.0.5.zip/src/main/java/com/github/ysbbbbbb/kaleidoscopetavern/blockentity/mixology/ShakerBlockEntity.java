package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.IShaker;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.IHasContainer;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class ShakerBlockEntity extends BaseBlockEntity implements IShaker {
   private final ItemStackHandler storage = new ItemStackHandler(3) {
      @Override
      public int getSlotLimit(int slot) {
         return 1;
      }
   };
   private class_1799 result = class_1799.field_8037;
   public int lastPutTick = 0;

   public ShakerBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.SHAKER_BE, pos, state);
   }

   @Override
   public boolean addIngredient(class_1799 stack, @Nullable class_1309 user) {
      if (!this.hasEmptySlots()) {
         return false;
      }

      if (!BottleBlockItem.isValidForShaker(stack)) {
         if (user instanceof class_1657 player && !player.method_73183().method_8608()) {
            player.method_7353(class_2561.method_43471("message.kaleidoscope_tavern.shaker.brew_level_too_low"), false);
         }

         return false;
      } else {
         class_1799 copy = stack.method_46651(1);
         ItemUtils.insertItemStacked(this.storage, copy, false);
         this.refresh();
         if (stack.method_7909() instanceof IHasContainer hasContainer && user != null && this.field_11863 != null) {
            class_1799 carried = hasContainer.getContainerItem().method_7854();
            if (user instanceof class_1657 player) {
               ItemUtils.giveItemToPlayer(player, carried);
            } else {
               class_1542 itemEntity = new class_1542(this.field_11863, user.method_23317(), user.method_23318(), user.method_23321(), carried);
               this.field_11863.method_8649(itemEntity);
            }

            this.field_11863.method_8396(null, this.field_11867, class_3417.field_14826, class_3419.field_15245, 0.75F, 1.0F);
         } else if (stack.method_7909() instanceof class_1812 && user != null && this.field_11863 != null) {
            class_1799 bottle = new class_1799(class_1802.field_8469);
            if (user instanceof class_1657 player) {
               ItemUtils.giveItemToPlayer(player, bottle);
            } else {
               class_1542 itemEntity = new class_1542(this.field_11863, user.method_23317(), user.method_23318(), user.method_23321(), bottle);
               this.field_11863.method_8649(itemEntity);
            }

            this.field_11863.method_8396(null, this.field_11867, class_3417.field_14826, class_3419.field_15245, 0.75F, 1.0F);
         } else if (this.field_11863 != null) {
            this.field_11863.method_8396(null, this.field_11867, class_3417.field_14667, class_3419.field_15245, 0.75F, 1.0F);
         }

         stack.method_7934(1);
         if (this.field_11863 != null) {
            this.lastPutTick = (int)this.field_11863.method_75260();
         }

         this.refresh();
         if (this.field_11863 instanceof class_3218 serverLevel) {
            serverLevel.method_65096(
               class_2398.field_11241,
               this.field_11867.method_10263() + 0.5,
               this.field_11867.method_10264() + 0.75,
               this.field_11867.method_10260() + 0.5,
               8,
               0.2,
               0.3,
               0.2,
               0.0
            );
         }

         return true;
      }
   }

   private boolean hasEmptySlots() {
      for (int i = 0; i < this.storage.getSlots(); i++) {
         class_1799 slot = this.storage.getStackInSlot(i);
         if (slot.method_7960()) {
            return true;
         }
      }

      return false;
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      this.storage.serialize(valueOutput, "Storage", "StorageSize");
      valueOutput.method_71468("result", class_1799.field_49266, this.result);
      valueOutput.method_71465("last_put_tick", this.lastPutTick);
   }

   public void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      this.storage.deserializeNBT(valueInput, "Storage", "StorageSize");
      this.result = valueInput.method_71426("result", class_1799.field_49266).orElse(class_1799.field_8037);
      this.lastPutTick = valueInput.method_71424("last_put_tick", 0);
   }

   public ItemStackHandler getStorage() {
      return this.storage;
   }

   public void setStorage(ItemStackHandler storage) {
      for (int i = 0; i < storage.getSlots(); i++) {
         class_1799 slot = storage.getStackInSlot(i);
         this.storage.setStackInSlot(i, slot);
      }
   }

   public class_1799 getResult() {
      return this.result;
   }

   public void setResult(class_1799 result) {
      this.result = result;
   }
}
