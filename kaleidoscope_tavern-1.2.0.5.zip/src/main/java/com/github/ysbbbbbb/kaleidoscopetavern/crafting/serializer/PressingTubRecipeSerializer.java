package com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6885;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class PressingTubRecipeSerializer implements class_1865<PressingTubRecipe> {
   public static final int DEFAULT_FLUID_AMOUNT = 125;
   private static final MapCodec<PressingTubRecipe> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            class_1856.field_52596
               .fieldOf("ingredient")
               .xmap(class_1856::method_8106, i -> class_6885.method_40242(i.method_8105().toList()))
               .forGetter(PressingTubRecipe::getIngredient),
            class_7923.field_41173.method_39673().fieldOf("fluid").forGetter(PressingTubRecipe::getFluid),
            Codec.INT.optionalFieldOf("fluid_amount", 125).forGetter(PressingTubRecipe::getFluidAmount)
         )
         .apply(instance, PressingTubRecipe::new)
   );
   private static final class_9139<class_9129, PressingTubRecipe> STREAM_CODEC = new class_9139<class_9129, PressingTubRecipe>() {
      @NotNull
      public PressingTubRecipe decode(class_9129 buf) {
         class_1856 ingredient = (class_1856)class_1856.field_48355.decode(buf);
         class_2960 fluidId = buf.method_10810();
         class_3611 fluid = Objects.requireNonNull((class_3611)class_7923.field_41173.method_63535(fluidId));
         int fluidAmount = buf.readInt();
         return new PressingTubRecipe(ingredient, fluid, fluidAmount);
      }

      public void encode(class_9129 buf, PressingTubRecipe recipe) {
         class_1856.field_48355.encode(buf, recipe.getIngredient());
         class_2960 fluidId = Objects.requireNonNull(class_7923.field_41173.method_10221(recipe.getFluid()));
         buf.method_10812(fluidId);
         buf.method_53002(recipe.getFluidAmount());
      }
   };

   @NotNull
   public MapCodec<PressingTubRecipe> method_53736() {
      return CODEC;
   }

   @NotNull
   public class_9139<class_9129, PressingTubRecipe> method_56104() {
      return STREAM_CODEC;
   }
}
