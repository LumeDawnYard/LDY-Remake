package com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6885;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class BarrelRecipeSerializer implements class_1865<BarrelRecipe> {
   public static final class_2960 EMPTY_RECIPE_ID = class_2960.method_60655("kaleidoscope_tavern", "empty");
   public static final int DEFAULT_UNIT_TIME = 2400;
   public static final int MAX_INGREDIENTS = 4;
   private static final MapCodec<BarrelRecipe> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            class_1856.field_52596
               .listOf()
               .xmap(
                  BarrelRecipeSerializer::normalizeHolderSets,
                  nonnull -> nonnull.stream().filter(i -> !i.method_65799()).map(i -> class_6885.method_40242(i.method_8105().toList())).toList()
               )
               .optionalFieldOf("ingredients", class_2371.method_10211())
               .forGetter(BarrelRecipe::ingredients),
            class_7923.field_41173.method_39673().fieldOf("fluid").forGetter(BarrelRecipe::fluid),
            class_1856.field_52596
               .fieldOf("carrier")
               .xmap(class_1856::method_8106, i -> class_6885.method_40242(i.method_8105().toList()))
               .forGetter(BarrelRecipe::carrier),
            class_1799.field_24671.fieldOf("result").forGetter(BarrelRecipe::result),
            Codec.INT.optionalFieldOf("unit_time", 2400).forGetter(BarrelRecipe::unitTime)
         )
         .apply(instance, BarrelRecipe::new)
   );
   private static final class_9139<class_9129, BarrelRecipe> STREAM_CODEC = new class_9139<class_9129, BarrelRecipe>() {
      @NotNull
      public BarrelRecipe decode(class_9129 buf) {
         int size = Math.min(4, buf.method_10816());
         class_2371<class_1856> ingredients = class_2371.method_10211();

         for (int i = 0; i < size; i++) {
            class_1856 ingredient = (class_1856)class_1856.field_48355.decode(buf);
            if (!ingredient.method_65799()) {
               ingredients.add(ingredient);
            }
         }

         class_2960 fluidId = buf.method_10810();
         class_3611 fluid = Objects.requireNonNull((class_3611)class_7923.field_41173.method_63535(fluidId));
         class_1856 carrier = (class_1856)class_1856.field_48355.decode(buf);
         class_1799 result = (class_1799)class_1799.field_48349.decode(buf);
         int unitTime = buf.method_10816();
         return new BarrelRecipe(ingredients, fluid, carrier, result, unitTime);
      }

      public void encode(class_9129 buf, BarrelRecipe recipe) {
         List<class_1856> nonEmpty = recipe.ingredients().stream().filter(i -> !i.method_65799()).limit(4L).toList();
         buf.method_10804(nonEmpty.size());

         for (class_1856 ingredient : nonEmpty) {
            class_1856.field_48355.encode(buf, ingredient);
         }

         class_2960 fluidId = class_7923.field_41173.method_10221(recipe.fluid());
         buf.method_10812(Objects.requireNonNull(fluidId));
         class_1856.field_48355.encode(buf, recipe.carrier());
         class_1799.field_48349.encode(buf, recipe.result());
         buf.method_10804(recipe.unitTime());
      }
   };

   private static class_2371<class_1856> normalizeHolderSets(List<class_6885<class_1792>> list) {
      class_2371<class_1856> nonnull = class_2371.method_10211();
      int size = Math.min(list.size(), 4);

      for (int i = 0; i < size; i++) {
         class_6885<class_1792> set = list.get(i);
         if (set != null && (!set.method_62680() || set.method_40247() > 0)) {
            nonnull.add(class_1856.method_8106(set));
         }
      }

      return nonnull;
   }

   @NotNull
   public MapCodec<BarrelRecipe> method_53736() {
      return CODEC;
   }

   @NotNull
   public class_9139<class_9129, BarrelRecipe> method_56104() {
      return STREAM_CODEC;
   }
}
