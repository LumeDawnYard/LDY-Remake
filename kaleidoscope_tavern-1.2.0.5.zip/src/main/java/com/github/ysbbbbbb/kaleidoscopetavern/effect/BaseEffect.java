package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

public class BaseEffect extends class_1291 {
   public BaseEffect(class_4081 category, int color) {
      super(category, color);
   }

   public BaseEffect(int color) {
      this(class_4081.field_18271, color);
   }

   public boolean method_5572(@NonNull class_3218 serverLevel, @NonNull class_1309 livingEntity, int i) {
      return true;
   }

   public void method_5564(
      @NonNull class_3218 serverLevel, @Nullable class_1297 entity, @Nullable class_1297 entity2, @NonNull class_1309 livingEntity, int i, double d
   ) {
   }

   public boolean method_5552(int duration, int amplifier) {
      return false;
   }
}
