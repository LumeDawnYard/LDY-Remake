package com.github.ysbbbbbb.kaleidoscopetavern.util.event;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.CropStateChangeEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.api.event.LivingChangeTargetEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class EventHooks {
   public static boolean onCropsGrowPre(class_1936 level, class_2338 pos, class_2680 state, boolean shouldGrow) {
      if (!shouldGrow) {
         return false;
      }

      CropStateChangeEvent.Pre event = new CropStateChangeEvent.Pre(level, pos, state);
      event.post();
      return !event.isCanceled();
   }

   public static void onCropsGrowPost(class_1937 level, class_2338 pos, class_2680 originalState) {
      class_2680 currentState = level.method_8320(pos);
      CropStateChangeEvent.Post event = new CropStateChangeEvent.Post(level, pos, originalState, currentState);
      event.post();
   }

   public static LivingChangeTargetEvent onLivingChangeTarget(
      class_1309 entity, @Nullable class_1309 originalTarget, LivingChangeTargetEvent.ILivingTargetType targetType
   ) {
      LivingChangeTargetEvent event = new LivingChangeTargetEvent(entity, originalTarget, targetType);
      event.post();
      return event;
   }
}
