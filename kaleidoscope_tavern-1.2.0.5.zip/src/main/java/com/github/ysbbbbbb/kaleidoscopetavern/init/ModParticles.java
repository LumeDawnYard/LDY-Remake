package com.github.ysbbbbbb.kaleidoscopetavern.init;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModParticles {
   public static final class_2400 WATER_TAP_DRIP = FabricParticleTypes.simple(true);
   public static final class_2400 LAVA_TAP_DRIP = FabricParticleTypes.simple(true);
   public static final class_2400 SAKURA_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 PINE_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 GINKGO_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 SPORE_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 CATNIP_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 SNOW_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 BUTTERFLY_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 FIREFLY_INCENSE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 PINE_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 GINKGO_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 CATNIP_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 SNOW_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 BUTTERFLY_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);
   public static final class_2400 FIREFLY_INCENSE_LARGE_PARTICLE = FabricParticleTypes.simple(false);

   public static void registerParticles() {
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "water_tap_drip"), WATER_TAP_DRIP);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "lava_tap_drip"), LAVA_TAP_DRIP);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "sakura_incense_particle"), SAKURA_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "pine_incense_particle"), PINE_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "ginkgo_incense_particle"), GINKGO_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "spore_incense_particle"), SPORE_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "catnip_incense_particle"), CATNIP_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "snow_incense_particle"), SNOW_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "butterfly_incense_particle"), BUTTERFLY_INCENSE_PARTICLE);
      class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "firefly_incense_particle"), FIREFLY_INCENSE_PARTICLE);
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "pine_incense_large_particle"), PINE_INCENSE_LARGE_PARTICLE
      );
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "ginkgo_incense_large_particle"), GINKGO_INCENSE_LARGE_PARTICLE
      );
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "catnip_incense_large_particle"), CATNIP_INCENSE_LARGE_PARTICLE
      );
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "snow_incense_large_particle"), SNOW_INCENSE_LARGE_PARTICLE
      );
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "butterfly_incense_large_particle"), BUTTERFLY_INCENSE_LARGE_PARTICLE
      );
      class_2378.method_10230(
         class_7923.field_41180, class_2960.method_60655("kaleidoscope_tavern", "firefly_incense_large_particle"), FIREFLY_INCENSE_LARGE_PARTICLE
      );
   }
}
