package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3481;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4865;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class WildGrapevineBlock extends class_4865 implements class_2256 {
   public static final MapCodec<WildGrapevineBlock> CODEC = method_54094(WildGrapevineBlock::new);
   public static class_2746 SHEARED = class_2746.method_11825("sheared");
   private static final class_265 SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

   public WildGrapevineBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_16004)
            .method_9640()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_28692)
            .method_50012(class_3619.field_15971),
         class_2350.field_11033,
         SHAPE,
         false,
         0.15
      );
      this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_22509, 0)).method_11657(SHEARED, false));
   }

   public @NonNull class_1269 method_55765(
      class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (stack.method_31574(class_1802.field_8868)) {
         if ((Boolean)state.method_11654(SHEARED)) {
            return class_1269.field_21466;
         }

         level.method_8501(pos, (class_2680)state.method_11657(SHEARED, true));
         stack.method_7970(1, player, PortHelper.getSlotForHand(hand));
         player.method_43077(class_3417.field_14975);
         return class_1269.field_5812;
      } else {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }
   }

   protected void method_9515(@NonNull class_2690<class_2248, class_2680> builder) {
      super.method_9515(builder);
      builder.method_11667(new class_2769[]{SHEARED});
   }

   public boolean method_9558(@NonNull class_2680 state, class_4538 level, class_2338 pos) {
      class_2338 relative = pos.method_10093(this.field_22507.method_10153());
      class_2680 relativeState = level.method_8320(relative);
      return relativeState.method_27852(this.method_24945())
         || relativeState.method_27852(this.method_24946())
         || this.method_24947(relativeState)
         || relativeState.method_26206(level, relative, this.field_22507);
   }

   protected boolean method_24947(class_2680 state) {
      return state.method_26164(class_3481.field_15503);
   }

   @NotNull
   protected MapCodec<? extends class_4865> method_53969() {
      return CODEC;
   }

   public void method_9514(class_2680 state, @NonNull class_3218 level, @NonNull class_2338 pos, @NonNull class_5819 random) {
      if (!(Boolean)state.method_11654(SHEARED)) {
         super.method_9514(state, level, pos, random);
      }
   }

   public boolean method_9651(@NonNull class_4538 level, @NonNull class_2338 pos, class_2680 state) {
      return !(Boolean)state.method_11654(SHEARED) && super.method_9651(level, pos, state);
   }

   protected int method_26376(@NonNull class_5819 randomSource) {
      return 1;
   }

   protected boolean method_24949(class_2680 state) {
      return state.method_26215();
   }

   @NotNull
   protected class_2248 method_24946() {
      return ModBlocks.WILD_GRAPEVINE_PLANT;
   }
}
