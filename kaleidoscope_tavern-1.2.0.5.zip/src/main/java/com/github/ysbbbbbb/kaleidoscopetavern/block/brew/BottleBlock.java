package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BottleBlock extends class_2383 implements class_3737 {
   public static final MapCodec<BottleBlock> CODEC = method_54094(p -> new BottleBlock());
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 14.0, 11.0);
   private final boolean irregular;

   public BottleBlock(class_2251 properties, boolean irregular) {
      super(properties.method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_11537));
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
            .method_11657(WATERLOGGED, false)
      );
      this.irregular = irregular;
   }

   public BottleBlock(String id, boolean irregular) {
      this(
         class_2251.method_9637()
            .method_22488()
            .method_9618()
            .method_50012(class_3619.field_15971)
            .method_63500(PortHelper.createBlockId(id))
            .method_9626(class_2498.field_11537),
         irregular
      );
   }

   public BottleBlock(boolean irregular) {
      this(class_2251.method_9637().method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_11537), irregular);
   }

   public BottleBlock() {
      this(false);
   }

   protected @NonNull class_1269 method_55766(
      @NonNull class_2680 state, @NonNull class_1937 level, @NonNull class_2338 pos, @NonNull class_1657 player, @NonNull class_3965 blockHitResult
   ) {
      if (level instanceof class_3218 serverLevel) {
         method_9562(state, serverLevel, pos, null).forEach(stack -> ItemUtils.giveItemToPlayer(player, stack));
         level.method_8652(pos, class_2246.field_10124.method_9564(), 35);
         level.method_8396(null, pos, class_2498.field_11544.method_10598(), player.method_5634(), 1.0F, 1.0F);
      }

      return class_1269.field_5812;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_3610 fluidState = context.method_8045().method_8316(context.method_8037());
      return (class_2680)((class_2680)this.method_9564().method_11657(field_11177, context.method_8042().method_10153()))
         .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
   }

   public void method_19286(class_1937 level, @NonNull class_2680 state, @NonNull class_3965 hit, @NonNull class_1676 projectile) {
      if (!level.method_8608() && level instanceof class_3218 serverLevel) {
         class_2338 pos = hit.method_17777();
         if (projectile.method_36971(serverLevel, pos)) {
            level.method_8650(pos, false);
            int id = class_2248.method_9507(class_2246.field_10033.method_9564());
            level.method_20290(2001, pos, id);
         }
      }
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, WATERLOGGED});
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(@NonNull class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      return SHAPE;
   }

   public boolean irregular() {
      return this.irregular;
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
