package com.github.ysbbbbbb.kaleidoscopetavern.client.render.block;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.GlasswareHolderBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate.StorageBlockEntityRenderState;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_5614.class_5615;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class GlasswareHolderBlockEntityRender implements class_827<GlasswareHolderBlockEntity, StorageBlockEntityRenderState> {
   private final class_776 blockRender;

   public GlasswareHolderBlockEntityRender(class_5615 context) {
      this.blockRender = context.comp_4535();
   }

   public void extractRenderState(
      @NonNull GlasswareHolderBlockEntity blockEntity,
      @NonNull StorageBlockEntityRenderState blockEntityRenderState,
      float f,
      @NonNull class_243 vec3,
      @Nullable class_11792 crumblingOverlay
   ) {
      super.method_74331(blockEntity, blockEntityRenderState, f, vec3, crumblingOverlay);
      ItemStackHandler items = blockEntity.getItems();

      for (int i = 0; i < items.getSlots(); i++) {
         blockEntityRenderState.items.add(items.getStackInSlot(i));
      }
   }

   public @NonNull StorageBlockEntityRenderState createRenderState() {
      return new StorageBlockEntityRenderState();
   }

   public void submit(
      StorageBlockEntityRenderState state, @NonNull class_4587 poseStack, @NonNull class_11659 submitNodeCollector, @NonNull class_12075 cameraRenderState
   ) {
      for (int i = 0; i < state.items.size(); i++) {
         class_1799 stack = state.items.get(i);
         if (!stack.method_7960() && stack.method_7909() instanceof class_1747 blockItem) {
            poseStack.method_22903();
            poseStack.method_22904(-0.25, 0.76, 0.75);
            poseStack.method_22904(0.5 * (i % 2), 0.0, 0.5 * (i / 2));
            poseStack.method_22907(class_7833.field_40713.rotationDegrees(180.0F));
            class_2680 blockState = blockItem.method_7711().method_9564();
            class_1087 blockStateModel = this.blockRender.method_3349(blockState);
            submitNodeCollector.method_73484(
               poseStack, class_4722.method_24074(), blockStateModel, 1.0F, 1.0F, 1.0F, state.field_62676, class_4608.field_21444, 0
            );
            poseStack.method_22909();
         }
      }
   }
}
