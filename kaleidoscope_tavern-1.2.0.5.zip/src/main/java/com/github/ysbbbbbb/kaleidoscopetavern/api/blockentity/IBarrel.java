package com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity;

import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface IBarrel {
   int MAX_ITEM_SLOTS = 4;
   int MAX_FLUID_AMOUNT = 4000;
   int BREWING_NOT_STARTED = 0;
   int BREWING_STARTED = 1;
   int BREWING_FINISHED = 6;

   boolean openLid(@Nullable class_1309 var1);

   boolean closeLid(@Nullable class_1309 var1);

   boolean addIngredient(@Nullable class_1309 var1, class_1799 var2);

   boolean removeIngredient(@NotNull class_1309 var1);

   boolean addFluid(@NotNull class_1309 var1, class_1799 var2);

   boolean removeFluid(@NotNull class_1309 var1, class_1799 var2);

   boolean isBrewing();

   boolean isMaxBrewLevel();

   boolean canTapExtract(class_1937 var1, class_2338 var2, class_1309 var3);

   void doTapExtract(class_1937 var1, class_2338 var2);

   ItemStackHandler getIngredient();

   CustomFluidTank getFluid();

   void setOpen(boolean var1);

   boolean isOpen();

   int getBrewLevel();

   @Nullable
   class_2960 getRecipeId();

   int getBrewTime();

   ItemStackHandler getOutput();
}
