package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class CocktailEffectHelper {
   public static final float EFFECT_MERGE_MULTIPLIER = 1.2F;

   public static CocktailEffectHelper.CollectedData collectFromStorage(ItemStackHandler storage) {
      Map<class_1792, DrinkEffectData> dataMap = DrinkEffectDataReloadListener.INSTANCE;
      List<DrinkEffectData.Entry> effects = Lists.newArrayList();
      List<class_124> colors = Lists.newArrayList();

      for (int i = 0; i < storage.getSlots(); i++) {
         class_1799 ingredient = storage.getStackInSlot(i);
         if (!ingredient.method_7960()) {
            class_1844 contents = (class_1844)ingredient.method_58694(class_9334.field_49651);
            if (contents != null) {
               colors.add(class_124.field_1068);

               for (class_1293 e : contents.comp_2380()) {
                  int durationSeconds = e.method_5584() / 20;
                  effects.add(new DrinkEffectData.Entry(e.method_5579(), durationSeconds, e.method_5578(), 1.0F));
               }
            } else {
               class_124 color = ColorUtils.ITEM_COLOR_CACHE.apply(ingredient.method_7909());
               if (color != class_124.field_1070) {
                  colors.add(color);
               }

               int brewLevel = BottleBlockItem.getBrewLevel(ingredient);
               if (brewLevel > 0 && dataMap.containsKey(ingredient.method_7909())) {
                  DrinkEffectData data = dataMap.get(ingredient.method_7909());
                  List<List<DrinkEffectData.Entry>> effectsList = data.effects();
                  brewLevel = Math.min(brewLevel, effectsList.size());
                  effects.addAll(effectsList.get(brewLevel - 1));
               }
            }
         }
      }

      return new CocktailEffectHelper.CollectedData(effects, colors);
   }

   public static List<DrinkEffectData.Entry> mergeEffects(List<DrinkEffectData.Entry> effects) {
      Map<class_6880<class_1291>, List<DrinkEffectData.Entry>> grouped = Maps.newLinkedHashMap();

      for (DrinkEffectData.Entry entry : effects) {
         grouped.computeIfAbsent(entry.effect(), k -> Lists.newArrayList()).add(entry);
      }

      List<DrinkEffectData.Entry> merged = Lists.newArrayList();

      for (Entry<class_6880<class_1291>, List<DrinkEffectData.Entry>> e : grouped.entrySet()) {
         int totalDuration = 0;
         int maxAmplifier = 0;
         float maxProbability = 0.0F;

         for (DrinkEffectData.Entry entry : e.getValue()) {
            totalDuration += entry.duration();
            maxAmplifier = Math.max(maxAmplifier, entry.amplifier());
            maxProbability = Math.max(maxProbability, entry.probability());
         }

         totalDuration = (int)(totalDuration * 1.2F);
         merged.add(new DrinkEffectData.Entry(e.getKey(), totalDuration, maxAmplifier, maxProbability));
      }

      return merged;
   }

   public record CollectedData(List<DrinkEffectData.Entry> effects, List<class_124> colors) {
   }
}
