package com.github.ysbbbbbb.kaleidoscopetavern.compat.jei;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category.BarrelRecipeCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category.PressingTubCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category.ShakerRecipeCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.fabricmc.fabric.api.recipe.v1.sync.RecipeSynchronization;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

@JeiPlugin
public class ModJeiPlugin implements IModPlugin {
   private static final class_2960 UID = class_2960.method_60655("kaleidoscope_tavern", "jei");

   public void registerCategories(IRecipeCategoryRegistration registration) {
      registration.addRecipeCategories(new IRecipeCategory[]{new BarrelRecipeCategory(registration.getJeiHelpers().getGuiHelper())});
      registration.addRecipeCategories(new IRecipeCategory[]{new PressingTubCategory(registration.getJeiHelpers().getGuiHelper())});
      registration.addRecipeCategories(new IRecipeCategory[]{new ShakerRecipeCategory(registration.getJeiHelpers().getGuiHelper())});
   }

   public void registerRecipes(IRecipeRegistration registration) {
      registration.addRecipes(BarrelRecipeCategory.TYPE, BarrelRecipeCategory.getRecipes());
      registration.addRecipes(PressingTubCategory.TYPE, PressingTubCategory.getRecipes());
      registration.addRecipes(ShakerRecipeCategory.TYPE, ShakerRecipeCategory.getRecipes());
   }

   public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
      registration.addCraftingStation(BarrelRecipeCategory.TYPE, new class_1935[]{ModItems.BARREL});
      registration.addCraftingStation(PressingTubCategory.TYPE, new class_1935[]{ModItems.PRESSING_TUB});
      registration.addCraftingStation(ShakerRecipeCategory.TYPE, new class_1935[]{ModItems.SHAKER});
   }

   public static void syncRecipes() {
      RecipeSynchronization.synchronizeRecipeSerializer(ModRecipes.BARREL_SERIALIZER);
      RecipeSynchronization.synchronizeRecipeSerializer(ModRecipes.PRESSING_TUB_SERIALIZER);
      RecipeSynchronization.synchronizeRecipeSerializer(ModRecipes.SHAKER_SERIALIZER);
   }

   @NotNull
   public class_2960 getPluginUid() {
      return UID;
   }
}
