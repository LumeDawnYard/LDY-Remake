package com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources;

import com.github.ysbbbbbb.kaleidoscopetavern.KaleidoscopeTavern;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_7654;
import org.jspecify.annotations.NonNull;

public class DrinkEffectDataReloadListener extends class_4309<DrinkEffectData> {
   public static final Map<class_1792, DrinkEffectData> INSTANCE = Maps.newHashMap();

   public DrinkEffectDataReloadListener() {
      super(DrinkEffectData.CODEC, class_7654.method_45114("datamap/drink_effect"));
   }

   protected void apply(Map<class_2960, DrinkEffectData> resources, @NonNull class_3300 resourceManager, @NonNull class_3695 profilerFiller) {
      INSTANCE.clear();

      for (Entry<class_2960, DrinkEffectData> entry : resources.entrySet()) {
         DrinkEffectData result = entry.getValue();
         if (result != null) {
            INSTANCE.put(result.item(), result);
         }
      }

      KaleidoscopeTavern.LOGGER.info("Successfully loaded drink effect data with {} entries", INSTANCE.size());
   }
}
