package com.github.ysbbbbbb.kaleidoscopetavern.item;

import net.minecraft.class_1304;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.Nullable;

public class StringLightsBlockItem extends class_1747 {
   public StringLightsBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties.method_63685().method_63682(class_1304.field_6174));
   }

   @Deprecated
   @Nullable
   public class_1304 getEquipmentSlot(class_1799 stack) {
      return class_1304.field_6174;
   }
}
