package com.github.ysbbbbbb.kaleidoscopetavern.block.dispenser;

import com.github.ysbbbbbb.kaleidoscopetavern.KaleidoscopeTavern;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2350;
import net.minecraft.class_2968;
import net.minecraft.class_2969;
import net.minecraft.class_3218;
import net.minecraft.class_2350.class_2351;
import org.jetbrains.annotations.NotNull;

public class BottleBlockDispenseBehavior extends class_2969 {
   @NotNull
   protected class_1799 method_10135(class_2342 source, class_1799 stack) {
      this.method_27955(false);
      class_3218 level = source.comp_1967();
      if (stack.method_7909() instanceof BottleBlockItem bottleBlockItem) {
         class_2350 facing = (class_2350)source.comp_1969().method_11654(class_2315.field_10918);
         class_2338 placePos = source.comp_1968().method_10093(facing);
         class_2350 placeDirection = facing.method_10166() == class_2351.field_11052 ? class_2350.field_11043 : facing;

         try {
            class_2968 context = new class_2968(level, placePos, facing, stack, placeDirection);
            this.method_27955(bottleBlockItem.placeForDispenser(context, source.comp_1970()).method_23665());
         } catch (Exception exception) {
            KaleidoscopeTavern.LOGGER.error("Error trying to place bottle block item from dispenser", exception);
         }
      } else if (stack.method_31574(ModItems.EMPTY_BOTTLE) && stack.method_7909() instanceof class_1747 blockItem) {
         class_2350 facing = (class_2350)source.comp_1969().method_11654(class_2315.field_10918);
         class_2338 placePos = source.comp_1968().method_10093(facing);
         class_2350 placeDirection = facing.method_10166() == class_2351.field_11052 ? class_2350.field_11043 : facing;

         try {
            class_2968 context = new class_2968(level, placePos, facing, stack, placeDirection);
            this.method_27955(blockItem.method_7712(context).method_23665());
         } catch (Exception exception) {
            KaleidoscopeTavern.LOGGER.error("Error trying to place bottle block item from dispenser", exception);
         }
      }

      return stack;
   }
}
