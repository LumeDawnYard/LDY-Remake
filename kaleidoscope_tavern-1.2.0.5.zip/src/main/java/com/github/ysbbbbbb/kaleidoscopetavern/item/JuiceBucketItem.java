package com.github.ysbbbbbb.kaleidoscopetavern.item;

import net.minecraft.class_10128;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3611;
import net.minecraft.class_5328;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class JuiceBucketItem extends class_1755 implements IHasContainer {
   public JuiceBucketItem(class_3611 fluid, class_1793 properties) {
      super(
         fluid, properties.method_7889(16).method_7896(class_1802.field_8550).method_57349(class_9334.field_53964, class_10128.method_62859().method_62851())
      );
   }

   @NotNull
   public class_1799 method_7861(@NonNull class_1799 stack, class_1937 level, @NonNull class_1309 entity) {
      if (!level.method_8608()) {
         entity.method_6012();
      }

      if (entity instanceof class_3222 serverPlayer) {
         class_174.field_1198.method_8821(serverPlayer, stack);
         serverPlayer.method_7259(class_3468.field_15372.method_14956(this));
      }

      if (entity instanceof class_1657 player && !player.method_68878()) {
         stack.method_7934(1);
      }

      return this.returnContainerToEntity(stack, level, entity);
   }

   public int method_7881(@NonNull class_1799 stack, @NonNull class_1309 entity) {
      return 32;
   }

   public @NonNull class_1839 method_7853(@NonNull class_1799 stack) {
      return class_1839.field_8946;
   }

   public @NonNull class_1269 method_7836(@NonNull class_1937 level, class_1657 player, @NonNull class_1268 hand) {
      return player.method_5715() ? super.method_7836(level, player, hand) : class_5328.method_29282(level, player, hand);
   }

   @Override
   public class_1792 getContainerItem() {
      return class_1802.field_8550;
   }
}
