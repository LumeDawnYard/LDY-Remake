package com.github.ysbbbbbb.kaleidoscopetavern.block.mixology;

import net.minecraft.class_11979;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_4970.class_2251;

public class MysteryCocktailBlock extends CocktailBlock {
   public MysteryCocktailBlock(class_2251 properties) {
      super(properties);
   }

   public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
      double x = pos.method_10263() + 0.5;
      double y = pos.method_10264() + 0.5;
      double z = pos.method_10260() + 0.5;
      double xSpeed = random.method_43058();
      double ySpeed = random.method_43058();
      double zSpeed = random.method_43058();
      level.method_8406(
         class_11979.method_74418(class_2398.field_11213, 1.0F, 0.8F, 0.2F, 1.0F),
         x + random.method_43058() / 5.0 * (random.method_43056() ? 1 : -1),
         y + random.method_43058() / 5.0,
         z + random.method_43058() / 5.0 * (random.method_43056() ? 1 : -1),
         xSpeed,
         ySpeed,
         zSpeed
      );
   }
}
