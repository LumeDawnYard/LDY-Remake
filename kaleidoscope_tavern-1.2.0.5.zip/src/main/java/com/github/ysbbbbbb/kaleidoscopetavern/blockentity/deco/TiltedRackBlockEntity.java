package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class TiltedRackBlockEntity extends StorageBlockEntity {
   public TiltedRackBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.TILTED_RACK_BE, pos, state, 3);
   }
}
