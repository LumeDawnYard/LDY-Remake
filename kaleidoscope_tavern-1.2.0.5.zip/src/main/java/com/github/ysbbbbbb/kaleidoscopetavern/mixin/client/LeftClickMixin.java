package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlayerLeftClickEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_310.class)
public class LeftClickMixin {
   @Shadow
   @Nullable
   public class_746 field_1724;

   @Inject(method = "method_1536", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_746;method_6104(Lnet/minecraft/class_1268;)V", shift = Shift.BY))
   private void ATTACK(CallbackInfoReturnable<Boolean> cir) {
      PlayerLeftClickEvent event = new PlayerLeftClickEvent(this.field_1724, class_1268.field_5808);
      event.post();
   }
}
