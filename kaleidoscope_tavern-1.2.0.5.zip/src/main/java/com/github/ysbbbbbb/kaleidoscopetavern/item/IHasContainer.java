package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface IHasContainer {
   class_1792 getContainerItem();

   default class_1799 returnContainerToEntity(class_1799 stack, class_1937 level, class_1309 entity) {
      class_1799 carried = this.getContainerItem().method_7854();
      if (stack.method_7960()) {
         return carried;
      }

      if (entity instanceof class_1657 player) {
         ItemUtils.giveItemToPlayer(player, carried);
      } else {
         class_1542 itemEntity = new class_1542(level, entity.method_23317(), entity.method_23318(), entity.method_23321(), carried);
         level.method_8649(itemEntity);
      }

      return stack;
   }
}
