package com.github.ysbbbbbb.kaleidoscopetavern.util;

import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_6862;

public class ColorUtils {
   public static final String[] COLORS = new String[]{
      "white", "light_gray", "gray", "black", "brown", "red", "orange", "yellow", "lime", "green", "cyan", "light_blue", "blue", "purple", "magenta", "pink"
   };
   public static final Map<class_6862<class_1792>, class_124> COCKTAIL_INGREDIENT_COLORS = (Map<class_6862<class_1792>, class_124>)class_156.method_654(
      Maps.newHashMap(), m -> {
         m.put(TagMod.COCKTAIL_INGREDIENT_BLACK, class_124.field_1074);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_BLUE, class_124.field_1058);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_GREEN, class_124.field_1077);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_AQUA, class_124.field_1062);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_RED, class_124.field_1079);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_PURPLE, class_124.field_1064);
         m.put(TagMod.COCKTAIL_INGREDIENT_GOLD, class_124.field_1065);
         m.put(TagMod.COCKTAIL_INGREDIENT_GRAY, class_124.field_1080);
         m.put(TagMod.COCKTAIL_INGREDIENT_DARK_GRAY, class_124.field_1063);
         m.put(TagMod.COCKTAIL_INGREDIENT_BLUE, class_124.field_1078);
         m.put(TagMod.COCKTAIL_INGREDIENT_GREEN, class_124.field_1060);
         m.put(TagMod.COCKTAIL_INGREDIENT_AQUA, class_124.field_1075);
         m.put(TagMod.COCKTAIL_INGREDIENT_RED, class_124.field_1061);
         m.put(TagMod.COCKTAIL_INGREDIENT_LIGHT_PURPLE, class_124.field_1076);
         m.put(TagMod.COCKTAIL_INGREDIENT_YELLOW, class_124.field_1054);
         m.put(TagMod.COCKTAIL_INGREDIENT_WHITE, class_124.field_1068);
      }
   );
   public static final Function<class_1792, class_124> ITEM_COLOR_CACHE = class_156.method_34866(item -> {
      for (class_6862<class_1792> tagKey : COCKTAIL_INGREDIENT_COLORS.keySet()) {
         if (item.method_40131().method_40220(tagKey)) {
            return COCKTAIL_INGREDIENT_COLORS.get(tagKey);
         }
      }

      return class_124.field_1070;
   });

   public static int mixColors(List<class_124> colors) {
      return mixColors(colors.toArray(new class_124[0]));
   }

   public static int mixColors(class_124... colors) {
      if (colors != null && colors.length != 0) {
         int totalR = 0;
         int totalG = 0;
         int totalB = 0;
         int count = 0;

         for (class_124 format : colors) {
            if (format != class_124.field_1070 && format.method_532() != null) {
               int colorVal = format.method_532();
               totalR += colorVal >> 16 & 0xFF;
               totalG += colorVal >> 8 & 0xFF;
               totalB += colorVal & 0xFF;
               count++;
            }
         }

         if (count == 0) {
            return 16777215;
         }

         int avgR = totalR / count;
         int avgG = totalG / count;
         int avgB = totalB / count;
         return avgR << 16 | avgG << 8 | avgB;
      } else {
         return 16777215;
      }
   }
}
