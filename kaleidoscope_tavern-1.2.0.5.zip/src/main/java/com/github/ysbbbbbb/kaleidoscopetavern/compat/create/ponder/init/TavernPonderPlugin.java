package com.github.ysbbbbbb.kaleidoscopetavern.compat.create.ponder.init;

import com.zurrtum.create.client.ponder.api.registration.PonderPlugin;
import com.zurrtum.create.client.ponder.api.registration.PonderSceneRegistrationHelper;
import com.zurrtum.create.client.ponder.api.registration.PonderTagRegistrationHelper;
import com.zurrtum.create.client.ponder.foundation.PonderIndex;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public class TavernPonderPlugin implements PonderPlugin {
   public static void init() {
      PonderIndex.addPlugin(new TavernPonderPlugin());
   }

   public void registerTags(PonderTagRegistrationHelper<class_2960> helper) {
      ModPonderTags.register(helper);
   }

   public void registerScenes(PonderSceneRegistrationHelper<class_2960> helper) {
      ModPonderScreen.register(helper);
   }

   public String getModId() {
      return "kaleidoscope_tavern";
   }
}
