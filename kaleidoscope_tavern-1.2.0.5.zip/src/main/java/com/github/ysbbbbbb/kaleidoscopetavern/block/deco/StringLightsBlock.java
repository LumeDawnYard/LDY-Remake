package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import java.util.Map;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class StringLightsBlock extends class_2383 implements class_3737 {
   public static final MapCodec<StringLightsBlock> CODEC = method_54094(p -> new StringLightsBlock(p, class_1802.field_8446));
   public static final Map<class_1792, StringLightsBlock> TRANSFORM_MAP = Maps.newHashMap();
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 SOUTH_SHAPE = class_2248.method_9541(0.0, 4.0, 0.0, 16.0, 16.0, 6.0);
   public static final class_265 NORTH_SHAPE = class_2248.method_9541(0.0, 4.0, 10.0, 16.0, 16.0, 16.0);
   public static final class_265 EAST_SHAPE = class_2248.method_9541(0.0, 4.0, 0.0, 6.0, 16.0, 16.0);
   public static final class_265 WEST_SHAPE = class_2248.method_9541(10.0, 4.0, 0.0, 16.0, 16.0, 16.0);
   @Nullable
   public final class_1769 dyeItem;

   public StringLightsBlock(class_2251 properties, @Nullable class_1792 dyeItem) {
      super(
         properties.method_51517(dyeItem instanceof class_1769 dye ? dye.method_7802() : class_1767.field_7952)
            .method_51368(class_2766.field_12645)
            .method_9632(0.8F)
            .method_9626(class_2498.field_24119)
            .method_9634()
            .method_9631(s -> 15)
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_11177, class_2350.field_11043))
            .method_11657(WATERLOGGED, false)
      );
      if (dyeItem instanceof class_1769 dye) {
         this.dyeItem = dye;
         TRANSFORM_MAP.put(dyeItem, this);
      } else {
         this.dyeItem = null;
      }
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @NotNull
   public class_1269 method_55765(
      class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      class_1792 item = stack.method_7909();
      if (TRANSFORM_MAP.containsKey(item) && item != this.dyeItem) {
         class_2680 transform = (class_2680)((class_2680)TRANSFORM_MAP.get(item)
               .method_9564()
               .method_11657(field_11177, (class_2350)state.method_11654(field_11177)))
            .method_11657(WATERLOGGED, (Boolean)state.method_11654(WATERLOGGED));
         level.method_8501(pos, transform);
         level.method_45447(null, pos, class_3417.field_28391, class_3419.field_15245);
         level.method_8444(player, 2001, pos, class_2248.method_9507(state));
         if (!player.method_68878()) {
            stack.method_7934(1);
         }

         return class_1269.field_5812;
      } else {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2350 clickedFace = context.method_8038();
      if (clickedFace.method_10166().method_10178()) {
         clickedFace = context.method_8042().method_10153();
      }

      boolean waterLogged = context.method_8045().method_22351(context.method_8037());
      return (class_2680)((class_2680)this.method_9564().method_11657(field_11177, clickedFace)).method_11657(WATERLOGGED, waterLogged);
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      return switch ((class_2350)pState.method_11654(field_11177)) {
         case field_11035 -> SOUTH_SHAPE;
         case field_11034 -> EAST_SHAPE;
         case field_11039 -> WEST_SHAPE;
         default -> NORTH_SHAPE;
      };
   }

   @NotNull
   protected MapCodec<? extends class_2383> method_53969() {
      return CODEC;
   }
}
