package com.github.ysbbbbbb.kaleidoscopetavern.api.entity;

public interface ISittable {
   float getSitHeight();
}
