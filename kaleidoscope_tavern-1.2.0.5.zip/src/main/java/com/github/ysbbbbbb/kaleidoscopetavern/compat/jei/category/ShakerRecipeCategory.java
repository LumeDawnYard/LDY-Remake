package com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.category;

import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.google.common.collect.Lists;
import java.util.List;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeHolderType;
import mezz.jei.api.recipe.types.IRecipeType;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_638;
import net.minecraft.class_8786;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class ShakerRecipeCategory implements IRecipeCategory<class_8786<ShakerRecipe>> {
   public static final IRecipeHolderType<ShakerRecipe> TYPE = IRecipeType.create(ModRecipes.SHAKER_RECIPE);
   private static final class_2960 BG = class_2960.method_60655("kaleidoscope_tavern", "textures/gui/jei/shaker.png");
   private static final class_5250 TITLE = class_2561.method_43471("block.kaleidoscope_tavern.shaker");
   public static final int WIDTH = 150;
   public static final int HEIGHT = 80;
   private final IDrawable bgDraw;
   private final IDrawable iconDraw;

   public ShakerRecipeCategory(IGuiHelper guiHelper) {
      this.bgDraw = guiHelper.createDrawable(BG, 0, 0, 150, 80);
      this.iconDraw = guiHelper.createDrawableItemLike(ModItems.SHAKER);
   }

   public static List<class_8786<ShakerRecipe>> getRecipes() {
      class_638 level = class_310.method_1551().field_1687;
      if (level == null) {
         return List.of();
      }

      List<class_8786<ShakerRecipe>> recipes = Lists.newArrayList();
      recipes.addAll(level.method_8433().getSynchronizedRecipes().getAllOfType(ModRecipes.SHAKER_RECIPE));
      return recipes;
   }

   public void draw(class_8786<ShakerRecipe> holder, @NonNull IRecipeSlotsView recipeSlotsView, @NonNull class_332 guiGraphics, double mouseX, double mouseY) {
      this.bgDraw.draw(guiGraphics);
      ((ShakerRecipe)holder.comp_1933()).ingredientColors().forEach((index, color) -> {
         int x = 66;
         int y = 14 + 18 * index;
         int rgba = 0xFF000000 | color.method_532();
         guiGraphics.method_25294(x, y, x + 8, y + 16, rgba);
      });
   }

   public void setRecipe(@NonNull IRecipeLayoutBuilder builder, class_8786<ShakerRecipe> holder, @NonNull IFocusGroup focuses) {
      ShakerRecipe recipe = (ShakerRecipe)holder.comp_1933();
      int offsetY = 0;

      for (class_1856 input : recipe.getIngredients()) {
         if (!input.method_65799()) {
            List<class_1799> list = input.method_8105().map(s -> ((class_1792)s.comp_349()).method_7854()).toList();
            builder.addSlot(RecipeIngredientRole.INPUT, 52, 14 + offsetY).addIngredients(VanillaTypes.ITEM_STACK, list);
            offsetY += 18;
         }
      }

      class_1799 outputStack = recipe.result();
      builder.addSlot(RecipeIngredientRole.OUTPUT, 112, 36).add(outputStack);
   }

   public @NonNull IRecipeType<class_8786<ShakerRecipe>> getRecipeType() {
      return TYPE;
   }

   @NotNull
   public class_2561 getTitle() {
      return TITLE;
   }

   public int getWidth() {
      return 150;
   }

   public int getHeight() {
      return 80;
   }

   @Nullable
   public IDrawable getIcon() {
      return this.iconDraw;
   }
}
