package com.github.ysbbbbbb.kaleidoscopetavern.game.tap;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.class_2248;

public class TapBehaviorManager {
   private static final Map<class_2248, ITapBehavior> BEHAVIOR_MAP = Maps.newHashMap();

   public static void register(class_2248 block, ITapBehavior behavior) {
      BEHAVIOR_MAP.put(block, behavior);
   }

   public static boolean contains(class_2248 block) {
      return BEHAVIOR_MAP.containsKey(block);
   }

   public static ITapBehavior get(class_2248 block) {
      return BEHAVIOR_MAP.get(block);
   }
}
