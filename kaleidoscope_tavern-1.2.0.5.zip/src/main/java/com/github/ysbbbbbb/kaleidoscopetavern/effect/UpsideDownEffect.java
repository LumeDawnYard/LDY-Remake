package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.jetbrains.annotations.Nullable;

public class UpsideDownEffect extends BaseEffect {
   private static final double RANGE = 16.0;
   private static final class_2561 GRUMM = class_2561.method_43470("Grumm");

   public UpsideDownEffect(int color) {
      super(class_4081.field_18273, color);
   }

   public boolean method_5561() {
      return true;
   }

   @Override
   public void method_5564(
      class_3218 serverLevel, @Nullable class_1297 source, @Nullable class_1297 indirectSource, class_1309 livingEntity, int amplifier, double health
   ) {
      this.performEffect(livingEntity);
   }

   @Override
   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      this.performEffect(livingEntity);
      return true;
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return duration == 1;
   }

   private void performEffect(class_1309 user) {
      class_1937 level = user.method_73183();
      if (!level.method_8608()) {
         class_238 area = user.method_5829().method_1014(16.0);

         for (class_1308 entity : level.method_8390(class_1308.class, area, class_1297::method_5805)) {
            entity.method_5665(GRUMM);
            entity.method_5880(false);
         }
      }
   }
}
