package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jspecify.annotations.NonNull;

public class BarCabinetBlockEntity extends BaseBlockEntity {
   private class_1799 leftItem = class_1799.field_8037;
   private class_1799 rightItem = class_1799.field_8037;
   private boolean isSingle = false;

   public BarCabinetBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.BAR_CABINET_BE, pos, state);
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      if (!this.leftItem.method_7960()) {
         valueOutput.method_71468("left_item", class_1799.field_24671, this.leftItem);
      }

      if (!this.rightItem.method_7960()) {
         valueOutput.method_71468("right_item", class_1799.field_24671, this.rightItem);
      }

      valueOutput.method_71472("is_single", this.isSingle);
   }

   protected void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      valueInput.method_71426("left_item", class_1799.field_24671)
         .ifPresentOrElse(itemStack -> this.leftItem = itemStack, () -> this.leftItem = class_1799.field_8037);
      valueInput.method_71426("right_item", class_1799.field_24671)
         .ifPresentOrElse(itemStack -> this.rightItem = itemStack, () -> this.rightItem = class_1799.field_8037);
      this.isSingle = valueInput.method_71433("is_single", false);
   }

   public class_1799 getLeftItem() {
      return this.leftItem;
   }

   public void setLeftItem(class_1799 leftItem) {
      this.leftItem = leftItem;
   }

   public class_1799 getRightItem() {
      return this.rightItem;
   }

   public void setRightItem(class_1799 rightItem) {
      this.rightItem = rightItem;
   }

   public void setSingle(boolean single) {
      this.isSingle = single;
   }

   public boolean isSingle() {
      return this.isSingle;
   }
}
