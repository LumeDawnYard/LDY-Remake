package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.DrinkBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.DrinkBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10128;
import net.minecraft.class_10691;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1844;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5328;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class DrinkBlockItem extends BottleBlockItem implements IHasContainer {
   public DrinkBlockItem(class_2248 block, class_1793 properties) {
      super(
         block,
         properties.method_7889(16)
            .method_63685()
            .method_7896(ModItems.EMPTY_BOTTLE)
            .method_57349(class_9334.field_53964, class_10128.method_62859().method_62851())
      );
   }

   public int method_7881(@NonNull class_1799 stack, @NonNull class_1309 entity) {
      return 32;
   }

   public @NonNull class_1839 method_7853(@NonNull class_1799 stack) {
      return class_1839.field_8946;
   }

   @NotNull
   public class_1269 method_7884(class_1838 context) {
      class_1937 level = context.method_8045();
      class_1657 player = context.method_8036();
      class_2338 pos = context.method_8037();
      class_1799 stack = context.method_8041();
      class_2680 state = level.method_8320(pos);
      class_2248 self = this.method_7711();
      if (player != null && !player.method_5715()) {
         class_1269 result = this.method_7836(level, player, context.method_20287());
         return (class_1269)(result == class_1269.field_21466 ? class_1269.field_52423 : result);
      } else {
         return (class_1269)(player != null && this.tryIncreaseCount(self, state, level, pos, stack, player)
            ? class_1269.field_5812
            : this.method_7712(new class_1750(context)));
      }
   }

   private boolean tryIncreaseCount(class_2248 self, class_2680 state, class_1937 level, class_2338 pos, class_1799 stack, class_1657 player) {
      if (self instanceof DrinkBlock drink && state.method_27852(self) && drink.tryIncreaseCount(level, pos, state, stack)) {
         class_2498 soundType = state.method_26231();
         class_3414 sound = this.method_19260(state);
         level.method_8396(player, pos, sound, class_3419.field_15245, (soundType.method_10597() + 1.0F) / 2.0F, soundType.method_10599() * 0.8F);
         if (!player.method_68878()) {
            stack.method_7934(1);
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean method_7710(@NonNull class_2338 pos, class_1937 level, @Nullable class_1657 player, @NonNull class_1799 stack, @NonNull class_2680 state) {
      if (level.method_8321(pos) instanceof DrinkBlockEntity be && be.addItem(stack)) {
         be.refresh();
      }

      return super.method_7710(pos, level, player, stack, state);
   }

   public @NonNull class_1269 method_7836(@NonNull class_1937 level, @NonNull class_1657 player, @NonNull class_1268 hand) {
      return class_5328.method_29282(level, player, hand);
   }

   @NotNull
   public class_1799 method_7861(@NonNull class_1799 stack, @NonNull class_1937 level, @NonNull class_1309 entity) {
      if (entity instanceof class_3222 serverPlayer) {
         class_174.field_1198.method_8821(serverPlayer, stack);
         serverPlayer.method_7259(class_3468.field_15372.method_14956(this));
      }

      this.addDrinkEffect(stack, level, entity);
      if (entity instanceof class_1657 player && !player.method_68878()) {
         stack.method_7934(1);
      }

      return this.returnContainerToEntity(stack, level, entity);
   }

   protected void addDrinkEffect(class_1799 drink, class_1937 level, class_1309 entity) {
      DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(drink.method_7909());
      if (effectData != null) {
         List<List<DrinkEffectData.Entry>> effects = effectData.effects();
         if (!effects.isEmpty()) {
            int brewLevel = BottleBlockItem.getBrewLevel(drink);
            if (brewLevel >= 1) {
               brewLevel = Math.min(brewLevel, effects.size());

               for (DrinkEffectData.Entry entry : effects.get(brewLevel - 1)) {
                  if (!level.method_8608() && level.field_9229.method_43057() < entry.probability()) {
                     int duration = entry.duration() * 20;
                     int amplifier = entry.amplifier();
                     class_1293 instance = new class_1293(entry.effect(), duration, amplifier);
                     entity.method_6092(instance);
                  }
               }
            }
         }
      }
   }

   public void makeThrownPotion(class_1937 level, double x, double y, double z, int brewLevel, @Nullable class_1297 owner) {
      DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(this);
      if (effectData != null) {
         List<List<DrinkEffectData.Entry>> effects = effectData.effects();
         if (!effects.isEmpty()) {
            brewLevel = BottleBlockItem.clampBrewLevel(brewLevel);
            if (brewLevel >= 1) {
               brewLevel = Math.min(brewLevel, effects.size());
               List<class_1293> instances = Lists.newArrayList();

               for (DrinkEffectData.Entry entry : effects.get(brewLevel - 1)) {
                  if (level.field_9229.method_43057() < entry.probability()) {
                     int duration = entry.duration() * 20;
                     int amplifier = entry.amplifier();
                     instances.add(new class_1293(entry.effect(), duration, amplifier));
                  }
               }

               class_1799 stack = new class_1799(this);
               class_10691 potion = new class_10691(level, x, y, z, stack);
               if (owner instanceof class_1309 livingEntity) {
                  potion.method_7432(livingEntity);
               }

               class_1844 contents = new class_1844(Optional.empty(), Optional.empty(), instances, Optional.empty());
               stack.method_57379(class_9334.field_49651, contents);
               potion.method_16940(stack);
               level.method_8649(potion);
            }
         }
      }
   }

   public void makeThrownPotion(class_1937 level, double x, double y, double z, int brewLevel, @Nullable class_1297 owner, @Nullable class_243 movement) {
      List<class_1293> instances = this.getEffectInstances(level, brewLevel);
      class_1799 stack = new class_1799(this);
      class_10691 potion = new class_10691(level, x, y, z, stack);
      if (owner instanceof class_1309 livingEntity) {
         potion.method_7432(livingEntity);
      }

      class_1844 contents = new class_1844(Optional.empty(), Optional.empty(), instances, Optional.empty());
      stack.method_57379(class_9334.field_49651, contents);
      potion.method_16940(stack);
      if (movement != null) {
         potion.method_18799(movement);
      }

      level.method_8649(potion);
   }

   protected List<class_1293> getEffectInstances(class_1937 level, int brewLevel) {
      DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(this);
      if (effectData == null) {
         return List.of();
      }

      List<List<DrinkEffectData.Entry>> effects = effectData.effects();
      if (effects.isEmpty()) {
         return List.of();
      }

      brewLevel = BottleBlockItem.clampBrewLevel(brewLevel);
      if (brewLevel < 1) {
         return List.of();
      }

      brewLevel = Math.min(brewLevel, effects.size());
      List<class_1293> instances = Lists.newArrayList();

      for (DrinkEffectData.Entry entry : effects.get(brewLevel - 1)) {
         if (level.field_9229.method_43057() < entry.probability()) {
            int duration = entry.duration() * 20;
            int amplifier = entry.amplifier();
            instances.add(new class_1293(entry.effect(), duration, amplifier));
         }
      }

      return instances;
   }

   @Override
   public class_1792 getContainerItem() {
      return ModItems.EMPTY_BOTTLE;
   }
}
