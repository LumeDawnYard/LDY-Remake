package com.github.ysbbbbbb.kaleidoscopetavern.block.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.DrinkBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.item.DrinkBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.VoxelShapeUtils;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class DrinkBlock extends BottleBlock implements class_2343 {
   protected final class_2758 countProperty;
   protected final int maxCount;
   protected final EnumMap<class_2350, class_265>[] shapes;
   protected final String id;

   public DrinkBlock(String id, boolean irregular, int maxCount, class_265... shapes) {
      super(id, irregular);
      this.id = id;
      this.maxCount = maxCount;
      this.countProperty = class_2758.method_11867("count", 1, maxCount);
      this.shapes = new EnumMap[shapes.length];

      for (int i = 0; i < shapes.length; i++) {
         this.shapes[i] = VoxelShapeUtils.horizontalShapes(shapes[i]);
      }

      class_2690<class_2248, class_2680> builder = new class_2690(this);
      this.createCountBlockStateDefinition(builder);
      this.field_10647 = builder.method_11668(class_2248::method_9564, class_2680::new);
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(this.countProperty, 1))
               .method_11657(field_11177, class_2350.field_11043))
            .method_11657(WATERLOGGED, false)
      );
   }

   public String getId() {
      return this.id;
   }

   public boolean tryIncreaseCount(class_1937 level, class_2338 pos, class_2680 state, class_1799 stack) {
      int count = (Integer)state.method_11654(this.countProperty);
      if (count < this.maxCount) {
         if (level.method_8321(pos) instanceof DrinkBlockEntity be && be.addItem(stack)) {
            be.refresh();
         }

         level.method_8501(pos, (class_2680)state.method_28493(this.countProperty));
         return true;
      } else {
         return false;
      }
   }

   public @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      if (level.method_8321(pos) instanceof DrinkBlockEntity be) {
         class_1799 removeItem = be.removeItem();
         if (!removeItem.method_7960()) {
            be.refresh();
            ItemUtils.giveItemToPlayer(player, removeItem);
            level.method_45447(null, pos, class_3417.field_14843, class_3419.field_15245);
         }
      }

      int count = (Integer)state.method_11654(this.countProperty);
      if (count > 1) {
         level.method_8501(pos, (class_2680)state.method_11657(this.countProperty, count - 1));
      } else {
         level.method_8650(pos, false);
      }

      return class_1269.field_5812;
   }

   @Override
   public void method_19286(class_1937 level, @NonNull class_2680 state, @NonNull class_3965 hit, @NonNull class_1676 projectile) {
      if (level.method_8608()) {
         super.method_19286(level, state, hit, projectile);
      } else {
         class_2338 pos = hit.method_17777();
         if (level.method_8321(pos) instanceof DrinkBlockEntity be) {
            int var11 = 0;

            for (int item = 0; item < be.getItems().size(); item++) {
               class_1799 stack = (class_1799)be.getItems().get(item);
               if (!stack.method_7960()) {
                  int brewLevel = BottleBlockItem.getBrewLevel(stack);
                  if (brewLevel > var11) {
                     var11 = brewLevel;
                  }
               }
            }

            if (var11 > 0 && this.method_8389() instanceof DrinkBlockItem item) {
               item.makeThrownPotion(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), var11, projectile.method_24921());
            }

            super.method_19286(level, state, hit, projectile);
         } else {
            super.method_19286(level, state, hit, projectile);
         }
      }
   }

   @NotNull
   public List<class_1799> method_9560(@NonNull class_2680 state, @NonNull class_8568 params) {
      List<class_1799> stacks = super.method_9560(state, params);
      class_2586 blockEntity = (class_2586)params.method_51876(class_181.field_1228);
      if (blockEntity instanceof DrinkBlockEntity be) {
         for (class_1799 stack : be.getItems()) {
            if (!stack.method_7960()) {
               stacks.add(stack.method_7972());
            }
         }
      }

      return stacks;
   }

   protected void createCountBlockStateDefinition(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{field_11177, this.countProperty, WATERLOGGED});
   }

   @NotNull
   @Override
   public class_265 method_9530(@NonNull class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      if (this.shapes.length == 0) {
         return super.method_9530(state, level, pos, context);
      }

      int count = (Integer)state.method_11654(this.countProperty);
      if (count > this.shapes.length) {
         count = this.shapes.length;
      }

      class_2350 direction = (class_2350)state.method_11654(field_11177);
      return this.shapes[count - 1].getOrDefault(direction, super.method_9530(state, level, pos, context));
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, @NonNull class_2680 state) {
      return new DrinkBlockEntity(pos, state);
   }

   public class_2758 getCountProperty() {
      return this.countProperty;
   }

   public int getMaxCount() {
      return this.maxCount;
   }

   public static DrinkBlock.Builder create() {
      return new DrinkBlock.Builder();
   }

   public static class Builder {
      private boolean irregular = false;
      private int maxCount;
      private class_265[] shapes;
      private String id = "";

      public DrinkBlock.Builder irregular() {
         this.irregular = true;
         return this;
      }

      public DrinkBlock.Builder setId(String id) {
         this.id = id;
         return this;
      }

      public DrinkBlock.Builder maxCount(int maxCount) {
         this.maxCount = maxCount;
         return this;
      }

      public DrinkBlock.Builder shapes(class_265... shapes) {
         this.shapes = shapes;
         return this;
      }

      public class_2248 build() {
         return new DrinkBlock(this.id, this.irregular, this.maxCount, this.shapes);
      }
   }
}
