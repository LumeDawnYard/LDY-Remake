package com.github.ysbbbbbb.kaleidoscopetavern.client.init;

import com.github.ysbbbbbb.kaleidoscopetavern.client.particle.ButterflyIncenseLargeParticle;
import com.github.ysbbbbbb.kaleidoscopetavern.client.particle.FireflyIncenseLargeParticle;
import com.github.ysbbbbbb.kaleidoscopetavern.client.particle.IncenseParticle;
import com.github.ysbbbbbb.kaleidoscopetavern.client.particle.IncenseSuspendedParticle;
import com.github.ysbbbbbb.kaleidoscopetavern.client.particle.TapDripParticle;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_703;
import net.minecraft.class_8253.class_10379;

@Environment(EnvType.CLIENT)
public final class ModParticleFactoryRegistry {
   public static void init() {
      ParticleFactoryRegistry registry = ParticleFactoryRegistry.getInstance();
      registry.register(ModParticles.WATER_TAP_DRIP, TapDripParticle.WaterProvider::new);
      registry.register(ModParticles.LAVA_TAP_DRIP, TapDripParticle.LavaProvider::new);
      registry.register(ModParticles.SAKURA_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.PINE_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.GINKGO_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.SPORE_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.CATNIP_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.SNOW_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.BUTTERFLY_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.FIREFLY_INCENSE_PARTICLE, IncenseParticle.Provider::new);
      registry.register(ModParticles.PINE_INCENSE_LARGE_PARTICLE, class_10379::new);
      registry.register(ModParticles.GINKGO_INCENSE_LARGE_PARTICLE, spriteSet -> (type, level, x, y, z, xSpeed, ySpeed, zSpeed, randomSource) -> {
         class_703 particle = new class_10379(spriteSet).method_65196(type, level, x, y, z, xSpeed, ySpeed, zSpeed, randomSource);
         particle.method_3087(1.5F);
         return particle;
      });
      registry.register(ModParticles.CATNIP_INCENSE_LARGE_PARTICLE, IncenseSuspendedParticle.Provider::new);
      registry.register(ModParticles.SNOW_INCENSE_LARGE_PARTICLE, class_10379::new);
      registry.register(ModParticles.BUTTERFLY_INCENSE_LARGE_PARTICLE, ButterflyIncenseLargeParticle.Provider::new);
      registry.register(ModParticles.FIREFLY_INCENSE_LARGE_PARTICLE, FireflyIncenseLargeParticle.Provider::new);
   }
}
