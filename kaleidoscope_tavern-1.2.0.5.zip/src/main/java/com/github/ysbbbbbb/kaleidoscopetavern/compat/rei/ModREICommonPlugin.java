package com.github.ysbbbbbb.kaleidoscopetavern.compat.rei;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category.ReiBarrelRecipeCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category.ReiPressingTubRecipeCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rei.category.ReiShakerRecipeCategory;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.PressingTubRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.ShakerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import me.shedaniel.rei.api.common.display.DisplaySerializerRegistry;
import me.shedaniel.rei.api.common.plugins.REICommonPlugin;
import me.shedaniel.rei.api.common.registry.display.ServerDisplayRegistry;
import net.minecraft.class_2960;

public class ModREICommonPlugin implements REICommonPlugin {
   private static final class_2960 BARREL_ID = class_2960.method_60655("kaleidoscope_tavern", "plugin/barrel");
   private static final class_2960 PRESSING_TUB_ID = class_2960.method_60655("kaleidoscope_tavern", "plugin/pressing_tub");
   private static final class_2960 SHAKER_ID = class_2960.method_60655("kaleidoscope_tavern", "plugin/shaker");

   public void registerDisplaySerializer(DisplaySerializerRegistry registry) {
      registerIfNeeded(registry);
   }

   private static void registerIfNeeded(DisplaySerializerRegistry registry) {
      if (!registry.isRegistered(ReiBarrelRecipeCategory.BarrelRecipeDisplay.SERIALIZER)) {
         registry.register(BARREL_ID, ReiBarrelRecipeCategory.BarrelRecipeDisplay.SERIALIZER);
      }

      if (!registry.isRegistered(ReiPressingTubRecipeCategory.PressingTubRecipeDisplay.SERIALIZER)) {
         registry.register(PRESSING_TUB_ID, ReiPressingTubRecipeCategory.PressingTubRecipeDisplay.SERIALIZER);
      }

      if (!registry.isRegistered(ReiShakerRecipeCategory.ShakerRecipeDisplay.SERIALIZER)) {
         registry.register(SHAKER_ID, ReiShakerRecipeCategory.ShakerRecipeDisplay.SERIALIZER);
      }
   }

   public void registerDisplays(ServerDisplayRegistry registry) {
      registerIfNeeded(DisplaySerializerRegistry.getInstance());
      registry.beginRecipeFiller(PressingTubRecipe.class)
         .filterType(ModRecipes.PRESSING_TUB_RECIPE)
         .fill(ReiPressingTubRecipeCategory.PressingTubRecipeDisplay::new);
      registry.beginRecipeFiller(BarrelRecipe.class).filterType(ModRecipes.BARREL_RECIPE).fill(ReiBarrelRecipeCategory.BarrelRecipeDisplay::new);
      registry.beginRecipeFiller(ShakerRecipe.class).filterType(ModRecipes.SHAKER_RECIPE).fill(ReiShakerRecipeCategory.ShakerRecipeDisplay::new);
   }
}
