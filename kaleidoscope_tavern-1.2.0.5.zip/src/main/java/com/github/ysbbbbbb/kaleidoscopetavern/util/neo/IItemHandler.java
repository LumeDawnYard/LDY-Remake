package com.github.ysbbbbbb.kaleidoscopetavern.util.neo;

import net.minecraft.class_1799;

public interface IItemHandler {
   int getSlots();

   class_1799 getStackInSlot(int var1);

   class_1799 insertItem(int var1, class_1799 var2, boolean var3);

   class_1799 extractItem(int var1, int var2, boolean var3);

   int getSlotLimit(int var1);

   boolean isItemValid(int var1, class_1799 var2);

   void setStackInSlot(int var1, class_1799 var2);
}
