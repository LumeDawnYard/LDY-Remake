package com.github.ysbbbbbb.kaleidoscopetavern.item;

import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.DrinkBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.data.DrinkEffectData;
import com.github.ysbbbbbb.kaleidoscopetavern.datamap.resources.DrinkEffectDataReloadListener;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModDataComponents;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ColorUtils;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2601;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class BottleBlockItem extends class_1747 {
   public static final String BREW_LEVEL_KEY = "BrewLevel";
   public static final int MIN_BREW_LEVEL_FOR_SHAKER = 4;

   public BottleBlockItem(class_2248 block) {
      this(block, new class_1793().method_7889(16));
   }

   public BottleBlockItem(class_2248 block, class_1793 properties) {
      super(block, properties);
   }

   public static class_1799 getMaxLevelDrink(class_1792 item) {
      class_1799 stack = item.method_7854();
      setBrewLevel(stack, 6);
      return stack;
   }

   public static void setBrewLevel(class_1799 stack, int brewLevel) {
      stack.method_57379(ModDataComponents.BREW_LEVEL, clampBrewLevel(brewLevel));
   }

   public static int getBrewLevel(class_1799 stack) {
      int brewLevel = (Integer)stack.method_58695(ModDataComponents.BREW_LEVEL, 0);
      int clampedBrewLevel = clampBrewLevel(brewLevel);
      if (brewLevel != clampedBrewLevel) {
         stack.method_57379(ModDataComponents.BREW_LEVEL, clampedBrewLevel);
      }

      return clampedBrewLevel;
   }

   public static int clampBrewLevel(int brewLevel) {
      return class_3532.method_15340(brewLevel, 0, 6);
   }

   public static boolean isValidForShaker(class_1799 stack) {
      return !(stack.method_7909() instanceof BottleBlockItem) ? true : getBrewLevel(stack) >= 4;
   }

   @NotNull
   public class_1269 placeForDispenser(@NotNull class_1750 placeContext, class_2601 entity) {
      class_2680 blockState = placeContext.method_8045().method_8320(placeContext.method_8037());
      if (blockState.method_27852(this.method_7711())
         && this.method_7711() instanceof DrinkBlock drinkBlock
         && drinkBlock.getMaxCount() > 1
         && (Integer)blockState.method_11654(drinkBlock.getCountProperty()) < drinkBlock.getMaxCount()) {
         class_1750 updatedPlaceContext = this.method_16356(placeContext);
         if (updatedPlaceContext != null) {
            placeContext.method_8041().method_57008(1, updatedPlaceContext.method_8036());
         }

         entity.method_58683(placeContext.method_8041());
         entity.method_5431();
         return (class_1269)(drinkBlock.tryIncreaseCount(placeContext.method_8045(), placeContext.method_8037(), blockState, placeContext.method_8041())
            ? class_1269.field_5812
            : class_1269.field_5814);
      } else {
         return super.method_7712(placeContext);
      }
   }

   public class_1799 getFilledStack(int brewLevel) {
      class_1799 stack = new class_1799(this);
      setBrewLevel(stack, brewLevel);
      return stack;
   }

   public void method_67187(
      @NonNull class_1799 stack,
      @NonNull class_9635 tooltipContext,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 tooltipFlag
   ) {
      class_124 applied = ColorUtils.ITEM_COLOR_CACHE.apply(stack.method_7909());
      if (applied != class_124.field_1070) {
         String key = "color.kaleidoscope_tavern.%s".formatted(applied.method_537());
         class_2561 text = class_2561.method_43471("color.kaleidoscope_tavern.prefix")
            .method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43471(key).method_27692(applied));
         consumer.accept(text);
      }

      int brewLevel = getBrewLevel(stack);
      if (0 < brewLevel) {
         class_2561 brewLevelText = class_2561.method_43471("message.kaleidoscope_tavern.barrel.brew_level.%d".formatted(brewLevel));
         consumer.accept(
            class_2561.method_43469("tooltip.kaleidoscope_tavern.bottle_block.brew_level", new Object[]{brewLevelText}).method_27692(class_124.field_1080)
         );
         DrinkEffectData effectData = DrinkEffectDataReloadListener.INSTANCE.get(stack.method_7909());
         if (effectData == null) {
            return;
         }

         List<List<DrinkEffectData.Entry>> effects = effectData.effects();
         if (effects.isEmpty()) {
            return;
         }

         List<class_1293> effectsShow = Lists.newArrayList();

         for (DrinkEffectData.Entry entry : effects.get(brewLevel - 1)) {
            if (entry.probability() >= 1.0F) {
               class_6880<class_1291> effect = entry.effect();
               int duration = entry.duration() * 20;
               int amplifier = entry.amplifier();
               effectsShow.add(new class_1293(effect, duration, amplifier));
            }
         }

         if (!effectsShow.isEmpty()) {
            class_1844.method_8065(effectsShow, consumer, 1.0F, tooltipContext.method_59531());
         }
      }
   }
}
