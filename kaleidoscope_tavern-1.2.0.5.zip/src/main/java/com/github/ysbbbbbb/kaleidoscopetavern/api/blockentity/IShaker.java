package com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public interface IShaker {
   boolean addIngredient(class_1799 var1, @Nullable class_1309 var2);
}
