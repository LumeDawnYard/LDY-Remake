package com.github.ysbbbbbb.kaleidoscopetavern.mixin;

import com.github.ysbbbbbb.kaleidoscopetavern.item.StringLightsBlockItem;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
   @Inject(
      method = "method_32326",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1799;method_58694(Lnet/minecraft/class_9331;)Ljava/lang/Object;"),
      cancellable = true
   )
   private static void getEquipmentSlotForItem(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
      if (itemStack.method_7909() instanceof StringLightsBlockItem) {
         if (cir == null || itemStack.method_7960()) {
            return;
         }

         cir.setReturnValue(class_1304.field_6174);
      }
   }
}
