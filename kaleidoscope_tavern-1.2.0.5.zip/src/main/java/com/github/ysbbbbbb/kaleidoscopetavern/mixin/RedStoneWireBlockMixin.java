package com.github.ysbbbbbb.kaleidoscopetavern.mixin;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2457.class)
public class RedStoneWireBlockMixin {
   @Inject(method = "method_10482", at = @At("HEAD"), cancellable = true)
   private static void shouldConnectTo(class_2680 blockState, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
      if (blockState.method_27852(ModBlocks.TAP)) {
         cir.setReturnValue(true);
      }
   }
}
