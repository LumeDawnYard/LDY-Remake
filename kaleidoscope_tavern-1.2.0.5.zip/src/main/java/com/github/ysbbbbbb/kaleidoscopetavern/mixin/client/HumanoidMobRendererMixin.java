package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.item.StringLightsBlockItem;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_909;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_909.class)
public abstract class HumanoidMobRendererMixin {
   @Inject(
      method = "method_65568",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/class_970;method_64081(Lnet/minecraft/class_1799;Lnet/minecraft/class_1304;)Z",
         shift = Shift.BY,
         by = -1
      ),
      cancellable = true
   )
   private static void getEquipmentIfRenderable(
      class_1309 livingEntity, class_1304 equipmentSlot, CallbackInfoReturnable<class_1799> cir, @Local(ordinal = 0) class_1799 itemStack
   ) {
      if (itemStack.method_7909() instanceof StringLightsBlockItem) {
         cir.setReturnValue(itemStack.method_7972());
      }
   }
}
