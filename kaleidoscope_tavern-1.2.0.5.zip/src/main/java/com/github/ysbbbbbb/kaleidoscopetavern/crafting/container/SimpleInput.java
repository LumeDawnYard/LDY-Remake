package com.github.ysbbbbbb.kaleidoscopetavern.crafting.container;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_9695;
import org.jetbrains.annotations.NotNull;

public record SimpleInput(List<class_1799> inputs) implements class_9695 {
   @NotNull
   public class_1799 method_59984(int index) {
      return this.inputs.get(index);
   }

   public int method_59983() {
      return this.inputs.size();
   }
}
