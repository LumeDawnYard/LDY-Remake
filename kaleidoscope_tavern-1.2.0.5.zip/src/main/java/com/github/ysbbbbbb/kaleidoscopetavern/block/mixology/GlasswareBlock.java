package com.github.ysbbbbbb.kaleidoscopetavern.block.mixology;

import com.github.ysbbbbbb.kaleidoscopetavern.api.client.IModelModifyRotationAfterBake;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_7718;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class GlasswareBlock extends class_2248 implements class_3737, IModelModifyRotationAfterBake<class_2758> {
   public static final class_2758 ROTATION = class_2741.field_12532;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 SHAPE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 10.0, 12.0);

   public GlasswareBlock(class_2251 properties) {
      super(properties.method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_11537));
      this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(ROTATION, 0)).method_11657(WATERLOGGED, false));
   }

   public GlasswareBlock() {
      this(class_2251.method_9637().method_22488().method_9618().method_50012(class_3619.field_15971).method_9626(class_2498.field_11537));
   }

   protected @NonNull class_1269 method_55765(
      class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
   ) {
      if (!player.method_5998(hand).method_7960()) {
         return class_1269.field_5811;
      }

      if (level instanceof class_3218 serverLevel) {
         method_9562(state, serverLevel, pos, level.method_8321(pos)).forEach(s -> ItemUtils.giveItemToPlayer(player, s));
         level.method_8652(pos, class_2246.field_10124.method_9564(), 35);
         level.method_8396(null, pos, class_2498.field_11544.method_10598(), player.method_5634(), 1.0F, 1.0F);
      }

      return class_1269.field_5812;
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 state,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 pos,
      @NonNull class_2350 direction,
      @NonNull class_2338 neighborPos,
      @NonNull class_2680 neighborState,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)state.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      return super.method_9559(state, levelReader, scheduledTickAccess, pos, direction, neighborPos, neighborState, randomSource);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      boolean isWaterAt = context.method_8045().method_22351(context.method_8037());
      int rotation = class_7718.method_45479(context.method_8044());
      return (class_2680)((class_2680)this.method_9564().method_11657(ROTATION, rotation)).method_11657(WATERLOGGED, isWaterAt);
   }

   public void method_19286(class_1937 level, class_2680 state, class_3965 hit, class_1676 projectile) {
      if (!level.method_8608()) {
         class_2338 pos = hit.method_17777();
         if (projectile.method_36971((class_3218)level, pos)) {
            level.method_8650(pos, false);
            int id = class_2248.method_9507(class_2246.field_10033.method_9564());
            level.method_20290(2001, pos, id);
         }
      }
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{ROTATION, WATERLOGGED});
   }

   public @NonNull class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   public @NonNull class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
      return SHAPE;
   }

   public float method_9575(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
      return 1.0F;
   }

   public @NonNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
      int max = class_7718.method_45478() + 1;
      return (class_2680)state.method_11657(ROTATION, rotation.method_10502((Integer)state.method_11654(ROTATION), max));
   }

   public @NonNull class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
      int max = class_7718.method_45478() + 1;
      return (class_2680)pState.method_11657(ROTATION, pMirror.method_10344((Integer)pState.method_11654(ROTATION), max));
   }

   public class_2758 getRotationProperty() {
      return ROTATION;
   }
}
