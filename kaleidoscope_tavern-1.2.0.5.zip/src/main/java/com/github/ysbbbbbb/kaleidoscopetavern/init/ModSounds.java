package com.github.ysbbbbbb.kaleidoscopetavern.init;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ModSounds {
   public static final class_3414 EFFECT_VISION = registerSound("effect.vision");
   public static final class_3414 HOLDER_POP = registerSound("block.holder.pop");
   public static final class_3414 SHAKER_SHAKING = registerSound("item.shaker.shaking");
   public static final class_3414 SHAKER_END = registerSound("item.shaker.end");

   public static void registerSounds() {
   }

   private static class_3414 registerSound(String name) {
      return (class_3414)class_2378.method_10230(
         class_7923.field_41172,
         class_2960.method_60655("kaleidoscope_tavern", name),
         class_3414.method_47909(class_2960.method_60655("kaleidoscope_tavern", name), 16.0F)
      );
   }
}
