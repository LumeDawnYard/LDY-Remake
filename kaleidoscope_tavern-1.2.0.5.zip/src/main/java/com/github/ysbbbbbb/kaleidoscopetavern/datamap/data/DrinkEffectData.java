package com.github.ysbbbbbb.kaleidoscopetavern.datamap.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jspecify.annotations.NonNull;

public record DrinkEffectData(class_1792 item, List<List<DrinkEffectData.Entry>> effects) {
   public static final Codec<DrinkEffectData> CODEC = RecordCodecBuilder.create(
      instance -> instance.group(
            class_7923.field_41178.method_39673().fieldOf("item").forGetter(DrinkEffectData::item),
            Codec.list(Codec.list(DrinkEffectData.Entry.ENTRY_CODEC)).fieldOf("effects").forGetter(DrinkEffectData::effects)
         )
         .apply(instance, DrinkEffectData::new)
   );
   public static final class_9139<class_9129, DrinkEffectData> STREAM_CODEC = class_9139.method_56435(
      class_9135.method_56365(class_7924.field_41197),
      DrinkEffectData::item,
      DrinkEffectData.Entry.STREAM_CODEC.method_56433(class_9135.method_56363()).method_56433(class_9135.method_56363()),
      DrinkEffectData::effects,
      DrinkEffectData::new
   );

   @Override
   public @NonNull String toString() {
      return "DrinkEffect:{" + this.item.toString() + "---" + this.effects.toString() + "}";
   }

   public record Entry(class_6880<class_1291> effect, int duration, int amplifier, float probability) {
      public static final Codec<DrinkEffectData.Entry> ENTRY_CODEC = RecordCodecBuilder.create(
         instance -> instance.group(
               class_1291.field_51933.fieldOf("effect").forGetter(DrinkEffectData.Entry::effect),
               Codec.INT.fieldOf("duration").forGetter(DrinkEffectData.Entry::duration),
               Codec.INT.fieldOf("amplifier").forGetter(DrinkEffectData.Entry::amplifier),
               Codec.FLOAT.fieldOf("probability").forGetter(DrinkEffectData.Entry::probability)
            )
            .apply(instance, DrinkEffectData.Entry::new)
      );
      public static final class_9139<class_9129, DrinkEffectData.Entry> STREAM_CODEC = class_9139.method_56905(
         class_1291.field_51934,
         DrinkEffectData.Entry::effect,
         class_9135.field_48550,
         DrinkEffectData.Entry::duration,
         class_9135.field_48550,
         DrinkEffectData.Entry::amplifier,
         class_9135.field_48552,
         DrinkEffectData.Entry::probability,
         DrinkEffectData.Entry::new
      );
   }
}
