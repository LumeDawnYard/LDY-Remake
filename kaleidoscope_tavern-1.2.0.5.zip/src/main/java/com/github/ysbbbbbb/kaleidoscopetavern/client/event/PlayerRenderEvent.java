package com.github.ysbbbbbb.kaleidoscopetavern.client.event;

import com.github.ysbbbbbb.kaleidoscopetavern.effect.GrassStealthEffect;
import net.minecraft.class_11890;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import org.jetbrains.annotations.NotNull;

public class PlayerRenderEvent {
   public static boolean shouldCancelRender(@NotNull class_11890 player) {
      if (!player.method_5805()) {
         return false;
      }

      if (!player.method_5715()) {
         return false;
      }

      class_1937 level = player.method_73183();
      class_2338 pos = player.method_24515();
      class_2338 abovePos = pos.method_10084();
      return !GrassStealthEffect.notInGrassStealthPlant(level, pos) || !GrassStealthEffect.notInGrassStealthPlant(level, abovePos);
   }
}
