package com.github.ysbbbbbb.kaleidoscopetavern.client.render.renderstate;

import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11954;
import net.minecraft.class_2350;
import net.minecraft.class_3611;

@Environment(EnvType.CLIENT)
public class PressingTubBlockEntityRenderState extends class_11954 {
   public ItemStackHandler items;
   public class_2350 facing;
   public boolean tilt;
   public long seed;
   public class_10444 itemState = new class_10444();
   public class_3611 fluid;
   public int fluidAmount;
}
