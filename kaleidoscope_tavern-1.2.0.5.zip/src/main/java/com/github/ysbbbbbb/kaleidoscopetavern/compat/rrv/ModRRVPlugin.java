package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv;

import cc.cassian.rrv.api.ReliableRecipeViewerPlugin;
import cc.cassian.rrv.api.recipe.ItemView;
import cc.cassian.rrv.common.recipe.ServerRecipeManager;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.barrel.BarrelServerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.barrel.BarrelViewRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.pressing_tub.PressingTubServerRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.pressing_tub.PressingTubViewRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1856;

public class ModRRVPlugin implements ReliableRecipeViewerPlugin {
   public void onIntegrationInitialize() {
      ItemView.addServerRecipeProvider(
         list -> {
            ServerRecipeManager.INSTANCE.getRecipesForType(ModRecipes.BARREL_RECIPE).forEach(recipe -> {
               List<class_1856> ingredients = new ArrayList<>(recipe.ingredients());
               ingredients.addFirst(class_1856.method_8101(recipe.fluid().method_15774()));
               list.add(new BarrelServerRecipe(recipe.result(), ingredients, recipe.carrier()));
            });
            ServerRecipeManager.INSTANCE
               .getRecipesForType(ModRecipes.PRESSING_TUB_RECIPE)
               .forEach(recipe -> list.add(new PressingTubServerRecipe(recipe.getFluid().method_15774().method_7854(), recipe.method_64720())));
         }
      );
      ItemView.addClientRecipeWrapper(BarrelServerRecipe.TYPE, i -> Collections.singletonList(new BarrelViewRecipe(i)));
      ItemView.addClientRecipeWrapper(PressingTubServerRecipe.TYPE, i -> Collections.singletonList(new PressingTubViewRecipe(i)));
   }
}
