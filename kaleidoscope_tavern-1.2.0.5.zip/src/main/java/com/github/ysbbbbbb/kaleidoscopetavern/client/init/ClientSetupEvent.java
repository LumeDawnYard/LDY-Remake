package com.github.ysbbbbbb.kaleidoscopetavern.client.init;

import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.BarCabinetBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.BarStoolBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.BarrelBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.CellarCabinetBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.ChalkboardBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.CircularRackBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.GlasswareHolderBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.HolderBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.PressingTubBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.SandwichBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.ShakerBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.block.TiltedRackBlockEntityRender;
import com.github.ysbbbbbb.kaleidoscopetavern.client.render.entity.ThrownMolotovRenderer;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEntities;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5616;
import net.minecraft.class_5619;

@Environment(EnvType.CLIENT)
public final class ClientSetupEvent {
   public static void init() {
      class_5616.method_32144(ModBlocks.CHALKBOARD_BE, ChalkboardBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.SANDWICH_BOARD_BE, SandwichBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.PRESSING_TUB_BE, PressingTubBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.BARREL_BE, BarrelBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.BAR_CABINET_BE, BarCabinetBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.BAR_STOOL_BE, BarStoolBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.TILTED_RACK_BE, TiltedRackBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.CIRCULAR_RACK_BE, CircularRackBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.CELLAR_CABINET_BE, CellarCabinetBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.HOLDER_BE, HolderBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.SHAKER_BE, ShakerBlockEntityRender::new);
      class_5616.method_32144(ModBlocks.GLASSWARE_HOLDER_BE, GlasswareHolderBlockEntityRender::new);
      class_5619.method_32173(ModEntities.THROWN_MOLOTOV, ThrownMolotovRenderer::new);
   }
}
