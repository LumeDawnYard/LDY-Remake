package com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.IBarrel;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.BaseBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.container.BarrelRecipeContainer;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe.BarrelRecipe;
import com.github.ysbbbbbb.kaleidoscopetavern.crafting.serializer.BarrelRecipeSerializer;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.item.BottleBlockItem;
import com.github.ysbbbbbb.kaleidoscopetavern.util.ItemUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.CustomFluidTank;
import com.github.ysbbbbbb.kaleidoscopetavern.util.fluids.FluidUtils;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.IItemHandler;
import com.github.ysbbbbbb.kaleidoscopetavern.util.neo.ItemStackHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3544;
import net.minecraft.class_5250;
import net.minecraft.class_5894;
import net.minecraft.class_8786;
import net.minecraft.class_1863.class_7266;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class BarrelBlockEntity extends BaseBlockEntity implements IBarrel {
   private static final int CHECK_INTERVAL = 97;
   private static final String INGREDIENT_ITEMS_KEY = "ingredient_items";
   private static final String INGREDIENT_SIZE_KEY = "ingredient_size";
   private static final String OUTPUT_ITEMS_KEY = "output_items";
   private static final String OUTPUT_SIZE_KEY = "output_size";
   private final class_7266<BarrelRecipeContainer, BarrelRecipe> quickCheck = class_1863.method_42302(ModRecipes.BARREL_RECIPE);
   private final ItemStackHandler ingredient = new ItemStackHandler(4) {
      @Override
      public int getSlotLimit(int slot) {
         return 16;
      }

      @Override
      protected void onContentsChanged(int slot) {
         BarrelBlockEntity.this.refresh();
      }
   };
   private final ItemStackHandler output = new ItemStackHandler(1);
   private final CustomFluidTank fluid = new CustomFluidTank(toTransferAmount(), this::refresh);
   private boolean open = true;
   private int brewLevel = 0;
   private int brewTime = -1;
   @Nullable
   private class_2960 recipeId = null;
   @Nullable
   private class_8786<BarrelRecipe> recipeHolder = null;

   public BarrelBlockEntity(class_2338 pos, class_2680 state) {
      super(ModBlocks.BARREL_BE, pos, state);
   }

   public void tick(class_1937 level) {
      if (!this.open) {
         if (!this.isMaxBrewLevel()) {
            int offset = this.hashCode() % 97 + 97;
            long tick = level.method_75260() + offset;
            if (tick % 97L == 0L) {
               if (this.isBrewing()) {
                  if (this.brewTime > 0) {
                     this.brewTime -= 97;
                     this.refresh();
                  } else {
                     this.brewLevel = Math.min(this.brewLevel + 1, 6);
                     this.brewTime = this.getBrewTimeForLevel();
                     this.refresh();
                  }
               } else if (this.fluid.getFluidAmountMb() >= 4000) {
                  BarrelRecipeContainer container = new BarrelRecipeContainer(this.ingredient, this.fluid);
                  if (level instanceof class_3218 serverLevel) {
                     this.quickCheck.method_42303(container, serverLevel).ifPresentOrElse(holder -> {
                        BarrelRecipe recipe = (BarrelRecipe)holder.comp_1933();
                        class_1799 assemble = recipe.assemble(container, level.method_30349());
                        this.output.setStackInSlot(0, assemble);
                        this.recipeId = holder.comp_1932().method_29177();
                        this.recipeHolder = (class_8786<BarrelRecipe>)holder;
                        this.brewLevel = 1;
                        this.brewTime = this.getBrewTimeForLevel();
                        this.clearItemsAndFluid();
                        this.refresh();
                     }, () -> {
                        class_1799 assemble = new class_1799(ModItems.VINEGAR, 16);
                        this.output.setStackInSlot(0, assemble);
                        this.recipeId = BarrelRecipeSerializer.EMPTY_RECIPE_ID;
                        this.recipeHolder = null;
                        this.brewLevel = 1;
                        this.brewTime = this.getBrewTimeForLevel();
                        this.clearItemsAndFluid();
                        this.refresh();
                     });
                  }
               }
            }
         }
      }
   }

   public int getBrewTimeForLevel() {
      if (this.field_11863 == null || this.recipeId == null || this.recipeId.equals(BarrelRecipeSerializer.EMPTY_RECIPE_ID)) {
         return 2400 * this.brewLevel;
      }

      if (this.isMaxBrewLevel()) {
         return -1;
      }

      if (this.field_11863 instanceof class_3218 serverLevel) {
         class_8786<BarrelRecipe> holder = this.resolveRecipeHolder(serverLevel);
         if (holder != null) {
            return ((BarrelRecipe)holder.comp_1933()).unitTime() * this.brewLevel;
         }
      }

      return 2400 * this.brewLevel;
   }

   public void clearItemsAndFluid() {
      for (int i = 0; i < this.ingredient.getSlots(); i++) {
         if (!this.ingredient.getStackInSlot(i).method_7960()) {
            this.ingredient.setStackInSlot(i, class_1799.field_8037);
         }
      }

      this.fluid.drain(this.fluid.getFluidAmountTransfer(), CustomFluidTank.FluidAction.EXECUTE);
   }

   @Override
   public boolean openLid(@Nullable class_1309 user) {
      if (this.isBrewing()) {
         this.tip(user, "brewing_unable_to_open");
         return false;
      }

      this.open = true;
      this.refresh();
      if (this.field_11863 != null) {
         class_2338 pos = this.method_11016().method_10086(2);
         this.field_11863.method_45447(null, pos, class_3417.field_17604, class_3419.field_15245);
      }

      return true;
   }

   @Override
   public boolean closeLid(@Nullable class_1309 user) {
      this.open = false;
      this.refresh();
      if (this.field_11863 != null) {
         class_2338 pos = this.method_11016().method_10086(2);
         this.field_11863.method_45447(null, pos, class_3417.field_17604, class_3419.field_15245);
      }

      return true;
   }

   @Override
   public boolean addIngredient(@Nullable class_1309 user, class_1799 stack) {
      if (stack.method_7960()) {
         return false;
      }

      if (!this.open) {
         return false;
      }

      if (this.isBrewing()) {
         return false;
      }

      if (this.fluid.getFluidAmountMb() < 4000) {
         this.tip(user, "add_ingredient_fluid_not_full");
         return false;
      }

      int count = Math.min(16, stack.method_7947());
      class_1799 input = stack.method_46651(count);
      class_1799 remaining = this.addIngredientOnce(this.ingredient, input, false);
      if (remaining.method_7947() < count) {
         if (user != null) {
            user.method_43077(class_3417.field_14667);
         }

         stack.method_7934(count - remaining.method_7947());
         this.refresh();
         return true;
      } else {
         this.tip(user, "add_ingredient_no_space");
         return false;
      }
   }

   public class_1799 addIngredientOnce(IItemHandler inventory, class_1799 stack, boolean simulate) {
      if (stack.method_7960()) {
         return stack;
      }

      if (!stack.method_7946()) {
         int slots = inventory.getSlots();

         for (int i = 0; i < slots; i++) {
            if (inventory.getStackInSlot(i).method_7960()) {
               return inventory.insertItem(i, stack, simulate);
            }
         }

         return stack;
      } else {
         int slots = inventory.getSlots();
         int beforeCount = stack.method_7947();

         for (int i = 0; i < slots; i++) {
            class_1799 slot = inventory.getStackInSlot(i);
            if (class_1799.method_31577(slot, stack)) {
               stack = inventory.insertItem(i, stack, simulate);
               if (stack.method_7947() < beforeCount) {
                  return stack;
               }
            }
         }

         if (!stack.method_7960()) {
            for (int i = 0; i < slots; i++) {
               if (inventory.getStackInSlot(i).method_7960()) {
                  return inventory.insertItem(i, stack, simulate);
               }
            }
         }

         return stack;
      }
   }

   @Override
   public boolean removeIngredient(@NotNull class_1309 user) {
      if (!this.open) {
         return false;
      }

      if (this.isBrewing()) {
         return false;
      }

      if (this.fluid.getFluidAmountMb() < 4000) {
         this.tip(user, "add_ingredient_fluid_not_full");
         return false;
      }

      for (int i = this.ingredient.getSlots() - 1; i >= 0; i--) {
         class_1799 stack = this.ingredient.getStackInSlot(i);
         if (!stack.method_7960()) {
            class_1799 removed = this.ingredient.extractItem(i, stack.method_7947(), false);
            user.method_43077(class_3417.field_14770);
            ItemUtils.getItemToLivingEntity(user, removed);
            this.refresh();
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean addFluid(@NotNull class_1309 user, class_1799 stack) {
      if (!this.open) {
         return false;
      }

      if (this.isBrewing()) {
         return false;
      }

      for (int i = 0; i < this.ingredient.getSlots(); i++) {
         if (!this.ingredient.getStackInSlot(i).method_7960()) {
            this.tip(user, "add_fluid_ingredient_not_empty");
            return false;
         }
      }

      boolean result = FluidUtils.emptyItem(user, stack, this.fluid, 4000);
      if (result) {
         this.refresh();
      }

      return result;
   }

   @Override
   public boolean removeFluid(@NotNull class_1309 user, class_1799 stack) {
      if (!this.open) {
         return false;
      }

      if (this.isBrewing()) {
         return false;
      }

      for (int i = 0; i < this.ingredient.getSlots(); i++) {
         if (!this.ingredient.getStackInSlot(i).method_7960()) {
            this.tip(user, "remove_fluid_ingredient_not_empty");
            return false;
         }
      }

      boolean result = FluidUtils.fillItem(user, stack, this.fluid, 4000);
      if (result) {
         this.refresh();
      }

      return result;
   }

   @Override
   public boolean canTapExtract(class_1937 level, class_2338 tapPos, @Nullable class_1309 user) {
      if (!this.isBrewing()) {
         this.tip(user, "tap_extract_not_brewing");
         return false;
      }

      if (this.output.getStackInSlot(0).method_7960()) {
         this.tip(user, "tap_extract_empty");
         return false;
      }

      class_2248 below = level.method_8320(tapPos.method_10074()).method_26204();
      if (below == class_2246.field_10124) {
         this.tip(user, "tap_extract_empty_container");
         return false;
      }

      if (below.method_8389() instanceof class_1747 blockItem) {
         if (this.recipeId == null || this.recipeId.equals(BarrelRecipeSerializer.EMPTY_RECIPE_ID)) {
            return below == ModBlocks.EMPTY_BOTTLE;
         } else if (level instanceof class_3218 serverLevel) {
            class_8786<BarrelRecipe> holder = this.resolveRecipeHolder(serverLevel);
            return holder == null ? false : ((BarrelRecipe)holder.comp_1933()).carrier().method_8093(blockItem.method_7854());
         } else {
            return false;
         }
      } else {
         this.tip(user, "tap_extract_invalid_container");
         return false;
      }
   }

   @Override
   public void doTapExtract(class_1937 level, class_2338 tapPos) {
      if (this.isBrewing()) {
         if (!this.output.getStackInSlot(0).method_7960()) {
            class_2338 below = tapPos.method_10074();
            class_2680 belowState = level.method_8320(below);
            if (this.recipeId != null && !this.recipeId.equals(BarrelRecipeSerializer.EMPTY_RECIPE_ID)) {
               if (level instanceof class_3218 serverLevel) {
                  class_8786<BarrelRecipe> holder = this.resolveRecipeHolder(serverLevel);
                  if (holder == null) {
                     if (belowState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
                        this.transform(level, below, belowState, (BottleBlockItem)ModItems.VINEGAR);
                     }
                  } else {
                     BarrelRecipe barrelRecipe = (BarrelRecipe)holder.comp_1933();
                     class_1799 belowStack = belowState.method_26204().method_8389().method_7854();
                     if (barrelRecipe.carrier().method_8093(belowStack)) {
                        this.transform(level, below, belowState, (BottleBlockItem)barrelRecipe.result().method_7909());
                     }
                  }
               }
            } else {
               if (belowState.method_27852(ModBlocks.EMPTY_BOTTLE)) {
                  this.transform(level, below, belowState, (BottleBlockItem)ModItems.VINEGAR);
               }
            }
         }
      }
   }

   private void transform(class_1937 level, class_2338 below, class_2680 belowState, BottleBlockItem result) {
      class_1799 stack = this.output.extractItem(0, 1, false);
      if (!stack.method_7960()) {
         this.refresh();
      }

      class_2680 state = result.method_7711().method_9564();
      if (state.method_28498(class_2741.field_12481) && belowState.method_28498(class_2741.field_12481)) {
         state = (class_2680)state.method_11657(class_2741.field_12481, (class_2350)belowState.method_11654(class_2741.field_12481));
      }

      level.method_8501(below, state);
      class_1799 filledStack = result.getFilledStack(this.getBrewLevel());
      if (level.method_8321(below) instanceof DrinkBlockEntity drinkBlock) {
         drinkBlock.addItem(filledStack);
      }

      if (this.output.getStackInSlot(0).method_7960()) {
         this.clearItemsAndFluid();
         this.recipeId = null;
         this.recipeHolder = null;
         this.brewLevel = 0;
         this.brewTime = -1;
         this.refresh();
      }
   }

   protected void method_11014(@NonNull class_11368 valueInput) {
      super.method_11014(valueInput);
      if (!valueInput.contains("ingredient_items") && !valueInput.contains("ingredient_size")) {
         this.ingredient.deserializeNBT(valueInput);
      } else {
         this.ingredient.deserializeNBT(valueInput, "ingredient_items", "ingredient_size");
      }

      this.normalizeIngredientInventory();
      if (!valueInput.contains("output_items") && !valueInput.contains("output_size")) {
         this.output.deserializeNBT(valueInput);
      } else {
         this.output.deserializeNBT(valueInput, "output_items", "output_size");
      }

      this.fluid.readFromNBT(valueInput);
      this.open = valueInput.method_71433("open", true);
      this.brewLevel = BottleBlockItem.clampBrewLevel(valueInput.method_71424("brew_level", 0));
      this.brewTime = valueInput.method_71424("brew_time", -1);
      this.recipeId = valueInput.method_71441("recipe_id").<class_2960>map(class_2960::method_60654).orElse(null);
      this.recipeHolder = null;
   }

   protected void method_11007(@NonNull class_11372 valueOutput) {
      super.method_11007(valueOutput);
      this.ingredient.serialize(valueOutput, "ingredient_items", "ingredient_size");
      this.output.serialize(valueOutput, "output_items", "output_size");
      this.fluid.writeToNBT(valueOutput);
      valueOutput.method_71472("open", this.open);
      valueOutput.method_71465("brew_level", this.getBrewLevel());
      valueOutput.method_71465("brew_time", this.brewTime);
      valueOutput.method_71469("recipe_id", this.recipeId == null ? "" : this.recipeId.toString());
   }

   public void tip(@Nullable class_1309 entity, String key) {
      if (entity instanceof class_3222 player) {
         class_2561 message = class_2561.method_43471("message.kaleidoscope_tavern.barrel.%s".formatted(key));
         player.field_13987.method_14364(new class_5894(message));
      }
   }

   public void tipBrewInfo(@Nullable class_1309 entity) {
      if (entity instanceof class_3222 player) {
         class_1799 result = this.output.getStackInSlot(0);
         class_2561 resultText = result.method_7964();
         class_5250 levelText = class_2561.method_43471("message.kaleidoscope_tavern.barrel.brew_level.%d".formatted(this.getBrewLevel()));
         if (!this.isBrewing()) {
            class_2561 message = class_2561.method_43471("message.kaleidoscope_tavern.barrel.not_brewing");
            player.field_13987.method_14364(new class_5894(message));
         } else if (this.isMaxBrewLevel()) {
            class_2561 message = class_2561.method_43469(
               "message.kaleidoscope_tavern.barrel.brew_info.full", new Object[]{resultText, result.method_7947(), levelText}
            );
            player.field_13987.method_14364(new class_5894(message));
         } else {
            class_2561 timeText = class_2561.method_43470(class_3544.method_15439(Math.max(this.brewTime, 0), 20.0F));
            class_2561 message = class_2561.method_43469(
               "message.kaleidoscope_tavern.barrel.brew_info.next", new Object[]{resultText, result.method_7947(), levelText, timeText}
            );
            player.field_13987.method_14364(new class_5894(message));
         }
      }
   }

   @Override
   public boolean isBrewing() {
      return this.getBrewLevel() >= 1;
   }

   @Override
   public boolean isMaxBrewLevel() {
      return this.getBrewLevel() >= 6;
   }

   @Override
   public ItemStackHandler getIngredient() {
      return this.ingredient;
   }

   @Override
   public CustomFluidTank getFluid() {
      return this.fluid;
   }

   @Override
   public void setOpen(boolean open) {
      this.open = open;
   }

   @Override
   public boolean isOpen() {
      return this.open;
   }

   @Override
   public int getBrewLevel() {
      return BottleBlockItem.clampBrewLevel(this.brewLevel);
   }

   @Override
   public int getBrewTime() {
      return this.brewTime;
   }

   @Override
   public ItemStackHandler getOutput() {
      return this.output;
   }

   @Nullable
   @Override
   public class_2960 getRecipeId() {
      return this.recipeId;
   }

   @Nullable
   private class_8786<BarrelRecipe> resolveRecipeHolder(class_3218 serverLevel) {
      if (this.recipeId != null && !this.recipeId.equals(BarrelRecipeSerializer.EMPTY_RECIPE_ID)) {
         if (this.recipeHolder != null && this.recipeHolder.comp_1932().method_29177().equals(this.recipeId)) {
            return this.recipeHolder;
         }

         this.recipeHolder = serverLevel.method_64577()
            .getSynchronizedRecipes()
            .getAllOfType(ModRecipes.BARREL_RECIPE)
            .stream()
            .filter(holder -> holder.comp_1932().method_29177().equals(this.recipeId))
            .findFirst()
            .orElse(null);
         return this.recipeHolder;
      } else {
         this.recipeHolder = null;
         return null;
      }
   }

   private void normalizeIngredientInventory() {
      int currentSlots = this.ingredient.getSlots();
      if (currentSlots == 4) {
         for (int i = 0; i < currentSlots; i++) {
            class_1799 slot = this.ingredient.getStackInSlot(i);
            int limit = this.ingredient.getSlotLimit(i);
            if (!slot.method_7960() && slot.method_7947() > limit) {
               this.ingredient.setStackInSlot(i, slot.method_46651(limit));
            }
         }
      } else {
         class_1799[] oldStacks = new class_1799[currentSlots];

         for (int i = 0; i < currentSlots; i++) {
            oldStacks[i] = this.ingredient.getStackInSlot(i).method_7972();
         }

         this.ingredient.setSize(4);

         for (class_1799 oldStack : oldStacks) {
            if (!oldStack.method_7960()) {
               ItemUtils.insertItem(this.ingredient, oldStack, false);
            }
         }
      }
   }

   private static long toTransferAmount() {
      return 324000L;
   }
}
