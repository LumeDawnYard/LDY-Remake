package com.github.ysbbbbbb.kaleidoscopetavern.mixin.client;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_757.class)
public class GameRendererMixin {
   @Unique
   private static final float TIPSY_NAUSEA_FACTOR = 0.18F;
   @Unique
   private static final float TIPSY_SPINNING_SPEED = 2.23F;
   @Shadow
   @Final
   private class_310 field_4015;

   @ModifyExpressionValue(method = "method_3182", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_746;method_66279(Lnet/minecraft/class_6880;F)F"))
   private float includeTipsyInSpinningTick(float nauseaIntensity) {
      return Math.max(nauseaIntensity, this.getTipsySpinningIntensity(1.0F));
   }

   @ModifyExpressionValue(method = "method_3182", at = @At(value = "CONSTANT", args = "floatValue=7.0F"))
   private float slowTipsySpinningSpeed(float nauseaSpinningSpeed) {
      class_746 player = this.field_4015.field_1724;
      if (player == null) {
         return nauseaSpinningSpeed;
      }

      float tipsyIntensity = this.getTipsySpinningIntensity(1.0F);
      float nauseaIntensity = player.method_66279(class_1294.field_5916, 1.0F);
      return tipsyIntensity > nauseaIntensity ? 2.23F : nauseaSpinningSpeed;
   }

   @ModifyExpressionValue(method = "method_3188", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_746;method_66279(Lnet/minecraft/class_6880;F)F"))
   private float includeTipsyInSpinningRender(float nauseaIntensity, class_9779 deltaTracker) {
      float partialTicks = deltaTracker.method_60637(false);
      return Math.max(nauseaIntensity, this.getTipsySpinningIntensity(partialTicks));
   }

   @Unique
   private float getTipsySpinningIntensity(float partialTicks) {
      class_746 player = this.field_4015.field_1724;
      return player != null && ModEffects.SLIGHTLY_TIPSY != null ? player.method_66279(ModEffects.SLIGHTLY_TIPSY, partialTicks) * 0.18F : 0.0F;
   }
}
