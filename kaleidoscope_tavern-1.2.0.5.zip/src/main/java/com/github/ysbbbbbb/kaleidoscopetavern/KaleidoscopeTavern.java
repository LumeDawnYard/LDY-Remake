package com.github.ysbbbbbb.kaleidoscopetavern;

import com.github.ysbbbbbb.kaleidoscopetavern.compat.jei.ModJeiPlugin;
import com.github.ysbbbbbb.kaleidoscopetavern.config.GeneralConfig;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModCreativeTabs;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModDataComponents;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEntities;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModFluids;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModSounds;
import com.github.ysbbbbbb.kaleidoscopetavern.init.registery.CommonRegistry;
import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.neoforged.fml.config.ModConfig.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class KaleidoscopeTavern implements ModInitializer {
   public static final String MOD_ID = "kaleidoscope_tavern";
   public static final Logger LOGGER = LoggerFactory.getLogger("kaleidoscope_tavern");

   public void onInitialize() {
      ConfigRegistry.INSTANCE.register("kaleidoscope_tavern", Type.COMMON, GeneralConfig.init());
      CommonRegistry.init();
      ModEffects.registerEffects();
      ModDataComponents.register();
      ModBlocks.registerBlocks();
      ModItems.registerItems();
      ModFluids.registerFluids();
      ModRecipes.registerRecipes();
      ModEntities.registerEntities();
      ModCreativeTabs.registerTabs();
      ModSounds.registerSounds();
      ModParticles.registerParticles();
      if (FabricLoader.getInstance().isModLoaded("jei")) {
         ModJeiPlugin.syncRecipes();
      }
   }
}
