package com.github.ysbbbbbb.kaleidoscopetavern.client.model.brew;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class BarrelModel extends class_3879<BarrelModel.State> {
   public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655("kaleidoscope_tavern", "barrel"), "main");
   private final class_630 root;
   private final class_630 close;
   private final class_630 open;
   private final class_630 body;

   public BarrelModel(class_630 root) {
      super(root, class_12249::method_75994);
      this.root = root.method_32086("root");
      this.close = this.root.method_32086("close");
      this.open = this.root.method_32086("open");
      this.body = this.root.method_32086("body");
   }

   public static class_5607 createBodyLayer() {
      class_5609 meshdefinition = new class_5609();
      class_5610 partdefinition = meshdefinition.method_32111();
      class_5610 root = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(8.0F, 9.0F, -9.0F));
      class_5610 close = root.method_32117(
         "close",
         class_5606.method_32108().method_32101(102, 113).method_32098(-16.0F, -33.0F, 1.0F, 16.0F, 2.0F, 16.0F, new class_5605(0.0F)),
         class_5603.method_32090(0.0F, 0.0F, 0.0F)
      );
      class_5610 open = root.method_32117("open", class_5606.method_32108(), class_5603.method_32091(-8.0F, -33.0F, -1.0F, 1.309F, 0.0F, 0.0F));
      class_5610 open_r1 = open.method_32117(
         "open_r1",
         class_5606.method_32108()
            .method_32101(106, 114)
            .method_32096()
            .method_32098(0.0F, -4.0F, -12.0F, 0.0F, 2.0F, 20.0F, new class_5605(0.0F))
            .method_32106(false),
         class_5603.method_32091(7.0F, 9.7654F, 5.0978F, -0.6109F, 0.0F, 0.0F)
      );
      class_5610 open_r2 = open.method_32117(
         "open_r2",
         class_5606.method_32108().method_32101(102, 113).method_32098(-8.0F, -2.4F, -2.8F, 16.0F, 2.0F, 16.0F, new class_5605(0.0F)),
         class_5603.method_32091(0.0F, 17.0F, 8.0F, 0.5672F, 0.0F, 0.0F)
      );
      class_5610 body = root.method_32117(
         "body",
         class_5606.method_32108()
            .method_32101(28, 136)
            .method_32098(6.0F, 7.0F, -10.0F, 4.0F, 8.0F, 4.0F, new class_5605(0.0F))
            .method_32101(28, 136)
            .method_32098(-26.0F, 7.0F, -10.0F, 4.0F, 8.0F, 4.0F, new class_5605(0.0F))
            .method_32101(174, 118)
            .method_32098(-22.0F, 7.0F, -8.0F, 28.0F, 4.0F, 2.0F, new class_5605(0.0F))
            .method_32101(174, 118)
            .method_32098(-22.0F, 7.0F, 22.0F, 28.0F, 4.0F, 2.0F, new class_5605(0.0F))
            .method_32101(28, 136)
            .method_32098(6.0F, 7.0F, 22.0F, 4.0F, 8.0F, 4.0F, new class_5605(0.0F))
            .method_32101(28, 136)
            .method_32098(-26.0F, 7.0F, 22.0F, 4.0F, 8.0F, 4.0F, new class_5605(0.0F))
            .method_32101(0, 0)
            .method_32098(-28.0F, -33.0F, -15.0F, 40.0F, 40.0F, 48.0F, new class_5605(0.0F))
            .method_32101(0, 160)
            .method_32098(-16.0F, -33.0F, 1.0F, 16.0F, 21.0F, 0.0F, new class_5605(0.0F))
            .method_32101(0, 144)
            .method_32098(0.0F, -33.0F, 1.0F, 0.0F, 24.0F, 16.0F, new class_5605(0.0F))
            .method_32101(0, 144)
            .method_32098(-16.0F, -33.0F, 1.0F, 0.0F, 21.0F, 16.0F, new class_5605(0.0F))
            .method_32101(32, 160)
            .method_32098(-16.0F, -12.0F, 1.0F, 16.0F, 0.0F, 16.0F, new class_5605(0.0F))
            .method_32101(0, 160)
            .method_32098(-16.0F, -33.0F, 17.0F, 16.0F, 21.0F, 0.0F, new class_5605(0.0F)),
         class_5603.method_32090(0.0F, 0.0F, 0.0F)
      );
      return class_5607.method_32110(meshdefinition, 256, 256);
   }

   public void setupAnim(BarrelModel.State object) {
      super.method_2819(object);
      boolean open = object.open();
      this.getOpen().field_3665 = open;
      this.getClose().field_3665 = !open;
   }

   public class_630 getClose() {
      return this.close;
   }

   public class_630 getOpen() {
      return this.open;
   }

   @Environment(EnvType.CLIENT)
   public record State(boolean open) {
   }
}
