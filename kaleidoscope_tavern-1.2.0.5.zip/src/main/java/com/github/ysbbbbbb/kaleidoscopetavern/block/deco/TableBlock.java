package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class TableBlock extends class_2248 implements class_3737 {
   public static final class_2754<class_2351> AXIS = class_2741.field_12529;
   public static final class_2758 POSITION = class_2758.method_11867("position", 0, 3);
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 SHAPE = class_2248.method_9541(0.0, 13.0, 0.0, 16.0, 16.0, 16.0);
   public static final int SINGLE = 0;
   public static final int LEFT = 1;
   public static final int MIDDLE = 2;
   public static final int RIGHT = 3;

   public TableBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12651)
            .method_9629(2.0F, 3.0F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(AXIS, class_2351.field_11051))
               .method_11657(POSITION, 0))
            .method_11657(WATERLOGGED, false)
      );
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{AXIS, POSITION, WATERLOGGED});
   }

   private class_2680 checkEastWestState(class_4538 LevelReader, class_2338 pos, class_2680 baseState) {
      if (baseState.method_11654(AXIS) == class_2351.field_11051 && (Integer)baseState.method_11654(POSITION) != 0) {
         return baseState;
      } else {
         class_2680 westState = LevelReader.method_8320(pos.method_10067());
         class_2680 eastState = LevelReader.method_8320(pos.method_10078());
         if (this.checkIfShouldLink(eastState, class_2351.field_11051) && this.checkIfShouldLink(westState, class_2351.field_11051)) {
            return (class_2680)((class_2680)baseState.method_11657(POSITION, 2)).method_11657(AXIS, class_2351.field_11048);
         } else if (this.checkIfShouldLink(eastState, class_2351.field_11051) && !this.checkIfShouldLink(westState, class_2351.field_11051)) {
            return (class_2680)((class_2680)baseState.method_11657(POSITION, 1)).method_11657(AXIS, class_2351.field_11048);
         } else {
            return !this.checkIfShouldLink(eastState, class_2351.field_11051) && this.checkIfShouldLink(westState, class_2351.field_11051)
               ? (class_2680)((class_2680)baseState.method_11657(POSITION, 3)).method_11657(AXIS, class_2351.field_11048)
               : (class_2680)baseState.method_11657(POSITION, 0);
         }
      }
   }

   private class_2680 checkNorthSouthState(class_4538 LevelReader, class_2338 pos, class_2680 baseState) {
      if (baseState.method_11654(AXIS) == class_2351.field_11048 && (Integer)baseState.method_11654(POSITION) != 0) {
         return baseState;
      } else {
         class_2680 northState = LevelReader.method_8320(pos.method_10095());
         class_2680 southState = LevelReader.method_8320(pos.method_10072());
         if (this.checkIfShouldLink(southState, class_2351.field_11048) && this.checkIfShouldLink(northState, class_2351.field_11048)) {
            return (class_2680)((class_2680)baseState.method_11657(POSITION, 2)).method_11657(AXIS, class_2351.field_11051);
         } else if (this.checkIfShouldLink(southState, class_2351.field_11048) && !this.checkIfShouldLink(northState, class_2351.field_11048)) {
            return (class_2680)((class_2680)baseState.method_11657(POSITION, 1)).method_11657(AXIS, class_2351.field_11051);
         } else {
            return !this.checkIfShouldLink(southState, class_2351.field_11048) && this.checkIfShouldLink(northState, class_2351.field_11048)
               ? (class_2680)((class_2680)baseState.method_11657(POSITION, 3)).method_11657(AXIS, class_2351.field_11051)
               : (class_2680)baseState.method_11657(POSITION, 0);
         }
      }
   }

   private boolean checkIfShouldLink(class_2680 state, class_2351 axis) {
      if (!state.method_27852(this)) {
         return false;
      } else {
         return state.method_11654(AXIS) == axis ? (Integer)state.method_11654(POSITION) == 0 : true;
      }
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 state,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)state.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      if (direction.method_10166() == class_2351.field_11048) {
         return this.checkEastWestState(levelReader, blockPos, state);
      } else {
         return direction.method_10166() == class_2351.field_11051 ? this.checkNorthSouthState(levelReader, blockPos, state) : state;
      }
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 clickedPos = context.method_8037();
      class_2350 direction = context.method_8042();
      boolean hasWater = level.method_8316(clickedPos).method_15772() == class_3612.field_15910;
      class_2680 base = (class_2680)this.method_9564().method_11657(WATERLOGGED, hasWater);
      if (direction.method_10166() == class_2351.field_11048) {
         return this.checkNorthSouthState(level, clickedPos, base);
      } else {
         return direction.method_10166() == class_2351.field_11051 ? this.checkEastWestState(level, clickedPos, base) : base;
      }
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(@NonNull class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      return SHAPE;
   }

   protected boolean method_9516(@NonNull class_2680 state, @NonNull class_10 pathComputationType) {
      return false;
   }
}
