package com.github.ysbbbbbb.kaleidoscopetavern.game.tap.impl;

import com.github.ysbbbbbb.kaleidoscopetavern.api.blockentity.ITapBehavior;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.BarrelBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.block.brew.TapBlock;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.brew.BarrelBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModParticles;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class BarrelTapBehavior implements ITapBehavior {
   @Override
   public boolean isMatch(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      class_2350 tapFacing = (class_2350)tapState.method_11654(TapBlock.FACING);
      if (!this.isValidConnection(sourceState, tapFacing)) {
         return false;
      }

      class_2338 relative = tapPos.method_10093(tapFacing.method_10153());
      class_2680 barrelState = level.method_8320(relative);
      BarrelBlockEntity barrelEntity = BarrelBlock.getBarrelEntity(level, relative, barrelState);
      return barrelEntity == null ? false : barrelEntity.canTapExtract(level, tapPos, player);
   }

   @Override
   public class_2394 onStartExtract(
      class_1937 level, @Nullable class_1657 player, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState
   ) {
      class_2350 tapFacing = (class_2350)tapState.method_11654(TapBlock.FACING);
      class_2338 relative = tapPos.method_10093(tapFacing.method_10153());
      class_2680 barrelState = level.method_8320(relative);
      BarrelBlockEntity barrelEntity = BarrelBlock.getBarrelEntity(level, relative, barrelState);
      if (barrelEntity == null) {
         return null;
      }

      class_2394 particle = ModParticles.WATER_TAP_DRIP;
      if (barrelEntity.getOutput().getStackInSlot(0).method_31574(ModItems.MOLOTOV)) {
         particle = ModParticles.LAVA_TAP_DRIP;
      }

      return particle;
   }

   @Override
   public void onEndExtract(class_1937 level, class_2338 tapPos, class_2680 tapState, class_2680 sourceState, class_2680 destinationState) {
      class_2350 tapFacing = (class_2350)tapState.method_11654(TapBlock.FACING);
      class_2338 relative = tapPos.method_10093(tapFacing.method_10153());
      class_2680 barrelState = level.method_8320(relative);
      BarrelBlockEntity barrelEntity = BarrelBlock.getBarrelEntity(level, relative, barrelState);
      if (barrelEntity != null) {
         barrelEntity.doTapExtract(level, tapPos);
         level.method_8396(null, tapPos.method_10074(), class_3417.field_14978, class_3419.field_15245, 1.0F, 1.0F);
         ITapBehavior.sendParticles(level, tapPos);
      }
   }

   private boolean isValidConnection(class_2680 barrelState, class_2350 tapFacing) {
      class_2350 barrelFacing = (class_2350)barrelState.method_11654(BarrelBlock.FACING);
      class_2738 layer = (class_2738)barrelState.method_11654(BarrelBlock.LAYER);
      int index = (Integer)barrelState.method_11654(BarrelBlock.INDEX);
      if (layer == class_2738.field_12471) {
         if (barrelFacing == class_2350.field_11043 && index == 1) {
            return tapFacing == class_2350.field_11043;
         }

         if (barrelFacing == class_2350.field_11035 && index == 7) {
            return tapFacing == class_2350.field_11035;
         }

         if (barrelFacing == class_2350.field_11039 && index == 3) {
            return tapFacing == class_2350.field_11039;
         }

         if (barrelFacing == class_2350.field_11034 && index == 5) {
            return tapFacing == class_2350.field_11034;
         }
      }

      return false;
   }
}
