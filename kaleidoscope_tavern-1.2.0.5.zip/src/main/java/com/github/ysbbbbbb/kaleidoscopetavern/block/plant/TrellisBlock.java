package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.api.event.PlantGrapeEvent;
import com.github.ysbbbbbb.kaleidoscopetavern.block.properties.TrellisType;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModBlocks;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class TrellisBlock extends class_2248 implements class_3737, ITrellis {
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_2746 WAXED = class_2746.method_11825("waxed");

   public TrellisBlock(class_2251 properties) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(TYPE, TrellisType.SINGLE)).method_11657(WAXED, false))
            .method_11657(WATERLOGGED, false)
      );
   }

   @NotNull
   public class_1269 method_55765(
      @NonNull class_1799 stack,
      class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      boolean waxed = (Boolean)state.method_11654(WAXED);
      if (waxed && player.method_5998(hand).method_31573(class_3489.field_42612)) {
         level.method_8501(pos, (class_2680)state.method_11657(WAXED, false));
         level.method_8396(player, pos, class_3417.field_29542, class_3419.field_15245, 1.0F, 1.0F);
         level.method_8444(player, 3004, pos, 0);
         return class_1269.field_5812;
      }

      if (!waxed && player.method_5998(hand).method_31574(class_1802.field_20414)) {
         level.method_8501(pos, (class_2680)state.method_11657(WAXED, true));
         level.method_8396(player, pos, class_3417.field_29543, class_3419.field_15245, 1.0F, 1.0F);
         level.method_8444(player, 3003, pos, 0);
         return class_1269.field_5812;
      }

      class_1799 itemInHand = player.method_5998(hand);
      if (!itemInHand.method_31574(ModItems.GRAPEVINE)) {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }

      TrellisType type = (TrellisType)state.method_11654(TYPE);
      if (type != TrellisType.SINGLE) {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }

      PlantGrapeEvent plantGrapeEvent = new PlantGrapeEvent(state, level, pos, player, hand, hitResult);
      plantGrapeEvent.post();
      return class_1269.field_5812;
   }

   protected @NonNull class_2680 method_9559(
      class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      boolean xHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11048);
      boolean yHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11052);
      boolean zHas = ITrellis.axisHasTrellis(levelReader, blockPos, class_2351.field_11051);
      TrellisType trellisType = ITrellis.updateType((TrellisType)blockState.method_11654(TYPE), xHas, yHas, zHas);
      blockState = (class_2680)blockState.method_11657(TYPE, trellisType);
      return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
   }

   @Override
   public boolean sameType(class_2680 state) {
      return state.method_27852(ModBlocks.TRELLIS) || state.method_27852(ModBlocks.GRAPEVINE_TRELLIS);
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_1937 level = context.method_8045();
      class_2338 pos = context.method_8037();
      class_2351 clickAxis = context.method_8038().method_10166();
      boolean xHas = ITrellis.axisHasTrellis(level, pos, class_2351.field_11048);
      boolean yHas = ITrellis.axisHasTrellis(level, pos, class_2351.field_11052);
      boolean zHas = ITrellis.axisHasTrellis(level, pos, class_2351.field_11051);
      TrellisType type = ITrellis.getTypeForPlacement(xHas, yHas, zHas, clickAxis);
      return (class_2680)((class_2680)this.method_9564().method_11657(TYPE, type)).method_11657(WATERLOGGED, level.method_22351(pos));
   }

   @NotNull
   public class_265 method_9549(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      return this.collisionShape((TrellisType)state.method_11654(TYPE));
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      return this.selectShape((TrellisType)state.method_11654(TYPE));
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{TYPE, WAXED, WATERLOGGED});
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }
}
