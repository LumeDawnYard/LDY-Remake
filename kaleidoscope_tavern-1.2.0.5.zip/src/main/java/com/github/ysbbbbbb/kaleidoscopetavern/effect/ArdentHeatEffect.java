package com.github.ysbbbbbb.kaleidoscopetavern.effect;

import com.github.ysbbbbbb.kaleidoscopetavern.api.entity.PlayerExtraData;
import com.github.ysbbbbbb.kaleidoscopetavern.init.ModEffects;
import com.github.ysbbbbbb.kaleidoscopetavern.init.tag.TagMod;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_2350.class_2351;

public class ArdentHeatEffect extends BaseEffect {
   private static final String COLLISION_COUNT_TAG = "kaleidoscope_tavern:ardent_heat_collision_count";
   private static final class_1304[] ARMOR_SLOTS = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

   public ArdentHeatEffect(int color) {
      super(color);
   }

   @Override
   public boolean method_5552(int duration, int amplifier) {
      return true;
   }

   @Override
   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      if (!(livingEntity instanceof class_1657 player)) {
         return true;
      } else {
         class_1937 level = player.method_73183();
         if (level.method_8608()) {
            return true;
         }

         class_1293 instance = player.method_6112(ModEffects.ARDENT_HEAT);
         if (instance != null && instance.method_5584() <= 1) {
            player.method_6092(new class_1293(class_1294.field_5903, 600, 0));
         }

         if (!player.method_5624()) {
            return true;
         }

         class_2350 facing = player.method_5735();
         boolean brokeBlocks = false;

         for (class_2338 pos : getFrontBlocks(player.method_24515(), facing)) {
            class_2680 state = level.method_8320(pos);
            if (state.method_26164(TagMod.ARDENT_HEAT_BREAKABLE)) {
               level.method_8651(pos, true, player);
               brokeBlocks = true;
            }
         }

         if (brokeBlocks) {
            player.method_7322(1.2F);
            List<class_1304> slots = Lists.newArrayList();

            for (class_1304 slot : ARMOR_SLOTS) {
               class_1799 armor = player.method_6118(slot);
               if (!armor.method_7960()) {
                  slots.add(slot);
               }
            }

            if (!slots.isEmpty()) {
               int index = level.field_9229.method_43048(slots.size());
               class_1304 selected = slots.get(index);
               class_1799 armor = player.method_6118(selected);
               if (armor.method_7963()) {
                  armor.method_7970(1, player, selected);
               }
            } else {
               class_2487 data = ((PlayerExtraData)player).kaleidoscope_tavern$getPersistentData();
               int count = data.method_10550("kaleidoscope_tavern:ardent_heat_collision_count").orElse(0) + 1;
               if (count >= 5) {
                  player.method_64419(player.method_48923().method_48830(), 1.0F);
                  count -= 5;
               }

               data.method_10569("kaleidoscope_tavern:ardent_heat_collision_count", count);
            }
         }

         return true;
      }
   }

   private static List<class_2338> getFrontBlocks(class_2338 playerPos, class_2350 facing) {
      List<class_2338> positions = new ArrayList<>();
      class_2338 center = playerPos.method_10093(facing);
      class_2351 facingAxis = facing.method_10166();

      for (int dy = 0; dy <= 2; dy++) {
         for (int d = -1; d <= 1; d++) {
            class_2338 pos;
            if (facingAxis == class_2351.field_11051) {
               pos = center.method_10069(d, dy, 0);
            } else {
               pos = center.method_10069(0, dy, d);
            }

            positions.add(pos);
         }
      }

      return positions;
   }
}
