package com.github.ysbbbbbb.kaleidoscopetavern.block.plant;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopetavern.util.PortHelper;
import com.github.ysbbbbbb.kaleidoscopetavern.util.event.EventHooks;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2250;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class GrapeCropBlock extends class_2248 implements class_2256 {
   public static final class_2758 AGE = class_2741.field_12482;
   public static final int MAX_AGE = 5;
   public static final class_265 SHAPE = class_2248.method_9541(2.0, 6.0, 2.0, 14.0, 16.0, 14.0);
   private final GrowPerTickProbability probability;
   private final Supplier<class_1799> shearResult;

   public GrapeCropBlock(class_2251 properties, GrowPerTickProbability probability, Supplier<class_1799> shearResult) {
      super(
         properties.method_31710(class_3620.field_16004)
            .method_22488()
            .method_9640()
            .method_9618()
            .method_9626(class_2498.field_17580)
            .method_49229(class_2250.field_10655)
            .method_9624()
            .method_50012(class_3619.field_15971)
      );
      this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(AGE, 0));
      this.probability = probability;
      this.shearResult = shearResult;
   }

   @Deprecated(since = "1.1.0")
   public GrapeCropBlock(class_2251 properties) {
      this(properties, (state, level, pos, random) -> 0.25F, () -> new class_1799(ModItems.GRAPE, 3));
   }

   @NotNull
   public class_1269 method_55765(
      @NonNull class_1799 stack,
      @NonNull class_2680 state,
      @NonNull class_1937 level,
      @NonNull class_2338 pos,
      class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      class_1799 heldItem = player.method_5998(hand);
      if (heldItem.method_31574(class_1802.field_8868) && this.isMaxAge(state)) {
         level.method_8501(pos, class_2246.field_10124.method_9564());
         class_2248.method_9577(level, pos, this.shearResult.get());
         if (level.field_9229.method_43057() < 0.3F) {
            int count = level.field_9229.method_43051(1, 3);
            class_2248.method_9577(level, pos, new class_1799(ModItems.GREEN_GRAPE, count));
         }

         heldItem.method_7970(1, player, PortHelper.getSlotForHand(hand));
         player.method_43077(class_3417.field_20611);
         return class_1269.field_5812;
      } else {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }
   }

   public boolean method_9542(@NonNull class_2680 state) {
      return super.method_9542(state) && (Integer)state.method_11654(AGE) < 5;
   }

   public void method_9514(@NonNull class_2680 state, @NonNull class_3218 level, @NonNull class_2338 pos, class_5819 random) {
      if (EventHooks.onCropsGrowPre(level, pos, state, random.method_43058() < this.probability.getProbability(state, level, pos, random))) {
         int nextAge = (Integer)state.method_11654(AGE) + random.method_43051(1, 3);
         level.method_8501(pos, (class_2680)state.method_11657(AGE, Math.min(nextAge, 5)));
         EventHooks.onCropsGrowPost(level, pos, state);
      }
   }

   protected @NonNull class_2680 method_9559(
      class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      return blockState.method_26184(levelReader, blockPos)
         ? super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource)
         : class_2246.field_10124.method_9564();
   }

   public boolean method_9558(@NonNull class_2680 state, class_4538 level, class_2338 pos) {
      class_2680 aboveState = level.method_8320(pos.method_10084());
      return aboveState.method_26204() instanceof GrapevineTrellisBlock trellis ? trellis.isMaxAge(aboveState) : false;
   }

   public boolean isMaxAge(class_2680 state) {
      return (Integer)state.method_11654(AGE) >= 5;
   }

   public boolean method_9651(@NonNull class_4538 level, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return !this.isMaxAge(state);
   }

   public boolean method_9650(@NonNull class_1937 level, @NonNull class_5819 random, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return true;
   }

   public void method_9652(class_3218 level, class_5819 random, @NonNull class_2338 pos, class_2680 state) {
      int newAge = Math.min((Integer)state.method_11654(AGE) + random.method_43051(1, 3), 5);
      level.method_8501(pos, (class_2680)state.method_11657(AGE, newAge));
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{AGE});
   }

   @NotNull
   public class_265 method_9530(@NonNull class_2680 pState, @NonNull class_1922 pLevel, @NonNull class_2338 pPos, @NonNull class_3726 pContext) {
      return SHAPE;
   }

   @NotNull
   public List<class_1799> method_9560(@NonNull class_2680 state, @NonNull class_8568 lootParamsBuilder) {
      return this.isMaxAge(state) ? super.method_9560(state, lootParamsBuilder) : Collections.emptyList();
   }

   protected @NonNull class_1799 method_9574(@NonNull class_4538 levelReader, @NonNull class_2338 blockPos, @NonNull class_2680 blockState, boolean bl) {
      return ModItems.GRAPE.method_7854();
   }
}
