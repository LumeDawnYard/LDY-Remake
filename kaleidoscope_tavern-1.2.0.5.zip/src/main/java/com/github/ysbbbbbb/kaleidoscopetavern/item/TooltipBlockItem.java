package com.github.ysbbbbbb.kaleidoscopetavern.item;

import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;

public class TooltipBlockItem extends class_1747 {
   private final String[] tooltipKeys;

   public TooltipBlockItem(class_2248 block, class_1793 properties, String... tooltipKeys) {
      super(block, properties);
      this.tooltipKeys = tooltipKeys;
   }

   public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> consumer, class_1836 flag) {
      for (String tooltipKey : this.tooltipKeys) {
         consumer.accept(class_2561.method_43471(tooltipKey).method_27692(class_124.field_1080));
      }
   }
}
