package com.github.ysbbbbbb.kaleidoscopetavern.compat.rrv.barrel;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu.SlotFillContext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;

public class BarrelViewRecipe implements ReliableClientRecipe {
   private final class_1799 result;
   private final List<class_1856> ingredients;
   private final class_1856 carrier;

   public BarrelViewRecipe(BarrelServerRecipe serverRecipe) {
      this.carrier = serverRecipe.getCarrier();
      this.ingredients = serverRecipe.getIngredients();
      this.result = serverRecipe.getResult();
   }

   public ReliableClientRecipeType getViewType() {
      return BarrelViewType.INSTANCE;
   }

   public void bindSlots(SlotFillContext slotFillContext) {
      slotFillContext.bindSlot(
         0, SlotContent.of(this.ingredients.getFirst().method_8105().map(s -> ((class_1792)s.comp_349()).method_7854().method_46651(4)).toList())
      );

      for (int i = 1; i < this.ingredients.size(); i++) {
         slotFillContext.bindSlot(
            i, SlotContent.of(this.ingredients.get(i).method_8105().map(s -> ((class_1792)s.comp_349()).method_7854().method_46651(16)).toList())
         );
      }

      slotFillContext.bindSlot(5, SlotContent.of(this.carrier));
      slotFillContext.bindSlot(6, SlotContent.of(this.result.method_46651(16)));
   }

   public List<SlotContent> getIngredients() {
      List<SlotContent> list = new ArrayList<>(this.ingredients.stream().map(SlotContent::of).toList());
      list.add(SlotContent.of(this.carrier));
      return list;
   }

   public List<SlotContent> getResults() {
      return Collections.singletonList(SlotContent.of(this.result));
   }
}
