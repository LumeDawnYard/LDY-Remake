package com.github.ysbbbbbb.kaleidoscopetavern.config;

import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;

public class GeneralConfig {
   public static BooleanValue PRESSING_TUB_DROP_CONTENTS_ON_NON_JUICEABLE;
   public static BooleanValue INFINITE_LAVA_FROM_TAP;
   public static BooleanValue WATER_BOTTLE_PLACEMENT;
   public static BooleanValue HONEY_BOTTLE_PLACEMENT;
   public static BooleanValue POTION_BOTTLE_PLACEMENT;
   public static BooleanValue DRAGON_BREATH_BOTTLE_PLACEMENT;
   public static BooleanValue EXPERIENCE_BOTTLE_PLACEMENT;

   public static ModConfigSpec init() {
      Builder builder = new Builder();
      general(builder);
      bottle(builder);
      return builder.build();
   }

   private static void general(Builder builder) {
      builder.push("tavern");
      builder.comment("Whether the Pressing Tub drops its contents when a non-juiceable item is pressed.");
      PRESSING_TUB_DROP_CONTENTS_ON_NON_JUICEABLE = builder.define("PressingTubDropContentsOnNonJuiceable", true);
      builder.comment("Whether to enable infinite lava from the tap. If enabled, the tap will provide infinite lava when attached to a lava cauldron.");
      INFINITE_LAVA_FROM_TAP = builder.define("InfiniteLavaFromTap", true);
      builder.pop();
   }

   private static void bottle(Builder builder) {
      builder.push("vanilla bottle placement");
      builder.comment("Whether vanilla water bottles can be placed by shift-right-clicking a block.");
      WATER_BOTTLE_PLACEMENT = builder.define("WaterBottle", true);
      builder.comment("Whether vanilla honey bottles can be placed by shift-right-clicking a block.");
      HONEY_BOTTLE_PLACEMENT = builder.define("HoneyBottle", true);
      builder.comment("Whether vanilla potion bottles can be placed by shift-right-clicking a block.");
      POTION_BOTTLE_PLACEMENT = builder.define("PotionBottle", true);
      builder.comment("Whether vanilla dragon's breath bottles can be placed by shift-right-clicking a block.");
      DRAGON_BREATH_BOTTLE_PLACEMENT = builder.define("DragonBreathBottle", true);
      builder.comment("Whether vanilla experience bottles can be placed by shift-right-clicking a block.");
      EXPERIENCE_BOTTLE_PLACEMENT = builder.define("ExperienceBottle", true);
      builder.pop();
   }
}
