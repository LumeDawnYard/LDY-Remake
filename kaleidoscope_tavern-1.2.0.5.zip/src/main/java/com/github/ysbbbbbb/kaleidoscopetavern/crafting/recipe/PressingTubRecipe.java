package com.github.ysbbbbbb.kaleidoscopetavern.crafting.recipe;

import com.github.ysbbbbbb.kaleidoscopetavern.init.ModRecipes;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3956;
import net.minecraft.class_3972;
import net.minecraft.class_7923;
import net.minecraft.class_9696;
import org.jspecify.annotations.NonNull;

public class PressingTubRecipe extends class_3972 {
   private final class_3611 fluid;
   private final int fluidAmount;

   public PressingTubRecipe(class_1856 ingredient, class_3611 fluid, int fluidAmount) {
      super("pressing_tub", ingredient, fluid.method_15774().method_7854());
      this.fluid = fluid;
      this.fluidAmount = fluidAmount;
   }

   public @NonNull class_1865<? extends class_3972> method_8119() {
      return ModRecipes.PRESSING_TUB_SERIALIZER;
   }

   public @NonNull class_3956<? extends class_3972> method_17716() {
      return ModRecipes.PRESSING_TUB_RECIPE;
   }

   public @NonNull class_10355 method_64668() {
      return (class_10355)class_2378.method_10230(class_7923.field_54927, class_2960.method_60655("kaleidoscope_tavern", "pressing_tub"), new class_10355());
   }

   public boolean method_64719(class_9696 input, @NonNull class_1937 level) {
      return this.method_64720().method_8093(input.method_59984(0));
   }

   public boolean method_8118() {
      return true;
   }

   public class_1856 getIngredient() {
      return this.method_64720();
   }

   public class_1799 getResult() {
      return this.method_64721();
   }

   public class_3611 getFluid() {
      return this.fluid;
   }

   public int getFluidAmount() {
      return this.fluidAmount;
   }
}
