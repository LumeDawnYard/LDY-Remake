package com.github.ysbbbbbb.kaleidoscopetavern.init;

import com.github.ysbbbbbb.kaleidoscopetavern.entity.SitEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.entity.ThrownMolotovEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_1299.class_1300;

public final class ModEntities {
   public static final class_1299<SitEntity> SIT = class_1300.method_5903(SitEntity::new, class_1311.field_17715)
      .method_17687(0.5F, 0.1F)
      .method_27299(10)
      .method_5901()
      .method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("kaleidoscope_tavern", "sit")));
   public static final class_1299<ThrownMolotovEntity> THROWN_MOLOTOV = class_1300.method_5903(ThrownMolotovEntity::new, class_1311.field_17715)
      .method_17687(0.5F, 0.5F)
      .method_27299(10)
      .method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("kaleidoscope_tavern", "thrown_molotov")));

   public static void registerEntities() {
      class_2378.method_10230(class_7923.field_41177, class_2960.method_60655("kaleidoscope_tavern", "sit"), SIT);
      class_2378.method_10230(class_7923.field_41177, class_2960.method_60655("kaleidoscope_tavern", "thrown_molotov"), THROWN_MOLOTOV);
   }
}
