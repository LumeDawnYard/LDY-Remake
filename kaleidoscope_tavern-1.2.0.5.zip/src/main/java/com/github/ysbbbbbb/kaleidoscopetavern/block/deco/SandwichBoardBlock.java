package com.github.ysbbbbbb.kaleidoscopetavern.block.deco;

import com.github.ysbbbbbb.kaleidoscopetavern.api.client.IModelModifyRotationAfterBake;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.SandwichBoardBlockEntity;
import com.github.ysbbbbbb.kaleidoscopetavern.blockentity.deco.TextBlockEntity;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10225;
import net.minecraft.class_11352;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2760;
import net.minecraft.class_2766;
import net.minecraft.class_2769;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_7718;
import net.minecraft.class_8942;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class SandwichBoardBlock extends class_2237 implements class_3737, IModelModifyRotationAfterBake<class_2758> {
   public static final MapCodec<SandwichBoardBlock> CODEC = method_54094(p -> new SandwichBoardBlock(p));
   public static final Map<class_1792, SandwichBoardBlock> TRANSFORM_MAP = Maps.newHashMap();
   public static final class_2758 ROTATION = class_2741.field_12532;
   public static final class_2754<class_2760> HALF = class_2741.field_12518;
   public static final class_2746 WATERLOGGED = class_2741.field_12508;
   public static final class_265 TOP_SHAPE = class_2248.method_9541(2.0, -16.0, 2.0, 14.0, 6.0, 14.0);
   public static final class_265 BOTTOM_SHAPE = class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 22.0, 14.0);
   private final List<class_1792> transformItems;
   @Nullable
   private List<String> transformItemNames;

   public SandwichBoardBlock(class_2251 properties, class_1792... transformItems) {
      super(
         properties.method_31710(class_3620.field_15996)
            .method_51368(class_2766.field_12654)
            .method_9632(0.8F)
            .method_9626(class_2498.field_11547)
            .method_22488()
            .method_50013()
      );
      this.method_9590(
         (class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(ROTATION, 0))
               .method_11657(HALF, class_2760.field_12617))
            .method_11657(WATERLOGGED, false)
      );
      this.transformItems = List.of(transformItems);
      this.transformItems.forEach(item -> TRANSFORM_MAP.put(item, this));
   }

   @Nullable
   public List<String> getTransformItemNames() {
      return this.transformItemNames;
   }

   public @NonNull class_1269 method_55765(
      @NonNull class_1799 stack,
      class_2680 state,
      class_1937 level,
      @NonNull class_2338 pos,
      @NonNull class_1657 player,
      @NonNull class_1268 hand,
      @NonNull class_3965 hitResult
   ) {
      class_2760 half = (class_2760)state.method_11654(HALF);
      class_2338 clickedPos = half == class_2760.field_12617 ? pos : pos.method_10074();
      if (level.method_8321(clickedPos) instanceof SandwichBoardBlockEntity sandwichBlock) {
         class_1792 item = player.method_5998(hand).method_7909();
         if (TRANSFORM_MAP.containsKey(item) && !this.transformItems.contains(item)) {
            class_2680 transform = (class_2680)((class_2680)((class_2680)TRANSFORM_MAP.get(item)
                     .method_9564()
                     .method_11657(ROTATION, (Integer)state.method_11654(ROTATION)))
                  .method_11657(HALF, class_2760.field_12617))
               .method_11657(WATERLOGGED, (Boolean)state.method_11654(WATERLOGGED));
            class_2487 tag = sandwichBlock.method_38244(level.method_30349());
            level.method_8501(clickedPos, transform);
            level.method_8501(clickedPos.method_10084(), (class_2680)transform.method_11657(HALF, class_2760.field_12619));
            if (level.method_8321(clickedPos) instanceof SandwichBoardBlockEntity be) {
               be.method_11014(class_11352.method_71417(class_8942.field_60348, level.method_30349(), tag));
               be.refresh();
            }

            level.method_8396(null, pos, class_2498.field_11535.method_10598(), class_3419.field_15245, 1.0F, 1.0F);
            if (!player.method_68878()) {
               player.method_5998(hand).method_7934(1);
            }

            return class_1269.field_5812;
         } else {
            return TextBlockEntity.onItemUse(level, sandwichBlock, player, hand);
         }
      } else {
         return super.method_55765(stack, state, level, pos, player, hand, hitResult);
      }
   }

   protected @NonNull class_2680 method_9559(
      @NonNull class_2680 blockState,
      @NonNull class_4538 levelReader,
      @NonNull class_10225 scheduledTickAccess,
      @NonNull class_2338 blockPos,
      @NonNull class_2350 direction,
      @NonNull class_2338 blockPos2,
      @NonNull class_2680 blockState2,
      @NonNull class_5819 randomSource
   ) {
      if ((Boolean)blockState.method_11654(WATERLOGGED)) {
         scheduledTickAccess.method_64312(blockPos, class_3612.field_15910, class_3612.field_15910.method_15789(levelReader));
      }

      class_2760 half = (class_2760)blockState.method_11654(HALF);
      boolean isBottom = half == class_2760.field_12617 && direction == class_2350.field_11036;
      boolean isTop = half == class_2760.field_12619 && direction == class_2350.field_11033;
      if (direction.method_10166() == class_2351.field_11052 && (isBottom || isTop)) {
         return blockState2.method_26204() instanceof SandwichBoardBlock && blockState2.method_11654(HALF) != half
            ? (class_2680)blockState.method_11657(ROTATION, (Integer)blockState2.method_11654(ROTATION))
            : class_2246.field_10124.method_9564();
      } else {
         return super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
      }
   }

   @NotNull
   public class_2680 method_9576(class_1937 level, @NonNull class_2338 pos, @NonNull class_2680 state, @NonNull class_1657 player) {
      if (!level.method_8608() && player.method_68878() && state.method_11654(HALF) == class_2760.field_12619) {
         class_2338 below = pos.method_10074();
         class_2680 belowState = level.method_8320(below);
         if (belowState.method_27852(state.method_26204()) && belowState.method_11654(HALF) == class_2760.field_12617) {
            class_2680 airBlockState = belowState.method_26227().method_39360(class_3612.field_15910)
               ? class_2246.field_10382.method_9564()
               : class_2246.field_10124.method_9564();
            level.method_8652(below, airBlockState, 35);
            level.method_8444(player, 2001, below, class_2248.method_9507(belowState));
         }
      }

      return super.method_9576(level, pos, state, player);
   }

   @Nullable
   public class_2586 method_10123(@NonNull class_2338 pos, class_2680 state) {
      return state.method_11654(HALF) == class_2760.field_12617 ? new SandwichBoardBlockEntity(pos, state) : null;
   }

   protected void method_9515(class_2690<class_2248, class_2680> builder) {
      builder.method_11667(new class_2769[]{ROTATION, HALF, WATERLOGGED});
   }

   @Nullable
   public class_2680 method_9605(class_1750 context) {
      class_2338 pos = context.method_8037();
      class_1937 level = context.method_8045();
      if (pos.method_10264() < level.method_31600() - 1 && level.method_8320(pos.method_10084()).method_26166(context)) {
         int rotation = class_7718.method_45479(context.method_8044());
         return (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(ROTATION, rotation)).method_11657(HALF, class_2760.field_12617))
            .method_11657(WATERLOGGED, level.method_22351(pos));
      } else {
         return null;
      }
   }

   public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, @NonNull class_1799 stack) {
      class_2338 above = pos.method_10084();
      class_2680 blockState = (class_2680)((class_2680)state.method_11657(HALF, class_2760.field_12619)).method_11657(WATERLOGGED, level.method_22351(above));
      level.method_8501(above, blockState);
   }

   @NotNull
   public List<class_1799> method_9560(class_2680 state, @NonNull class_8568 lootParamsBuilder) {
      return state.method_11654(HALF) == class_2760.field_12617 ? super.method_9560(state, lootParamsBuilder) : Collections.emptyList();
   }

   @NotNull
   public class_3610 method_9545(class_2680 state) {
      return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
   }

   @NotNull
   public class_265 method_9530(class_2680 state, @NonNull class_1922 level, @NonNull class_2338 pos, @NonNull class_3726 context) {
      return state.method_11654(HALF) == class_2760.field_12619 ? TOP_SHAPE : BOTTOM_SHAPE;
   }

   @NotNull
   public class_2464 method_9604(@NonNull class_2680 state) {
      return class_2464.field_11458;
   }

   @NotNull
   public class_2680 method_9598(class_2680 state, class_2470 rot) {
      int max = class_7718.method_45478() + 1;
      return (class_2680)state.method_11657(ROTATION, rot.method_10502((Integer)state.method_11654(ROTATION), max));
   }

   @NotNull
   public class_2680 method_9569(class_2680 state, class_2415 mirror) {
      int max = class_7718.method_45478() + 1;
      return (class_2680)state.method_11657(ROTATION, mirror.method_10344((Integer)state.method_11654(ROTATION), max));
   }

   public void appendHoverText(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 tooltipFlag) {
      if (this.transformItemNames == null && !this.transformItems.isEmpty()) {
         this.transformItemNames = this.transformItems.stream().<String>map(class_1792::method_7876).toList();
      }

      if (this.transformItemNames != null) {
         this.transformItemNames.forEach(name -> tooltip.add(class_2561.method_43471(name).method_27692(class_124.field_1080)));
      }
   }

   @NotNull
   protected MapCodec<? extends class_2237> method_53969() {
      return CODEC;
   }

   public class_2758 getRotationProperty() {
      return ROTATION;
   }
}
