package com.bmt.kaleidoscope_nether.client;

import com.bmt.kaleidoscope_nether.init.KNBlocks;
import com.bmt.kaleidoscope_nether.init.KNEntities;
import com.bmt.kaleidoscope_nether.init.KNFluids;
import com.bmt.kaleidoscope_nether.init.KNFoodBiteRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_11515;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_5619;
import net.minecraft.class_7923;
import net.minecraft.class_953;
import org.jspecify.annotations.NonNull;

@Environment(EnvType.CLIENT)
public class ClientEvents {
   public static void register() {
      class_5619.method_32173(KNEntities.BLAZE_HEART_PROJECTILE.get(), class_953::new);
      BlockRenderLayerMap.putBlocks(
         class_11515.field_60925,
         new class_2248[]{
            (class_2248)KNBlocks.POISONOUS_FRUIT.get(),
            (class_2248)KNBlocks.SOUL_PEPPER.get(),
            (class_2248)KNBlocks.TWISTING_CAVE_VINES.get(),
            (class_2248)KNBlocks.TWISTING_CAVE_VINES_PLANT.get(),
            (class_2248)KNBlocks.WEEPING_CAVE_VINES.get(),
            (class_2248)KNBlocks.WEEPING_CAVE_VINES_PLANT.get()
         }
      );
      KNFoodBiteRegistry.forEach((id, data) -> {
         class_2248 block = (class_2248)class_7923.field_41175.method_63535(id);
         if (block != class_2246.field_10124) {
            BlockRenderLayerMap.putBlock(block, class_11515.field_60925);
         }
      });
      registerCrimsonJuiceRender(KNFluids.CRIMSON_JUICE, KNFluids.FLOWING_CRIMSON_JUICE);
      registerWarpedJuiceRender(KNFluids.WARPED_JUICE, KNFluids.FLOWING_WARPED_JUICE);
   }

   private static void registerCrimsonJuiceRender(class_3611 still, class_3611 flowing) {
      class_2960 stillTexture = class_2960.method_60655("kaleidoscope_nether", "block/crimson_juice_still");
      class_2960 flowTexture = class_2960.method_60655("kaleidoscope_nether", "block/crimson_juice_flow");
      FluidRenderHandlerRegistry.INSTANCE.register(still, flowing, new SimpleFluidRenderHandler(stillTexture, flowTexture, stillTexture, -1));
      registration(still, stillTexture, flowTexture);
      registration(flowing, stillTexture, flowTexture);
   }

   private static void registerWarpedJuiceRender(class_3611 still, class_3611 flowing) {
      class_2960 stillTexture = class_2960.method_60655("kaleidoscope_nether", "block/warped_juice_still");
      class_2960 flowTexture = class_2960.method_60655("kaleidoscope_nether", "block/warped_juice_flow");
      FluidRenderHandlerRegistry.INSTANCE.register(still, flowing, new SimpleFluidRenderHandler(stillTexture, flowTexture, stillTexture, -1));
      registration(still, stillTexture, flowTexture);
      registration(flowing, stillTexture, flowTexture);
   }

   private static void registration(class_3611 fluid, class_2960 stillId, class_2960 flowId) {
      FluidVariantRendering.register(fluid, new FluidVariantRenderHandler() {
         public class_1058 @NonNull [] getSprites(@NonNull FluidVariant fluidVariant) {
            class_1059 atlas = (class_1059)class_310.method_1551().method_1531().method_4619(class_1059.field_5275);
            class_1058 stillSprite = atlas.method_4608(stillId);
            class_1058 flowSprite = atlas.method_4608(flowId);
            return new class_1058[]{stillSprite, flowSprite};
         }

         public int getColor(@NonNull FluidVariant fluidVariant, class_1920 view, class_2338 pos) {
            return -1;
         }
      });
   }
}
