package com.bmt.kaleidoscope_nether.block;

import com.bmt.kaleidoscope_nether.api.KNTags;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModItems;
import net.minecraft.class_10774;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_4970.class_2251;
import org.jspecify.annotations.NonNull;

public class PoisonousFruit extends KNCropBlockBase {
   public PoisonousFruit(class_2251 properties) {
      super(properties);
   }

   protected boolean method_9695(class_2680 blockState, @NonNull class_1922 blockGetter, @NonNull class_2338 blockPos) {
      return blockState.method_26164(KNTags.Blocks.SOUL_SOIL_SAND);
   }

   public void method_9514(class_2680 blockState, @NonNull class_3218 serverLevel, @NonNull class_2338 blockPos, @NonNull class_5819 randomSource) {
      int i = (Integer)blockState.method_11654(field_10835);
      if (i < 7 && randomSource.method_43048(10) == 0) {
         blockState = (class_2680)blockState.method_11657(field_10835, i + 1);
         serverLevel.method_8652(blockPos, blockState, 2);
      }
   }

   protected void method_9548(
      @NonNull class_2680 blockState,
      @NonNull class_1937 level,
      @NonNull class_2338 blockPos,
      @NonNull class_1297 entity,
      @NonNull class_10774 insideBlockEffectApplier,
      boolean bl
   ) {
      if (entity instanceof class_1657 living
         && (
            living.method_6118(class_1304.field_6166).method_7909() != ModItems.FARMER_BOOTS
               || living.method_6118(class_1304.field_6172).method_7909() != ModItems.FARMER_LEGGINGS
               || living.method_6118(class_1304.field_6174).method_7909() != ModItems.FARMER_CHEST_PLATE
         )) {
         class_1293 effect = living.method_6112(KNEffects.MYSTERIOUS_POISON);
         if (effect != null) {
            if (effect.method_5584() <= 140) {
               living.method_6092(new class_1293(KNEffects.MYSTERIOUS_POISON, 180, effect.method_5578() + 1));
            }
         } else {
            living.method_6092(new class_1293(KNEffects.MYSTERIOUS_POISON, 180));
         }
      }

      super.method_9548(blockState, level, blockPos, entity, insideBlockEffectApplier, bl);
   }

   protected @NonNull class_1935 method_9832() {
      return (class_1935)KNItems.POISONOUS_FRUIT.get();
   }

   public boolean method_9558(@NonNull class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
      class_2338 blockpos = blockPos.method_10074();
      class_2680 belowState = levelReader.method_8320(blockpos);
      return this.method_9695(belowState, levelReader, blockpos);
   }
}
