package com.bmt.kaleidoscope_nether.block;

import com.github.ysbbbbbb.kaleidoscopecookery.item.SickleItem;
import java.util.Set;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class KNCropBlockBase extends class_2302 {
   public KNCropBlockBase(class_2251 properties) {
      super(properties);
   }

   @NotNull
   protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
      if (!(player.method_6047().method_7909() instanceof SickleItem) && !(player.method_6079().method_7909() instanceof SickleItem)) {
         if (state.method_26204() instanceof class_2302 cropBlock && cropBlock.method_9825(state)) {
            this.getHandHarvestItem(state, level, pos, null, player, class_1799.field_8037);
            int ageAfterUse = 5;
            level.method_43128(
               null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, class_3417.field_17610, class_3419.field_15245, 1.0F, 1.0F
            );
            level.method_8652(pos, this.method_9828(ageAfterUse), 2);
            return class_1269.field_5812;
         } else {
            return class_1269.field_5811;
         }
      } else {
         return class_1269.field_5811;
      }
   }

   public Set<class_1792> getHandHarvestExclude() {
      return Set.of();
   }

   public void getHandHarvestItem(
      class_2680 pState, class_1937 pLevel, class_2338 pPos, @Nullable class_2586 pBlockEntity, @Nullable class_1297 pEntity, class_1799 pTool
   ) {
      if (pLevel instanceof class_3218) {
         method_9609(pState, (class_3218)pLevel, pPos, pBlockEntity, pEntity, pTool).forEach(itemStack -> {
            if (!this.getHandHarvestExclude().contains(itemStack.method_7909())) {
               method_9577(pLevel, pPos, itemStack);
            }
         });
         pState.method_26180((class_3218)pLevel, pPos, pTool, true);
      }
   }
}
