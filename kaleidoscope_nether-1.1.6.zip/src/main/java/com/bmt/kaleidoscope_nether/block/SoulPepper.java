package com.bmt.kaleidoscope_nether.block;

import com.bmt.kaleidoscope_nether.api.KNTags;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModItems;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class SoulPepper extends KNCropBlockBase {
   public SoulPepper(class_2251 properties) {
      super(properties);
   }

   protected boolean method_9695(class_2680 blockState, @NonNull class_1922 blockGetter, @NonNull class_2338 blockPos) {
      return blockState.method_26164(KNTags.Blocks.SOUL_SOIL_SAND);
   }

   public void method_9514(class_2680 blockState, @NonNull class_3218 serverLevel, @NonNull class_2338 blockPos, @NonNull class_5819 randomSource) {
      int i = (Integer)blockState.method_11654(field_10835);
      if (i < 7 && randomSource.method_43048(10) == 0) {
         blockState = (class_2680)blockState.method_11657(field_10835, i + 1);
         serverLevel.method_8652(blockPos, blockState, 2);
      }
   }

   @Override
   public Set<class_1792> getHandHarvestExclude() {
      return Set.of(ModItems.CHILI_SEED);
   }

   public void method_9496(@NonNull class_2680 blockState, @NonNull class_1937 level, @NonNull class_2338 blockPos, class_5819 randomSource) {
      if (randomSource.method_43048(5) == 0) {
         spawnSoulParticles(level, blockPos);
      }
   }

   @NotNull
   protected class_1935 method_9832() {
      return ModItems.CHILI_SEED;
   }

   public boolean method_9558(@NonNull class_2680 blockState, @NonNull class_4538 levelReader, class_2338 blockPos) {
      class_2338 blockpos = blockPos.method_10074();
      return this.method_9695(levelReader.method_8320(blockpos), levelReader, blockpos);
   }

   private static void spawnSoulParticles(class_1937 level, class_2338 pos) {
      double x = pos.method_10263() + 0.5;
      double y = pos.method_10264();
      double z = pos.method_10260() + 0.5;
      int particleCount = 1;

      for (int i = 0; i < particleCount; i++) {
         double offsetX = (level.field_9229.method_43058() - 0.5) * 0.8;
         double offsetY = level.field_9229.method_43058() * 0.5;
         double offsetZ = (level.field_9229.method_43058() - 0.5) * 0.8;
         double speedX = (level.field_9229.method_43058() - 0.5) * 0.02;
         double speedY = level.field_9229.method_43058() * 0.03 + 0.01;
         double speedZ = (level.field_9229.method_43058() - 0.5) * 0.02;
         level.method_8406(class_2398.field_23114, x + offsetX, y + offsetY, z + offsetZ, speedX, speedY, speedZ);
      }
   }
}
