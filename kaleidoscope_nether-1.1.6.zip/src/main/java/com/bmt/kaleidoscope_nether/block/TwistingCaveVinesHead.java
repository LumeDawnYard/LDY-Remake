package com.bmt.kaleidoscope_nether.block;

import com.bmt.kaleidoscope_nether.init.KNBlocks;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4864;
import net.minecraft.class_4865;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5712.class_7397;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class TwistingCaveVinesHead extends class_4865 implements class_2256 {
   public static final MapCodec<TwistingCaveVinesHead> CODEC = method_54094(TwistingCaveVinesHead::new);
   public static final class_2746 BERRIES = class_2741.field_28716;
   public static final class_265 SHAPE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);

   @NotNull
   protected MapCodec<? extends class_4865> method_53969() {
      return CODEC;
   }

   public TwistingCaveVinesHead(class_2251 properties) {
      super(properties, class_2350.field_11036, SHAPE, true, 0.1);
      this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(BERRIES, Boolean.FALSE));
   }

   protected void method_9515(@NonNull class_2690<class_2248, class_2680> builder) {
      super.method_9515(builder);
      builder.method_11667(new class_2769[]{BERRIES});
   }

   @NotNull
   protected class_4864 getBodyBlock() {
      return KNBlocks.TWISTING_CAVE_VINES_PLANT.get();
   }

   protected int method_26376(@NonNull class_5819 random) {
      return 0;
   }

   protected boolean method_24949(class_2680 state) {
      return state.method_26215();
   }

   @NotNull
   protected class_1269 method_55766(class_2680 state, @NonNull class_1937 level, @NonNull class_2338 pos, @NonNull class_1657 player, @NonNull class_3965 hit) {
      if ((Boolean)state.method_11654(BERRIES)) {
         class_2248.method_9577(level, pos, new class_1799((class_1935)KNItems.WARPED_FRUIT.get(), 1));
         float f = class_3532.method_32750(level.field_9229, 0.8F, 1.2F);
         level.method_8396(null, pos, class_3417.field_28575, class_3419.field_15245, 1.0F, f);
         class_2680 newState = (class_2680)state.method_11657(BERRIES, Boolean.FALSE);
         level.method_8652(pos, newState, 2);
         level.method_43276(class_5712.field_28733, pos, class_7397.method_43286(player, newState));
         return class_1269.field_5812;
      } else {
         return class_1269.field_5811;
      }
   }

   public boolean method_9651(@NonNull class_4538 level, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return true;
   }

   public boolean method_9650(@NonNull class_1937 level, @NonNull class_5819 random, @NonNull class_2338 pos, @NonNull class_2680 state) {
      return true;
   }

   public void method_9652(@NonNull class_3218 level, @NonNull class_5819 random, @NonNull class_2338 pos, class_2680 state) {
      if ((Boolean)state.method_11654(BERRIES)) {
         class_2248.method_9577(level, pos, new class_1799((class_1935)KNItems.WARPED_FRUIT.get(), 1));
         float f = class_3532.method_32750(level.field_9229, 0.8F, 1.2F);
         level.method_8396(null, pos, class_3417.field_28575, class_3419.field_15245, 1.0F, f);
         class_2680 newState = (class_2680)state.method_11657(BERRIES, Boolean.FALSE);
         level.method_8652(pos, newState, 2);
         level.method_43276(class_5712.field_28733, pos, class_7397.method_43287(newState));
      } else {
         level.method_8652(pos, (class_2680)state.method_11657(BERRIES, Boolean.TRUE), 2);
      }
   }
}
