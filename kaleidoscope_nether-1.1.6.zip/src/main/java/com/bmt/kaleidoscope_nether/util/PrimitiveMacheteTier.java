package com.bmt.kaleidoscope_nether.util;

import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_9886;

public final class PrimitiveMacheteTier {
   public static final class_9886 INSTANCE = new class_9886(class_3481.field_49925, 2031, 7.0F, 7.0F, 15, class_3489.field_23211);

   private PrimitiveMacheteTier() {
   }
}
