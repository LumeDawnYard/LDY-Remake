package com.bmt.kaleidoscope_nether.datagen;

import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import net.minecraft.class_2405;
import net.minecraft.class_2409;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7784.class_7489;
import net.minecraft.class_7784.class_7490;
import org.jetbrains.annotations.NotNull;

public class ModAdvancementProvider extends class_2409 {
   private final class_7489 pathProvider;
   public static BiConsumer<JsonObject, class_2960> BUILD_CONDITION;

   public ModAdvancementProvider(class_7784 output, CompletableFuture<class_7874> registries) {
      super(output, registries, List.of());
      this.pathProvider = output.method_45973(class_7490.field_39367, "advancements");
   }

   @NotNull
   public CompletableFuture<?> method_10319(@NotNull class_7403 cachedOutput) {
      List<CompletableFuture<?>> list = new ArrayList<>();
      BUILD_CONDITION = (jsonObject, resourceLocation) -> {
         Path path = this.pathProvider.method_44107(resourceLocation);
         list.add(class_2405.method_10320(cachedOutput, jsonObject, path));
      };
      return CompletableFuture.allOf(super.method_10319(cachedOutput), CompletableFuture.allOf(list.toArray(CompletableFuture[]::new)));
   }
}
