package com.bmt.kaleidoscope_nether.datagen;

import com.bmt.kaleidoscope_nether.api.KNTags;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModItems;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider.ItemTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_7225.class_7874;
import org.jetbrains.annotations.NotNull;

public class ModItemTagProvider extends ItemTagProvider {
   public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7874> registriesFuture) {
      super(output, registriesFuture);
   }

   protected void method_10514(@NotNull class_7874 provider) {
      this.valueLookupBuilder(KNTags.Items.BLAZE_FOODS).method_71558(new class_1792[]{KNItems.EVERLASTING_FLAME_STEAK.get(), KNItems.BLAZE_SOUP.get()});
      this.valueLookupBuilder(KNTags.Items.MAGMA_CREAM_FOODS).method_71558(new class_1792[]{KNItems.MAGMA_CREAM_SOUP.get(), KNItems.MAGMA_CREAM_PUDDING.get()});
      this.valueLookupBuilder(KNTags.Items.SOUL_PEPPER_TRANSFORMABLE).method_71558(new class_1792[]{ModItems.RED_CHILI, ModItems.GREEN_CHILI});
      this.valueLookupBuilder(KNTags.Items.STAR_BLESSING_FOODS)
         .method_71558(new class_1792[]{KNItems.STAR_STEW.get(), KNItems.STAR_GHAST_PASTA.get(), KNItems.STAR_STEW_MEAT.get(), KNItems.SOUL_RETURN_RICE.get()});
      this.valueLookupBuilder(KNTags.Items.WARPED_FOOD).method_71554(KNItems.WARPED_FRUIT.get());
   }
}
