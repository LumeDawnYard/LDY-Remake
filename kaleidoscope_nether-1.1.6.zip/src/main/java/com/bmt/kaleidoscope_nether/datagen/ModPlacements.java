package com.bmt.kaleidoscope_nether.datagen;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_6016;
import net.minecraft.class_6646;
import net.minecraft.class_6732;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6794;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModPlacements {
   public static final class_5321<class_6796> POISONOUS_FRUIT = createKey("poisonous_fruit");
   public static final class_5321<class_6796> TWISTING_CAVE_VINES = createKey("twisting_cave_vines");
   public static final class_5321<class_6796> WEEPING_CAVE_VINES = createKey("weeping_cave_vines");

   public static class_5321<class_6796> createKey(String key) {
      return class_5321.method_29179(class_7924.field_41245, KaleidoscopeNether.id(key));
   }

   public static void bootstrap(class_7891<class_6796> context) {
      class_7871<class_2975<?, ?>> holdergetter = context.method_46799(class_7924.field_41239);
      class_6817.method_40370(
         context,
         POISONOUS_FRUIT,
         holdergetter.method_46747(ModFeatures.POISONOUS_FRUIT),
         new class_6797[]{class_6817.field_36082, class_6792.method_39614(), class_6799.method_39659(5)}
      );
      class_6817.method_40370(
         context,
         TWISTING_CAVE_VINES,
         holdergetter.method_46747(ModFeatures.TWISTING_CAVE_VINES),
         new class_6797[]{
            class_6793.method_39623(10),
            class_5450.method_39639(),
            class_6817.field_36082,
            class_6794.method_39629(class_2350.field_11033, class_6646.method_39930(class_2350.field_11036), class_6646.field_35696, 12),
            class_6732.method_39656(class_6016.method_34998(1)),
            class_6792.method_39614()
         }
      );
      class_6817.method_40370(
         context,
         WEEPING_CAVE_VINES,
         holdergetter.method_46747(ModFeatures.WEEPING_CAVE_VINES),
         new class_6797[]{
            class_6793.method_39623(50),
            class_5450.method_39639(),
            class_6817.field_36082,
            class_6794.method_39629(
               class_2350.field_11036,
               class_6646.method_38878(class_6646.method_39930(class_2350.field_11033), class_6646.method_43290(new class_2248[]{class_2246.field_10541})),
               class_6646.field_35696,
               12
            ),
            class_6732.method_39656(class_6016.method_34998(-1)),
            class_6792.method_39614()
         }
      );
   }
}
