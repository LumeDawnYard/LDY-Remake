package com.bmt.kaleidoscope_nether.datagen;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_6646;
import net.minecraft.class_6862;

public class ModFeatureUtils {
   public static class_6646 simplePatchPredicate(class_6862<class_2248> blocks) {
      return class_6646.method_38878(class_6646.field_35696, class_6646.method_39908(class_2350.field_11033.method_62675(), blocks));
   }

   public static class_6646 notAirPredicate(class_2350 direction) {
      return class_6646.method_38877(class_6646.method_43288(direction.method_62675(), new class_2248[]{class_2246.field_10124}));
   }
}
