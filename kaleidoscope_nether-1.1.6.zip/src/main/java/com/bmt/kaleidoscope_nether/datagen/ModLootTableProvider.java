package com.bmt.kaleidoscope_nether.datagen;

import com.bmt.kaleidoscope_nether.init.KNBlocks;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.github.ysbbbbbb.kaleidoscopecookery.block.food.FoodBiteBlock;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModItems;
import com.github.ysbbbbbb.kaleidoscopecookery.init.registry.FoodBiteRegistry;
import com.github.ysbbbbbb.kaleidoscopecookery.init.registry.FoodBiteRegistry.FoodData;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_173;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_1935;
import net.minecraft.class_201;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2438;
import net.minecraft.class_2439;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5803;
import net.minecraft.class_73;
import net.minecraft.class_77;
import net.minecraft.class_7701;
import net.minecraft.class_7784;
import net.minecraft.class_7788;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_94;
import net.minecraft.class_2438.class_7790;
import net.minecraft.class_4559.class_4560;
import net.minecraft.class_52.class_53;
import net.minecraft.class_5341.class_210;
import net.minecraft.class_55.class_56;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_85.class_86;

public class ModLootTableProvider extends class_2438 {
   public ModLootTableProvider(class_7784 packOutput, CompletableFuture<class_7874> registries) {
      super(packOutput, Set.of(), List.of(new class_7790(ModLootTableProvider.BlockLoots::new, class_173.field_1172)), registries);
   }

   public static class BlockLoots extends class_7788 {
      private final Set<class_2248> getKnownBlocks = new HashSet<>();

      protected BlockLoots(class_7874 provider) {
         super(Set.of(), class_7701.field_40180.method_45383(), provider);
      }

      public void method_10379() {
         this.simpleCropBlockLoot((class_2248)KNBlocks.POISONOUS_FRUIT.get(), KNItems.POISONOUS_FRUIT.get(), KNItems.POISONOUS_FRUIT.get());
         this.simpleCropBlockLoot((class_2248)KNBlocks.SOUL_PEPPER.get(), ModItems.CHILI_SEED, KNItems.SOUL_PEPPER.get());
         this.vines((class_2248)KNBlocks.TWISTING_CAVE_VINES.get(), class_1802.field_23070, KNItems.WARPED_FRUIT.get());
         this.vines((class_2248)KNBlocks.TWISTING_CAVE_VINES_PLANT.get(), class_1802.field_23070, KNItems.WARPED_FRUIT.get());
         this.vines((class_2248)KNBlocks.WEEPING_CAVE_VINES.get(), class_1802.field_21992, KNItems.CRIMSON_FRUIT.get());
         this.vines((class_2248)KNBlocks.WEEPING_CAVE_VINES_PLANT.get(), class_1802.field_21992, KNItems.CRIMSON_FRUIT.get());
         this.method_46025((class_2248)KNBlocks.NETHER_STOVE.get());
         FoodBiteRegistry.FOOD_DATA_MAP.forEach((resourceLocation, foodData) -> {
            if (resourceLocation.method_12836().equals("kaleidoscope_nether")) {
               this.dropFoodBite(resourceLocation, foodData);
            }
         });
      }

      private void vines(class_2248 block, class_1792 normal, class_1792 berries) {
         this.method_45988(
            block,
            class_52.method_324()
               .method_336(
                  class_55.method_347()
                     .method_351(class_77.method_411(berries))
                     .method_356(class_212.method_900(block).method_22584(class_4560.method_22523().method_22527(class_5803.field_28688, true)))
               )
               .method_336(class_55.method_347().method_351(class_77.method_411(normal)))
         );
      }

      private void simpleCropBlockLoot(class_2248 cropBlock, class_1792 seed, class_1792 crop) {
         class_210 ageCondition = class_212.method_900(cropBlock).method_22584(class_4560.method_22523().method_22524(class_2439.field_10835, 7));
         this.method_45988(
            cropBlock,
            (class_53)this.method_45977(
               cropBlock,
               class_52.method_324()
                  .method_336(class_55.method_347().method_351(class_77.method_411(seed)))
                  .method_336(
                     class_55.method_347()
                        .method_356(ageCondition)
                        .method_351(
                           class_77.method_411(crop)
                              .method_438(
                                 class_94.method_463(this.field_51845.method_46762(class_7924.field_41265).method_46747(class_1893.field_9130), 0.5714286F, 3)
                              )
                        )
                  )
            )
         );
      }

      private void dropFoodBite(class_2960 id, FoodData data) {
         class_2248 block = (class_2248)class_7923.field_41175.method_63535(id);
         class_1792 food = (class_1792)class_7923.field_41178.method_63535(id);
         if (block instanceof FoodBiteBlock foodBiteBlock) {
            class_44 exactly = class_44.method_32448(1.0F);
            class_4560 notBite = class_4560.method_22523().method_22524(foodBiteBlock.getBites(), 0);
            class_210 builder = class_212.method_900(foodBiteBlock).method_22584(notBite);
            class_53 lootTable = class_52.method_324();

            for (int i = 0; i < data.getLootItems().size(); i++) {
               class_1935 itemLike = (class_1935)data.getLootItems().get(i);
               class_56 rolls = class_55.method_347().method_352(exactly).method_356(class_201.method_871());
               if (i == 0) {
                  rolls.method_351(((class_86)class_77.method_411(food).method_421(builder)).method_417(class_77.method_411(itemLike)));
               } else {
                  rolls.method_351(((class_86)class_73.method_401().method_421(builder)).method_417(class_77.method_411(itemLike)));
               }

               lootTable.method_336(rolls);
            }

            this.method_45988(block, lootTable);
            this.getKnownBlocks.add(block);
         }
      }
   }
}
