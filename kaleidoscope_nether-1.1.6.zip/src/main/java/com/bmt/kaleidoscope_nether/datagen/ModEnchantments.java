package com.bmt.kaleidoscope_nether.datagen;

import com.bmt.kaleidoscope_nether.init.KNEnchantments;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_3489;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_9274;

public class ModEnchantments {
   public static void bootstrap(class_7891<class_1887> context) {
      class_7871<class_1792> items = context.method_46799(class_7924.field_41197);
      context.method_46838(
         KNEnchantments.LAVA_WALKER,
         class_1887.method_60030(
               class_1887.method_58442(
                  items.method_46735(class_3489.field_48299),
                  2,
                  1,
                  class_1887.method_58441(10, 0),
                  class_1887.method_58441(40, 0),
                  1,
                  new class_9274[]{class_9274.field_49220}
               )
            )
            .method_60060(KNEnchantments.LAVA_WALKER.method_29177())
      );
   }
}
