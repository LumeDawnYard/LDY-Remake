package com.bmt.kaleidoscope_nether.datagen;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.api.KNTags;
import com.bmt.kaleidoscope_nether.init.KNBlocks;
import java.util.List;
import net.minecraft.class_2302;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_4638;
import net.minecraft.class_4651;
import net.minecraft.class_4657;
import net.minecraft.class_5321;
import net.minecraft.class_5803;
import net.minecraft.class_5805;
import net.minecraft.class_5929;
import net.minecraft.class_6012;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6642;
import net.minecraft.class_6646;
import net.minecraft.class_6655;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModFeatures {
   public static final class_5321<class_2975<?, ?>> POISONOUS_FRUIT = createKey("poisonous_fruit");
   public static final class_5321<class_2975<?, ?>> TWISTING_CAVE_VINES = createKey("twisting_cave_vines");
   public static final class_5321<class_2975<?, ?>> WEEPING_CAVE_VINES = createKey("weeping_cave_vines");

   public static class_5321<class_2975<?, ?>> createKey(String name) {
      return class_5321.method_29179(class_7924.field_41239, KaleidoscopeNether.id(name));
   }

   public static void bootstrap(class_7891<class_2975<?, ?>> context) {
      class_5929 TwistingCaveVinesHead = new class_5929(
         new class_4657(
            class_6012.method_66215()
               .method_34975(KNBlocks.TWISTING_CAVE_VINES.get().method_9564(), 4)
               .method_34975((class_2680)KNBlocks.TWISTING_CAVE_VINES.get().method_9564().method_11657(class_5803.field_28688, true), 1)
               .method_34974()
         ),
         class_5805.field_22509,
         class_6019.method_35017(23, 25)
      );
      class_4657 TwistingCaveVinesPlant = new class_4657(
         class_6012.method_66215()
            .method_34975(KNBlocks.TWISTING_CAVE_VINES_PLANT.get().method_9564(), 1)
            .method_34975((class_2680)KNBlocks.TWISTING_CAVE_VINES_PLANT.get().method_9564().method_11657(class_5803.field_28688, true), 1)
            .method_34974()
      );
      class_5929 WeepingCaveVinesHead = new class_5929(
         new class_4657(
            class_6012.method_66215()
               .method_34975(KNBlocks.WEEPING_CAVE_VINES.get().method_9564(), 4)
               .method_34975((class_2680)KNBlocks.WEEPING_CAVE_VINES.get().method_9564().method_11657(class_5803.field_28688, true), 1)
               .method_34974()
         ),
         class_5805.field_22509,
         class_6019.method_35017(23, 25)
      );
      class_4657 WeepingCaveVinesPlant = new class_4657(
         class_6012.method_66215()
            .method_34975(KNBlocks.WEEPING_CAVE_VINES_PLANT.get().method_9564(), 1)
            .method_34975((class_2680)KNBlocks.WEEPING_CAVE_VINES_PLANT.get().method_9564().method_11657(class_5803.field_28688, true), 1)
            .method_34974()
      );
      class_6803.method_39708(
         context,
         POISONOUS_FRUIT,
         class_3031.field_21220,
         new class_4638(
            96,
            7,
            3,
            class_6817.method_40367(
               class_3031.field_13518,
               new class_3175(class_4651.method_38433((class_2680)KNBlocks.POISONOUS_FRUIT.get().method_9564().method_11657(class_2302.field_10835, 7))),
               ModFeatureUtils.simplePatchPredicate(KNTags.Blocks.SOUL_SOIL_SAND)
            )
         )
      );
      class_6803.method_39708(
         context,
         TWISTING_CAVE_VINES,
         class_3031.field_35072,
         new class_6655(
            List.of(
               class_6655.method_38908(
                  new class_6642(
                     class_6012.method_66215()
                        .method_34975(class_6019.method_35017(0, 19), 1)
                        .method_34975(class_6019.method_35017(0, 2), 3)
                        .method_34975(class_6019.method_35017(0, 6), 10)
                        .method_34974()
                  ),
                  TwistingCaveVinesPlant
               ),
               class_6655.method_38908(class_6016.method_34998(1), TwistingCaveVinesHead)
            ),
            class_2350.field_11036,
            class_6646.field_35696,
            true
         )
      );
      class_6803.method_39708(
         context,
         WEEPING_CAVE_VINES,
         class_3031.field_35072,
         new class_6655(
            List.of(
               class_6655.method_38908(
                  new class_6642(
                     class_6012.method_66215()
                        .method_34975(class_6019.method_35017(0, 19), 1)
                        .method_34975(class_6019.method_35017(0, 2), 3)
                        .method_34975(class_6019.method_35017(0, 6), 10)
                        .method_34974()
                  ),
                  WeepingCaveVinesPlant
               ),
               class_6655.method_38908(class_6016.method_34998(1), WeepingCaveVinesHead)
            ),
            class_2350.field_11033,
            class_6646.field_35696,
            true
         )
      );
   }
}
