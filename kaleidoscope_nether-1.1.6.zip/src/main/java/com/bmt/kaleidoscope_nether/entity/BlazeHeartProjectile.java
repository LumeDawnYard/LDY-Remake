package com.bmt.kaleidoscope_nether.entity;

import com.bmt.kaleidoscope_nether.init.KNEntities;
import com.bmt.kaleidoscope_nether.init.KNItems;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3857;
import net.minecraft.class_1937.class_7867;
import org.jetbrains.annotations.NotNull;

public class BlazeHeartProjectile extends class_3857 {
   public BlazeHeartProjectile(class_1299<? extends BlazeHeartProjectile> entityType, class_1937 level) {
      super(entityType, level);
   }

   public BlazeHeartProjectile(class_1937 level, class_1309 shooter) {
      super(KNEntities.BLAZE_HEART_PROJECTILE.get(), level);
   }

   public BlazeHeartProjectile(class_1937 level, double x, double y, double z) {
      super(KNEntities.BLAZE_HEART_PROJECTILE.get(), level);
   }

   @NotNull
   protected class_1792 method_16942() {
      return KNItems.BLAZE_HEART.get();
   }

   protected void method_7488(@NotNull class_239 result) {
      super.method_7488(result);
      if (!this.method_73183().method_8608()) {
         class_1309 owner = this.method_24921() instanceof class_1309 ? (class_1309)this.method_24921() : null;
         this.method_73183()
            .method_8537(
               (class_1297)(owner != null ? owner : this), this.method_23317(), this.method_23318(), this.method_23321(), 3.0F, false, class_7867.field_40888
            );
         this.method_31472();
      }
   }

   public void method_5773() {
      super.method_5773();
      if (!this.method_5740()) {
         class_243 vec3 = this.method_18798();
         this.method_18800(vec3.field_1352, vec3.field_1351 - 0.03, vec3.field_1350);
      }
   }
}
