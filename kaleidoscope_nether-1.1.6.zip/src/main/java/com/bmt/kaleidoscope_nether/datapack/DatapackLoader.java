package com.bmt.kaleidoscope_nether.datapack;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;

public class DatapackLoader {
   public static void load() {
      FabricLoader.getInstance()
         .getModContainer("kaleidoscope_nether")
         .ifPresent(container -> ResourceManagerHelper.registerBuiltinResourcePack(class_2960.method_60656(""), container, ResourcePackActivationType.NORMAL));
   }
}
