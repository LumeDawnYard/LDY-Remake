package com.bmt.kaleidoscope_nether.item;

import com.bmt.kaleidoscope_nether.entity.BlazeHeartProjectile;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class ThrowableFuelItem extends FuelItem {
   public ThrowableFuelItem(class_1793 properties, int burnTime) {
      super(properties, burnTime);
   }

   @NotNull
   public class_1269 method_7836(class_1937 level, class_1657 player, @NotNull class_1268 hand) {
      class_1799 itemstack = player.method_5998(hand);
      level.method_43128(
         null,
         player.method_23317(),
         player.method_23318(),
         player.method_23321(),
         class_3417.field_14873,
         class_3419.field_15254,
         0.5F,
         0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F)
      );
      if (!level.method_8608()) {
         BlazeHeartProjectile projectile = new BlazeHeartProjectile(level, player);
         projectile.method_16940(itemstack);
         projectile.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 1.5F, 1.0F);
         level.method_8649(projectile);
      }

      if (!player.method_31549().field_7477) {
         itemstack.method_7934(1);
      }

      player.method_7259(class_3468.field_15372.method_14956(this));
      return level.method_8608() ? class_1269.field_5812 : class_1269.field_52422;
   }

   public int method_7881(@NotNull class_1799 stack, @NotNull class_1309 entity) {
      return 72000;
   }
}
