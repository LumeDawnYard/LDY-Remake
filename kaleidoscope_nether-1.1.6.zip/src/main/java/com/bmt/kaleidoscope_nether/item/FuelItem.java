package com.bmt.kaleidoscope_nether.item;

import net.minecraft.class_1792;
import net.minecraft.class_1792.class_1793;

public class FuelItem extends class_1792 {
   private final int burnTime;

   public FuelItem(class_1793 properties, int burnTime) {
      super(properties);
      this.burnTime = burnTime;
   }

   public int getBurnTimeValue() {
      return this.burnTime;
   }
}
