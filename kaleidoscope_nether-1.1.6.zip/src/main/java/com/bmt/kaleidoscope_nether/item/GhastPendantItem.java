package com.bmt.kaleidoscope_nether.item;

import com.bmt.kaleidoscope_nether.integration.CuriosIntegration;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1740;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_8051;
import net.minecraft.class_1792.class_1793;

public class GhastPendantItem extends class_1792 {
   public GhastPendantItem(class_1793 properties) {
      super(properties.method_7894(class_1814.field_8907).method_7889(1).method_66332(class_1740.field_7897, class_8051.field_41935));
   }

   public static boolean isWearingGhastPendant(class_1657 player) {
      class_1799 chestplate = player.method_6118(class_1304.field_6174);
      return chestplate.method_7909() instanceof GhastPendantItem ? true : CuriosIntegration.hasItemInCurios(player, GhastPendantItem.class);
   }
}
