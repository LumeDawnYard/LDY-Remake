package com.bmt.kaleidoscope_nether.item;

import com.bmt.kaleidoscope_nether.config.MainConfig;
import com.bmt.kaleidoscope_nether.init.KNSounds;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3419;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class StarDustItem extends class_1792 {
   public StarDustItem(class_1793 properties) {
      super(properties);
   }

   public boolean method_31566(
      @NotNull class_1799 starDustStack,
      @NotNull class_1799 incoming,
      @NotNull class_1735 slot,
      @NotNull class_5536 action,
      @NotNull class_1657 player,
      @NotNull class_5630 carriedSlotAccessor
   ) {
      if (action != class_5536.field_27014 || !slot.method_32754(player)) {
         return false;
      } else {
         return incoming.method_7960() ? false : this.repairTargetItem(player, starDustStack, incoming, carriedSlotAccessor);
      }
   }

   public boolean method_31565(@NotNull class_1799 starDustStack, @NotNull class_1735 slot, @NotNull class_5536 action, @NotNull class_1657 player) {
      if (action == class_5536.field_27014 && slot.method_32754(player)) {
         class_1799 targetStack = slot.method_7677();
         return targetStack.method_7960() ? false : this.repairTargetItem(player, starDustStack, targetStack, slot);
      } else {
         return false;
      }
   }

   private boolean repairTargetItem(class_1657 player, class_1799 starDustStack, class_1799 targetStack, Object target) {
      if (!targetStack.method_7963()) {
         return false;
      } else if (targetStack.method_7919() == 0) {
         return false;
      } else {
         return starDustStack.method_7960() ? false : this.performRepair(player, starDustStack, targetStack, target);
      }
   }

   private boolean performRepair(class_1657 player, class_1799 starDustStack, class_1799 targetStack, Object target) {
      if (player.method_73183().method_8608()) {
         return false;
      }

      int maxDurability = targetStack.method_7936();
      int currentDamage = targetStack.method_7919();
      int repairAmount = (int)(maxDurability * (Integer)MainConfig.STAR_DUST_REPAIR_PERCENTAGE.get() / 100.0F)
         + (Integer)MainConfig.STAR_DUST_REPAIR_FLAT.get();
      int newDamage = Math.max(0, currentDamage - repairAmount);
      targetStack.method_7974(newDamage);
      starDustStack.method_7934(1);
      if (target instanceof class_1735 slot) {
         slot.method_7668();
      } else if (target instanceof class_5630 slotAccess) {
         slotAccess.method_32332(targetStack);
      }

      player.method_73183()
         .method_43128(
            null, player.method_23317(), player.method_23318(), player.method_23321(), KNSounds.STAR_DUST_REPAIR.get(), class_3419.field_15248, 0.8F, 1.0F
         );
      return true;
   }
}
