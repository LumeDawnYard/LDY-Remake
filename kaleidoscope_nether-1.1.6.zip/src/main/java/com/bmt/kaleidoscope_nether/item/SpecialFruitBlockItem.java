package com.bmt.kaleidoscope_nether.item;

import net.minecraft.class_10124;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_4174;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class SpecialFruitBlockItem extends class_1747 {
   public SpecialFruitBlockItem(class_2248 block, class_1793 properties, class_4174 food, class_10124 consumable, class_1814 rarity) {
      super(block, properties.method_62833(food, consumable).method_7894(rarity));
   }

   @NotNull
   public class_1799 method_7861(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1309 entity) {
      return super.method_7861(stack, level, entity);
   }
}
