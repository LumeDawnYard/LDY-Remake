package com.bmt.kaleidoscope_nether.item;

import com.github.ysbbbbbb.kaleidoscopecookery.init.ModFoods;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1792.class_1793;
import org.jspecify.annotations.NonNull;

public class KNChiliItem extends class_1792 {
   private final int damage;

   public KNChiliItem(class_1793 p, int damage) {
      super(p.method_19265(ModFoods.CHILI));
      this.damage = damage;
   }

   public @NonNull class_1799 method_7861(@NonNull class_1799 stack, class_1937 level, class_1309 entity) {
      entity.method_64419(level.method_48963().method_48831(), this.damage);
      return super.method_7861(stack, level, entity);
   }
}
