package com.bmt.kaleidoscope_nether.item;

import java.util.function.Consumer;
import net.minecraft.class_10124;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_4985;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class NetherCaterpillarItem extends class_1792 {
   public NetherCaterpillarItem(class_1793 properties, class_4174 food, class_10124 consumable) {
      super(properties.method_62833(food, consumable));
   }

   public void method_67187(
      @NonNull class_1799 stack,
      @NonNull class_9635 context,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 flag
   ) {
      super.method_67187(stack, context, tooltipDisplay, consumer, flag);
      consumer.accept(class_2561.method_43471("item.kaleidoscope_nether.nether_caterpillar.tooltip.line1"));
   }

   @NotNull
   public class_1269 method_7847(@NotNull class_1799 stack, class_1657 player, @NotNull class_1309 target, @NotNull class_1268 hand) {
      class_1937 level = player.method_73183();
      if (!(target instanceof class_4985 strider && strider.method_6109())) {
         return super.method_7847(stack, player, target, hand);
      } else if (!level.method_8608()) {
         if (!player.method_31549().field_7477) {
            stack.method_7934(1);
         }

         strider.method_5614(0);
         level.method_8421(strider, (byte)18);
         return class_1269.field_5812;
      } else {
         return class_1269.field_21466;
      }
   }
}
