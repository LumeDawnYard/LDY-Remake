package com.bmt.kaleidoscope_nether.item;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class BlowgunItem extends class_1811 {
   public static final int MAX_DRAW_DURATION = 5;
   public static final float DEFAULT_POWER = 3.0F;

   public BlowgunItem(class_1793 properties) {
      super(properties);
   }

   @NotNull
   public Predicate<class_1799> method_19268() {
      return field_18281;
   }

   public int method_24792() {
      return 15;
   }

   protected void method_7763(@NotNull class_1309 shooter, class_1676 projectile, int index, float velocity, float inaccuracy, float angle, class_1309 target) {
      projectile.method_24919(shooter, shooter.method_36455(), shooter.method_36454() + angle, 0.0F, velocity, inaccuracy);
   }

   public boolean method_7840(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1309 shooter, int timeLeft) {
      if (shooter instanceof class_1657 player) {
         class_1799 ammo = player.method_18808(stack);
         if (!ammo.method_7960()) {
            int used = this.method_7881(stack, shooter) - timeLeft;
            used = Math.min(used, 5);
            float power = getPowerForTime(used);
            if (power >= 0.1F) {
               if (level instanceof class_3218 serverLevel) {
                  List<class_1799> projectiles = method_57390(stack, ammo, player);
                  if (!projectiles.isEmpty()) {
                     this.method_57393(serverLevel, player, player.method_6058(), stack, projectiles, power * 3.0F, 1.0F, power == 1.0F, null);
                  }
               }

               level.method_43128(
                  null,
                  player.method_23317(),
                  player.method_23318(),
                  player.method_23321(),
                  class_3417.field_14600,
                  class_3419.field_15248,
                  1.0F,
                  1.0F / (level.method_8409().method_43057() * 0.4F + 1.2F) + power * 0.5F
               );
               player.method_7259(class_3468.field_15372.method_14956(this));
               return true;
            }
         }
      }

      return false;
   }

   @NotNull
   public class_1269 method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
      class_1799 stack = player.method_5998(hand);
      boolean hasAmmo = !player.method_18808(stack).method_7960();
      if (!player.method_31549().field_7477 && !hasAmmo) {
         return class_1269.field_5814;
      }

      player.method_6019(hand);
      return class_1269.field_21466;
   }

   public int method_7881(@NotNull class_1799 stack, @NotNull class_1309 entity) {
      return 72000;
   }

   @NotNull
   public class_1839 method_7853(@NotNull class_1799 stack) {
      return class_1839.field_8953;
   }

   private static float getPowerForTime(int useTime) {
      float power = useTime / 5.0F;
      if (power > 1.0F) {
         power = 1.0F;
      }

      return power;
   }

   public boolean method_7886(@NotNull class_1799 stack) {
      return false;
   }
}
