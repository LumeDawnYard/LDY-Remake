package com.bmt.kaleidoscope_nether.item;

import com.bmt.kaleidoscope_nether.init.KNSounds;
import net.minecraft.class_10124;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3419;
import net.minecraft.class_4174;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class LavaRoastedChickenItem extends class_1792 {
   public LavaRoastedChickenItem(class_1793 properties, class_4174 food, class_10124 consumable) {
      super(properties.method_62833(food, consumable));
   }

   @NotNull
   public class_1799 method_7861(@NotNull class_1799 stack, class_1937 level, @NotNull class_1309 entity) {
      if (!level.method_8608() && entity instanceof class_1657 player) {
         level.method_43128(
            null,
            player.method_23317(),
            player.method_23318(),
            player.method_23321(),
            KNSounds.LAVA_ROASTED_CHICKEN_EAT.get(),
            class_3419.field_15248,
            1.0F,
            1.0F
         );
         entity.method_5639(29.0F);
      }

      return super.method_7861(stack, level, entity);
   }
}
