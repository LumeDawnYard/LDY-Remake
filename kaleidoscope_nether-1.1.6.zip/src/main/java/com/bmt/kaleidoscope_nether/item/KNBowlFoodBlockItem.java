package com.bmt.kaleidoscope_nether.item;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.github.ysbbbbbb.kaleidoscopecookery.block.food.FoodBiteBlock;
import com.github.ysbbbbbb.kaleidoscopecookery.config.ClientConfig;
import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_10124;
import net.minecraft.class_10132;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4174;
import net.minecraft.class_52;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8567;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_8567.class_8568;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jspecify.annotations.NonNull;

public class KNBowlFoodBlockItem extends class_1747 {
   private final List<class_1293> effectInstances = Lists.newArrayList();
   private final Optional<class_1799> usingConvertsTo;

   public KNBowlFoodBlockItem(class_2248 block, class_4174 food, class_10124 consumable, @Nullable class_1935 usingConvertsTo, String name) {
      super(
         block,
         new class_1793()
            .method_7889(16)
            .method_63685()
            .method_62833(food, consumable)
            .method_63686(class_5321.method_29179(class_7924.field_41197, KaleidoscopeNether.id(name)))
      );
      this.usingConvertsTo = usingConvertsTo == null ? Optional.empty() : Optional.of(new class_1799(usingConvertsTo));
      consumable.comp_3089().forEach(effect -> {
         if (effect instanceof class_10132 $b$0) {
            class_10132 var10000 = $b$0;

            try {
               var9 = var10000.comp_3094();
            } catch (Throwable var8) {
               throw new MatchException(var8.toString(), var8);
            }

            List patt1$temp = var9;
            List<class_1293> effects = patt1$temp;
            var10000 = $b$0;

            try {
               var10000.comp_3095();
            } catch (Throwable var7) {
               throw new MatchException(var7.toString(), var7);
            }

            if (true) {
               this.effectInstances.addAll(effects);
            }
         }
      });
   }

   @NotNull
   public class_1799 method_7861(@NonNull class_1799 stack, @NonNull class_1937 level, @NonNull class_1309 entity) {
      if (level instanceof class_3218 serverLevel && this.method_7711() instanceof FoodBiteBlock foodBiteBlock) {
         class_8568 builder = new class_8568(serverLevel)
            .method_51874(class_181.field_24424, class_243.method_24953(entity.method_24515()))
            .method_51874(class_181.field_1229, class_1799.field_8037)
            .method_51877(class_181.field_1226, entity)
            .method_51877(class_181.field_1228, null);
         class_2680 state = (class_2680)foodBiteBlock.method_9564().method_11657(foodBiteBlock.getBites(), foodBiteBlock.getMaxBites());
         List<class_1799> drops = this.getDrops(state, builder);
         drops.forEach(itemStack -> {
            if (!itemStack.method_7960()) {
               if (!this.usingConvertsTo.isPresent() || !class_1799.method_7984(itemStack, this.usingConvertsTo.get())) {
                  if (entity instanceof class_1657 player) {
                     player.method_31548().method_7398(itemStack);
                  } else {
                     class_1542 itemEntity = new class_1542(level, entity.method_23317(), entity.method_23318(), entity.method_23321(), itemStack);
                     level.method_8649(itemEntity);
                  }
               }
            }
         });
      }

      return super.method_7861(stack, level, entity);
   }

   private List<class_1799> getDrops(class_2680 state, class_8568 params) {
      if (state.method_26204().method_26162().isEmpty()) {
         return Collections.emptyList();
      }

      class_5321<class_52> lootTableKey = (class_5321<class_52>)state.method_26204().method_26162().get();
      class_8567 lootParams = params.method_51874(class_181.field_1224, state).method_51875(class_173.field_1172);
      class_3218 serverLevel = lootParams.method_51863();
      class_52 lootTable = serverLevel.method_8503().method_58576().method_58295(lootTableKey);
      return lootTable.method_51878(lootParams);
   }

   public void method_67187(
      class_1799 stack,
      @NonNull class_9635 tooltip,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 tooltipFlag
   ) {
      class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
      String key = "tooltip.%s.%s.maxim".formatted(id.method_12836(), id.method_12832());
      class_5250 full = class_2561.method_43471(key).method_27695(new class_124[]{class_124.field_1063, class_124.field_1056});
      String text = full.getString();

      for (String line : text.split("\n")) {
         if (!line.isEmpty()) {
            consumer.accept(class_2561.method_43470(line).method_27695(new class_124[]{class_124.field_1063, class_124.field_1056}));
         } else {
            consumer.accept(class_5244.field_39003);
         }
      }

      if (!this.effectInstances.isEmpty() && (Boolean)ClientConfig.SHOW_FOOD_EFFECT_TOOLTIPS.get()) {
         consumer.accept(class_5244.method_48320());
         class_1844.method_8065(this.effectInstances, consumer, 1.0F, tooltip.method_59531());
      }
   }
}
