package com.bmt.kaleidoscope_nether.item;

import com.github.ysbbbbbb.kaleidoscopecookery.item.FoodWithEffectsItem;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_10124;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_4174;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class EverlastingFoodItem extends FoodWithEffectsItem {
   private final Supplier<Integer> eatingCooldown;
   private final Supplier<Boolean> isEnabled;

   public EverlastingFoodItem(
      class_1793 properties, class_4174 food, class_10124 consumable, Supplier<Integer> eatingCooldown, Supplier<Boolean> isEnabled, class_1814 rarity
   ) {
      super(properties.method_7894(rarity), food, consumable);
      this.eatingCooldown = eatingCooldown;
      this.isEnabled = isEnabled;
   }

   public void method_67187(
      @NonNull class_1799 stack,
      @NonNull class_9635 context,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 flag
   ) {
      super.method_67187(stack, context, tooltipDisplay, consumer, flag);
      consumer.accept(class_2561.method_43471("item.kaleidoscope_nether.everlasting_flame_steak.tooltip.line1").method_27692(class_124.field_1080));
   }

   @NotNull
   public class_1799 method_7861(class_1799 stack, @NotNull class_1937 world, @NotNull class_1309 entity) {
      if (stack.method_57826(class_9334.field_50075)) {
         super.method_7861(stack.method_7972(), world, entity);
         this.addCooldown(stack, entity, this.eatingCooldown.get());
      }

      return stack;
   }

   @NotNull
   public class_1269 method_7836(@NotNull class_1937 level, @NotNull class_1657 player, @NotNull class_1268 hand) {
      return (class_1269)(!this.isEnabled.get() ? class_1269.field_5811 : super.method_7836(level, player, hand));
   }

   private void addCooldown(class_1799 stack, class_1309 entity, int cooldown) {
      if (entity instanceof class_1657 player) {
         player.method_7357().method_62835(stack, cooldown);
      }
   }
}
