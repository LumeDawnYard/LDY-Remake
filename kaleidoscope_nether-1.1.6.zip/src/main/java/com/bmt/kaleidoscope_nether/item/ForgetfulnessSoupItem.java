package com.bmt.kaleidoscope_nether.item;

import com.github.ysbbbbbb.kaleidoscopecookery.item.BowlFoodOnlyItem;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_10124;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4174;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_3222.class_10766;
import net.minecraft.class_5217.class_12064;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class ForgetfulnessSoupItem extends BowlFoodOnlyItem {
   public ForgetfulnessSoupItem(class_1793 properties, class_4174 food, class_10124 consumable) {
      super(properties, food, consumable);
   }

   public void method_67187(
      @NonNull class_1799 stack,
      @NonNull class_9635 context,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 flag
   ) {
      super.method_67187(stack, context, tooltipDisplay, consumer, flag);
      consumer.accept(class_2561.method_43471("item.kaleidoscope_nether.forgetfulness_soup.tooltip.line1").method_27692(class_124.field_1080));
   }

   @NotNull
   public class_1799 method_7861(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1309 entity) {
      class_1799 result = super.method_7861(stack, level, entity);
      if (!level.method_8608() && entity instanceof class_3222 player) {
         class_10766 respawnConfig = player.method_67564();
         class_3218 targetLevel;
         class_2338 targetPos;
         if (respawnConfig != null) {
            class_12064 respawnData = respawnConfig.comp_4913();
            targetLevel = level.method_8503() == null ? null : level.method_8503().method_3847(respawnData.method_74894());
            targetPos = respawnData.method_74897();
         } else {
            targetLevel = level.method_8503() == null ? null : level.method_8503().method_30002();
            targetPos = targetLevel == null ? null : targetLevel.method_74854().method_74897();
         }

         if (targetLevel != null && targetPos != null) {
            player.method_48105(
               targetLevel,
               targetPos.method_10263() + 0.5,
               targetPos.method_10264(),
               targetPos.method_10260() + 0.5,
               Set.of(),
               player.method_36454(),
               player.method_36455(),
               true
            );
         }

         player.method_51469()
            .method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F);
      }

      return result;
   }
}
