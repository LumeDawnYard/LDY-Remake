package com.bmt.kaleidoscope_nether.item;

import com.github.ysbbbbbb.kaleidoscopecookery.item.FoodWithEffectsItem;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_10124;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4174;
import net.minecraft.class_4208;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1792.class_9635;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

public class SoulReturnRiceItem extends FoodWithEffectsItem {
   public SoulReturnRiceItem(class_1793 properties, class_4174 food, class_10124 consumable) {
      super(properties, food, consumable);
   }

   public void method_67187(
      @NonNull class_1799 stack,
      @NonNull class_9635 context,
      @NonNull class_10712 tooltipDisplay,
      @NonNull Consumer<class_2561> consumer,
      @NonNull class_1836 flag
   ) {
      super.method_67187(stack, context, tooltipDisplay, consumer, flag);
      consumer.accept(class_2561.method_43471("item.kaleidoscope_nether.soul_return_rice.tooltip.line1").method_27692(class_124.field_1080));
   }

   @NotNull
   public class_1799 method_7861(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1309 entity) {
      class_1799 result = super.method_7861(stack, level, entity);
      if (!level.method_8608() && entity instanceof class_3222 player) {
         Optional<class_4208> deathLocation = player.method_43122();
         if (deathLocation.isPresent()) {
            class_4208 globalPos = deathLocation.get();
            class_3218 targetLevel = level.method_8503() == null ? null : level.method_8503().method_3847(globalPos.comp_2207());
            if (targetLevel != null) {
               class_2338 pos = globalPos.comp_2208();
               player.method_48105(
                  targetLevel,
                  pos.method_10263() + 0.5,
                  pos.method_10264(),
                  pos.method_10260() + 0.5,
                  Set.of(),
                  player.method_36454(),
                  player.method_36455(),
                  true
               );
               player.method_51469()
                  .method_43128(
                     null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F
                  );
            }
         }
      }

      return result;
   }
}
