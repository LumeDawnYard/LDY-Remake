package com.bmt.kaleidoscope_nether.item;

import com.github.ysbbbbbb.kaleidoscopecookery.api.item.IHasContainer;
import com.github.ysbbbbbb.kaleidoscopecookery.item.FoodWithEffectsItem;
import net.minecraft.class_10124;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_4174;
import net.minecraft.class_1792.class_1793;
import org.jetbrains.annotations.NotNull;

public class StickReturnFoodItem extends FoodWithEffectsItem implements IHasContainer {
   public StickReturnFoodItem(class_1793 itemProperties, class_4174 properties, class_10124 consumable) {
      super(itemProperties, properties, consumable);
   }

   @NotNull
   public class_1799 method_7861(@NotNull class_1799 stack, @NotNull class_1937 level, @NotNull class_1309 entity) {
      class_1799 itemStack = super.method_7861(stack, level, entity);
      class_1799 stick = new class_1799(class_1802.field_8600);
      if (itemStack.method_7960()) {
         return stick;
      }

      if (entity instanceof class_1657 player) {
         if (!player.method_31548().method_7394(stick)) {
            player.method_7328(stick, false);
         }
      } else {
         class_1542 itemEntity = new class_1542(level, entity.method_23317(), entity.method_23318(), entity.method_23321(), stick);
         level.method_8649(itemEntity);
      }

      return itemStack;
   }

   public class_1792 getContainerItem() {
      return class_1802.field_8600;
   }
}
