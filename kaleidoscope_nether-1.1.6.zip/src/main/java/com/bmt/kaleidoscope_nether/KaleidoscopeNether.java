package com.bmt.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.advancement.KNAdvancementTriggerRegistry;
import com.bmt.kaleidoscope_nether.config.MainConfig;
import com.bmt.kaleidoscope_nether.event.AnvilEventHandler;
import com.bmt.kaleidoscope_nether.event.DamageEventHandler;
import com.bmt.kaleidoscope_nether.event.ItemTabEventHandler;
import com.bmt.kaleidoscope_nether.event.KNEventSubscriber;
import com.bmt.kaleidoscope_nether.event.LavaWalkerEventHandler;
import com.bmt.kaleidoscope_nether.event.ModEvents;
import com.bmt.kaleidoscope_nether.event.StarBlessingEffectEvents;
import com.bmt.kaleidoscope_nether.init.KNBlocks;
import com.bmt.kaleidoscope_nether.init.KNBrewingRecipes;
import com.bmt.kaleidoscope_nether.init.KNComposterRegistry;
import com.bmt.kaleidoscope_nether.init.KNCreativeTabs;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNEntities;
import com.bmt.kaleidoscope_nether.init.KNFluids;
import com.bmt.kaleidoscope_nether.init.KNFoodBiteRegistry;
import com.bmt.kaleidoscope_nether.init.KNFoods;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.bmt.kaleidoscope_nether.init.KNPotions;
import com.bmt.kaleidoscope_nether.init.KNSounds;
import com.bmt.kaleidoscope_nether.integration.KaleidoscopeDollIntegration;
import com.mojang.logging.LogUtils;
import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2960;
import net.neoforged.fml.config.ModConfig.Type;
import org.slf4j.Logger;

public final class KaleidoscopeNether implements ModInitializer {
   public static final String MOD_ID = "kaleidoscope_nether";
   public static final Logger LOGGER = LogUtils.getLogger();

   public void onInitialize() {
      ConfigRegistry.INSTANCE.register("kaleidoscope_nether", Type.COMMON, MainConfig.SPEC);
      KNEffects.registerEffects();
      KNSounds.registerSoundEvents();
      KNBlocks.registerBlocks();
      KNEntities.registerEntities();
      KNPotions.registerPotions();
      KNAdvancementTriggerRegistry.register();
      KNItems.registerItems();
      KNFoodBiteRegistry.registerFoodBiteBlocks();
      KNCreativeTabs.registerTabs();
      KNFoods.init();
      KNComposterRegistry.register();
      KNBrewingRecipes.register();
      KNFluids.registerFluids();
      KNEventSubscriber.register();
      ModEvents.register();
      DamageEventHandler.register();
      LavaWalkerEventHandler.register();
      StarBlessingEffectEvents.register();
      AnvilEventHandler.register();
      ItemTabEventHandler.register();
      KaleidoscopeDollIntegration.register();
      LOGGER.info("Kaleidoscope Nether initialized on Fabric");
   }

   public static class_2960 id(String name) {
      return class_2960.method_60655("kaleidoscope_nether", name);
   }
}
