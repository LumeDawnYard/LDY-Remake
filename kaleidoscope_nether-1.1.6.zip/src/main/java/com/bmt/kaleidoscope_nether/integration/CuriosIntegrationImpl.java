package com.bmt.kaleidoscope_nether.integration;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

class CuriosIntegrationImpl {
   static boolean hasItemInCurios(class_1657 player, Class<?> itemClass) {
      try {
         Class<?> apiClass = Class.forName("dev.emi.trinkets.api.TrinketsApi");
         Method getComponent = apiClass.getMethod("getTrinketComponent", class_1309.class);
         Optional<?> componentOptional = (Optional<?>)getComponent.invoke(null, player);
         if (componentOptional.isEmpty()) {
            return false;
         }

         Object component = componentOptional.get();
         Method getInventory = component.getClass().getMethod("getInventory");
         Map<?, ?> inventory = (Map<?, ?>)getInventory.invoke(component);

         for (Object groupObj : inventory.values()) {
            if (groupObj instanceof Map<?, ?> group) {
               for (Object trinketInventory : group.values()) {
                  Method getContainerSize = trinketInventory.getClass().getMethod("getContainerSize");
                  Method getItem = trinketInventory.getClass().getMethod("getItem", int.class);
                  int size = (Integer)getContainerSize.invoke(trinketInventory);

                  for (int i = 0; i < size; i++) {
                     if (getItem.invoke(trinketInventory, i) instanceof class_1799 stack && itemClass.isInstance(stack.method_7909())) {
                        return true;
                     }
                  }
               }
            }
         }
      } catch (Exception var19) {
      }

      return false;
   }
}
