package com.bmt.kaleidoscope_nether.integration;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;

public class CuriosIntegration {
   private static final String TRINKETS_MOD_ID = "trinkets";

   public static boolean hasItemInCurios(class_1657 player, Class<?> itemClass) {
      return !isLoaded() ? false : CuriosIntegrationImpl.hasItemInCurios(player, itemClass);
   }

   public static boolean isLoaded() {
      return FabricLoader.getInstance().isModLoaded("trinkets");
   }
}
