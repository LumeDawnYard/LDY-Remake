package com.bmt.kaleidoscope_nether.integration;

public class KaleidoscopeDollIntegration {
   public static void register() {
   }
}
