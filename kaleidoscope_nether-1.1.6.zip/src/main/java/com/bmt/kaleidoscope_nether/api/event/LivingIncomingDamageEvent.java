package com.bmt.kaleidoscope_nether.api.event;

import com.github.ysbbbbbb.kaleidoscopecookery.api.event.ActionEvent;
import com.github.ysbbbbbb.kaleidoscopecookery.api.event.IActionCancelable;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

public class LivingIncomingDamageEvent extends ActionEvent implements IActionCancelable {
   private final class_1309 entity;
   private final class_1282 source;
   private final float amount;

   public LivingIncomingDamageEvent(class_1309 entity, class_1282 source, float amount) {
      this.entity = entity;
      this.source = source;
      this.amount = amount;
   }

   public class_1309 getEntity() {
      return this.entity;
   }

   public class_1282 getSource() {
      return this.source;
   }

   public float getAmount() {
      return this.amount;
   }

   @FunctionalInterface
   public interface LivingIncomingDamageHandler {
      void onIncomingDamage(LivingIncomingDamageEvent var1);
   }
}
