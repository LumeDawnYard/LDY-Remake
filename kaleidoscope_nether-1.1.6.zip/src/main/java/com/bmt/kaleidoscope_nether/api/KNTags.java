package com.bmt.kaleidoscope_nether.api;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public interface KNTags {
   interface Blocks {
      class_6862<class_2248> SOUL_SOIL_SAND = register();

      private static class_6862<class_2248> register() {
         return class_6862.method_40092(class_7924.field_41254, KaleidoscopeNether.id("soul_soil_sand"));
      }
   }

   interface Items {
      class_6862<class_1792> MOD_ITEMS = register("mod_items");
      class_6862<class_1792> SOUL_PEPPER_TRANSFORMABLE = register("soul_pepper_transformable");
      class_6862<class_1792> BLAZE_FOODS = register("blaze_foods");
      class_6862<class_1792> MAGMA_CREAM_FOODS = register("magma_cream_foods");
      class_6862<class_1792> STAR_BLESSING_FOODS = register("star_blessing_foods");
      class_6862<class_1792> WARPED_FOOD = register("warped_food");

      private static class_6862<class_1792> register(String name) {
         return class_6862.method_40092(class_7924.field_41197, KaleidoscopeNether.id(name));
      }
   }
}
