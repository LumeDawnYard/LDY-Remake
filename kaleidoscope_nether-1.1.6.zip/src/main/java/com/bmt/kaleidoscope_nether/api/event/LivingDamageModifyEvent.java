package com.bmt.kaleidoscope_nether.api.event;

import com.github.ysbbbbbb.kaleidoscopecookery.api.event.ActionEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

public class LivingDamageModifyEvent extends ActionEvent {
   private final class_1309 entity;
   private final class_1282 source;
   private final float originalDamage;
   private float newDamage;

   public LivingDamageModifyEvent(class_1309 entity, class_1282 source, float originalDamage) {
      this.entity = entity;
      this.source = source;
      this.originalDamage = originalDamage;
      this.newDamage = originalDamage;
   }

   public class_1309 getEntity() {
      return this.entity;
   }

   public class_1282 getSource() {
      return this.source;
   }

   public float getOriginalDamage() {
      return this.originalDamage;
   }

   public float getNewDamage() {
      return this.newDamage;
   }

   public void setNewDamage(float newDamage) {
      this.newDamage = newDamage;
   }

   @FunctionalInterface
   public interface LivingDamageModifyHandler {
      void onModify(LivingDamageModifyEvent var1);
   }
}
