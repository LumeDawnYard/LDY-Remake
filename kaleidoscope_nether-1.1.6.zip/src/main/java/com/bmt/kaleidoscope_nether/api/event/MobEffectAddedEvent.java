package com.bmt.kaleidoscope_nether.api.event;

import com.github.ysbbbbbb.kaleidoscopecookery.api.event.ActionEvent;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;

public class MobEffectAddedEvent extends ActionEvent {
   private final class_1309 entity;
   private final class_1293 effectInstance;
   @Nullable
   private final class_1297 source;

   public MobEffectAddedEvent(class_1309 entity, class_1293 effectInstance, @Nullable class_1297 source) {
      this.entity = entity;
      this.effectInstance = effectInstance;
      this.source = source;
   }

   public class_1309 getEntity() {
      return this.entity;
   }

   public class_1293 getEffectInstance() {
      return this.effectInstance;
   }

   @Nullable
   public class_1297 getSource() {
      return this.source;
   }

   @FunctionalInterface
   public interface MobEffectAddedHandler {
      void onAdded(MobEffectAddedEvent var1);
   }
}
