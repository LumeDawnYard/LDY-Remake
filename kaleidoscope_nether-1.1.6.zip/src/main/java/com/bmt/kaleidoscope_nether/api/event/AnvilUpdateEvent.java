package com.bmt.kaleidoscope_nether.api.event;

import com.github.ysbbbbbb.kaleidoscopecookery.api.event.ActionEvent;
import com.github.ysbbbbbb.kaleidoscopecookery.api.event.IActionCancelable;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public class AnvilUpdateEvent extends ActionEvent implements IActionCancelable {
   private final class_1799 left;
   private final class_1799 right;
   private final String name;
   private class_1799 output;
   private long cost;
   private int materialCost;
   private final class_1657 player;

   public AnvilUpdateEvent(class_1799 left, class_1799 right, String name, long cost, class_1657 player) {
      this.left = left;
      this.right = right;
      this.output = class_1799.field_8037;
      this.name = name;
      this.player = player;
      this.setCost(cost);
      this.setMaterialCost(0);
   }

   public class_1799 getLeft() {
      return this.left;
   }

   public class_1799 getRight() {
      return this.right;
   }

   @Nullable
   public String getName() {
      return this.name;
   }

   public class_1799 getOutput() {
      return this.output;
   }

   public void setOutput(class_1799 output) {
      this.output = output;
   }

   public long getCost() {
      return this.cost;
   }

   public void setCost(long cost) {
      this.cost = cost;
   }

   public int getMaterialCost() {
      return this.materialCost;
   }

   public void setMaterialCost(int materialCost) {
      this.materialCost = materialCost;
   }

   public class_1657 getPlayer() {
      return this.player;
   }

   @FunctionalInterface
   public interface AnvilUpdateHandler {
      void onUpdate(AnvilUpdateEvent var1);
   }
}
