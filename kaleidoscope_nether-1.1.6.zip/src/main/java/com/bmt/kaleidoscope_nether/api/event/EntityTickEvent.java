package com.bmt.kaleidoscope_nether.api.event;

import com.bmt.kaleidoscope_nether.init.KNEvents;
import com.github.ysbbbbbb.kaleidoscopecookery.api.event.ActionEvent;
import com.github.ysbbbbbb.kaleidoscopecookery.api.event.IActionCancelable;
import net.minecraft.class_1297;

public class EntityTickEvent extends ActionEvent {
   private final class_1297 entity;

   protected EntityTickEvent(class_1297 entity) {
      this.entity = entity;
   }

   public class_1297 getEntity() {
      return this.entity;
   }

   public static class Post extends EntityTickEvent {
      public Post(class_1297 entity) {
         super(entity);
      }

      public static void fireEntityTickPost(class_1297 entity) {
         EntityTickEvent.Post post = new EntityTickEvent.Post(entity);
         ((EntityTickEvent.Post.PostHandler)KNEvents.ENTITY_POST.invoker()).post(post);
      }

      @FunctionalInterface
      public interface PostHandler {
         void post(EntityTickEvent.Post var1);
      }
   }

   public static class Pre extends EntityTickEvent implements IActionCancelable {
      public Pre(class_1297 entity) {
         super(entity);
      }

      public void setCanceled(boolean canceled) {
         super.setCanceled(canceled);
      }

      public static EntityTickEvent.Pre fireEntityTickPre(class_1297 entity) {
         EntityTickEvent.Pre pre = new EntityTickEvent.Pre(entity);
         ((EntityTickEvent.Pre.PreHandler)KNEvents.ENTITY_PRE.invoker()).pre(pre);
         return pre;
      }

      @FunctionalInterface
      public interface PreHandler {
         void pre(EntityTickEvent.Pre var1);
      }
   }
}
