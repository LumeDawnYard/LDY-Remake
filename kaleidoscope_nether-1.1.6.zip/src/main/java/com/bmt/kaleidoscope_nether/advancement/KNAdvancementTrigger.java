package com.bmt.kaleidoscope_nether.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_4558.class_8788;
import org.jetbrains.annotations.NotNull;

public class KNAdvancementTrigger extends class_4558<KNAdvancementTrigger.Instance> {
   public void trigger(class_3222 serverPlayer, String id) {
      this.method_22510(serverPlayer, instance -> instance.triggerId().equals(id));
   }

   @NotNull
   public Codec<KNAdvancementTrigger.Instance> method_54937() {
      return KNAdvancementTrigger.Instance.CODEC;
   }

   public record Instance(Optional<class_5258> player, String triggerId) implements class_8788 {
      public static final Codec<KNAdvancementTrigger.Instance> CODEC = RecordCodecBuilder.create(
         instance -> instance.group(
               class_5258.field_47234.optionalFieldOf("player").forGetter(KNAdvancementTrigger.Instance::comp_2029),
               Codec.STRING.fieldOf("triggerId").forGetter(KNAdvancementTrigger.Instance::triggerId)
            )
            .apply(instance, KNAdvancementTrigger.Instance::new)
      );

      public static KNAdvancementTrigger.Instance id(String triggerId) {
         return new KNAdvancementTrigger.Instance(Optional.empty(), triggerId);
      }

      public Optional<class_5258> comp_2029() {
         return this.player;
      }
   }
}
