package com.bmt.kaleidoscope_nether.advancement;

import net.minecraft.class_174;

public class KNAdvancementTriggerRegistry {
   public static KNAdvancementTrigger SIMPLE_ID;

   public static void register() {
      SIMPLE_ID = (KNAdvancementTrigger)class_174.method_767("kaleidoscope_nether:simple_id", new KNAdvancementTrigger());
   }
}
