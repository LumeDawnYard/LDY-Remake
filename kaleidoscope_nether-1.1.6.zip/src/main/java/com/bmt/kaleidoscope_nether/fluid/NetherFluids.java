package com.bmt.kaleidoscope_nether.fluid;

import java.util.function.Supplier;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3621;
import net.minecraft.class_4538;
import net.minecraft.class_2689.class_2690;
import org.jetbrains.annotations.NotNull;

public abstract class NetherFluids extends class_3621 {
   private final Supplier<class_3611> still;
   private final Supplier<class_3611> flowing;

   public NetherFluids(Supplier<class_3611> still, Supplier<class_3611> flowing) {
      this.still = still;
      this.flowing = flowing;
   }

   @NotNull
   public class_3611 method_15750() {
      return this.flowing.get();
   }

   @NotNull
   public class_3611 method_15751() {
      return this.still.get();
   }

   protected boolean method_15737(class_3218 level) {
      return false;
   }

   public int method_15789(class_4538 level) {
      return 20;
   }

   public boolean method_15793(class_3610 fluidState) {
      return false;
   }

   public int method_15779(class_3610 fluidState) {
      return 0;
   }

   public static final class Flowing extends NetherFluids {
      public Flowing(Supplier<class_3611> still, Supplier<class_3611> flowing) {
         super(still, flowing);
         this.method_15781((class_3610)((class_3610)this.field_15905.method_11664()).method_11657(class_3609.field_15900, 7));
      }

      protected void method_15775(class_2690<class_3611, class_3610> builder) {
         super.method_15775(builder);
         builder.method_11667(new class_2769[]{class_3609.field_15900});
      }

      @Override
      public int method_15779(class_3610 state) {
         return (Integer)state.method_11654(class_3609.field_15900);
      }
   }

   public static final class Source extends NetherFluids {
      public Source(Supplier<class_3611> still, Supplier<class_3611> flowing) {
         super(still, flowing);
      }

      @Override
      public boolean method_15793(class_3610 state) {
         return true;
      }

      @Override
      public int method_15779(class_3610 state) {
         return 8;
      }
   }
}
