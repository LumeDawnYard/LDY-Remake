package com.bmt.kaleidoscope_nether.compat.jei;

import com.bmt.kaleidoscope_nether.init.KNItems;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

@JeiPlugin
public class KNInfo implements IModPlugin {
   @NotNull
   public class_2960 getPluginUid() {
      return class_2960.method_60655("kaleidoscope_nether", "jei_plugin");
   }

   public void registerRecipes(@NotNull IRecipeRegistration registration) {
      this.addAllMaterialInfo(registration);
   }

   private void addAllMaterialInfo(IRecipeRegistration registration) {
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.GHAST_HIDE.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.ghast_hide.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.HOGLIN_TUSK.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.hoglin_tusk.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.STRIDER_ROCK_SHELL.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.strider_rock_shell.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.GILDED_FRAGMENT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.gilded_fragment.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.WITHER_RIB.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.wither_rib.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.STAR_DUST.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.star_dust.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.BLAZE_HEART.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.blaze_heart.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.HOGLIN_HIDE.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.hoglin_hide.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.RAW_STRIDER_MEAT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.raw_strider_meat.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.HAM.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.ham.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.GHAST_TENTACLE.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.ghast_tentacle.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.RAW_PIGLIN_MEAT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.raw_piglin_meat.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.CRIMSON_FRUIT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.crimson_fruit.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.WARPED_FRUIT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.warped_fruit.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.POISONOUS_FRUIT.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.poisonous_fruit.description")}
      );
      registration.addIngredientInfo(
         new class_1799((class_1935)KNItems.SOUL_PEPPER.get()),
         VanillaTypes.ITEM_STACK,
         new class_2561[]{class_2561.method_43471("item.kaleidoscope_nether.soul_pepper.description")}
      );
   }
}
