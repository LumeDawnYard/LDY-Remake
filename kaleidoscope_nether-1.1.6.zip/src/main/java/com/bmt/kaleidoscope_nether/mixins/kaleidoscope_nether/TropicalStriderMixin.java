package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.init.KNEffects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_5134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class TropicalStriderMixin extends class_1297 {
   public TropicalStriderMixin(class_1299<?> entityType, class_1937 level) {
      super(entityType, level);
   }

   @Inject(method = "method_23326", at = @At("HEAD"), cancellable = true)
   private void onGetBlockSpeedFactor(CallbackInfoReturnable<Float> cir) {
      class_1309 entity = (class_1309)this;
      if (entity.method_6059(KNEffects.TROPICAL_STRIDER) && this.method_73183().method_27983().equals(class_1937.field_25180)) {
         class_2680 blockState = this.method_73183().method_8320(this.method_23314());
         float friction = blockState.method_26204().method_9499();
         float baseSpeed = 1.0F;
         float frictionBonus = Math.max(1.0F - friction, 0.0F) * 0.2F;
         float totalSpeed = baseSpeed + frictionBonus;
         float movementEfficiency = (float)entity.method_45325(class_5134.field_51582);
         float finalSpeed = class_3532.method_16439(movementEfficiency, totalSpeed, 1.0F);
         cir.setReturnValue(finalSpeed);
      }
   }
}
