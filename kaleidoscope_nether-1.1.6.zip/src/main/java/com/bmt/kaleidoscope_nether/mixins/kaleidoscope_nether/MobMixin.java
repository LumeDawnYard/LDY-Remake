package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import com.bmt.kaleidoscope_nether.item.GhastPendantItem;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1571;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public abstract class MobMixin {
   @Inject(method = "method_5968", at = @At("RETURN"), cancellable = true)
   private void onGetTarget(CallbackInfoReturnable<class_1309> cir) {
      class_1309 target = (class_1309)cir.getReturnValue();
      if (target instanceof class_1657 player) {
         class_1308 self = (class_1308)this;
         if (self instanceof class_1571 && GhastPendantItem.isWearingGhastPendant(player)) {
            cir.setReturnValue(null);
            return;
         }

         if (WarpedEffect.isAffectedMob(self) && WarpedEffect.shouldAffectMob(self, player)) {
            cir.setReturnValue(null);
         }
      }
   }

   @Inject(method = "method_5980", at = @At("HEAD"), cancellable = true)
   private void onSetTarget(class_1309 target, CallbackInfo ci) {
      if (target instanceof class_1657 player) {
         class_1308 self = (class_1308)this;
         if (self instanceof class_1571 && GhastPendantItem.isWearingGhastPendant(player)) {
            ci.cancel();
            return;
         }

         if (WarpedEffect.isAffectedMob(self) && WarpedEffect.shouldAffectMob(self, player)) {
            ci.cancel();
         }
      }
   }
}
