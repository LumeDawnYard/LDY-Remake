package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether.client;

import com.bmt.kaleidoscope_nether.api.event.EntityTickEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_638.class)
public class ClientLevelMixin {
   @WrapOperation(method = "method_18646", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1297;method_5773()V"))
   private void tickNonPassenger(class_1297 instance, Operation<Void> original) {
      EntityTickEvent.Pre pre = EntityTickEvent.Pre.fireEntityTickPre(instance);
      if (!pre.isCanceled()) {
         original.call(new Object[]{instance});
         EntityTickEvent.Post.fireEntityTickPost(instance);
      }
   }
}
