package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.api.event.EntityTickEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3218.class)
public class ServerLevelMixin {
   @WrapOperation(method = "method_18762", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1297;method_5773()V"))
   private void tickNonPassenger(class_1297 instance, Operation<Void> original) {
      EntityTickEvent.Pre pre = EntityTickEvent.Pre.fireEntityTickPre(instance);
      if (!pre.isCanceled()) {
         original.call(new Object[]{instance});
         EntityTickEvent.Post.fireEntityTickPost(instance);
      }
   }
}
