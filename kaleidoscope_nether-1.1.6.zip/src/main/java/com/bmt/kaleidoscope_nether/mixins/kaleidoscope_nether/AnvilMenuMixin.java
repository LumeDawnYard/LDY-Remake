package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.api.event.AnvilUpdateEvent;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.class_8047;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1706.class)
public abstract class AnvilMenuMixin extends class_4861 {
   @Unique
   private static final class_8047 KN$SLOT_DEFINITION = class_8047.method_48364()
      .method_48374(0, 27, 47, stack -> true)
      .method_48374(1, 76, 47, stack -> true)
      .method_48373(2, 134, 47)
      .method_48372();
   @Shadow
   @Nullable
   private String field_7774;

   public AnvilMenuMixin(@Nullable class_3917<?> menuType, int i, class_1661 inventory, class_3914 containerLevelAccess) {
      super(menuType, i, inventory, containerLevelAccess, KN$SLOT_DEFINITION);
   }

   @Inject(
      method = "method_24928",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1799;method_7960()Z", ordinal = 0, shift = Shift.BEFORE),
      cancellable = true
   )
   private void createResult(CallbackInfo ci, @Local class_1799 itemStack, @Local long j) {
      if (!itemStack.method_7960()
         && !onAnvilChange((class_1706)this, itemStack, this.field_22480.method_5438(1), this.field_22479, this.field_7774, j, this.field_22482)) {
         ci.cancel();
      }
   }

   @Unique
   private static boolean onAnvilChange(
      class_1706 container, class_1799 left, class_1799 right, class_1263 outputSlot, String name, long baseCost, class_1657 player
   ) {
      AnvilUpdateEvent e = new AnvilUpdateEvent(left, right, name, baseCost, player);
      ((AnvilUpdateEvent.AnvilUpdateHandler)KNEvents.UPDATE_ANVIL.invoker()).onUpdate(e);
      if (e.isCanceled()) {
         outputSlot.method_5447(0, class_1799.field_8037);
         container.field_7770.method_17404((int)class_3532.method_53062(0L, 0L, 2147483647L));
         container.field_7776 = 0;
         return false;
      }

      if (e.getOutput().method_7960()) {
         return true;
      }

      outputSlot.method_5447(0, e.getOutput());
      container.field_7770.method_17404((int)class_3532.method_53062(e.getCost(), 0L, 2147483647L));
      container.field_7776 = e.getMaterialCost();
      return false;
   }
}
