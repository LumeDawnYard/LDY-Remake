package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_5418;
import net.minecraft.class_5420;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5420.class)
public abstract class PiglinBruteAiMixin {
   @Inject(method = "method_30247", at = @At("RETURN"), cancellable = true)
   private static void onFindNearestValidAttackTarget(
      class_3218 serverLevel, class_5418 abstractPiglin, CallbackInfoReturnable<Optional<? extends class_1309>> cir
   ) {
      Optional<? extends class_1309> targetOptional = (Optional<? extends class_1309>)cir.getReturnValue();
      if (targetOptional.isPresent()) {
         class_1309 target = targetOptional.get();
         if (target instanceof class_1657 player && WarpedEffect.shouldAffectMob(abstractPiglin, player)) {
            cir.setReturnValue(Optional.empty());
         }
      }
   }
}
