package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_4760;
import net.minecraft.class_4835;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4835.class)
public abstract class HoglinAiMixin {
   @Inject(method = "method_24684", at = @At("RETURN"), cancellable = true)
   private static void onFindNearestValidAttackTarget(class_3218 serverLevel, class_4760 hoglin, CallbackInfoReturnable<Optional<? extends class_1309>> cir) {
      Optional<? extends class_1309> targetOptional = (Optional<? extends class_1309>)cir.getReturnValue();
      if (targetOptional.isPresent()) {
         class_1309 target = targetOptional.get();
         if (target instanceof class_1657 player && WarpedEffect.shouldAffectMob(hoglin, player)) {
            cir.setReturnValue(Optional.empty());
         }
      }
   }

   @Inject(method = "method_24672", at = @At("HEAD"), cancellable = true)
   private static void onWasHurtBy(class_3218 serverLevel, class_4760 hoglin, class_1309 attacker, CallbackInfo ci) {
      if (attacker instanceof class_1657 player && WarpedEffect.shouldAffectMob(hoglin, player)) {
         ci.cancel();
      }
   }

   @Inject(method = "method_24685", at = @At("HEAD"), cancellable = true)
   private static void onSetAttackTarget(class_4760 hoglin, class_1309 target, CallbackInfo ci) {
      if (target instanceof class_1657 player && WarpedEffect.shouldAffectMob(hoglin, player)) {
         ci.cancel();
      }
   }
}
