package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_4836;
import net.minecraft.class_4838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4838.class)
public abstract class PiglinAiMixin {
   @Inject(method = "method_24777", at = @At("RETURN"), cancellable = true)
   private static void onFindNearestValidAttackTarget(class_3218 serverLevel, class_4836 piglin, CallbackInfoReturnable<Optional<? extends class_1309>> cir) {
      Optional<? extends class_1309> targetOptional = (Optional<? extends class_1309>)cir.getReturnValue();
      if (targetOptional.isPresent()) {
         class_1309 target = targetOptional.get();
         if (target instanceof class_1657 player && WarpedEffect.shouldAffectMob(piglin, player)) {
            cir.setReturnValue(Optional.empty());
         }
      }
   }
}
