package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.api.KNTags;
import com.bmt.kaleidoscope_nether.init.KNBlocks;
import com.bmt.kaleidoscope_nether.init.KNItems;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModItems;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1747.class)
public abstract class BlockItemMixin {
   @Inject(method = "method_7707", at = @At("RETURN"), cancellable = true)
   private void replaceState(class_1750 context, CallbackInfoReturnable<class_2680> cir) {
      if (context.method_8041().method_7909() == ModItems.CHILI_SEED
         && context.method_8045().method_8320(context.method_8037().method_10087(1)).method_26164(KNTags.Blocks.SOUL_SOIL_SAND)) {
         cir.setReturnValue(KNBlocks.SOUL_PEPPER.get().method_9564());
      }

      if (context.method_8041().method_7909() == KNItems.POISONOUS_FRUIT.get()
         && context.method_8045().method_8320(context.method_8037().method_10087(1)).method_26164(KNTags.Blocks.SOUL_SOIL_SAND)) {
         cir.setReturnValue(KNBlocks.POISONOUS_FRUIT.get().method_9564());
      }
   }
}
