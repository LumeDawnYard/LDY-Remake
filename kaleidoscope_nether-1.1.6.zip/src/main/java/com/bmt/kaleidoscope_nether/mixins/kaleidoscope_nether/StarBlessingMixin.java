package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.init.KNEffects;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class StarBlessingMixin extends class_1297 {
   public StarBlessingMixin(class_1299<?> entityType, class_1937 level) {
      super(entityType, level);
   }

   @Inject(method = "method_37222", at = @At("HEAD"), cancellable = true)
   private void onAddEffect(class_1293 effectInstance, class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
      class_1309 livingEntity = (class_1309)this;
      if (livingEntity.method_6059(KNEffects.STAR_BLESSING)) {
         class_1291 effect = (class_1291)effectInstance.method_5579().comp_349();
         if (effect.method_18792() == class_4081.field_18272) {
            cir.setReturnValue(false);
            cir.cancel();
         }
      }
   }

   @Inject(method = "method_6005", at = @At("HEAD"), cancellable = true)
   private void onKnockback(double strength, double x, double z, CallbackInfo ci) {
      class_1309 livingEntity = (class_1309)this;
      if (livingEntity.method_6059(KNEffects.STAR_BLESSING)) {
         ci.cancel();
      }
   }

   @Inject(method = "method_64397", at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1309;method_6005(DDD)V"))
   private void onHurtKnockback(class_3218 serverLevel, class_1282 damageSource, float f, CallbackInfoReturnable<Boolean> cir) {
      class_1309 livingEntity = (class_1309)this;
      livingEntity.method_6059(KNEffects.STAR_BLESSING);
   }
}
