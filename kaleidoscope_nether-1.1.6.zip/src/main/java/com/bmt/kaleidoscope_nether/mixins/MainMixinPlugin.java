package com.bmt.kaleidoscope_nether.mixins;

import com.mojang.logging.LogUtils;
import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public class MainMixinPlugin implements IMixinConfigPlugin {
   private static final Logger LOGGER = LogUtils.getLogger();

   public void onLoad(String mixinPackage) {
      LOGGER.info("Initializing Kaleidoscope Nether Mixins");
   }

   public String getRefMapperConfig() {
      return null;
   }

   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
      return !targetClassName.contains("FoodProperties") || !FabricLoader.getInstance().isModLoaded("kaleidoscope_end");
   }

   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
   }

   public List<String> getMixins() {
      return null;
   }

   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }

   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }
}
