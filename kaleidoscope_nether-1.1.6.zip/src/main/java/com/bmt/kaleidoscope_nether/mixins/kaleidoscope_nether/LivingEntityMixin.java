package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.api.event.LivingDamageModifyEvent;
import com.bmt.kaleidoscope_nether.api.event.LivingIncomingDamageEvent;
import com.bmt.kaleidoscope_nether.api.event.MobEffectAddedEvent;
import com.bmt.kaleidoscope_nether.effect.CrimsonEffect;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
   @Inject(method = "method_64397", at = @At("HEAD"), cancellable = true)
   private void onIncomingDamage(class_3218 serverLevel, class_1282 damageSource, float damage, CallbackInfoReturnable<Boolean> cir) {
      LivingIncomingDamageEvent event = new LivingIncomingDamageEvent((class_1309)this, damageSource, damage);
      ((LivingIncomingDamageEvent.LivingIncomingDamageHandler)KNEvents.LIVING_INCOMING_DAMAGE.invoker()).onIncomingDamage(event);
      if (event.isCanceled()) {
         cir.setReturnValue(false);
      }
   }

   @ModifyVariable(method = "method_64397", at = @At("HEAD"), argsOnly = true, ordinal = 0)
   private float modifyDamage(float damage, class_3218 serverLevel, class_1282 damageSource) {
      LivingDamageModifyEvent event = new LivingDamageModifyEvent((class_1309)this, damageSource, damage);
      ((LivingDamageModifyEvent.LivingDamageModifyHandler)KNEvents.MODIFY_LIVING_DAMAGE.invoker()).onModify(event);
      return event.getNewDamage();
   }

   @Inject(
      method = "method_37222",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1309;method_6020(Lnet/minecraft/class_1293;Lnet/minecraft/class_1297;)V", shift = Shift.AFTER)
   )
   private void onEffectAdded(class_1293 effectInstance, @Nullable class_1297 source, CallbackInfoReturnable<Boolean> cir) {
      ((MobEffectAddedEvent.MobEffectAddedHandler)KNEvents.MOB_EFFECT_ADDED.invoker())
         .onAdded(new MobEffectAddedEvent((class_1309)this, effectInstance, source));
   }

   @Inject(method = "method_6132", at = @At("HEAD"), cancellable = true)
   private void onGetDamageAfterArmorAbsorb(class_1282 damageSource, float damage, CallbackInfoReturnable<Float> cir) {
      class_1309 target = (class_1309)this;
      if (damageSource.method_5529() instanceof class_1309 attacker && attacker.method_6059(KNEffects.CRIMSON)) {
         float effectiveArmor = CrimsonEffect.calculateArmorPenetration(attacker, target);
         float armorDamageReduction = effectiveArmor * 0.04F;
         float totalDamageReduction = armorDamageReduction * damage;
         float finalDamage = damage - totalDamageReduction;
         cir.setReturnValue(finalDamage);
      }
   }
}
