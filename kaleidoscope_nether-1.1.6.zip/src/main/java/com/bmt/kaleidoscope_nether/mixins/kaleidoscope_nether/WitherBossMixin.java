package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import net.minecraft.class_1309;
import net.minecraft.class_1528;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1528.class)
public abstract class WitherBossMixin {
   @Inject(method = "method_6882", at = @At("RETURN"), cancellable = true)
   private void onGetAlternativeTarget(int head, CallbackInfoReturnable<Integer> cir) {
      int entityId = (Integer)cir.getReturnValue();
      if (entityId > 0) {
         class_1528 self = (class_1528)this;
         if ((self.method_73183().method_8469(entityId) instanceof class_1309 living ? living : null) instanceof class_1657 player
            && WarpedEffect.shouldAffectMob(self, player)) {
            cir.setReturnValue(0);
         }
      }
   }

   @Inject(method = "method_6876", at = @At("HEAD"), cancellable = true)
   private void onSetAlternativeTarget(int targetOffset, int newId, CallbackInfo ci) {
      if (newId > 0) {
         class_1528 self = (class_1528)this;
         if ((self.method_73183().method_8469(newId) instanceof class_1309 living ? living : null) instanceof class_1657 player
            && WarpedEffect.shouldAffectMob(self, player)) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = "method_5958",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1528;method_5968()Lnet/minecraft/class_1309;", shift = Shift.AFTER)
   )
   private void onCustomServerAiStep(CallbackInfo ci) {
      class_1528 self = (class_1528)this;
      if (self.method_5968() instanceof class_1657 player && WarpedEffect.shouldAffectMob(self, player)) {
         self.method_5980(null);
      }
   }
}
