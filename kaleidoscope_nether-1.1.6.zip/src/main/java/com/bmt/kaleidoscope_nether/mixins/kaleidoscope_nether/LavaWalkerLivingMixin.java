package com.bmt.kaleidoscope_nether.mixins.kaleidoscope_nether;

import com.bmt.kaleidoscope_nether.init.KNEnchantments;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_7924;
import net.minecraft.class_2350.class_2351;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1297.class)
public class LavaWalkerLivingMixin {
   @ModifyVariable(
      method = "method_5784",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1297;method_17835(Lnet/minecraft/class_243;)Lnet/minecraft/class_243;"),
      argsOnly = true
   )
   public class_243 lavaWalker$enableLavaWalking(class_243 original) {
      class_1297 boots = (class_1297)this;
      if (boots instanceof class_1309 entity) {
         if (original.field_1351 > 0.0) {
            return original;
         }

         class_1799 bootsx = entity.method_6118(class_1304.field_6166);
         if (bootsx.method_7960()) {
            return original;
         }

         int enchantmentLevel = class_1890.method_8225(
            entity.method_73183().method_30349().method_30530(class_7924.field_41265).method_46747(KNEnchantments.LAVA_WALKER), bootsx
         );
         if (enchantmentLevel <= 0) {
            return original;
         }

         if (entity.method_5715()) {
            return original;
         }

         class_1937 level = entity.method_73183();
         int[][] offsets = new int[][]{
            {1, 0, 1}, {1, 0, 0}, {1, -1, 0}, {1, 0, -1}, {0, 0, 1}, {0, 0, 0}, {0, -1, 0}, {0, 0, -1}, {-1, 0, 1}, {-1, 0, 0}, {-1, -1, 0}, {-1, 0, -1}
         };
         double highestLavaY = original.field_1351;
         boolean foundLava = false;

         for (int[] offset : offsets) {
            class_2338 sourcePos = entity.method_24515();
            class_2338 pos = new class_2338(sourcePos.method_10263() + offset[0], sourcePos.method_10264() + offset[1], sourcePos.method_10260() + offset[2]);
            class_3610 fluidState = level.method_8316(pos);
            if (!fluidState.method_15769() && fluidState.method_15767(class_3486.field_15518)) {
               class_265 shape = class_259.method_1077().method_1096(pos.method_10263(), pos.method_10264() + fluidState.method_20785(), pos.method_10260());
               if (class_259.method_1074(shape, class_259.method_1078(entity.method_5829().method_1014(0.5)), class_247.field_16896)) {
                  double height = shape.method_1105(class_2351.field_11052) - entity.method_23318() - 1.0;
                  if (highestLavaY < height) {
                     highestLavaY = height;
                     foundLava = true;
                  }
               }
            }
         }

         if (foundLava) {
            entity.field_6017 = 0.0;
            entity.method_24830(true);
            return new class_243(original.field_1352, highestLavaY, original.field_1350);
         } else {
            return original;
         }
      } else {
         return original;
      }
   }
}
