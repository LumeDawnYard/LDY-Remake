package com.bmt.kaleidoscope_nether.config;

import java.util.Arrays;
import java.util.List;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.ConfigValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class MainConfig {
   private static final Builder BUILDER = new Builder();
   public static final BooleanValue STAR_DUST_REPAIR_ENABLED = BUILDER.comment("Whether star dust repair functionality is enabled").define("enabled", true);
   public static final IntValue STAR_DUST_REPAIR_PERCENTAGE = BUILDER.comment("Star dust repair percentage (e.g., 25 means 25%)")
      .defineInRange("percentage", 25, 1, 100);
   public static final IntValue STAR_DUST_REPAIR_FLAT = BUILDER.comment("Star dust flat repair value (additional durability points repaired)")
      .defineInRange("flat", 150, 1, 1000);
   public static final BooleanValue EVERLASTING_FLAME_STEAK_ENABLED = BUILDER.comment("Whether the Everlasting Flame Steak is enabled").define("enabled", true);
   public static final IntValue EVERLASTING_FLAME_STEAK_COOLDOWN = BUILDER.comment("Cooldown in ticks for Everlasting Flame Steak (20 ticks = 1 second)")
      .defineInRange("cooldown", 300, 0, 1200);
   public static final ConfigValue<List<? extends String>> WARPED_BUFF_AFFECTED_MOBS = BUILDER.comment(
         "List of mob entity IDs that are affected by Warped Buff (e.g., minecraft:piglin, minecraft:ghast)"
      )
      .defineList(
         "affectedMobs",
         Arrays.asList(
            "minecraft:piglin",
            "minecraft:piglin_brute",
            "minecraft:zombified_piglin",
            "minecraft:hoglin",
            "minecraft:zoglin",
            "minecraft:ghast",
            "minecraft:magma_cube",
            "minecraft:blaze",
            "minecraft:wither_skeleton",
            "minecraft:wither"
         ),
         obj -> obj instanceof String
      );
   public static final BooleanValue BLAZE_HEART_DESTROY_TERRAIN = BUILDER.comment("Whether Blaze Heart explosion destroys terrain blocks")
      .define("destroyTerrain", false);
   public static final BooleanValue BLAZE_HEART_HURT_OWNER = BUILDER.comment("Whether Blaze Heart explosion can hurt the thrower/owner")
      .define("hurtOwner", false);
   public static final ModConfigSpec SPEC = BUILDER.build();

   private MainConfig() {
   }

   static {
      BUILDER.push("star_dust_repair");
      BUILDER.pop();
      BUILDER.push("everlasting_flame_steak");
      BUILDER.pop();
      BUILDER.push("warped_buff");
      BUILDER.pop();
      BUILDER.push("blaze_heart");
      BUILDER.pop();
   }
}
