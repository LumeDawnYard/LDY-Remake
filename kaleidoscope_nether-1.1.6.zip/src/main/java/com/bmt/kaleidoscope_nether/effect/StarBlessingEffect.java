package com.bmt.kaleidoscope_nether.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_4081;

public class StarBlessingEffect extends class_1291 {
   public StarBlessingEffect(int color) {
      super(class_4081.field_18271, color);
   }

   public boolean method_5572(class_3218 serverLevel, class_1309 entity, int amplifier) {
      if (entity instanceof class_1657 player && player.field_6012 % 10 == 0) {
         float maxHealth = player.method_6063();
         float healAmount = maxHealth * 0.02F;
         player.method_6025(healAmount);
      }

      return true;
   }

   public boolean method_5552(int duration, int amplifier) {
      return true;
   }
}
