package com.bmt.kaleidoscope_nether.effect;

import com.bmt.kaleidoscope_nether.config.MainConfig;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_7923;

public class WarpedEffect extends class_1291 {
   public WarpedEffect(int color) {
      super(class_4081.field_18271, color);
   }

   public boolean method_5552(int duration, int amplifier) {
      return false;
   }

   public static boolean shouldAffectMob(class_1309 target, class_1309 player) {
      return !player.method_6059(KNEffects.WARPED) ? false : isAffectedMob(target);
   }

   public static boolean isAffectedMob(class_1309 entity) {
      List<? extends String> affectedMobIds = (List<? extends String>)MainConfig.WARPED_BUFF_AFFECTED_MOBS.get();
      if (affectedMobIds.isEmpty()) {
         return false;
      }

      class_2960 entityId = class_7923.field_41177.method_10221(entity.method_5864());
      String entityIdString = entityId.toString();
      return affectedMobIds.contains(entityIdString);
   }
}
