package com.bmt.kaleidoscope_nether.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4081;

public class TropicalStriderEffect extends class_1291 {
   public TropicalStriderEffect(int color) {
      super(class_4081.field_18271, color);
   }

   public boolean method_5552(int duration, int amplifier) {
      return duration % 20 == 0;
   }

   public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int amplifier) {
      boolean isInNether = serverLevel.method_27983().equals(class_1937.field_25180);
      if (isInNether) {
         class_2338 posBelow = livingEntity.method_23312();
         if (livingEntity.method_5809() && serverLevel.method_8320(posBelow).method_26204() == class_2246.field_10092) {
            livingEntity.method_5646();
         }
      }

      return true;
   }
}
