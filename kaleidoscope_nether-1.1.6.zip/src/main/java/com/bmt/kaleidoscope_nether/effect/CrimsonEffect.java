package com.bmt.kaleidoscope_nether.effect;

import com.bmt.kaleidoscope_nether.init.KNEffects;
import java.util.Objects;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.jetbrains.annotations.NotNull;

public class CrimsonEffect extends class_1291 {
   public CrimsonEffect(int color) {
      super(class_4081.field_18271, color);
   }

   public boolean method_5572(@NotNull class_3218 serverLevel, @NotNull class_1309 livingEntity, int amplifier) {
      return false;
   }

   public static float calculateDamageBonus(class_1309 attacker, float baseDamage) {
      if (attacker.method_6059(KNEffects.CRIMSON)) {
         int amplifier = Objects.requireNonNull(attacker.method_6112(KNEffects.CRIMSON)).method_5578();
         float multiplier = 1.5F + amplifier * 0.5F;
         return baseDamage * multiplier;
      } else {
         return baseDamage;
      }
   }

   public static float calculateArmorPenetration(class_1309 attacker, class_1309 target) {
      if (attacker.method_6059(KNEffects.CRIMSON)) {
         float armorValue = target.method_6096();
         float armorPenetration = armorValue * 0.3F + 10.0F;
         return Math.max(0.0F, armorValue - armorPenetration);
      } else {
         return target.method_6096();
      }
   }

   @Deprecated
   public static float getDamageMultiplier(class_1309 attacker, class_1309 target) {
      if (attacker.method_6059(KNEffects.CRIMSON)) {
         int amplifier = Objects.requireNonNull(attacker.method_6112(KNEffects.CRIMSON)).method_5578();
         return 1.5F + amplifier * 0.5F;
      } else {
         return 1.0F;
      }
   }
}
