package com.bmt.kaleidoscope_nether.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_4081;
import org.jspecify.annotations.NonNull;

public class GhostEffect extends class_1291 {
   public GhostEffect(int color) {
      super(class_4081.field_18271, color);
   }

   public boolean method_5572(@NonNull class_3218 serverLevel, @NonNull class_1309 entity, int amplifier) {
      if (this.shouldWallClimb(entity)) {
         entity.field_6017 = 0.0;
         class_243 motion = entity.method_18798();
         double horizontalLimit = 0.15;
         double climbSpeed = entity.method_21754() ? 0.0 : 0.2;
         entity.method_18800(
            class_3532.method_15350(motion.field_1352, -0.15, 0.15),
            Math.max(motion.field_1351, climbSpeed),
            class_3532.method_15350(motion.field_1350, -0.15, 0.15)
         );
         entity.field_6037 = true;
         entity.method_35054(true);
      }

      this.spawnSoulParticles(serverLevel, entity, amplifier);
      return true;
   }

   private boolean shouldWallClimb(class_1309 entity) {
      return !entity.method_6101() && !entity.method_5799() && !entity.method_5771() ? entity.field_5976 || entity.field_34927 : false;
   }

   private void spawnSoulParticles(class_3218 serverLevel, class_1309 entity, int amplifier) {
      if (entity.field_6012 % 10 == 0) {
         class_243 pos = entity.method_73189();
         int particleCount = 1 + amplifier;

         for (int i = 0; i < particleCount; i++) {
            double offsetX = (entity.method_59922().method_43058() - 0.5) * entity.method_17681();
            double offsetY = entity.method_59922().method_43058() * entity.method_17682();
            double offsetZ = (entity.method_59922().method_43058() - 0.5) * entity.method_17681();
            double speedX = (entity.method_59922().method_43058() - 0.5) * 0.01;
            double speedY = entity.method_59922().method_43058() * 0.03 + 0.01;
            double speedZ = (entity.method_59922().method_43058() - 0.5) * 0.01;
            serverLevel.method_65096(
               class_2398.field_23114, pos.method_10216() + offsetX, pos.method_10214() + offsetY, pos.method_10215() + offsetZ, 1, speedX, speedY, speedZ, 0.0
            );
         }
      }
   }

   public boolean method_5552(int duration, int amplifier) {
      return true;
   }
}
