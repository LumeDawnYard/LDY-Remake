package com.bmt.kaleidoscope_nether.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.jetbrains.annotations.NotNull;

public class MysteriousPoisonEffect extends class_1291 {
   public MysteriousPoisonEffect(int color) {
      super(class_4081.field_18272, color);
   }

   public boolean method_5572(@NotNull class_3218 serverLevel, @NotNull class_1309 livingEntity, int amplifier) {
      float maxHealth = livingEntity.method_6063();
      float damage = maxHealth * 0.01F + amplifier * 0.5F;
      damage = Math.max(damage, 1.0F);
      livingEntity.method_64419(serverLevel.method_48963().method_48831(), damage);
      return true;
   }

   public boolean method_5552(int duration, int amplifier) {
      int interval = 20 - amplifier * 3;
      interval = Math.max(interval, 5);
      return duration % interval == 0;
   }
}
