package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.api.event.LivingIncomingDamageEvent;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import com.bmt.kaleidoscope_nether.init.KNPotions;
import net.minecraft.class_1293;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class ModEvents {
   public static void register() {
      KNEvents.LIVING_INCOMING_DAMAGE.register(ModEvents::onLivingIncomingDamage);
   }

   public static void onLivingIncomingDamage(LivingIncomingDamageEvent event) {
      if (event.getSource().method_5526() instanceof class_1665 arrow) {
         class_1844 potionContents = getArrowPotionContents(arrow);
         if (!potionContents.comp_2378().isEmpty() && ((class_6880)potionContents.comp_2378().get()).method_55838(KNPotions.MYSTERIOUS_POISON)) {
            class_1293 instance = event.getEntity().method_6112(KNEffects.MYSTERIOUS_POISON);
            if (instance != null) {
               event.getEntity().method_6092(new class_1293(KNEffects.MYSTERIOUS_POISON, 187, instance.method_5578() + 1));
            } else {
               event.getEntity().method_6092(new class_1293(KNEffects.MYSTERIOUS_POISON, 1500, 0));
            }
         }
      }
   }

   private static class_1844 getArrowPotionContents(class_1665 arrow) {
      class_1799 pickupStack = arrow.method_54759();
      return (class_1844)pickupStack.method_58695(class_9334.field_49651, class_1844.field_49274);
   }
}
