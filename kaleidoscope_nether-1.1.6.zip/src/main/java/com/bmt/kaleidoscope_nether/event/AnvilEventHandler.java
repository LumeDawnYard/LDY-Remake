package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.api.event.AnvilUpdateEvent;
import com.bmt.kaleidoscope_nether.init.KNEnchantments;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import com.bmt.kaleidoscope_nether.init.KNItems;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_9304.class_9305;

public class AnvilEventHandler {
   private static final String SHELL_COUNT_TAG = "StriderShellCount";
   private static final int REQUIRED_SHELLS = 1;

   public static void register() {
      KNEvents.UPDATE_ANVIL.register(AnvilEventHandler::onAnvilUpdate);
   }

   public static void onAnvilUpdate(AnvilUpdateEvent event) {
      class_1799 left = event.getLeft();
      class_1799 right = event.getRight();
      if (isBoots(left) && right.method_31574(KNItems.STRIDER_ROCK_SHELL.get())) {
         class_9304 enchantments = left.method_58657();
         class_2378<class_1887> enchantmentLookup = event.getPlayer().method_73183().method_30349().method_30530(class_7924.field_41265);
         class_6883<class_1887> lavaWalker = enchantmentLookup.method_46747(KNEnchantments.LAVA_WALKER);
         if (enchantments.method_57536(lavaWalker) > 0) {
            return;
         }

         if (right.method_7947() < 1) {
            return;
         }

         class_1799 result = left.method_7972();
         class_9305 mutable = new class_9305(result.method_58657());
         mutable.method_57547(lavaWalker, 1);
         result.method_57379(class_9334.field_49633, mutable.method_57549());
         class_2487 tag = ((class_9279)left.method_58695(class_9334.field_49628, class_9279.field_49302)).method_57461();
         if (tag.method_10545("StriderShellCount")) {
            tag.method_10551("StriderShellCount");
         }

         if (!tag.method_33133()) {
            result.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
         }

         event.setOutput(result);
         event.setCost(1L);
         event.setMaterialCost(1);
      }
   }

   private static boolean isBoots(class_1799 stack) {
      if (stack.method_7960()) {
         return false;
      }

      class_10192 equippable = (class_10192)stack.method_58694(class_9334.field_54196);
      return equippable != null && equippable.comp_3174() == class_1304.field_6166;
   }
}
