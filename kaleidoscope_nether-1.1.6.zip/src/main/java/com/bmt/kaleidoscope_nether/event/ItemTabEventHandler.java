package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.init.KNItems;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.ModifyEntries;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_7706;

public class ItemTabEventHandler {
   public static void register() {
      ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202)
         .register((ModifyEntries)entries -> entries.addAfter(class_1802.field_8399, new class_1935[]{(class_1935)KNItems.BLOWGUN.get()}));
   }
}
