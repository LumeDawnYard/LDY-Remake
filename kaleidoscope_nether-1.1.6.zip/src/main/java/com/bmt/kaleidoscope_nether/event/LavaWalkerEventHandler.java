package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.api.event.EntityTickEvent;
import com.bmt.kaleidoscope_nether.init.KNEnchantments;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_7924;

public class LavaWalkerEventHandler {
   public static void register() {
      KNEvents.ENTITY_POST.register(LavaWalkerEventHandler::onLivingTick);
   }

   public static void onLivingTick(EntityTickEvent.Post event) {
      if (event.getEntity() instanceof class_1309 entity) {
         class_1799 boots = entity.method_6118(class_1304.field_6166);
         if (!boots.method_7960()) {
            int enchantmentLevel;
            try {
               enchantmentLevel = class_1890.method_8225(
                  entity.method_73183().method_30349().method_30530(class_7924.field_41265).method_46747(KNEnchantments.LAVA_WALKER), boots
               );
            } catch (Exception e) {
               return;
            }

            if (enchantmentLevel > 0) {
               if (!entity.method_5715()) {
                  class_243 pos = entity.method_73189();
                  class_243 motion = entity.method_18798();
                  boolean isMoving = motion.method_1027() > 1.0E-4;
                  boolean inLava = entity.method_5771();
                  boolean onLavaGround = entity.method_73183().method_8316(entity.method_23312()).method_15767(class_3486.field_15518);
                  if (onLavaGround) {
                     if (motion.field_1351 < 0.0) {
                        entity.method_18799(new class_243(motion.field_1352, 0.0, motion.field_1350));
                     }
                  } else {
                     entity.method_5875(false);
                  }

                  if ((inLava || onLavaGround) && isMoving && entity.method_73183() instanceof class_3218 level && entity.field_6012 % 5 == 0) {
                     level.method_65096(class_2398.field_11239, pos.field_1352, pos.field_1351 + 0.1, pos.field_1350, 3, 0.2, 0.1, 0.2, 1.5);
                  }
               }
            }
         }
      }
   }
}
