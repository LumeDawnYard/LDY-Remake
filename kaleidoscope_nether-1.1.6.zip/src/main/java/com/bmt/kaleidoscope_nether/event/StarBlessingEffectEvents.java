package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.api.event.LivingDamageModifyEvent;
import com.bmt.kaleidoscope_nether.api.event.MobEffectAddedEvent;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_4081;
import net.minecraft.class_6880;

public class StarBlessingEffectEvents {
   public static void register() {
      KNEvents.MODIFY_LIVING_DAMAGE.register(StarBlessingEffectEvents::onLivingDamage);
      KNEvents.MOB_EFFECT_ADDED.register(StarBlessingEffectEvents::onEffectAdded);
   }

   public static void onLivingDamage(LivingDamageModifyEvent event) {
      if (event.getEntity().method_6059(KNEffects.STAR_BLESSING)) {
         event.setNewDamage(event.getNewDamage() * 0.2F);
      }
   }

   public static void onEffectAdded(MobEffectAddedEvent event) {
      if (event.getEffectInstance().method_5579().method_55838(KNEffects.STAR_BLESSING)) {
         List<class_6880<class_1291>> effectsToRemove = new ArrayList<>();

         for (class_1293 effect : event.getEntity().method_6088().values()) {
            if (((class_1291)effect.method_5579().comp_349()).method_18792() == class_4081.field_18272) {
               effectsToRemove.add(effect.method_5579());
            }
         }

         for (class_6880<class_1291> effect : effectsToRemove) {
            event.getEntity().method_6016(effect);
         }
      }
   }
}
