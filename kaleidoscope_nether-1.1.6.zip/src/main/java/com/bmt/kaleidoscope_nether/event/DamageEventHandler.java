package com.bmt.kaleidoscope_nether.event;

import com.bmt.kaleidoscope_nether.api.event.LivingIncomingDamageEvent;
import com.bmt.kaleidoscope_nether.init.KNEffects;
import com.bmt.kaleidoscope_nether.init.KNEvents;
import net.minecraft.class_8103;

public class DamageEventHandler {
   public static void register() {
      KNEvents.LIVING_INCOMING_DAMAGE.register(DamageEventHandler::onLivingIncomingDamage);
   }

   public static void onLivingIncomingDamage(LivingIncomingDamageEvent event) {
      if (event.getEntity().method_6059(KNEffects.TROPICAL_STRIDER) && event.getSource().method_48789(class_8103.field_42246)) {
         event.setCanceled(true);
         event.getEntity().method_5646();
      }
   }
}
