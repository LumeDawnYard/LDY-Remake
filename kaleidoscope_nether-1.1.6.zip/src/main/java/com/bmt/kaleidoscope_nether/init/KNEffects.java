package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.effect.CrimsonEffect;
import com.bmt.kaleidoscope_nether.effect.GhostEffect;
import com.bmt.kaleidoscope_nether.effect.MysteriousPoisonEffect;
import com.bmt.kaleidoscope_nether.effect.StarBlessingEffect;
import com.bmt.kaleidoscope_nether.effect.TropicalStriderEffect;
import com.bmt.kaleidoscope_nether.effect.WarpedEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class KNEffects {
   public static class_6880<class_1291> CRIMSON;
   public static class_6880<class_1291> WARPED;
   public static class_6880<class_1291> STAR_BLESSING;
   public static class_6880<class_1291> GHOST;
   public static class_6880<class_1291> TROPICAL_STRIDER;
   public static class_6880<class_1291> MYSTERIOUS_POISON;

   public static void registerEffects() {
      CRIMSON = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("crimson"), new CrimsonEffect(16711680));
      WARPED = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("warped"), new WarpedEffect(65442));
      STAR_BLESSING = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("star_blessing"), new StarBlessingEffect(8900331));
      GHOST = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("ghost"), new GhostEffect(4886754));
      TROPICAL_STRIDER = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("tropical_strider"), new TropicalStriderEffect(13382400));
      MYSTERIOUS_POISON = class_2378.method_47985(class_7923.field_41174, KaleidoscopeNether.id("mysterious_poison"), new MysteriousPoisonEffect(9055202));
   }
}
