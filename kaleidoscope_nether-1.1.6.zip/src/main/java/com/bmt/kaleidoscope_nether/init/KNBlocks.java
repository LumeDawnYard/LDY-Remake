package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.block.PoisonousFruit;
import com.bmt.kaleidoscope_nether.block.SoulPepper;
import com.bmt.kaleidoscope_nether.block.TwistingCaveVinesHead;
import com.bmt.kaleidoscope_nether.block.TwistingCaveVinesPlant;
import com.bmt.kaleidoscope_nether.block.WeepingCaveVinesHead;
import com.bmt.kaleidoscope_nether.block.WeepingCaveVinesPlant;
import com.github.ysbbbbbb.kaleidoscopecookery.block.kitchen.StoveBlock;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_4970.class_2251;

public final class KNBlocks {
   public static final Supplier<PoisonousFruit> POISONOUS_FRUIT = register("poisonous_fruit", PoisonousFruit::new, cropProperties());
   public static final Supplier<SoulPepper> SOUL_PEPPER = register("soul_pepper", SoulPepper::new, cropProperties());
   public static final Supplier<TwistingCaveVinesPlant> TWISTING_CAVE_VINES_PLANT = register(
      "twisting_cave_vines_plant", TwistingCaveVinesPlant::new, caveVinesProperties()
   );
   public static final Supplier<TwistingCaveVinesHead> TWISTING_CAVE_VINES = register("twisting_cave_vines", TwistingCaveVinesHead::new, caveVinesProperties());
   public static final Supplier<WeepingCaveVinesPlant> WEEPING_CAVE_VINES_PLANT = register(
      "weeping_cave_vines_plant", WeepingCaveVinesPlant::new, caveVinesProperties()
   );
   public static final Supplier<WeepingCaveVinesHead> WEEPING_CAVE_VINES = register("weeping_cave_vines", WeepingCaveVinesHead::new, caveVinesProperties());
   public static final Supplier<StoveBlock> NETHER_STOVE = register(
      "nether_stove",
      StoveBlock::new,
      class_2251.method_9637()
         .method_31710(class_3620.field_16023)
         .method_9626(class_2498.field_11544)
         .method_29292()
         .method_9631(state -> state.method_11654(StoveBlock.LIT) ? 13 : 0)
         .method_9640()
         .method_9629(1.5F, 6.0F)
   );

   private static <T extends class_2248> Supplier<T> register(String name, Function<class_2251, T> factory, class_2251 properties) {
      class_5321<class_2248> resourceKey = class_5321.method_29179(class_7924.field_41254, KaleidoscopeNether.id(name));
      T block = (T)factory.apply(properties.method_63500(resourceKey));
      class_2378.method_39197(class_7923.field_41175, resourceKey, block);
      return () -> block;
   }

   private static class_2251 cropProperties() {
      return class_2251.method_9637()
         .method_31710(class_3620.field_16004)
         .method_9634()
         .method_9640()
         .method_9618()
         .method_9626(class_2498.field_17580)
         .method_50012(class_3619.field_15971);
   }

   private static class_2251 caveVinesProperties() {
      return class_2251.method_9637()
         .method_31710(class_3620.field_16026)
         .method_9640()
         .method_9634()
         .method_9618()
         .method_9626(class_2498.field_22140)
         .method_50012(class_3619.field_15971);
   }

   public static void registerBlocks() {
   }
}
