package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import net.minecraft.class_1293;
import net.minecraft.class_1842;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class KNPotions {
   public static class_6880<class_1842> MYSTERIOUS_POISON;

   public static void registerPotions() {
      MYSTERIOUS_POISON = class_2378.method_47985(
         class_7923.field_41179,
         KaleidoscopeNether.id("mysterious_poison"),
         new class_1842("mysterious_poison", new class_1293[]{new class_1293(KNEffects.MYSTERIOUS_POISON, 1500, 0)})
      );
   }
}
