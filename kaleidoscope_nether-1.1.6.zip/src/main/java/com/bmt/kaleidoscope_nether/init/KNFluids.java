package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.fluid.NetherFluids;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;

public final class KNFluids {
   public static class_3611 WARPED_JUICE = register("warped_juice", new NetherFluids.Source(() -> WARPED_JUICE, () -> KNFluids.FLOWING_WARPED_JUICE));
   public static class_3611 FLOWING_WARPED_JUICE = register("flowing_warped_juice", new NetherFluids.Flowing(() -> WARPED_JUICE, () -> FLOWING_WARPED_JUICE));
   public static class_3611 CRIMSON_JUICE = register("crimson_juice", new NetherFluids.Source(() -> CRIMSON_JUICE, () -> KNFluids.FLOWING_CRIMSON_JUICE));
   public static class_3611 FLOWING_CRIMSON_JUICE = register(
      "flowing_crimson_juice", new NetherFluids.Flowing(() -> CRIMSON_JUICE, () -> FLOWING_CRIMSON_JUICE)
   );

   private static class_3611 register(String id, class_3611 fluid) {
      return (class_3611)class_2378.method_10230(class_7923.field_41173, class_2960.method_60655("kaleidoscope_nether", id), fluid);
   }

   public static void registerFluids() {
   }
}
