package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class KNSounds {
   public static final Supplier<class_3414> LAVA_ROASTED_CHICKEN_EAT = registerSoundEvent("lava_roasted_chicken_eat");
   public static final Supplier<class_3414> STAR_DUST_REPAIR = registerSoundEvent("star_dust_repair");

   private static Supplier<class_3414> registerSoundEvent(String name) {
      class_2960 location = KaleidoscopeNether.id(name);
      class_3414 soundEvent = (class_3414)class_2378.method_10230(class_7923.field_41172, location, class_3414.method_47908(location));
      return () -> soundEvent;
   }

   public static void registerSoundEvents() {
   }
}
