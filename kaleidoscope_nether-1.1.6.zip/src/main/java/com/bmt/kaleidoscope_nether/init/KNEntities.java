package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.entity.BlazeHeartProjectile;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_1299.class_1300;

public final class KNEntities {
   public static final Supplier<class_1299<BlazeHeartProjectile>> BLAZE_HEART_PROJECTILE = register(
      "blaze_heart_projectile",
      class_1300.method_5903(BlazeHeartProjectile::new, class_1311.field_17715)
         .method_17687(0.25F, 0.25F)
         .method_27299(4)
         .method_27300(10)
         .method_5905(class_5321.method_29179(class_7924.field_41266, KaleidoscopeNether.id("blaze_heart_projectile")))
   );

   private static <T extends class_1297> Supplier<class_1299<T>> register(String name, class_1299<T> entityType) {
      class_1299<T> registered = (class_1299<T>)class_2378.method_10230(class_7923.field_41177, KaleidoscopeNether.id(name), entityType);
      return () -> registered;
   }

   public static void registerEntities() {
   }
}
