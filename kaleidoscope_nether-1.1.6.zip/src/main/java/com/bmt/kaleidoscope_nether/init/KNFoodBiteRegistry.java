package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.item.KNBowlFoodBlockItem;
import com.github.ysbbbbbb.kaleidoscopecookery.block.food.FoodBiteBlock;
import com.github.ysbbbbbb.kaleidoscopecookery.block.food.FoodBiteOneByTwoBlock;
import com.github.ysbbbbbb.kaleidoscopecookery.init.registry.FoodBiteRegistry.BlockType;
import com.github.ysbbbbbb.kaleidoscopecookery.init.registry.FoodBiteRegistry.FoodData;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_4970.class_2251;
import org.jetbrains.annotations.NotNull;

public final class KNFoodBiteRegistry {
   public static final Map<class_2960, FoodData> FOOD_DATA_MAP = new ConcurrentHashMap<>();
   private static final CopyOnWriteArrayList<class_2960> FOOD_DATA_ORDER = new CopyOnWriteArrayList<>();
   public static class_2960 SOUL_LAMB_CHOP;
   public static class_2960 BRAISED_PORK_RICE;
   public static class_2960 BRAISED_LION_HEAD;
   public static class_2960 CORN_CARROT_PORK_RIB_SOUP;

   public static void init() {
      SOUL_LAMB_CHOP = registerFoodData(
         KaleidoscopeNether.id("soul_lamb_chop"),
         FoodData.create(3, KNFoods.SOUL_LAMB_CHOP_BLOCK, KNFoods.SOUL_LAMB_CHOP_ITEM, KNConsumables.SOUL_LAMB_CHOP_BLOCK, KNConsumables.SOUL_LAMB_CHOP_ITEM)
      );
      BRAISED_PORK_RICE = registerFoodData(
         KaleidoscopeNether.id("braised_pork_rice"),
         FoodData.create(
               4, KNFoods.BRAISED_PORK_RICE_BLOCK, KNFoods.BRAISED_PORK_RICE_ITEM, KNConsumables.BRAISED_PORK_RICE_BLOCK, KNConsumables.BRAISED_PORK_RICE_ITEM
            )
            .bowlAABB()
      );
      BRAISED_LION_HEAD = registerFoodData(
         KaleidoscopeNether.id("braised_lion_head"),
         FoodData.create(
            5, KNFoods.BRAISED_LION_HEAD_BLOCK, KNFoods.BRAISED_LION_HEAD_ITEM, KNConsumables.BRAISED_LION_HEAD_BLOCK, KNConsumables.BRAISED_LION_HEAD_ITEM
         )
      );
      CORN_CARROT_PORK_RIB_SOUP = registerFoodData(
         KaleidoscopeNether.id("corn_carrot_pork_rib_soup"),
         FoodData.create(
               3,
               KNFoods.CORN_CARROT_PORK_RIB_SOUP_BLOCK,
               KNFoods.CORN_CARROT_PORK_RIB_SOUP_ITEM,
               KNConsumables.CORN_CARROT_PORK_RIB_SOUP_BLOCK,
               KNConsumables.CORN_CARROT_PORK_RIB_SOUP_ITEM
            )
            .setLootItem(class_1802.field_8074)
            .soupPotAABB()
            .potSoupAnimateTick()
      );
   }

   public static void registerFoodBiteBlocks() {
      init();
      FOOD_DATA_MAP.forEach((id, data) -> {
         FoodBiteBlock biteBlock = getFoodBiteBlock(data, id.method_12832());
         class_2378.method_10230(class_7923.field_41175, id, biteBlock);
         class_2248 block = (class_2248)class_7923.field_41175.method_63535(id);
         class_1935 first = (class_1935)data.getLootItems().getFirst();
         class_2378.method_10230(class_7923.field_41178, id, new KNBowlFoodBlockItem(block, data.itemFood(), data.itemConsumable(), first, id.method_12832()));
      });
   }

   @NotNull
   private static FoodBiteBlock getFoodBiteBlock(FoodData data, String name) {
      class_2251 properties = class_2251.method_9637()
         .method_51369()
         .method_9618()
         .method_31710(class_3620.field_15996)
         .method_9626(class_2498.field_11547)
         .method_50012(class_3619.field_15971)
         .method_22488();
      FoodBiteBlock biteBlock;
      if (data.blockType() == BlockType.ONE_BY_TWO) {
         biteBlock = new FoodBiteOneByTwoBlock(
            properties.method_63500(class_5321.method_29179(class_7924.field_41254, KaleidoscopeNether.id(name))),
            data.blockFood(),
            data.blockConsumable(),
            data.maxBites(),
            data.animateTick()
         );
      } else {
         biteBlock = new FoodBiteBlock(
            properties.method_63500(class_5321.method_29179(class_7924.field_41254, KaleidoscopeNether.id(name))),
            data.blockFood(),
            data.blockConsumable(),
            data.maxBites(),
            data.animateTick()
         );
      }

      class_265 aabb = data.getAABB();
      if (aabb != null) {
         biteBlock.setAABB(aabb);
      }

      return biteBlock;
   }

   private static class_2960 registerFoodData(class_2960 id, FoodData data) {
      FOOD_DATA_MAP.put(id, data);
      FOOD_DATA_ORDER.addIfAbsent(id);
      return id;
   }

   public static void forEach(BiConsumer<class_2960, FoodData> consumer) {
      for (class_2960 id : FOOD_DATA_ORDER) {
         FoodData data = FOOD_DATA_MAP.get(id);
         if (data != null) {
            consumer.accept(id, data);
         }
      }
   }
}
