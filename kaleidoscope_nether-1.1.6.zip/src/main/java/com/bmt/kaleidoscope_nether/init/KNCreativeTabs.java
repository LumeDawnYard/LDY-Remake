package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class KNCreativeTabs {
   public static void registerTabs() {
      class_2378.method_10230(
         class_7923.field_44687,
         KaleidoscopeNether.id("kaleidoscope_nether_tab"),
         FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.kaleidoscope_nether"))
            .method_47320(() -> new class_1799((class_1935)KNItems.BLOWGUN.get()))
            .method_47317((parameters, output) -> {
               output.method_45421((class_1935)KNItems.PRIMITIVE_MACHETE.get());
               output.method_45421((class_1935)KNItems.GHAST_TENTACLE.get());
               output.method_45421((class_1935)KNItems.ROASTED_GHAST_TENTACLE.get());
               output.method_45421((class_1935)KNItems.HAM_SLICE.get());
               output.method_45421((class_1935)KNItems.HAM.get());
               output.method_45421((class_1935)KNItems.HOGLIN_HIDE.get());
               output.method_45421((class_1935)KNItems.NETHER_CATERPILLAR.get());
               output.method_45421((class_1935)KNItems.RAW_PIGLIN_MEAT.get());
               output.method_45421((class_1935)KNItems.COOKED_PIGLIN_MEAT.get());
               output.method_45421((class_1935)KNItems.RAW_STRIDER_MEAT.get());
               output.method_45421((class_1935)KNItems.COOKED_STRIDER_MEAT.get());
               output.method_45421((class_1935)KNItems.HOGLIN_TUSK.get());
               output.method_45421((class_1935)KNItems.STRIDER_ROCK_SHELL.get());
               output.method_45421((class_1935)KNItems.GILDED_FRAGMENT.get());
               output.method_45421((class_1935)KNItems.WITHER_RIB.get());
               output.method_45421((class_1935)KNItems.STAR_DUST.get());
               output.method_45421((class_1935)KNItems.BLAZE_HEART.get());
               output.method_45421((class_1935)KNItems.CRIMSON_FRUIT.get());
               output.method_45421((class_1935)KNItems.WARPED_FRUIT.get());
               output.method_45421((class_1935)KNItems.SOUL_PEPPER.get());
               output.method_45421((class_1935)KNItems.POISONOUS_FRUIT.get());
               output.method_45421((class_1935)KNItems.LAVA_ROASTED_CHICKEN.get());
               output.method_45421((class_1935)KNItems.ROUJIAMO.get());
               output.method_45421((class_1935)KNItems.SPICY_POT.get());
               output.method_45421((class_1935)KNItems.SPICY_POT_RICE.get());
               output.method_45421((class_1935)KNItems.MAPO_TOFU.get());
               output.method_45421((class_1935)KNItems.MAPO_TOFU_RICE.get());
               output.method_45421((class_1935)KNItems.MAGMA_CREAM_STIR_FRY.get());
               output.method_45421((class_1935)KNItems.MAGMA_CREAM_STIR_FRY_RICE.get());
               output.method_45421((class_1935)KNItems.SOUL_STIR_FRY_MEAT.get());
               output.method_45421((class_1935)KNItems.SOUL_STIR_FRY_MEAT_RICE.get());
               output.method_45421((class_1935)KNItems.CARAMEL_NETHER_CATERPILLAR.get());
               output.method_45421((class_1935)KNItems.CARAMEL_NETHER_CATERPILLAR_RICE.get());
               output.method_45421((class_1935)KNItems.STAR_STEW.get());
               output.method_45421((class_1935)KNItems.SOUL_SOUP.get());
               output.method_45421((class_1935)KNItems.BLAZE_SOUP.get());
               output.method_45421((class_1935)KNItems.MAGMA_CREAM_SOUP.get());
               output.method_45421((class_1935)KNItems.WITHER_BONE_SOUP.get());
               output.method_45421((class_1935)KNItems.POISONOUS_SOUP.get());
               output.method_45421((class_1935)KNItems.GLOWING_SOUP.get());
               output.method_45421((class_1935)KNItems.CHONGQING_NOODLES.get());
               output.method_45421((class_1935)KNItems.LUOSIFEN.get());
               output.method_45421((class_1935)KNItems.SPICY_HOGLIN_RAMEN.get());
               output.method_45421((class_1935)KNItems.SAUERKRAUT_FISH.get());
               output.method_45421((class_1935)KNItems.NETHER_REED_STEW.get());
               output.method_45421((class_1935)KNItems.SOUL_RETURN_RICE.get());
               output.method_45421((class_1935)KNItems.STRIDER_NETHER_WART_STEW.get());
               output.method_45421((class_1935)KNItems.WARPED_SALAD.get());
               output.method_45421((class_1935)KNItems.CRIMSON_SALAD.get());
               output.method_45421((class_1935)KNItems.BRAISED_STRIDER.get());
               output.method_45421((class_1935)KNItems.WARPED_HOGLIN_TENDERLOIN_STEW.get());
               output.method_45421((class_1935)KNItems.GHAST_PASTA.get());
               output.method_45421((class_1935)KNItems.STAR_GHAST_PASTA.get());
               output.method_45421((class_1935)KNItems.SOUL_GLAZED_ROAST.get());
               output.method_45421((class_1935)KNItems.MAGMA_CREAM_PUDDING.get());
               output.method_45421((class_1935)KNItems.GHAST_PUDDING.get());
               output.method_45421((class_1935)KNItems.GILDED_BARBARIC_ROAST.get());
               output.method_45421((class_1935)KNItems.CRIMSON_MAGMA_STEW.get());
               output.method_45421((class_1935)KNItems.STAR_STEW_MEAT.get());
               output.method_45421((class_1935)KNItems.WARPED_CAKE.get());
               output.method_45421((class_1935)KNItems.GOLDEN_ROAST.get());
               output.method_45421((class_1935)KNItems.GLOWING_PUDDING.get());
               output.method_45421((class_1935)KNItems.LAVA_JELLY.get());
               output.method_45421((class_1935)KNItems.NETHER_CATERPILLAR_SASHIMI.get());
               output.method_45421((class_1935)KNItems.NETHER_FRIES_PLATTER.get());
               output.method_45421((class_1935)KNItems.HOGLIN_TUSK_BRAISED_MEAT.get());
               output.method_45421((class_1935)KNItems.POISONOUS_GHAST_ROAST.get());
               output.method_45421((class_1935)KNItems.SOUL_PEPPER_STIR_FRY.get());
               output.method_45421((class_1935)KNItems.STRIDER_SHELL_STIR_FRY.get());
               output.method_45421((class_1935)KNItems.FRUIT_PLATTER.get());
               output.method_45421((class_1935)KNItems.HAM_YOGURT.get());
               output.method_45421((class_1935)KNItems.MAGMA_SWEET_AND_SOUR_PORK.get());
               output.method_45421((class_1935)KNItems.GIANT_BEAST_CROISSANT.get());
               KNFoodBiteRegistry.forEach((resourceLocation, foodData) -> {
                  class_1792 item = (class_1792)class_7923.field_41178.method_63535(resourceLocation);
                  if (item != class_1802.field_8162) {
                     output.method_45421(item);
                  }
               });
               output.method_45421((class_1935)KNItems.GLOWING_SALAD.get());
               output.method_45421((class_1935)KNItems.BLACK_APPLE_SALAD.get());
               output.method_45421((class_1935)KNItems.RUBY_STEAK.get());
               output.method_45421((class_1935)KNItems.GHAST_KABOB.get());
               output.method_45421((class_1935)KNItems.SOUL_STRIDER_KABOB.get());
               output.method_45421((class_1935)KNItems.GOLDEN_KABOB.get());
               output.method_45421((class_1935)KNItems.BLAZING_KABOB.get());
               output.method_45421((class_1935)KNItems.CRIMSON_KABOB.get());
               output.method_45421((class_1935)KNItems.WARPED_KABOB.get());
               output.method_45421((class_1935)KNItems.GLOWING_KABOB.get());
               output.method_45421((class_1935)KNItems.FORGETFULNESS_SOUP.get());
               output.method_45421((class_1935)KNItems.GARLIC_OYSTERS.get());
               output.method_45421((class_1935)KNItems.COUPLES_LUNG_SLICE.get());
               output.method_45421((class_1935)KNItems.PEPPER_PORK_BELLY_CHICKEN_SOUP.get());
               output.method_45421((class_1935)KNItems.NETHER_STOVE.get());
            })
            .method_47324()
      );
   }
}
