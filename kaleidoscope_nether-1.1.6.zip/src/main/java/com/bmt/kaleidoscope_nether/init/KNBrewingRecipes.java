package com.bmt.kaleidoscope_nether.init;

import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistryBuilder;
import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistryBuilder.BuildCallback;
import net.minecraft.class_1847;

public final class KNBrewingRecipes {
   public static void register() {
      FabricBrewingRecipeRegistryBuilder.BUILD
         .register((BuildCallback)builder -> builder.method_59705(class_1847.field_8999, KNItems.POISONOUS_FRUIT.get(), KNPotions.MYSTERIOUS_POISON));
   }
}
