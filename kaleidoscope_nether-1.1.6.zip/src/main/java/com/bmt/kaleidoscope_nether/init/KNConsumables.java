package com.bmt.kaleidoscope_nether.init;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_10124.class_10125;
import org.jetbrains.annotations.Nullable;

public interface KNConsumables {
   class_10124 GIANT_BEAST_CROISSANT = buildConsumable();
   class_10124 MAGMA_SWEET_AND_SOUR_PORK = buildConsumable();
   class_10124 SOUL_LAMB_CHOP_ITEM = buildConsumable(createNetherEffect("ghost", 3600));
   class_10124 SOUL_LAMB_CHOP_BLOCK = buildConsumable(createNetherEffect("ghost", 4800));
   class_10124 EVERLASTING_FLAME_STEAK = buildConsumable(createCookeryEffect("satiated_shield", 300), createCookeryEffect("warmth", 600));
   class_10124 CRIMSON_FRUIT = buildConsumable();
   class_10124 WARPED_FRUIT = buildConsumable();
   class_10124 NETHER_CATERPILLAR = buildConsumable(createDefaultEffect("nausea", 200));
   class_10124 SOUL_RETURN_RICE = buildConsumable(createNetherEffect("ghost", 1800));
   class_10124 LAVA_ROASTED_CHICKEN = buildConsumable();
   class_10124 STAR_STEW = buildConsumable(createNetherEffect("star_blessing", 600));
   class_10124 SOUL_SOUP = buildConsumable(createNetherEffect("ghost", 1800));
   class_10124 RAW_STRIDER_MEAT = buildConsumable();
   class_10124 COOKED_STRIDER_MEAT = buildConsumable();
   class_10124 HAM = buildConsumable();
   class_10124 HAM_SLICE = buildConsumable();
   class_10124 ROASTED_HAM = buildConsumable();
   class_10124 ROUJIAMO = buildConsumable(createDefaultEffect("absorption", 1600));
   class_10124 BRAISED_STRIDER = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 WITHER_BONE_SOUP = buildConsumable(createCookeryEffect("vigor", 6000));
   class_10124 STRIDER_NETHER_WART_STEW = buildConsumable(createCookeryEffect("satiated_shield", 1800));
   class_10124 GHAST_KABOB = buildConsumable();
   class_10124 GHAST_TENTACLE = buildConsumable();
   class_10124 ROASTED_GHAST_TENTACLE = buildConsumable();
   class_10124 GHAST_PASTA = buildConsumable(createCookeryEffect("sulfur", 1800));
   class_10124 MAGMA_CREAM_SOUP = buildConsumable(createCookeryEffect("warmth", 9600));
   class_10124 MAGMA_CREAM_PUDDING = buildConsumable(createCookeryEffect("warmth", 3600));
   class_10124 POISONOUS_FRUIT = buildConsumable();
   class_10124 POISONOUS_SOUP = buildConsumable(createNetherEffect("mysterious_poison", 1600));
   class_10124 SOUL_GLAZED_ROAST = buildConsumable(createCookeryEffect("satiated_shield", 1800));
   class_10124 GHAST_PUDDING = buildConsumable(createCookeryEffect("vigor", 3600));
   class_10124 GILDED_BARBARIC_ROAST = buildConsumable(createCookeryEffect("satiated_shield", 1800));
   class_10124 NETHER_CATERPILLAR_SASHIMI = buildConsumable(createCookeryEffect("mustard", 6000));
   class_10124 GOLDEN_ROAST = buildConsumable(createCookeryEffect("vigor", 2400));
   class_10124 NETHER_FRIES_PLATTER = buildConsumable(createNetherEffect("tropical_strider", 6000));
   class_10124 HOGLIN_TUSK_BRAISED_MEAT = buildConsumable(createCookeryEffect("satiated_shield", 1600));
   class_10124 POISONOUS_GHAST_ROAST = buildConsumable(createNetherEffect("mysterious_poison", 1200));
   class_10124 SOUL_PEPPER_STIR_FRY = buildConsumable(createNetherEffect("ghost", 1200));
   class_10124 STRIDER_SHELL_STIR_FRY = buildConsumable(createNetherEffect("tropical_strider", 6000));
   class_10124 FRUIT_PLATTER = buildConsumable(createCookeryEffect("preservation", 1800));
   class_10124 HAM_YOGURT = buildConsumable(createCookeryEffect("satiated_shield", 1800));
   class_10124 SAUERKRAUT_FISH = buildConsumable(createCookeryEffect("vigor", 4800));
   class_10124 BLAZE_SOUP = buildConsumable(createNetherEffect("tropical_strider", 3600));
   class_10124 LAVA_JELLY = buildConsumable(createNetherEffect("tropical_strider", 2400));
   class_10124 CRIMSON_SALAD = buildConsumable(createNetherEffect("crimson", 1800));
   class_10124 CRIMSON_MAGMA_STEW = buildConsumable(createCookeryEffect("warmth", 3600));
   class_10124 WARPED_SALAD = buildConsumable(createNetherEffect("warped", 1800));
   class_10124 SOUL_STRIDER_KABOB = buildConsumable(createNetherEffect("warped", 600));
   class_10124 GOLDEN_KABOB = buildConsumable(createCookeryEffect("vigor", 1200));
   class_10124 BLAZING_KABOB = buildConsumable(createNetherEffect("tropical_strider", 600));
   class_10124 CRIMSON_KABOB = buildConsumable(createNetherEffect("crimson", 900));
   class_10124 WARPED_KABOB = buildConsumable(createNetherEffect("warped", 900));
   class_10124 STAR_GHAST_PASTA = buildConsumable(createNetherEffect("star_blessing", 600));
   class_10124 STAR_STEW_MEAT = buildConsumable(createNetherEffect("star_blessing", 600));
   class_10124 GLOWING_SOUP = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 GLOWING_PUDDING = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 GLOWING_KABOB = buildConsumable(createCookeryEffect("satiated_shield", 900));
   class_10124 GLOWING_SALAD = buildConsumable(createCookeryEffect("satiated_shield", 1800));
   class_10124 BLACK_APPLE_SALAD = buildConsumable(createCookeryEffect("preservation", 1800));
   class_10124 RUBY_STEAK = buildConsumable(createCookeryEffect("satiated_shield", 4800));
   class_10124 NETHER_REED_STEW = buildConsumable(createCookeryEffect("warmth", 9600));
   class_10124 MAGMA_CREAM_STIR_FRY = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 MAGMA_CREAM_STIR_FRY_RICE = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 MAPO_TOFU = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 MAPO_TOFU_RICE = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 WARPED_CAKE = buildConsumable(createNetherEffect("warped", 1200));
   class_10124 CHONGQING_NOODLES = buildConsumable(createCookeryEffect("warmth", 3600));
   class_10124 LUOSIFEN = buildConsumable(createCookeryEffect("warmth", 3600));
   class_10124 SOUL_STIR_FRY_MEAT = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 SOUL_STIR_FRY_MEAT_RICE = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 CARAMEL_NETHER_CATERPILLAR = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 CARAMEL_NETHER_CATERPILLAR_RICE = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 RAW_PIGLIN_MEAT = buildConsumable();
   class_10124 COOKED_PIGLIN_MEAT = buildConsumable();
   class_10124 WARPED_HOGLIN_TENDERLOIN_STEW = buildConsumable(createCookeryEffect("flatulence", 700));
   class_10124 SPICY_HOGLIN_RAMEN = buildConsumable(createCookeryEffect("warmth", 3600));
   class_10124 SPICY_POT = buildConsumable(createCookeryEffect("vigor", 1800));
   class_10124 SPICY_POT_RICE = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 FORGETFULNESS_SOUP = buildConsumable(createCookeryEffect("warmth", 1600));
   class_10124 BRAISED_LION_HEAD_ITEM = buildConsumable(createCookeryEffect("warmth", 1600));
   class_10124 BRAISED_LION_HEAD_BLOCK = buildConsumable(createCookeryEffect("warmth", 1600));
   class_10124 GARLIC_OYSTERS = buildConsumable(createDefaultEffect("water_breathing", 3600));
   class_10124 COUPLES_LUNG_SLICE = buildConsumable(createCookeryEffect("warmth", 1600));
   class_10124 BRAISED_PORK_RICE_ITEM = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 BRAISED_PORK_RICE_BLOCK = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 PEPPER_PORK_BELLY_CHICKEN_SOUP = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 CORN_CARROT_PORK_RIB_SOUP_ITEM = buildConsumable(createCookeryEffect("satiated_shield", 3600));
   class_10124 CORN_CARROT_PORK_RIB_SOUP_BLOCK = buildConsumable(createCookeryEffect("satiated_shield", 3600));

   private static class_10124 buildConsumable(class_1293... effects) {
      class_10125 builder = class_10128.method_62858();
      List<class_1293> instances = Arrays.stream(effects).filter(Objects::nonNull).toList();
      if (!instances.isEmpty()) {
         builder.method_62854(new class_10132(instances, 1.0F));
      }

      return builder.method_62851();
   }

   private static class_10124 buildConsumable() {
      return class_10128.method_62858().method_62851();
   }

   @Nullable
   private static class_1293 createCookeryEffect(String path, int duration) {
      return createEffect("kaleidoscope_nether", path, duration);
   }

   @Nullable
   private static class_1293 createNetherEffect(String path, int duration) {
      return createEffect("kaleidoscope_nether", path, duration);
   }

   @Nullable
   private static class_1293 createDefaultEffect(String path, int duration) {
      return createEffect("minecraft", path, duration);
   }

   @Nullable
   private static class_1293 createEffect(String namespace, String path, int duration) {
      class_2960 id = class_2960.method_60655(namespace, path);
      return class_7923.field_41174.method_10223(id).map(effect -> new class_1293(effect, duration, 0)).orElse(null);
   }

   static void init() {
   }
}
