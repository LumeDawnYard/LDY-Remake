package com.bmt.kaleidoscope_nether.init;

import com.bmt.kaleidoscope_nether.KaleidoscopeNether;
import com.bmt.kaleidoscope_nether.config.MainConfig;
import com.bmt.kaleidoscope_nether.item.BlowgunItem;
import com.bmt.kaleidoscope_nether.item.EverlastingFoodItem;
import com.bmt.kaleidoscope_nether.item.ForgetfulnessSoupItem;
import com.bmt.kaleidoscope_nether.item.GhastPendantItem;
import com.bmt.kaleidoscope_nether.item.KNChiliItem;
import com.bmt.kaleidoscope_nether.item.LavaRoastedChickenItem;
import com.bmt.kaleidoscope_nether.item.MysteriousPoisonFoodBlockItem;
import com.bmt.kaleidoscope_nether.item.NetherCaterpillarItem;
import com.bmt.kaleidoscope_nether.item.SoulReturnRiceItem;
import com.bmt.kaleidoscope_nether.item.SpecialFruitBlockItem;
import com.bmt.kaleidoscope_nether.item.StarDustItem;
import com.bmt.kaleidoscope_nether.item.StickReturnFoodItem;
import com.bmt.kaleidoscope_nether.item.ThrowableFuelItem;
import com.bmt.kaleidoscope_nether.util.PrimitiveMacheteTier;
import com.github.ysbbbbbb.kaleidoscopecookery.item.BowlFoodOnlyItem;
import com.github.ysbbbbbb.kaleidoscopecookery.item.FoodWithEffectsItem;
import com.github.ysbbbbbb.kaleidoscopecookery.item.KitchenKnifeItem;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_1792.class_1793;

public final class KNItems {
   public static final Supplier<class_1792> GIANT_BEAST_CROISSANT = register(
      "giant_beast_croissant",
      properties -> new class_1792(properties.method_24359().method_62833(KNFoods.GIANT_BEAST_CROISSANT, KNConsumables.GIANT_BEAST_CROISSANT))
   );
   public static final Supplier<class_1792> MAGMA_SWEET_AND_SOUR_PORK = register(
      "magma_sweet_and_sour_pork",
      properties -> new class_1792(properties.method_24359().method_62833(KNFoods.MAGMA_SWEET_AND_SOUR_PORK, KNConsumables.MAGMA_SWEET_AND_SOUR_PORK))
   );
   public static final Supplier<class_1792> GHAST_HIDE = register("ghast_hide", properties -> new class_1792(properties.method_7894(class_1814.field_8906)));
   public static final Supplier<class_1792> HOGLIN_TUSK = register("hoglin_tusk", properties -> new class_1792(properties.method_7894(class_1814.field_8906)));
   public static final Supplier<class_1792> STRIDER_ROCK_SHELL = register("strider_rock_shell", properties -> new class_1792(properties.method_24359()));
   public static final Supplier<class_1792> GILDED_FRAGMENT = register(
      "gilded_fragment", properties -> new class_1792(properties.method_7894(class_1814.field_8906))
   );
   public static final Supplier<class_1792> WITHER_RIB = register("wither_rib", properties -> new class_1792(properties.method_7894(class_1814.field_8906)));
   public static final Supplier<class_1792> NETHER_STOVE = register(
      "nether_stove", properties -> new class_1747((class_2248)KNBlocks.NETHER_STOVE.get(), properties.method_63685())
   );
   public static final Supplier<class_1792> STAR_DUST = register("star_dust", properties -> new StarDustItem(properties.method_7894(class_1814.field_8907)));
   public static final Supplier<class_1792> BLAZE_HEART = register(
      "blaze_heart", properties -> new ThrowableFuelItem(properties.method_7894(class_1814.field_8906).method_7889(16), 3000)
   );
   public static final Supplier<class_1792> HOGLIN_HIDE = register("hoglin_hide", class_1792::new);
   public static final Supplier<class_1792> BLOWGUN = register(
      "blowgun", properties -> new BlowgunItem(properties.method_7895(384).method_7894(class_1814.field_8907))
   );
   public static final Supplier<class_1792> PRIMITIVE_MACHETE = register(
      "primitive_machete", properties -> new KitchenKnifeItem(properties, PrimitiveMacheteTier.INSTANCE, 3.0F, -2.4F)
   );
   public static final Supplier<class_1792> GHAST_PENDANT = register("ghast_pendant", GhastPendantItem::new, new class_1793());
   public static final Supplier<class_1792> EVERLASTING_FLAME_STEAK = register(
      "everlasting_flame_steak",
      properties -> new EverlastingFoodItem(
         properties,
         KNFoods.EVERLASTING_FLAME_STEAK,
         KNConsumables.EVERLASTING_FLAME_STEAK,
         MainConfig.EVERLASTING_FLAME_STEAK_COOLDOWN,
         MainConfig.EVERLASTING_FLAME_STEAK_ENABLED,
         class_1814.field_8904
      )
   );
   public static final Supplier<class_1792> CRIMSON_FRUIT = register(
      "crimson_fruit",
      properties -> new SpecialFruitBlockItem(
         (class_2248)KNBlocks.WEEPING_CAVE_VINES.get(), properties, KNFoods.CRIMSON_FRUIT, KNConsumables.CRIMSON_FRUIT, class_1814.field_8906
      )
   );
   public static final Supplier<class_1792> WARPED_FRUIT = register(
      "warped_fruit",
      properties -> new SpecialFruitBlockItem(
         (class_2248)KNBlocks.TWISTING_CAVE_VINES.get(), properties, KNFoods.WARPED_FRUIT, KNConsumables.WARPED_FRUIT, class_1814.field_8906
      )
   );
   public static final Supplier<class_1792> NETHER_CATERPILLAR = register(
      "nether_caterpillar", properties -> new NetherCaterpillarItem(properties, KNFoods.NETHER_CATERPILLAR, KNConsumables.NETHER_CATERPILLAR)
   );
   public static final Supplier<class_1792> SOUL_RETURN_RICE = register(
      "soul_return_rice", properties -> new SoulReturnRiceItem(properties, KNFoods.SOUL_RETURN_RICE, KNConsumables.SOUL_RETURN_RICE)
   );
   public static final Supplier<class_1792> LAVA_ROASTED_CHICKEN = register(
      "lava_roasted_chicken", properties -> new LavaRoastedChickenItem(properties, KNFoods.LAVA_ROASTED_CHICKEN, KNConsumables.LAVA_ROASTED_CHICKEN)
   );
   public static final Supplier<class_1792> STAR_STEW = register(
      "star_stew", properties -> new BowlFoodOnlyItem(properties, KNFoods.STAR_STEW, KNConsumables.STAR_STEW)
   );
   public static final Supplier<class_1792> SOUL_PEPPER = register("soul_pepper", properties -> new KNChiliItem(properties, 4));
   public static final Supplier<class_1792> SOUL_SOUP = register(
      "soul_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.SOUL_SOUP, KNConsumables.SOUL_SOUP)
   );
   public static final Supplier<class_1792> RAW_STRIDER_MEAT = register(
      "raw_strider_meat", properties -> new class_1792(properties.method_62833(KNFoods.RAW_STRIDER_MEAT, KNConsumables.RAW_STRIDER_MEAT))
   );
   public static final Supplier<class_1792> COOKED_STRIDER_MEAT = register(
      "cooked_strider_meat", properties -> new class_1792(properties.method_62833(KNFoods.COOKED_STRIDER_MEAT, KNConsumables.COOKED_STRIDER_MEAT))
   );
   public static final Supplier<class_1792> HAM = register("ham", properties -> new class_1792(properties.method_62833(KNFoods.HAM, KNConsumables.HAM)));
   public static final Supplier<class_1792> HAM_SLICE = register(
      "ham_slice", properties -> new class_1792(properties.method_62833(KNFoods.HAM_SLICE, KNConsumables.HAM_SLICE))
   );
   public static final Supplier<class_1792> ROASTED_HAM = register(
      "roasted_ham", properties -> new class_1792(properties.method_62833(KNFoods.ROASTED_HAM, KNConsumables.ROASTED_HAM))
   );
   public static final Supplier<class_1792> ROUJIAMO = register(
      "roujiamo", properties -> new FoodWithEffectsItem(properties, KNFoods.ROUJIAMO, KNConsumables.ROUJIAMO)
   );
   public static final Supplier<class_1792> BRAISED_STRIDER = register(
      "braised_strider", properties -> new BowlFoodOnlyItem(properties, KNFoods.BRAISED_STRIDER, KNConsumables.BRAISED_STRIDER)
   );
   public static final Supplier<class_1792> WITHER_BONE_SOUP = register(
      "wither_bone_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.WITHER_BONE_SOUP, KNConsumables.WITHER_BONE_SOUP)
   );
   public static final Supplier<class_1792> STRIDER_NETHER_WART_STEW = register(
      "strider_nether_wart_stew", properties -> new BowlFoodOnlyItem(properties, KNFoods.STRIDER_NETHER_WART_STEW, KNConsumables.STRIDER_NETHER_WART_STEW)
   );
   public static final Supplier<class_1792> GHAST_KABOB = register(
      "ghast_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.GHAST_KABOB, KNConsumables.GHAST_KABOB)
   );
   public static final Supplier<class_1792> GHAST_TENTACLE = register(
      "ghast_tentacle", properties -> new class_1792(properties.method_62833(KNFoods.GHAST_TENTACLE, KNConsumables.GHAST_TENTACLE))
   );
   public static final Supplier<class_1792> ROASTED_GHAST_TENTACLE = register(
      "roasted_ghast_tentacle", properties -> new class_1792(properties.method_62833(KNFoods.ROASTED_GHAST_TENTACLE, KNConsumables.ROASTED_GHAST_TENTACLE))
   );
   public static final Supplier<class_1792> GHAST_PASTA = register(
      "ghast_pasta", properties -> new BowlFoodOnlyItem(properties, KNFoods.GHAST_PASTA, KNConsumables.GHAST_PASTA)
   );
   public static final Supplier<class_1792> MAGMA_CREAM_SOUP = register(
      "magma_cream_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAGMA_CREAM_SOUP, KNConsumables.MAGMA_CREAM_SOUP)
   );
   public static final Supplier<class_1792> MAGMA_CREAM_PUDDING = register(
      "magma_cream_pudding", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAGMA_CREAM_PUDDING, KNConsumables.MAGMA_CREAM_PUDDING)
   );
   public static final Supplier<class_1792> POISONOUS_FRUIT = register(
      "poisonous_fruit",
      properties -> new MysteriousPoisonFoodBlockItem(
         (class_2248)KNBlocks.POISONOUS_FRUIT.get(), properties, KNFoods.POISONOUS_FRUIT, KNConsumables.POISONOUS_FRUIT, class_1814.field_8906
      )
   );
   public static final Supplier<class_1792> POISONOUS_SOUP = register(
      "poisonous_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.POISONOUS_SOUP, KNConsumables.POISONOUS_SOUP)
   );
   public static final Supplier<class_1792> SOUL_GLAZED_ROAST = register(
      "soul_glazed_roast", properties -> new BowlFoodOnlyItem(properties, KNFoods.SOUL_GLAZED_ROAST, KNConsumables.SOUL_GLAZED_ROAST)
   );
   public static final Supplier<class_1792> GHAST_PUDDING = register(
      "ghast_pudding", properties -> new BowlFoodOnlyItem(properties, KNFoods.GHAST_PUDDING, KNConsumables.GHAST_PUDDING)
   );
   public static final Supplier<class_1792> GILDED_BARBARIC_ROAST = register(
      "gilded_barbaric_roast", properties -> new BowlFoodOnlyItem(properties, KNFoods.GILDED_BARBARIC_ROAST, KNConsumables.GILDED_BARBARIC_ROAST)
   );
   public static final Supplier<class_1792> NETHER_CATERPILLAR_SASHIMI = register(
      "nether_caterpillar_sashimi",
      properties -> new BowlFoodOnlyItem(properties, KNFoods.NETHER_CATERPILLAR_SASHIMI, KNConsumables.NETHER_CATERPILLAR_SASHIMI)
   );
   public static final Supplier<class_1792> GOLDEN_ROAST = register(
      "golden_roast", properties -> new BowlFoodOnlyItem(properties, KNFoods.GOLDEN_ROAST, KNConsumables.GOLDEN_ROAST)
   );
   public static final Supplier<class_1792> NETHER_FRIES_PLATTER = register(
      "nether_fries_platter", properties -> new BowlFoodOnlyItem(properties, KNFoods.NETHER_FRIES_PLATTER, KNConsumables.NETHER_FRIES_PLATTER)
   );
   public static final Supplier<class_1792> HOGLIN_TUSK_BRAISED_MEAT = register(
      "hoglin_tusk_braised_meat", properties -> new FoodWithEffectsItem(properties, KNFoods.HOGLIN_TUSK_BRAISED_MEAT, KNConsumables.HOGLIN_TUSK_BRAISED_MEAT)
   );
   public static final Supplier<class_1792> POISONOUS_GHAST_ROAST = register(
      "poisonous_ghast_roast", properties -> new BowlFoodOnlyItem(properties, KNFoods.POISONOUS_GHAST_ROAST, KNConsumables.POISONOUS_GHAST_ROAST)
   );
   public static final Supplier<class_1792> SOUL_PEPPER_STIR_FRY = register(
      "soul_pepper_stir_fry", properties -> new BowlFoodOnlyItem(properties, KNFoods.SOUL_PEPPER_STIR_FRY, KNConsumables.SOUL_PEPPER_STIR_FRY)
   );
   public static final Supplier<class_1792> STRIDER_SHELL_STIR_FRY = register(
      "strider_shell_stir_fry", properties -> new BowlFoodOnlyItem(properties, KNFoods.STRIDER_SHELL_STIR_FRY, KNConsumables.STRIDER_SHELL_STIR_FRY)
   );
   public static final Supplier<class_1792> FRUIT_PLATTER = register(
      "fruit_platter", properties -> new BowlFoodOnlyItem(properties, KNFoods.FRUIT_PLATTER, KNConsumables.FRUIT_PLATTER)
   );
   public static final Supplier<class_1792> HAM_YOGURT = register(
      "ham_yogurt", properties -> new BowlFoodOnlyItem(properties, KNFoods.HAM_YOGURT, KNConsumables.HAM_YOGURT)
   );
   public static final Supplier<class_1792> SAUERKRAUT_FISH = register(
      "sauerkraut_fish", properties -> new BowlFoodOnlyItem(properties, KNFoods.SAUERKRAUT_FISH, KNConsumables.SAUERKRAUT_FISH)
   );
   public static final Supplier<class_1792> BLAZE_SOUP = register(
      "blaze_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.BLAZE_SOUP, KNConsumables.BLAZE_SOUP)
   );
   public static final Supplier<class_1792> LAVA_JELLY = register(
      "lava_jelly", properties -> new BowlFoodOnlyItem(properties, KNFoods.LAVA_JELLY, KNConsumables.LAVA_JELLY)
   );
   public static final Supplier<class_1792> CRIMSON_SALAD = register(
      "crimson_salad", properties -> new BowlFoodOnlyItem(properties, KNFoods.CRIMSON_SALAD, KNConsumables.CRIMSON_SALAD)
   );
   public static final Supplier<class_1792> CRIMSON_MAGMA_STEW = register(
      "crimson_magma_stew", properties -> new BowlFoodOnlyItem(properties, KNFoods.CRIMSON_MAGMA_STEW, KNConsumables.CRIMSON_MAGMA_STEW)
   );
   public static final Supplier<class_1792> WARPED_SALAD = register(
      "warped_salad", properties -> new BowlFoodOnlyItem(properties, KNFoods.WARPED_SALAD, KNConsumables.WARPED_SALAD)
   );
   public static final Supplier<class_1792> SOUL_STRIDER_KABOB = register(
      "soul_strider_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.SOUL_STRIDER_KABOB, KNConsumables.SOUL_STRIDER_KABOB)
   );
   public static final Supplier<class_1792> GOLDEN_KABOB = register(
      "golden_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.GOLDEN_KABOB, KNConsumables.GOLDEN_KABOB)
   );
   public static final Supplier<class_1792> BLAZING_KABOB = register(
      "blazing_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.BLAZING_KABOB, KNConsumables.BLAZING_KABOB)
   );
   public static final Supplier<class_1792> CRIMSON_KABOB = register(
      "crimson_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.CRIMSON_KABOB, KNConsumables.CRIMSON_KABOB)
   );
   public static final Supplier<class_1792> WARPED_KABOB = register(
      "warped_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.WARPED_KABOB, KNConsumables.WARPED_KABOB)
   );
   public static final Supplier<class_1792> STAR_GHAST_PASTA = register(
      "star_ghast_pasta", properties -> new BowlFoodOnlyItem(properties, KNFoods.STAR_GHAST_PASTA, KNConsumables.STAR_GHAST_PASTA)
   );
   public static final Supplier<class_1792> STAR_STEW_MEAT = register(
      "star_stew_meat", properties -> new BowlFoodOnlyItem(properties, KNFoods.STAR_STEW_MEAT, KNConsumables.STAR_STEW_MEAT)
   );
   public static final Supplier<class_1792> GLOWING_SOUP = register(
      "glowing_soup", properties -> new BowlFoodOnlyItem(properties, KNFoods.GLOWING_SOUP, KNConsumables.GLOWING_SOUP)
   );
   public static final Supplier<class_1792> GLOWING_PUDDING = register(
      "glowing_pudding", properties -> new BowlFoodOnlyItem(properties, KNFoods.GLOWING_PUDDING, KNConsumables.GLOWING_PUDDING)
   );
   public static final Supplier<class_1792> GLOWING_KABOB = register(
      "glowing_kabob", properties -> new StickReturnFoodItem(properties, KNFoods.GLOWING_KABOB, KNConsumables.GLOWING_KABOB)
   );
   public static final Supplier<class_1792> GLOWING_SALAD = register(
      "glowing_salad", properties -> new BowlFoodOnlyItem(properties, KNFoods.GLOWING_SALAD, KNConsumables.GLOWING_SALAD)
   );
   public static final Supplier<class_1792> BLACK_APPLE_SALAD = register(
      "black_apple_salad", properties -> new BowlFoodOnlyItem(properties, KNFoods.BLACK_APPLE_SALAD, KNConsumables.BLACK_APPLE_SALAD)
   );
   public static final Supplier<class_1792> RUBY_STEAK = register(
      "ruby_steak", properties -> new BowlFoodOnlyItem(properties, KNFoods.RUBY_STEAK, KNConsumables.RUBY_STEAK)
   );
   public static final Supplier<class_1792> NETHER_REED_STEW = register(
      "nether_reed_stew", properties -> new BowlFoodOnlyItem(properties, KNFoods.NETHER_REED_STEW, KNConsumables.NETHER_REED_STEW)
   );
   public static final Supplier<class_1792> MAGMA_CREAM_STIR_FRY = register(
      "magma_cream_stir_fry", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAGMA_CREAM_STIR_FRY, KNConsumables.MAGMA_CREAM_STIR_FRY)
   );
   public static final Supplier<class_1792> MAGMA_CREAM_STIR_FRY_RICE = register(
      "magma_cream_stir_fry_rice", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAGMA_CREAM_STIR_FRY_RICE, KNConsumables.MAGMA_CREAM_STIR_FRY_RICE)
   );
   public static final Supplier<class_1792> MAPO_TOFU = register(
      "mapo_tofu", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAPO_TOFU, KNConsumables.MAPO_TOFU)
   );
   public static final Supplier<class_1792> MAPO_TOFU_RICE = register(
      "mapo_tofu_rice", properties -> new BowlFoodOnlyItem(properties, KNFoods.MAPO_TOFU_RICE, KNConsumables.MAPO_TOFU_RICE)
   );
   public static final Supplier<class_1792> WARPED_CAKE = register(
      "warped_cake", properties -> new FoodWithEffectsItem(properties, KNFoods.WARPED_CAKE, KNConsumables.WARPED_CAKE)
   );
   public static final Supplier<class_1792> CHONGQING_NOODLES = register(
      "chongqing_noodles", properties -> new BowlFoodOnlyItem(properties, KNFoods.CHONGQING_NOODLES, KNConsumables.CHONGQING_NOODLES)
   );
   public static final Supplier<class_1792> LUOSIFEN = register(
      "luosifen", properties -> new BowlFoodOnlyItem(properties, KNFoods.LUOSIFEN, KNConsumables.LUOSIFEN)
   );
   public static final Supplier<class_1792> SOUL_STIR_FRY_MEAT = register(
      "soul_stir_fry_meat", properties -> new BowlFoodOnlyItem(properties, KNFoods.SOUL_STIR_FRY_MEAT, KNConsumables.SOUL_STIR_FRY_MEAT)
   );
   public static final Supplier<class_1792> SOUL_STIR_FRY_MEAT_RICE = register(
      "soul_stir_fry_meat_rice", properties -> new BowlFoodOnlyItem(properties, KNFoods.SOUL_STIR_FRY_MEAT_RICE, KNConsumables.SOUL_STIR_FRY_MEAT_RICE)
   );
   public static final Supplier<class_1792> CARAMEL_NETHER_CATERPILLAR = register(
      "caramel_nether_caterpillar",
      properties -> new BowlFoodOnlyItem(properties, KNFoods.CARAMEL_NETHER_CATERPILLAR, KNConsumables.CARAMEL_NETHER_CATERPILLAR)
   );
   public static final Supplier<class_1792> CARAMEL_NETHER_CATERPILLAR_RICE = register(
      "caramel_nether_caterpillar_rice",
      properties -> new BowlFoodOnlyItem(properties, KNFoods.CARAMEL_NETHER_CATERPILLAR_RICE, KNConsumables.CARAMEL_NETHER_CATERPILLAR_RICE)
   );
   public static final Supplier<class_1792> RAW_PIGLIN_MEAT = register(
      "raw_piglin_meat", properties -> new class_1792(properties.method_62833(KNFoods.RAW_PIGLIN_MEAT, KNConsumables.RAW_PIGLIN_MEAT))
   );
   public static final Supplier<class_1792> COOKED_PIGLIN_MEAT = register(
      "cooked_piglin_meat", properties -> new class_1792(properties.method_62833(KNFoods.COOKED_PIGLIN_MEAT, KNConsumables.COOKED_PIGLIN_MEAT))
   );
   public static final Supplier<class_1792> WARPED_HOGLIN_TENDERLOIN_STEW = register(
      "warped_hoglin_tenderloin_stew",
      properties -> new BowlFoodOnlyItem(properties, KNFoods.WARPED_HOGLIN_TENDERLOIN_STEW, KNConsumables.WARPED_HOGLIN_TENDERLOIN_STEW)
   );
   public static final Supplier<class_1792> SPICY_HOGLIN_RAMEN = register(
      "spicy_hoglin_ramen", properties -> new BowlFoodOnlyItem(properties, KNFoods.SPICY_HOGLIN_RAMEN, KNConsumables.SPICY_HOGLIN_RAMEN)
   );
   public static final Supplier<class_1792> SPICY_POT = register(
      "spicy_pot", properties -> new BowlFoodOnlyItem(properties, KNFoods.SPICY_POT, KNConsumables.SPICY_POT)
   );
   public static final Supplier<class_1792> SPICY_POT_RICE = register(
      "spicy_pot_rice", properties -> new BowlFoodOnlyItem(properties, KNFoods.SPICY_POT_RICE, KNConsumables.SPICY_POT_RICE)
   );
   public static final Supplier<class_1792> FORGETFULNESS_SOUP = register(
      "forgetfulness_soup", properties -> new ForgetfulnessSoupItem(properties, KNFoods.FORGETFULNESS_SOUP, KNConsumables.FORGETFULNESS_SOUP)
   );
   public static final Supplier<class_1792> GARLIC_OYSTERS = register(
      "garlic_oysters", properties -> new BowlFoodOnlyItem(properties, KNFoods.GARLIC_OYSTERS, KNConsumables.GARLIC_OYSTERS)
   );
   public static final Supplier<class_1792> COUPLES_LUNG_SLICE = register(
      "couples_lung_slice", properties -> new BowlFoodOnlyItem(properties, KNFoods.COUPLES_LUNG_SLICE, KNConsumables.COUPLES_LUNG_SLICE)
   );
   public static final Supplier<class_1792> PEPPER_PORK_BELLY_CHICKEN_SOUP = register(
      "pepper_pork_belly_chicken_soup",
      properties -> new BowlFoodOnlyItem(properties, KNFoods.PEPPER_PORK_BELLY_CHICKEN_SOUP, KNConsumables.PEPPER_PORK_BELLY_CHICKEN_SOUP)
   );

   private static <T extends class_1792> Supplier<T> register(String name, Function<class_1793, T> factory) {
      return register(name, factory, new class_1793());
   }

   private static <T extends class_1792> Supplier<T> register(String name, Function<class_1793, T> factory, class_1793 properties) {
      class_5321<class_1792> resourceKey = class_5321.method_29179(class_7924.field_41197, KaleidoscopeNether.id(name));
      T item = (T)factory.apply(properties.method_63686(resourceKey));
      if (item instanceof class_1747 blockItem) {
         blockItem.method_7713(class_1792.field_8003, item);
      }

      class_2378.method_39197(class_7923.field_41178, resourceKey, item);
      return () -> item;
   }

   public static void registerItems() {
   }
}
