package com.bmt.kaleidoscope_nether.init;

import net.minecraft.class_1935;
import net.minecraft.class_3962;

public final class KNComposterRegistry {
   public static void register() {
      class_3962.field_17566.put((class_1935)KNItems.CRIMSON_FRUIT.get(), 0.65F);
      class_3962.field_17566.put((class_1935)KNItems.WARPED_FRUIT.get(), 0.65F);
      class_3962.field_17566.put((class_1935)KNItems.POISONOUS_FRUIT.get(), 0.65F);
      class_3962.field_17566.put((class_1935)KNItems.SOUL_PEPPER.get(), 0.65F);
      class_3962.field_17566.put((class_1935)KNItems.WARPED_CAKE.get(), 1.0F);
      class_3962.field_17566.put((class_1935)KNItems.NETHER_CATERPILLAR.get(), 1.0F);
   }
}
