package com.bmt.kaleidoscope_nether.init;

import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class KNEnchantments {
   public static final class_5321<class_1887> LAVA_WALKER = class_5321.method_29179(
      class_7924.field_41265, class_2960.method_60655("kaleidoscope_nether", "lava_walker")
   );
}
